# Celestial — Fabric 1.21.11

Полный клиентский порт Celestial с Minecraft 1.12.2 на Fabric 1.21.11. Исходный код не обфусцирован, а проект подготовлен для сборки через Gradle.

## Целевая среда

- Minecraft `1.21.11`
- Fabric Loader `0.19.3`
- Fabric API `0.141.6+1.21.11`
- Yarn `1.21.11+build.6`
- Java `21`
- Loom Remap `1.17.19`

## Сборка

Требуется JDK 21. При первой сборке Gradle загрузит Minecraft, Yarn, Fabric API и остальные зависимости из репозиториев, указанных в `build.gradle`.

```powershell
$env:JAVA_HOME = 'C:\path\to\jdk-21'
.\gradlew.bat clean build
```

На Linux/macOS:

```bash
chmod +x gradlew
./gradlew clean build
```

Готовый мод появляется в `build/libs/celestial-port-0.1.0.jar`. Установите профиль Fabric Loader `0.19.3` для Minecraft 1.21.11, затем положите `celestial-port-0.1.0.jar` и Fabric API `0.141.6+1.21.11` в папку `mods` этой клиентской установки.

Меню открывается клавишей `Right Shift`. В нём:

- ЛКМ включает модуль;
- ПКМ раскрывает настройки;
- средняя кнопка назначает bind;
- колесо прокручивает список;
- текстовые, цветовые и клавишные настройки редактируются прямо в меню.

## Структура

- `src/main/java` — компилируемый Fabric-порт;
- `src/main/resources` — metadata и обязательные ресурсы Celestial;
- `libs` — локальные зависимости Baritone API и Nether Pathfinder;
- `gradle` и `gradlew*` — Gradle Wrapper.

Лицензии и notices локальных сторонних зависимостей находятся в `src/main/resources/META-INF/licenses`.

## Запуск

После сборки установите Fabric Loader `0.19.3` для Minecraft `1.21.11`, положите `celestial-port-0.1.0.jar` и Fabric API `0.141.6+1.21.11` в папку `mods`, затем запустите игру. Runtime-конфиги создаются самой игрой и в архив исходников не входят.
