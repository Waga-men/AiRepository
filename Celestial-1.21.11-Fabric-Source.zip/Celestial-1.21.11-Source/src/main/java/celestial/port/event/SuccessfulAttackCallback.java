package celestial.port.event;

import net.fabricmc.fabric.api.event.Event;
import net.fabricmc.fabric.api.event.EventFactory;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

@FunctionalInterface
public interface SuccessfulAttackCallback {
    Event<SuccessfulAttackCallback> EVENT = EventFactory.createArrayBacked(
            SuccessfulAttackCallback.class,
            listeners -> (attacker, target) -> {
                for (SuccessfulAttackCallback listener : listeners) {
                    listener.onSuccessfulAttack(attacker, target);
                }
            }
    );

    void onSuccessfulAttack(PlayerEntity attacker, Entity target);
}
