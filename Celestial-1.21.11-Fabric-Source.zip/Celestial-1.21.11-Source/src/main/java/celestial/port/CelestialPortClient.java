package celestial.port;

import celestial.port.client.command.LegacyCommandBootstrap;
import celestial.port.client.ui.CelestialHud;
import celestial.port.client.ui.ClientFeedback;
import celestial.port.client.ui.ConfigProfiles;
import celestial.port.client.ui.CelestialScreen;
import celestial.port.core.Module;
import celestial.port.core.ModuleManager;
import celestial.port.core.config.ConfigManager;
import celestial.port.core.macro.MacroManager;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.staff.ManualStaffRegistry;
import celestial.port.modules.combat.*;
import celestial.port.modules.impl.*;
import celestial.port.modules.inventory.*;
import celestial.port.modules.legacyutility.*;
import celestial.port.modules.movement.*;
import celestial.port.modules.player.*;
import celestial.port.modules.render.*;
import celestial.port.modules.rendering.*;
import celestial.port.modules.utility.*;
import celestial.port.modules.visual.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.HashSet;
import java.util.Set;

public final class CelestialPortClient implements ClientModInitializer {
    public static final String MOD_ID = "celestial";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    public static final ModuleManager MODULES = new ModuleManager();

    private static final Set<Integer> PRESSED_MODULE_KEYS = new HashSet<>();
    private static ConfigManager config;

    @Override
    public void onInitializeClient() {
        registerModules();
        config = new ConfigManager(MODULES);
        loadConfig();
        ClientFeedback.initialize();
        MacroManager.initialize();
        ManualStaffRegistry.initialize();
        LegacyCommandBootstrap.install();

        ClientTickEvents.END_CLIENT_TICK.register(this::onEndTick);
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> saveConfig());
        HudElementRegistry.addLast(Identifier.of(MOD_ID, "client_hud"),
                (context, tickCounter) -> CelestialHud.render(context, MODULES));

        LOGGER.info("Celestial Fabric port initialized for Minecraft 1.21.11 with {} registered modules",
                MODULES.modules().size());
    }

    private static void registerModules() {

        MODULES.register(new AttackAuraModule());
        MODULES.register(new ShieldBreakerModule());
        MODULES.register(new ItemsCooldownModule());
        MODULES.register(new ItemsFixModule());
        MODULES.register(new AutoExplosionModule());
        MODULES.register(new AutoTotem());
        MODULES.register(new AutoPotionModule());
        MODULES.register(new AutoGAppleModule());
        MODULES.register(new VelocityModule());
        MODULES.register(new HitBoxModule());
        MODULES.register(new ReachModule());
        MODULES.register(new BowSpamModule());
        MODULES.register(new NoFriendsModule());
        MODULES.register(new TriggerBot());
        MODULES.register(new HitSoundsModule());
        MODULES.register(new BackTrackModule());
        MODULES.register(new AutoSwapModule());
        MODULES.register(new TargetStrafeModule());
        MODULES.register(new SuperBowModule());

        MODULES.register(new AutoSprint());
        MODULES.register(new Flight());
        MODULES.register(new NoSlow());
        MODULES.register(new Strafe());
        MODULES.register(new LongJump());
        MODULES.register(new Jesus());
        MODULES.register(new Spider());
        MODULES.register(new Speed());
        MODULES.register(new WaterSpeed());
        MODULES.register(new AirJump());
        MODULES.register(new AntiWeb());
        MODULES.register(new TimerModule());
        MODULES.register(new DamageSpeed());
        MODULES.register(new WebLeave());
        MODULES.register(new ElytraFlight());

        MODULES.register(new FreeCameraModule());
        MODULES.register(new AntiLevitation());
        MODULES.register(new NoClip());
        MODULES.register(new InventoryMove());
        MODULES.register(new ClickFriend());
        MODULES.register(new NoInteract());
        MODULES.register(new AutoTPAccept());
        MODULES.register(new AutoRespawn());
        MODULES.register(new AutoLeave());
        MODULES.register(new DeathCoords());
        MODULES.register(new NameProtectModule());
        MODULES.register(new AutoEat());
        MODULES.register(new FastBreak());
        MODULES.register(new KTLeave());
        MODULES.register(new AutoArmor());
        MODULES.register(new Disabler());
        MODULES.register(new NoServerRotationsModule());

        MODULES.register(new ClickGuiModule());
        MODULES.register(new HudModule());
        MODULES.register(new ArrayListModule());
        MODULES.register(new NotificationsModule());
        Tracers tracers = MODULES.register(new Tracers());
        MODULES.register(new SwingAnimations());
        MODULES.register(new Prediction());
        MODULES.register(new JumpCircles());
        MODULES.register(new ChinaHat());
        ESP esp = MODULES.register(new ESP());
        NoRender noRender = MODULES.register(new NoRender());
        MODULES.register(new TimeChanger());
        MODULES.register(new ChunkAnimator());
        MODULES.register(new CustomModel());
        CustomWorld customWorld = MODULES.register(new CustomWorld());
        MODULES.register(new ShaderESP());
        BlockESP blockEsp = MODULES.register(new BlockESP());
        MODULES.register(new XRay());
        MODULES.register(new Trails());
        MODULES.register(new BlurVisuals());
        Crosshair crosshair = MODULES.register(new Crosshair());
        RotationView rotationView = MODULES.register(new RotationView());
        MODULES.register(new Particles());

        MODULES.register(new AutoBuy());
        MODULES.register(new AutoTool());
        MODULES.register(new AutoWay());
        MODULES.register(new AirDropSteal());
        MODULES.register(new GriefJoiner());
        MODULES.register(new ItemScroller());
        MODULES.register(new ClickPearl());
        MODULES.register(new celestial.port.modules.inventory.ElytraSwap());
        MODULES.register(new ClickTP());
        MODULES.register(new AntiAFK());
        MODULES.register(new FastWorld());
        MODULES.register(new MinecraftOptimizer());
        MODULES.register(new StaffStatistics());
        MODULES.register(new BaritoneBridge());
        MODULES.register(new ElytraFix());
        MODULES.register(new AutoFish());
        MODULES.register(new ClientSounds());
        MODULES.register(new RWHelper());

        RenderingCallbacks.register(crosshair, tracers, esp, blockEsp, noRender, customWorld, rotationView);
        VisualCallbacks.register(MODULES);
    }

    private void onEndTick(MinecraftClient client) {
        pollModuleKeys(client);
        MODULES.tick();
    }

    private static void pollModuleKeys(MinecraftClient client) {
        Set<Integer> currentlyPressed = new HashSet<>();
        for (Module module : MODULES.modules()) {
            int key = module.key();
            if (BindSetting.isPressed(client.getWindow().getHandle(), key)) {
                currentlyPressed.add(key);
            }
        }

        if (client.currentScreen == null) {
            boolean changed = false;
            for (int key : currentlyPressed) {
                if (!PRESSED_MODULE_KEYS.contains(key)) {
                    changed |= MODULES.toggleByKey(key) > 0;
                }
            }
            if (changed) {
                saveConfig();
            }
        }
        PRESSED_MODULE_KEYS.clear();
        PRESSED_MODULE_KEYS.addAll(currentlyPressed);
    }

    private static void loadConfig() {
        try {
            if (!config.load()) {
                MODULES.require("hud").setEnabled(true);
                MODULES.require("array_list").setEnabled(true);
                MODULES.require("notifications").setEnabled(true);
                config.save();
            }
        } catch (IOException | RuntimeException exception) {
            LOGGER.error("Unable to load Celestial config; defaults will be used", exception);
            MODULES.find("hud").ifPresent(module -> module.setEnabled(true));
            MODULES.find("array_list").ifPresent(module -> module.setEnabled(true));
        }
    }

    public static void saveConfig() {
        if (config == null) {
            return;
        }
        try {
            config.save();
        } catch (IOException exception) {
            LOGGER.error("Unable to save Celestial config", exception);
        }
    }

    public static void openClickGui() {
        ConfigProfiles profiles = new ConfigProfiles(MODULES,
                config.configFile().getParent().resolve("profiles"));
        MinecraftClient.getInstance().setScreen(new CelestialScreen(
                MODULES, CelestialPortClient::saveConfig, profiles));
    }
}
