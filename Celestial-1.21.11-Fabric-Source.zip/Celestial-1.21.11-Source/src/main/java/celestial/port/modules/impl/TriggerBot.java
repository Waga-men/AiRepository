package celestial.port.modules.impl;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.mob.Monster;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;

import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.nio.charset.StandardCharsets;

public final class TriggerBot extends Module {
    private static final int[] RANDOM_DELAYS = {
            13, 11, 13, 12, 11, 12, 12, 12, 13, 12, 11, 12, 11, 13, 10, 12,
            13, 11, 12, 13, 12, 11, 10, 12, 12, 13, 12, 11, 12, 11, 13, 12,
            12, 13, 11, 12, 13, 11, 12, 13, 11, 12, 12, 13, 11, 10, 13, 11,
            12, 12, 12, 12, 11, 12, 12, 11, 15, 10, 13, 13, 11, 12, 11, 11,
            13, 10, 12, 12, 12, 12, 13, 10, 13, 11, 13, 9, 11, 12, 12
    };

    private final MultiSelectSetting targets = addSetting(new MultiSelectSetting(
            "targets", "Выбор целей", Set.of("Мобы"), List.of("Мобы", "Игроки")
    ));
    private final BooleanSetting onlyCriticals = addSetting(new BooleanSetting(
            "only_criticals", "Только криты", false
    ));
    private final BooleanSetting randomizeClicks = addSetting(new BooleanSetting(
            "randomize_clicks", "Рандомайз кликов", false
    ));

    private int delayTicks;
    private int randomIndex;

    public TriggerBot() {
        super("trigger_bot", "Trigger Bot",
                "Автоматически атакует цель на прицеле", Category.COMBAT);
    }

    @Override
    protected void onTick() {
        try {
            tickLegacy();
        } catch (Exception ignored) {

        }
    }

    private void tickLegacy() {
        if (delayTicks > 0) {
            delayTicks--;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        Entity target = client.targetedEntity;
        if (delayTicks != 0
                || player == null
                || client.world == null
                || client.interactionManager == null
                || !(target instanceof LivingEntity living)
                || !validTarget(player, target, living)
                || !attackReady(player)) {
            return;
        }

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
        if (randomizeClicks.enabled()) {
            if (randomIndex >= RANDOM_DELAYS.length) {
                randomIndex = 0;
            }
            delayTicks = RANDOM_DELAYS[randomIndex++];
        } else {
            delayTicks = 10;
        }
    }

    private boolean validTarget(ClientPlayerEntity player, Entity entity, LivingEntity living) {
        if (entity instanceof ArmorStandEntity
                || entity.getName().getString().equals(player.getName().getString())
                || !living.isAlive()) {
            return false;
        }
        if (entity instanceof PlayerEntity target) {
            return targets.selected("Игроки") && !legacyBot(target) && !FriendManager.isFriend(target);
        }
        if (entity instanceof Monster && !targets.selected("Мобы")) {
            return false;
        }
        return true;
    }

    private static boolean legacyBot(PlayerEntity player) {
        UUID offline = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + player.getGameProfile().name()).getBytes(StandardCharsets.UTF_8)
        );
        return !player.getUuid().equals(offline);
    }

    private boolean attackReady(ClientPlayerEntity player) {
        if (player.getAttackCooldownProgress(1.5F) < 0.93F) {
            return false;
        }
        if (!onlyCriticals.enabled()) {
            return true;
        }

        if (player.getAbilities().flying
                || player.isGliding()
                || player.isClimbing()
                || player.isSubmergedInWater()
                || isInsideCobweb(player)
                || player.hasStatusEffect(StatusEffects.LEVITATION)) {
            return true;
        }
        int truncatedY = (int) player.getY();
        int ceilingY = (int) Math.ceil(player.getY());
        if (truncatedY != ceilingY && player.isOnGround()) {
            net.minecraft.util.math.Box headBox = new net.minecraft.util.math.Box(
                    player.getX() - 0.3, player.getEyeY(), player.getZ() - 0.3,
                    player.getX() + 0.3, player.getY() + 2.5, player.getZ() + 0.3);
            if (player.getEntityWorld().getBlockCollisions(player, headBox).iterator().hasNext()) {
                return true;
            }
        }
        return !player.isOnGround() && player.fallDistance > 0.0F;
    }

    private static boolean isInsideCobweb(ClientPlayerEntity player) {
        Box box = player.getBoundingBox();
        int minimumX = MathHelper.floor(box.minX + 1.0E-6);
        int minimumY = MathHelper.floor(box.minY + 1.0E-6);
        int minimumZ = MathHelper.floor(box.minZ + 1.0E-6);
        int maximumX = MathHelper.floor(box.maxX - 1.0E-6);
        int maximumY = MathHelper.floor(box.maxY - 1.0E-6);
        int maximumZ = MathHelper.floor(box.maxZ - 1.0E-6);

        for (int x = minimumX; x <= maximumX; x++) {
            for (int y = minimumY; y <= maximumY; y++) {
                for (int z = minimumZ; z <= maximumZ; z++) {
                    if (player.getEntityWorld().getBlockState(new BlockPos(x, y, z)).isOf(Blocks.COBWEB)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
