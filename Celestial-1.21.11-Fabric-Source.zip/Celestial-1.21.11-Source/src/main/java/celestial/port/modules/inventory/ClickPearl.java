package celestial.port.modules.inventory;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.BooleanSetting;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.lwjgl.glfw.GLFW;

public final class ClickPearl extends Module {
    private static ClickPearl instance;

    private final BindSetting activationKey = addSetting(new BindSetting(
            "activation_key", "Клавиша",
            BindSetting.forMouseButton(GLFW.GLFW_MOUSE_BUTTON_MIDDLE)
    ));
    private final BooleanSetting antiBlocker = addSetting(new BooleanSetting(
            "anti_blocker", "Анти-блокер", false
    ));

    private boolean previousActivation;
    private boolean previousRightMouse;
    private boolean throwing;
    private boolean usePacketRewritten;
    private int ticks;
    private int blockerRestoreSlot = -1;
    private float serverYaw;
    private float serverPitch;

    public ClickPearl() {
        super("click_pearl", "Click Pearl",
                "Автоматически кидает эндер-пёрл нажатием на кнопку", Category.UTILITY);
        instance = this;
        UseBlockCallback.EVENT.register((player, world, hand, hit) -> {
            ClickPearl module = instance;
            if (module == null || !module.enabled() || !module.antiBlocker.enabled()
                    || !world.isClient() || player != MinecraftClient.getInstance().player
                    || !player.getStackInHand(hand).isOf(Items.ENDER_PEARL)
                    || world.getBlockState(hit.getBlockPos()).isAir()) {
                return ActionResult.PASS;
            }
            return ActionResult.FAIL;
        });
    }

    public BindSetting activationKey() {
        return activationKey;
    }

    public BooleanSetting antiBlocker() {
        return antiBlocker;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || !player.isAlive() || client.interactionManager == null
                || client.getNetworkHandler() == null) {
            resetSequence();
            return;
        }

        boolean activation = activationPressed(client);
        boolean rightMouse = GLFW.glfwGetMouseButton(client.getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        boolean directTrigger = activation && !previousActivation;
        boolean blockerTrigger = antiBlocker.enabled()
                && rightMouse && !previousRightMouse
                && player.getMainHandStack().isOf(Items.ENDER_PEARL);
        previousActivation = activation;
        previousRightMouse = rightMouse;

        if (!throwing && (directTrigger || blockerTrigger)) {
            throwing = true;
            ticks = 0;
            serverYaw = player.getYaw();
            serverPitch = player.getPitch();
            prepareAntiBlocker(client);
        }

        if (!throwing) {
            return;
        }
        ticks++;
        boolean aimedAtBlock = client.crosshairTarget instanceof BlockHitResult hit
                && !client.world.getBlockState(hit.getBlockPos()).isAir();
        if (aimedAtBlock && ticks <= 2) {
            return;
        }

        try {
            throwPearl(client);
        } finally {
            try {
                restoreBlockerSlot(client);
            } finally {
                boolean restoreRotation = usePacketRewritten;
                usePacketRewritten = false;
                throwing = false;
                ticks = 0;
                if (restoreRotation) {
                    player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                            player.getYaw(), player.getPitch(), player.isOnGround(),
                            player.horizontalCollision));
                }
            }
        }
    }

    private boolean activationPressed(MinecraftClient client) {
        if (activationKey.isBound()) {
            return BindSetting.isPressed(client.getWindow().getHandle(), activationKey.key());
        }
        return GLFW.glfwGetMouseButton(client.getWindow().getHandle(),
                GLFW.GLFW_MOUSE_BUTTON_MIDDLE) == GLFW.GLFW_PRESS;
    }

    private void prepareAntiBlocker(MinecraftClient client) {
        if (!antiBlocker.enabled()
                || !(client.crosshairTarget instanceof BlockHitResult hit)
                || client.world.getBlockState(hit.getBlockPos()).isAir()
                || !client.player.getMainHandStack().isOf(Items.ENDER_PEARL)) {
            return;
        }
        PlayerInventory inventory = client.player.getInventory();
        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            if (inventory.getStack(slot).isOf(Items.ENDER_PEARL)) {
                continue;
            }
            blockerRestoreSlot = inventory.getSelectedSlot();
            client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
            break;
        }
    }

    private void throwPearl(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player.getItemCooldownManager().isCoolingDown(new ItemStack(Items.ENDER_PEARL))) {
            return;
        }
        if (player.getOffHandStack().isOf(Items.ENDER_PEARL)) {
            use(client, Hand.OFF_HAND);
            return;
        }

        PlayerInventory inventory = player.getInventory();
        int hotbarPearl = InventoryActions.findHotbar(inventory,
                stack -> stack.isOf(Items.ENDER_PEARL));
        if (hotbarPearl != PlayerInventory.NOT_FOUND) {
            int original = inventory.getSelectedSlot();
            inventory.setSelectedSlot(hotbarPearl);
            client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(hotbarPearl));
            use(client, Hand.MAIN_HAND);
            inventory.setSelectedSlot(original);
            client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(original));
            return;
        }

        int inventoryPearl = InventoryActions.findMainInventory(inventory,
                stack -> stack.isOf(Items.ENDER_PEARL));
        int selected = inventory.getSelectedSlot();
        if (inventoryPearl != PlayerInventory.NOT_FOUND
                && InventoryActions.swapInventorySlots(client, inventoryPearl, selected)) {
            use(client, Hand.MAIN_HAND);
            InventoryActions.swapInventorySlots(client, inventoryPearl, selected);
        }
    }

    private static void use(MinecraftClient client, Hand hand) {
        ActionResult result = client.interactionManager.interactItem(client.player, hand);
        if (result.isAccepted()) {
            client.player.swingHand(hand);
        }
    }

    private void restoreBlockerSlot(MinecraftClient client) {
        if (blockerRestoreSlot < 0 || client.getNetworkHandler() == null) {
            blockerRestoreSlot = -1;
            return;
        }
        client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(blockerRestoreSlot));
        blockerRestoreSlot = -1;
    }

    public static boolean ownsMovementRotation(ClientPlayerEntity player) {
        ClickPearl module = instance;
        return module != null && module.enabled() && module.throwing
                && player != null && MinecraftClient.getInstance().player == player;
    }

    public static Packet<?> rewriteMovementPacket(Packet<?> packet) {
        ClickPearl module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || !module.throwing
                || client.player == null) {
            return packet;
        }
        if (packet instanceof PlayerInteractItemC2SPacket usePacket) {
            module.usePacketRewritten = true;
            return new PlayerInteractItemC2SPacket(
                    usePacket.getHand(), usePacket.getSequence(),
                    module.serverYaw, module.serverPitch);
        }
        if (!(packet instanceof PlayerMoveC2SPacket movement)) {
            return packet;
        }
        ClientPlayerEntity player = client.player;
        boolean horizontalCollision = movement.horizontalCollision();
        if (movement.changesPosition()) {
            return new PlayerMoveC2SPacket.Full(
                    movement.getX(player.getX()), movement.getY(player.getY()),
                    movement.getZ(player.getZ()), module.serverYaw, module.serverPitch,
                    movement.isOnGround(), horizontalCollision);
        }
        return new PlayerMoveC2SPacket.LookAndOnGround(
                module.serverYaw, module.serverPitch,
                movement.isOnGround(), horizontalCollision);
    }

    private void resetSequence() {
        MinecraftClient client = MinecraftClient.getInstance();
        try {
            restoreBlockerSlot(client);
        } finally {
            throwing = false;
            usePacketRewritten = false;
            ticks = 0;
            previousActivation = false;
            previousRightMouse = false;
        }
    }

    @Override
    protected void onDisable() {
        resetSequence();
    }
}
