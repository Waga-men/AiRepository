package celestial.port.modules.inventory;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.equipment.ArmorMaterial;
import net.minecraft.item.equipment.ArmorMaterials;
import net.minecraft.item.equipment.EquipmentAssetKeys;
import net.minecraft.item.equipment.EquipmentType;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.OptionalInt;

public final class AutoArmor extends Module {
    private static final List<EquipmentSlot> ARMOR_SLOTS = List.of(
            EquipmentSlot.FEET, EquipmentSlot.LEGS,
            EquipmentSlot.CHEST, EquipmentSlot.HEAD
    );

    private final BooleanSetting withoutMovement = addSetting(new BooleanSetting(
            "without_movement", "Без движения", false
    ));
    private final NumberSetting delay = addSetting(new NumberSetting(
            "delay", "Задержка", 1.0, 0.0, 10.0, 0.5
    ));

    private long lastActionNanos = System.nanoTime();

    public AutoArmor() {
        super("auto_armor", "AutoArmor",
                "Автоматически надевает броню", Category.PLAYER);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!canClickPlayerInventory(client)) {
            return;
        }
        if (withoutMovement.enabled()
                && (client.player.forwardSpeed != 0.0F || client.player.sidewaysSpeed != 0.0F)) {
            return;
        }

        PlayerInventory inventory = client.player.getInventory();
        int[] bestSlot = {-1, -1, -1, -1};
        double[] bestScore = new double[4];
        for (int armorIndex = 0; armorIndex < ARMOR_SLOTS.size(); armorIndex++) {
            EquipmentSlot slot = ARMOR_SLOTS.get(armorIndex);
            ItemStack equipped = client.player.getEquippedStack(slot);
            double score = legacyArmorScore(client.player, equipped, slot);
            bestScore[armorIndex] = Double.isFinite(score) ? score : 0.0;
        }

        for (int inventorySlot = 0; inventorySlot < PlayerInventory.MAIN_SIZE; inventorySlot++) {
            ItemStack candidate = inventory.getStack(inventorySlot);
            for (int armorIndex = 0; armorIndex < ARMOR_SLOTS.size(); armorIndex++) {
                EquipmentSlot equipmentSlot = ARMOR_SLOTS.get(armorIndex);
                double score = legacyArmorScore(client.player, candidate, equipmentSlot);
                if (score > bestScore[armorIndex]) {
                    bestScore[armorIndex] = score;
                    bestSlot[armorIndex] = inventorySlot;
                }
            }
        }

        List<Integer> order = new ArrayList<>(List.of(0, 1, 2, 3));
        Collections.shuffle(order);
        for (int armorIndex : order) {
            int candidate = bestSlot[armorIndex];
            if (candidate < 0) {
                continue;
            }
            EquipmentSlot equipmentSlot = ARMOR_SLOTS.get(armorIndex);
            ItemStack equipped = client.player.getEquippedStack(equipmentSlot);
            if (!equipped.isEmpty() && !hasEmptyMainSlot(inventory)) {
                continue;
            }
            long delayNanos = Math.round(delay.value() * 100_000_000.0);
            long now = System.nanoTime();
            if (now - lastActionNanos <= delayNanos) {
                return;
            }

            if (!equipped.isEmpty()) {
                int equipmentIndex = InventoryActions.equipmentInventoryIndex(equipmentSlot);
                if (!quickMoveInventorySlot(client, equipmentIndex)) {
                    lastActionNanos = now;
                    return;
                }
            }
            quickMoveInventorySlot(client, candidate);
            lastActionNanos = now;
            return;
        }
    }

    private static boolean canClickPlayerInventory(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        return player != null
                && player.isAlive()
                && client.interactionManager != null
                && client.getNetworkHandler() != null
                && player.currentScreenHandler == player.playerScreenHandler;
    }

    private static boolean quickMoveInventorySlot(MinecraftClient client, int inventoryIndex) {
        if (!canClickPlayerInventory(client)) {
            return false;
        }
        ClientPlayerEntity player = client.player;
        ScreenHandler handler = player.playerScreenHandler;
        OptionalInt slotId = handler.getSlotIndex(player.getInventory(), inventoryIndex);
        if (slotId.isEmpty()) {
            return false;
        }
        Slot slot = handler.getSlot(slotId.getAsInt());
        if (!slot.hasStack() || !slot.canTakeItems(player)) {
            return false;
        }
        client.interactionManager.clickSlot(
                handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, player);
        return true;
    }

    private static boolean hasEmptyMainSlot(PlayerInventory inventory) {
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (inventory.getStack(slot).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private static double legacyArmorScore(
            ClientPlayerEntity player, ItemStack stack, EquipmentSlot slot
    ) {
        if (stack.isEmpty()) {
            return Double.NEGATIVE_INFINITY;
        }

        EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        if (equippable == null || equippable.slot() != slot) {
            return Double.NEGATIVE_INFINITY;
        }

        EquipmentType equipmentType = equipmentType(slot);
        if (equipmentType == null) {
            return Double.NEGATIVE_INFINITY;
        }

        ArmorMaterial material = armorMaterial(equippable);
        double baseArmor;
        double toughness;
        int leggingsMaterialBonus;
        if (material != null) {
            baseArmor = material.defense().getOrDefault(equipmentType, 0);
            toughness = material.toughness();
            leggingsMaterialBonus = material.defense().getOrDefault(EquipmentType.LEGGINGS, 0);
        } else {
            AttributeModifiersComponent modifiers = stack.getOrDefault(
                    DataComponentTypes.ATTRIBUTE_MODIFIERS,
                    AttributeModifiersComponent.DEFAULT
            );
            baseArmor = modifiers.applyOperations(EntityAttributes.ARMOR, 0.0, slot);
            toughness = modifiers.applyOperations(EntityAttributes.ARMOR_TOUGHNESS, 0.0, slot);
            leggingsMaterialBonus = 0;
        }
        if (baseArmor <= 0.0 && toughness <= 0.0) {
            return Double.NEGATIVE_INFINITY;
        }

        var enchantments = player.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        int protection = EnchantmentHelper.getLevel(
                enchantments.getOrThrow(Enchantments.PROTECTION), stack);
        return baseArmor * 5.0
                + protection * 3.0
                + (int) toughness
                + leggingsMaterialBonus;
    }

    private static EquipmentType equipmentType(EquipmentSlot slot) {
        return switch (slot) {
            case FEET -> EquipmentType.BOOTS;
            case LEGS -> EquipmentType.LEGGINGS;
            case CHEST -> EquipmentType.CHESTPLATE;
            case HEAD -> EquipmentType.HELMET;
            default -> null;
        };
    }

    private static ArmorMaterial armorMaterial(EquippableComponent equippable) {
        RegistryKey<?> asset = equippable.assetId().orElse(null);
        if (EquipmentAssetKeys.LEATHER.equals(asset)) return ArmorMaterials.LEATHER;
        if (EquipmentAssetKeys.COPPER.equals(asset)) return ArmorMaterials.COPPER;
        if (EquipmentAssetKeys.CHAINMAIL.equals(asset)) return ArmorMaterials.CHAIN;
        if (EquipmentAssetKeys.IRON.equals(asset)) return ArmorMaterials.IRON;
        if (EquipmentAssetKeys.GOLD.equals(asset)) return ArmorMaterials.GOLD;
        if (EquipmentAssetKeys.DIAMOND.equals(asset)) return ArmorMaterials.DIAMOND;
        if (EquipmentAssetKeys.TURTLE_SCUTE.equals(asset)) return ArmorMaterials.TURTLE_SCUTE;
        if (EquipmentAssetKeys.NETHERITE.equals(asset)) return ArmorMaterials.NETHERITE;
        return null;
    }
}
