package celestial.port.modules.visual;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.minecraft.block.AirBlock;
import net.minecraft.block.Block;
import net.minecraft.block.ButtonBlock;
import net.minecraft.block.CarpetBlock;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.PlantBlock;
import net.minecraft.block.SlabBlock;
import net.minecraft.block.SnowBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import org.joml.Quaternionf;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class Particles extends Module implements WorldVisual {
    private static final String ORBS = "Орбизы";
    private static final String CRITS = "Криты";
    private static final String BOTH = "Криты + Орбизы";
    private static final Random RANDOM = new Random();
    private static volatile Particles instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", ORBS, List.of(ORBS, CRITS, BOTH)
    ));
    private final NumberSetting critCount = addSetting(new NumberSetting(
            "crit_count", "Количество критов", 32.0, 8.0, 64.0, 8.0
    ).visibleWhen(() -> mode.value().contains(CRITS)));
    private final NumberSetting critSpeed = addSetting(new NumberSetting(
            "crit_speed", "Скорость критов", 0.3, 0.1, 1.0, 0.01
    ).visibleWhen(() -> mode.value().contains(CRITS)));

    private final List<Orb> orbs = new ArrayList<>(200);

    private long previousFrameTime;

    public Particles() {
        super("particles", "Particles", "Изменяет и добавляет частицы при ударе", Category.RENDER);
        instance = this;
    }

    public ModeSetting mode() {
        return mode;
    }

    public NumberSetting critCount() {
        return critCount;
    }

    public NumberSetting critSpeed() {
        return critSpeed;
    }

    void onAttack(Entity target) {
        if (!mode.value().contains(ORBS) || !(target instanceof LivingEntity living)) {
            return;
        }
        long now = Util.getMeasuringTimeMs();
        for (int index = 0; index < 20; index++) {
            Vec3d position = new Vec3d(
                    living.getX() + (RANDOM.nextFloat() - 0.5F) * 0.5F,
                    living.getY() + RANDOM.nextFloat() + 0.1F,
                    living.getZ() + (RANDOM.nextFloat() - 0.5F) * 0.5F
            );
            float angle = (float) (RANDOM.nextFloat() * Math.PI * 2.0);
            float velocityX = (float) ((double) 0.1F * Math.sin(angle) * (double) 0.03F);
            float velocityZ = (float) ((double) 0.1F * Math.cos(angle) * (double) 0.03F);
            Vec3d velocity = new Vec3d(
                    velocityX,
                    0.0,
                    velocityZ
            );
            if (orbs.size() >= 200) {
                orbs.removeFirst();
            }
            orbs.add(new Orb(position, velocity, clientColor(index * 10.0F), now));
        }
    }

    public static boolean replaceCritParticles(Entity target) {
        return false;
    }

    public static boolean customCritsActive() {
        Particles module = instance;
        return module != null && module.enabled() && module.mode.value().contains(CRITS);
    }

    public static int critEmitterCount(int vanillaCount) {
        Particles module = instance;
        return module != null && module.enabled() && module.mode.value().contains(CRITS)
                ? module.critCount.value().intValue()
                : vanillaCount;
    }

    public static float critParticleSpeed() {
        Particles module = instance;
        return module != null ? module.critSpeed.value().floatValue() : 1.0F;
    }

    @Override
    public void collectVisuals(WorldExtractionContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientWorld world = client.world;
        long now = Util.getMeasuringTimeMs();
        double deltaMillis = previousFrameTime == 0L
                ? Math.max(0, (int) (context.tickCounter().getFixedDeltaTicks() * 50.0F))
                : Math.max(0L, now - previousFrameTime);
        previousFrameTime = now;
        if (world == null || client.player == null || context.world() != world
                || !mode.value().contains(ORBS) || orbs.isEmpty()) {
            return;
        }

        for (Orb orb : orbs) {
            updateOrb(world, orb, deltaMillis);
        }
        orbs.removeIf(orb -> client.player.squaredDistanceTo(orb.position) > 100.0
                || now - orb.createdAt > 30_000L);

        Quaternionf cameraRotation = new Quaternionf(context.camera().getRotation());
        Vector3f rightVector = cameraRotation.transform(new Vector3f(1.0F, 0.0F, 0.0F));
        Vector3f upVector = cameraRotation.transform(new Vector3f(0.0F, 1.0F, 0.0F));
        Vec3d right = new Vec3d(rightVector.x, rightVector.y, rightVector.z);
        Vec3d up = new Vec3d(upVector.x, upVector.y, upVector.z);

        List<Fan> fans = new ArrayList<>();
        int renderIndex = 0;
        for (Orb orb : orbs) {
            renderIndex++;
            double distanceSquared = client.player.squaredDistanceTo(
                    orb.position.x, orb.position.y - 1.0, orb.position.z);
            int angularStep = Math.min(350, (int) (distanceSquared * 2.0 + 15.0));

            if (renderIndex % 10 != 0 && distanceSquared > 250.0
                    || renderIndex % 3 == 0 && distanceSquared > 150.0) {
                continue;
            }

            addFan(fans, orb.position, right, up, 0.7F, angularStep,
                    rawAlpha(orb.color, 255));
            addFan(fans, orb.position, right, up, 1.5F, angularStep,
                    rawAlpha(orb.color, 30));
            if (distanceSquared < 20.0) {
                addFan(fans, orb.position, right, up, 2.0F, angularStep,
                        rawAlpha(orb.color, 30));
            }
        }

        if (!fans.isEmpty()) {

            GizmoDrawing.collect((drawer, delta) -> {
                for (Fan fan : fans) {
                    drawer.addPolygon(fan.vertices, fan.color);
                }
            });
        }
    }

    private static void updateOrb(ClientWorld world, Orb orb, double deltaMillis) {
        Vec3d previous = orb.position;
        orb.position = orb.position.add(orb.velocity.multiply(deltaMillis));
        orb.velocity = new Vec3d(
                orb.velocity.x / 0.999998F,
                orb.velocity.y - 1.5E-6F,
                orb.velocity.z / 0.999998F
        );

        BlockPos blockPos = BlockPos.ofFloored(orb.position);
        Block block = world.getBlockState(blockPos).getBlock();
        boolean legacyPassThrough = block instanceof AirBlock
                || block instanceof PlantBlock
                || block instanceof FluidBlock
                || block instanceof SnowBlock
                || block instanceof FallingBlock
                || block instanceof ButtonBlock
                || block instanceof SlabBlock
                || block instanceof CarpetBlock;
        if (!legacyPassThrough) {

            orb.position = previous;
            double localX = previous.x - Math.floor(previous.x);
            double localY = previous.y - Math.floor(previous.y);
            double localZ = previous.z - Math.floor(previous.z);
            Vec3d normal = new Vec3d(
                    localX < 0.1 ? -1.0 : localX > 0.9 ? 1.0 : 0.0,
                    localY < 0.1 ? -1.0 : localY > 0.9 ? 1.0 : 0.0,
                    localZ < 0.1 ? -1.0 : localZ > 0.9 ? 1.0 : 0.0
            );
            double dot = orb.velocity.dotProduct(normal);
            orb.velocity = orb.velocity.subtract(normal.multiply(2.0 * dot));
        }
    }

    private static void addFan(
            List<Fan> fans, Vec3d center, Vec3d right, Vec3d up,
            float radius, int angularStep, int color
    ) {
        int vertexCount = (int) Math.floor(360.0F / angularStep) + 1;
        if (vertexCount < 3) {
            return;
        }
        Vec3d[] vertices = new Vec3d[vertexCount];
        for (int index = 0; index < vertexCount; index++) {
            double angle = Math.toRadians(index * angularStep);
            double localX = Math.cos(angle) * radius;
            double localY = -3.0 + Math.sin(angle) * radius;

            vertices[index] = center
                    .add(right.multiply(-0.04 * localX))
                    .add(up.multiply(-0.04 * localY));
        }
        fans.add(new Fan(vertices, color));
    }

    @Override
    protected void onDisable() {
        if (mode.value().contains(ORBS)) {
            orbs.clear();
        }
        previousFrameTime = 0L;
    }

    private static int clientColor(float offset) {
        return VisualColors.clientColor((int) offset);
    }

    private static int rawAlpha(int color, int alpha) {

        return (alpha & 255) << 24 | color & 0xFFFFFF;
    }

    private record Fan(Vec3d[] vertices, int color) {
    }

    private static final class Orb {
        private Vec3d position;
        private Vec3d velocity;
        private final int color;
        private final long createdAt;

        private Orb(Vec3d position, Vec3d velocity, int color, long createdAt) {
            this.position = position;
            this.velocity = velocity;
            this.color = color;
            this.createdAt = createdAt;
        }
    }
}
