package celestial.port.modules.inventory;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.OptionalInt;

public final class OffhandTransactions {
    private OffhandTransactions() {
    }

    public static boolean canUsePlayerHandler(MinecraftClient client, boolean emptyCursorRequired) {
        ClientPlayerEntity player = client.player;
        if (player == null
                || !player.isAlive()
                || client.interactionManager == null
                || client.getNetworkHandler() == null
                || client.currentScreen instanceof CreativeInventoryScreen
                || player.currentScreenHandler != player.playerScreenHandler) {
            return false;
        }
        return !emptyCursorRequired || player.currentScreenHandler.getCursorStack().isEmpty();
    }

    public static int slotId(ClientPlayerEntity player, int inventoryIndex) {
        OptionalInt slotId = player.currentScreenHandler.getSlotIndex(player.getInventory(), inventoryIndex);
        return slotId.orElse(-1);
    }

    public static boolean pickup(MinecraftClient client, int inventoryIndex, int button) {
        if (!canUsePlayerHandler(client, false)) {
            return false;
        }
        int slotId = slotId(client.player, inventoryIndex);
        return slotId >= 0 && clickSlot(client, slotId, button, SlotActionType.PICKUP);
    }

    public static boolean pickupOffhand(MinecraftClient client, int button) {
        return pickup(client, PlayerInventory.OFF_HAND_SLOT, button);
    }

    public static boolean clickSlot(
            MinecraftClient client,
            int slotId,
            int button,
            SlotActionType actionType
    ) {
        if (!canUsePlayerHandler(client, false)) {
            return false;
        }
        ScreenHandler handler = client.player.currentScreenHandler;
        if (slotId < 0 || slotId >= handler.slots.size()) {
            return false;
        }
        Slot slot = handler.getSlot(slotId);
        if (actionType == SlotActionType.PICKUP
                && !slot.getStack().isEmpty()
                && !slot.canTakeItems(client.player)) {
            return false;
        }
        client.interactionManager.clickSlot(handler.syncId, slotId, button, actionType, client.player);
        return true;
    }

    public static boolean pickupSwapWithOffhand(MinecraftClient client, int sourceInventoryIndex, int firstButton) {
        if (!canUsePlayerHandler(client, true)) {
            return false;
        }
        int sourceId = slotId(client.player, sourceInventoryIndex);
        int offhandId = slotId(client.player, PlayerInventory.OFF_HAND_SLOT);
        if (sourceId < 0 || offhandId < 0) {
            return false;
        }
        ItemStack source = client.player.currentScreenHandler.getSlot(sourceId).getStack();
        if (source.isEmpty()) {
            return false;
        }

        if (!clickSlot(client, sourceId, firstButton, SlotActionType.PICKUP)
                || !clickSlot(client, offhandId, 0, SlotActionType.PICKUP)) {
            return false;
        }
        if (!client.player.currentScreenHandler.getCursorStack().isEmpty()) {
            clickSlot(client, sourceId, 0, SlotActionType.PICKUP);
        }
        return client.player.currentScreenHandler.getCursorStack().isEmpty();
    }

    public static boolean silentSwapInventorySlotWithOffhand(MinecraftClient client, int sourceInventoryIndex) {
        if (!canUsePlayerHandler(client, true)
                || sourceInventoryIndex < 0
                || sourceInventoryIndex >= PlayerInventory.MAIN_SIZE) {
            return false;
        }
        ClientPlayerEntity player = client.player;
        PlayerInventory inventory = player.getInventory();
        int originalSelected = inventory.getSelectedSlot();

        if (PlayerInventory.isValidHotbarIndex(sourceInventoryIndex)) {
            selectSlot(client, sourceInventoryIndex);
            try {
                return swapSelectedWithOffhand(client);
            } finally {
                selectSlot(client, originalSelected);
            }
        }

        int sourceId = slotId(player, sourceInventoryIndex);
        if (sourceId < 0) {
            return false;
        }
        if (!clickSlot(client, sourceId, originalSelected, SlotActionType.SWAP)) {
            return false;
        }
        boolean swapped = swapSelectedWithOffhand(client);
        boolean restoredHotbar = clickSlot(client, sourceId, originalSelected, SlotActionType.SWAP);
        return swapped && restoredHotbar;
    }

    private static void selectSlot(MinecraftClient client, int slot) {
        if (client.player.getInventory().getSelectedSlot() == slot) {
            return;
        }
        client.player.getInventory().setSelectedSlot(slot);
        client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private static boolean swapSelectedWithOffhand(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        PlayerInventory inventory = player.getInventory();
        ItemStack selected = inventory.getSelectedStack();
        ItemStack offhand = player.getOffHandStack();

        client.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                PlayerActionC2SPacket.Action.SWAP_ITEM_WITH_OFFHAND,
                BlockPos.ORIGIN,
                Direction.DOWN
        ));

        inventory.setSelectedStack(offhand);
        player.setStackInHand(Hand.OFF_HAND, selected);
        inventory.markDirty();
        return true;
    }
}
