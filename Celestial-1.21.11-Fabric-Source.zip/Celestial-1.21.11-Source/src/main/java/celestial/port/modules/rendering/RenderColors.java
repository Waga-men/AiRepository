package celestial.port.modules.rendering;

import net.minecraft.world.debug.gizmo.VisibilityConfigurable;

final class RenderColors {
    private RenderColors() {
    }

    static int withAlpha(int argb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (argb & 0x00FF_FFFF);
    }

    static int opaque(int argb) {
        return withAlpha(argb, 255);
    }

    static void throughWalls(VisibilityConfigurable configurable, boolean enabled) {
        if (enabled) {
            configurable.ignoreOcclusion();
        }
    }

    static int rainbow(long milliseconds) {
        double hue = Math.floorMod(milliseconds, 6_000L) / 6_000.0;
        double scaled = hue * 6.0;
        int sector = (int) scaled;
        double fraction = scaled - sector;
        int rising = (int) Math.round(fraction * 255.0);
        int falling = 255 - rising;

        return switch (sector) {
            case 0 -> 0xFFFF0000 | (rising << 8);
            case 1 -> 0xFF00FF00 | (falling << 16);
            case 2 -> 0xFF00FF00 | rising;
            case 3 -> 0xFF0000FF | (falling << 8);
            case 4 -> 0xFF0000FF | (rising << 16);
            default -> 0xFFFF0000 | falling;
        };
    }
}
