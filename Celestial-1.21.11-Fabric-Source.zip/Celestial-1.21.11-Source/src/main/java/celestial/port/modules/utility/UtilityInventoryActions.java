package celestial.port.modules.utility;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

import java.util.OptionalInt;

final class UtilityInventoryActions {
    static final int CHEST_INVENTORY_INDEX = 38;

    private UtilityInventoryActions() {
    }

    static boolean canClickPlayerInventory(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        return player != null
                && player.isAlive()
                && client.interactionManager != null
                && client.getNetworkHandler() != null
                && client.currentScreen == null
                && player.currentScreenHandler == player.playerScreenHandler
                && player.currentScreenHandler.getCursorStack().isEmpty();
    }

    static boolean swapInventorySlots(MinecraftClient client, int sourceIndex, int destinationIndex) {
        if (!canClickPlayerInventory(client) || sourceIndex == destinationIndex) {
            return false;
        }
        ClientPlayerEntity player = client.player;
        ScreenHandler handler = player.currentScreenHandler;
        OptionalInt sourceSlotId = handler.getSlotIndex(player.getInventory(), sourceIndex);
        OptionalInt destinationSlotId = handler.getSlotIndex(player.getInventory(), destinationIndex);
        if (sourceSlotId.isEmpty() || destinationSlotId.isEmpty()) {
            return false;
        }

        Slot source = handler.getSlot(sourceSlotId.getAsInt());
        Slot destination = handler.getSlot(destinationSlotId.getAsInt());
        ItemStack sourceStack = source.getStack();
        ItemStack destinationStack = destination.getStack();
        if (sourceStack.isEmpty()
                || !source.canTakeItems(player)
                || !destination.canInsert(sourceStack)
                || (!destinationStack.isEmpty()
                && (!destination.canTakeItems(player) || !source.canInsert(destinationStack)))) {
            return false;
        }

        client.interactionManager.clickSlot(handler.syncId, source.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(handler.syncId, destination.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(handler.syncId, source.id, 0, SlotActionType.PICKUP, player);
        return handler.getCursorStack().isEmpty();
    }

    static boolean equipsChest(ItemStack stack) {
        EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        return equippable != null && equippable.slot() == EquipmentSlot.CHEST;
    }

    static double chestplateScore(ItemStack stack) {
        if (stack.isEmpty() || !equipsChest(stack)) {
            return Double.NEGATIVE_INFINITY;
        }
        AttributeModifiersComponent modifiers = stack.getOrDefault(
                DataComponentTypes.ATTRIBUTE_MODIFIERS,
                AttributeModifiersComponent.DEFAULT
        );
        double armor = modifiers.applyOperations(EntityAttributes.ARMOR, 0.0, EquipmentSlot.CHEST);
        double toughness = modifiers.applyOperations(EntityAttributes.ARMOR_TOUGHNESS, 0.0, EquipmentSlot.CHEST);
        if (armor <= 0.0 && toughness <= 0.0) {
            return Double.NEGATIVE_INFINITY;
        }
        double durability = stack.isDamageable() && stack.getMaxDamage() > 0
                ? (double) (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage()
                : 1.0;
        return armor * 100.0 + toughness * 10.0 + durability;
    }
}
