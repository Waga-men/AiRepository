package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec3d;

public final class AntiWeb extends Module {
    private final BooleanSetting solidBlock = addSetting(new BooleanSetting(
            "solid_block", "\u0422\u0432\u0435\u0440\u0434\u044b\u0439 \u0431\u043b\u043e\u043a", false
    ));
    private int sneakAccumulator;
    private ClientPlayerEntity cobwebCollisionPlayer;
    private int cobwebCollisionAge = Integer.MIN_VALUE;

    public AntiWeb() {
        super("anti_web", "Anti Web",
                "\u0423\u0441\u043a\u043e\u0440\u044f\u0435\u0442 \u0432\u0430\u0441 \u0432 \u043f\u0430\u0443\u0442\u0438\u043d\u0435", Category.MOVEMENT);
    }

    public static boolean solidCollisionActive() {
        AntiWeb module = module();
        return module != null && module.enabled()
                && module.solidBlock.enabled() && !WebLeave.active();
    }

    public static void onCobwebCollision(Entity entity) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!(entity instanceof ClientPlayerEntity player) || player != client.player) {
            return;
        }
        AntiWeb module = module();
        if (module != null) {
            module.cobwebCollisionPlayer = player;
            module.cobwebCollisionAge = player.age;
        }
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        AntiWeb module = module();
        if (module != null && module.enabled()) {
            module.runPreUpdate(player);
        }
    }

    private void runPreUpdate(ClientPlayerEntity player) {
        if (WebLeave.active()) {
            return;
        }

        PlayerInput input = player.input.playerInput;
        boolean jumping = input.jump();
        boolean sneaking = input.sneak() && !player.isSleeping();

        boolean inWeb = cobwebCollisionPlayer == player && cobwebCollisionAge == player.age - 1;
        sneakAccumulator = sneaking
                ? Math.min(10, sneakAccumulator + 5)
                : Math.max(0, sneakAccumulator - 1);
        if (!inWeb) {
            return;
        }

        Vec3d velocity = player.getVelocity();
        if (sneaking || jumping) {
            player.setVelocity(velocity.x, sneaking ? -1.99 : 1.99, velocity.z);
            return;
        }

        setLegacyHorizontalVelocity(player, sneakAccumulator > 1 ? 0.33F : 0.44F);
    }

    private static void setLegacyHorizontalVelocity(ClientPlayerEntity player, float speed) {
        float yaw = player.getYaw();
        float forward = player.forwardSpeed;
        float strafe = player.sidewaysSpeed;
        if (forward != 0.0F) {
            if (strafe > 0.0F) {
                yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (strafe < 0.0F) {
                yaw += forward > 0.0F ? 45.0F : -45.0F;
            }
            strafe = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
        }

        double cosine = Math.cos(Math.toRadians(yaw + 90.0F));
        double sine = Math.sin(Math.toRadians(yaw + 90.0F));
        double x = (double) (forward * speed) * cosine + (double) (strafe * speed) * sine;
        double z = (double) (forward * speed) * sine - (double) (strafe * speed) * cosine;
        player.setVelocity(x, 0.0, z);
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        sneakAccumulator = 0;
    }

    @Override
    protected void onEnable() {
        sneakAccumulator = 0;
    }

    @Override
    protected void onDisable() {
        sneakAccumulator = 0;
    }

    private static AntiWeb module() {
        Module raw = CelestialPortClient.MODULES.find("anti_web").orElse(null);
        return raw instanceof AntiWeb module ? module : null;
    }
}
