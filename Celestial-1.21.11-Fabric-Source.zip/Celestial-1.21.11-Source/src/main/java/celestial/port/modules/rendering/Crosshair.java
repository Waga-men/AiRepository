package celestial.port.modules.rendering;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.debug.DebugHudEntries;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.util.hit.EntityHitResult;

public final class Crosshair extends Module {
    private final BooleanSetting centerDot = addSetting(new BooleanSetting(
            "center_dot", "Точка по середине", true
    ));
    private final BooleanSetting cooldown = addSetting(new BooleanSetting(
            "cooldown", "Кулдаун", false
    ));
    private final ColorSetting color = addSetting(new ColorSetting(
            "color", "Цвет", 0xFFFFFFFF, false
    ));
    private final BooleanSetting highlightTarget = addSetting(new BooleanSetting(
            "highlight_target", "Подсветка энтити", true
    ));
    private final ColorSetting targetColor = addSetting(new ColorSetting(
            "target_color", "Цвет подсветки", 0xFFFF0000, false
    ).visibleWhen(highlightTarget::enabled));
    private final NumberSetting radius = addSetting(new NumberSetting(
            "radius", "Радиус", 3.0, 3.0, 6.0, 0.5
    ));

    public Crosshair() {
        super("crosshair", "Crosshair", "Кастомный прицел", Category.RENDER);
    }

    public BooleanSetting centerDot() {
        return centerDot;
    }

    public BooleanSetting cooldown() {
        return cooldown;
    }

    public ColorSetting color() {
        return color;
    }

    public BooleanSetting highlightTarget() {
        return highlightTarget;
    }

    public ColorSetting targetColor() {
        return targetColor;
    }

    public NumberSetting radius() {
        return radius;
    }

    boolean shouldRenderCustom() {
        MinecraftClient client = MinecraftClient.getInstance();
        return enabled()
                && client.player != null
                && client.options.getPerspective().isFirstPerson()
                && !client.debugHudEntryList.isF3Enabled()
                && !client.debugHudEntryList.isEntryVisible(DebugHudEntries.THREE_DIMENSIONAL_CROSSHAIR);
    }

    void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();

        float centerX = context.getScaledWindowWidth() / 2.0F;
        float centerY = context.getScaledWindowHeight() / 2.0F;
        float attackGap = cooldown.enabled()
                ? (1.0F - client.player.getAttackCooldownProgress(0.5F)) * 10.0F
                : 0.0F;
        float armRadius = radius.value().floatValue() + attackGap;
        boolean entityTarget = client.crosshairTarget instanceof EntityHitResult;
        int foreground = highlightTarget.enabled() && entityTarget ? targetColor.argb() : color.argb();

        if (centerDot.enabled()) {
            legacyRect(context, centerX, centerY, 1.0F, 1.0F, foreground);
        }
        legacyRect(context, centerX - armRadius - 2.0F, centerY, 3.0F, 1.0F, foreground);
        legacyRect(context, centerX, centerY - armRadius - 2.0F, 1.0F, 3.0F, foreground);
        legacyRect(context, centerX + armRadius, centerY, 3.0F, 1.0F, foreground);
        legacyRect(context, centerX, centerY + armRadius, 1.0F, 3.0F, foreground);
    }

    private static void legacyRect(DrawContext context, float x, float y, float width, float height, int color) {
        int right = (int) (width * 2.0F);
        int bottom = (int) (height * 2.0F);
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(0.5F, 0.5F);
        context.fill(-1, -1, right + 1, bottom + 1, 0xFF000000);
        context.fill(0, 0, right, bottom, color);
        context.getMatrices().popMatrix();
    }
}
