package celestial.port.modules.impl;

import celestial.port.client.ui.ClientFeedback;
import celestial.port.core.Category;
import celestial.port.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;

public final class DeathCoords extends Module {
    private static volatile DeathCoords instance;
    private static volatile BlockPos lastDeathPosition;

    public DeathCoords() {
        super("death_coords", "Death Coords",
                "\u041f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0441\u043c\u0435\u0440\u0442\u0438", Category.PLAYER);
        instance = this;
    }

    public static void beforeVanillaPlayerTick(ClientPlayerEntity player) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (player == null || player != client.player || client.world == null
                || player.getHealth() > 0.0F || player.deathTime >= 1) {
            return;
        }

        lastDeathPosition = new BlockPos(
                (int) player.getX(), (int) player.getY(), (int) player.getZ());
        DeathCoords module = instance;
        if (module == null || !module.enabled()) {
            return;
        }
        BlockPos legacyLoadedProbe = new BlockPos(player.getBlockX(), 0, player.getBlockZ());
        if (!client.world.isPosLoaded(legacyLoadedProbe)) {
            return;
        }

        int x = (int) player.getX();
        int y = (int) player.getY();
        int z = (int) player.getZ();
        player.sendMessage(legacyChat(x, y, z), false);
        ClientFeedback.info("Death Coords", notificationDescription(x, y, z), 10);
    }

    public static BlockPos lastDeathPosition() {
        return lastDeathPosition;
    }

    private static Text notificationDescription(int x, int y, int z) {
        return Text.empty()
                .append(Text.literal("\u0412\u0430\u0448\u0438 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0441\u043c\u0435\u0440\u0442\u0438 - "))
                .append(Text.literal("X: ").formatted(Formatting.RED))
                .append(Text.literal(Integer.toString(x)).formatted(Formatting.WHITE))
                .append(Text.literal(" Y: ").formatted(Formatting.RED))
                .append(Text.literal(Integer.toString(y)).formatted(Formatting.WHITE))
                .append(Text.literal(" Z: ").formatted(Formatting.RED))
                .append(Text.literal(Integer.toString(z)).formatted(Formatting.WHITE));
    }

    private static Text legacyChat(int x, int y, int z) {
        MutableText boldPayload = Text.empty().formatted(Formatting.BOLD)
                .append(Text.literal("\u0412\u0430\u0448\u0438 \u043a\u043e\u043e\u0440\u0434\u0438\u043d\u0430\u0442\u044b \u0441\u043c\u0435\u0440\u0442\u0438 - ")
                        .formatted(Formatting.WHITE))
                .append(Text.literal("X: ").formatted(Formatting.RED))
                .append(Text.literal(Integer.toString(x)).formatted(Formatting.WHITE))
                .append(Text.literal(" Y: ").formatted(Formatting.RED))
                .append(Text.literal(Integer.toString(y)).formatted(Formatting.WHITE))
                .append(Text.literal(" Z: ").formatted(Formatting.RED))
                .append(Text.literal(Integer.toString(z)).formatted(Formatting.WHITE));
        return Text.empty()
                .append(Text.literal("(").formatted(Formatting.GRAY))
                .append(Text.literal("Celestial").formatted(Formatting.LIGHT_PURPLE))
                .append(Text.literal(") ").formatted(Formatting.GRAY))
                .append(Text.literal("\u00bb ").formatted(Formatting.DARK_GRAY))
                .append(boldPayload);
    }
}
