package celestial.port.modules.impl;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;

import java.util.List;

public final class TimeChanger extends Module {
    private static volatile TimeChanger instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", "Ночь", List.of("Ночь", "День", "Утро", "Закат")));

    public TimeChanger() {
        super("time_changer", "Time Changer", "Позволяет менять время в мире", Category.RENDER);
        instance = this;
    }

    @Override
    protected void onTick() {
        applyOverride(MinecraftClient.getInstance().world);
    }

    public static WorldTimeUpdateS2CPacket rewrite(WorldTimeUpdateS2CPacket packet) {
        TimeChanger module = instance;
        ClientWorld world = MinecraftClient.getInstance().world;
        if (module == null || !module.enabled() || world == null) {
            return packet;
        }
        return new WorldTimeUpdateS2CPacket(packet.time(), world.getTimeOfDay(), true);
    }

    private void applyOverride(ClientWorld world) {
        if (world == null) {
            return;
        }
        long time = switch (mode.value()) {
            case "Утро" -> 0L;
            case "День" -> 5_000L;
            case "Закат" -> 13_000L;
            default -> 17_000L;
        };

        world.setTime(world.getLevelProperties().getTime(), time, true);
    }
}
