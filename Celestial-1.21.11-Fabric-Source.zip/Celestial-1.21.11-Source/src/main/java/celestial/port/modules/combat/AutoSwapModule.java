package celestial.port.modules.combat;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.inventory.AutoTotem;
import celestial.port.modules.inventory.OffhandTransactions;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.List;

public final class AutoSwapModule extends Module {
    private static final long RETURN_DELAY_NANOS = 400_000_000L;
    private static AutoSwapModule instance;

    private final ModeSetting switchingMode = addSetting(new ModeSetting(
            "switching_mode",
            "Режим переключения",
            "Умный",
            List.of("Умный", "По бинду")
    ));
    private final ModeSetting neededItem = addSetting(new ModeSetting(
            "needed_item",
            "Нужный предмет",
            "Щит",
            List.of("Щит", "Тотем", "Шар (ReallyWorld)", "Руна (Sunrise)")
    ));
    private final NumberSetting health = addSetting(new NumberSetting(
            "health",
            "Здоровье",
            11.0,
            5.0,
            19.0,
            0.5
    ).visibleWhen(() -> switchingMode.is("РЈРјРЅС‹Р№")));
    private final BindSetting activationKey = addSetting(new BindSetting(
            "activation_key",
            "Клавиша",
            BindSetting.forMouseButton(GLFW.GLFW_MOUSE_BUTTON_MIDDLE)
    ).visibleWhen(() -> switchingMode.is("РџРѕ Р±РёРЅРґСѓ")));
    private final BooleanSetting checkCrystal = addSetting(new BooleanSetting(
            "check_crystal",
            "Проверять кристалл",
            true
    ).visibleWhen(() -> neededItem.is("РЁР°СЂ (ReallyWorld)")));
    private final BooleanSetting vulcanBypass = addSetting(new BooleanSetting(
            "vulcan_bypass",
            "Обход Vulcan",
            false
    ));

    private ClientPlayerEntity ownerPlayer;
    private ClientWorld ownerWorld;
    private int returnSlot = PlayerInventory.NOT_FOUND;
    private boolean shieldCooldownFlow;
    private boolean eatingApple;
    private boolean deferredRestore;
    private boolean cooldownRestoreRequested;
    private boolean putRequested;
    private boolean restoreRequested;
    private boolean keyWasPressed;
    private boolean bypassArmed;
    private int bypassTicks;
    private long returnTimer = System.nanoTime();
    private String observedMode;
    private String observedItem;

    public AutoSwapModule() {
        super(
                "auto_swap",
                "Auto Swap",
                "Автоматически меняет предмет на гэпплы, что помогает в ХВХ",
                Category.COMBAT
        );
        instance = this;
        observedMode = switchingMode.value();
        observedItem = neededItem.value();
    }

    public static void onCooldownStarted(ItemCooldownManager manager, Identifier group) {
        AutoSwapModule module = instance;
        if (module == null || !module.enabled()) {
            return;
        }
        module.onCooldown(manager, group, true);
    }

    public static void onCooldownEnded(ItemCooldownManager manager, Identifier group) {
        AutoSwapModule module = instance;
        if (module == null || !module.enabled()) {
            return;
        }
        module.onCooldown(manager, group, false);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!validSession(client)) {
            resetState();
            ownerPlayer = client.player;
            ownerWorld = client.world;
        }
        if (settingsChanged()) {
            resetState();
        }
        advanceBypass(client);

        if (client.player == null || client.world == null || !client.player.isAlive()) {
            keyWasPressed = false;
            return;
        }

        boolean allowed = maySwap(client);
        boolean keyPressed = physicalBindPressed(client);
        boolean keyRising = keyPressed && !keyWasPressed;
        keyWasPressed = keyPressed;

        if (switchingMode.is("По бинду")) {
            if (keyRising && allowed) {
                if (client.player.getOffHandStack().isOf(selectedItem())) {
                    putRequested = true;
                    restoreRequested = false;
                } else {
                    restoreRequested = true;
                    putRequested = false;
                }
            }
            if (putRequested) {
                putGapple(client, false);
            } else if (restoreRequested && restoreSelectedItem(client, false)) {
                resetState();
                returnTimer = System.nanoTime();
            }
            return;
        }

        eatingApple = isEatingOffhandApple(client);
        if (!allowed || !OffhandTransactions.canUsePlayerHandler(client, false)) {
            return;
        }
        if (eatingApple) {
            returnTimer = System.nanoTime();
            return;
        }
        if (deferredRestore || cooldownRestoreRequested) {
            if (restoreSelectedItem(client, true)) {
                resetState();
                returnTimer = System.nanoTime();
            }
            return;
        }
        if (shieldCooldownFlow) {
            return;
        }

        if (effectiveHealth(client.player) <= health.value()) {
            putGapple(client, false);
        } else if (restoreSelectedItem(client, true)) {
            resetState();
            returnTimer = System.nanoTime();
        }
    }

    private void onCooldown(ItemCooldownManager manager, Identifier group, boolean started) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || manager != client.player.getItemCooldownManager()) {
            return;
        }
        if (!client.isOnThread()) {
            client.execute(() -> onCooldown(manager, group, started));
            return;
        }
        if (!switchingMode.is("Умный")) {
            return;
        }

        boolean shieldGroup = group.equals(manager.getGroup(new ItemStack(Items.SHIELD)));
        boolean appleGroup = group.equals(manager.getGroup(new ItemStack(Items.GOLDEN_APPLE)))
                || group.equals(manager.getGroup(new ItemStack(Items.ENCHANTED_GOLDEN_APPLE)));

        if (started && neededItem.is("Щит") && shieldGroup) {
            shieldCooldownFlow = true;
            putGapple(client, true);
            return;
        }
        if (!shieldCooldownFlow || (!started && !shieldGroup) || (started && !appleGroup)) {
            return;
        }

        eatingApple = isEatingOffhandApple(client);
        if (eatingApple) {
            deferredRestore = true;
        } else if (restoreSelectedItem(client, true)) {
            resetState();
            returnTimer = System.nanoTime();
        } else {
            cooldownRestoreRequested = true;
        }
    }

    private boolean putGapple(MinecraftClient client, boolean cooldownTriggered) {
        if (!OffhandTransactions.canUsePlayerHandler(client, false)
                || isApple(client.player.getOffHandStack())) {
            return false;
        }

        int appleSlot = findMain(client.player.getInventory(), Items.GOLDEN_APPLE);
        ItemStack cursor = client.player.currentScreenHandler.getCursorStack();
        if (appleSlot == PlayerInventory.NOT_FOUND && !cursor.isOf(Items.GOLDEN_APPLE)) {
            clearBypass();
            return false;
        }
        if (!cooldownTriggered && !passesVulcanBypass(client)) {
            return false;
        }

        if (appleSlot == PlayerInventory.NOT_FOUND) {
            if (!OffhandTransactions.pickupOffhand(client, 0)) {
                return false;
            }
        } else {
            if (returnSlot == PlayerInventory.NOT_FOUND) {
                returnSlot = appleSlot;
            }
            if (!OffhandTransactions.pickupSwapWithOffhand(client, appleSlot, 0)) {
                return false;
            }
        }

        putRequested = false;
        clearBypass();
        return true;
    }

    private boolean restoreSelectedItem(MinecraftClient client, boolean automatic) {
        if (System.nanoTime() - returnTimer < RETURN_DELAY_NANOS
                || !OffhandTransactions.canUsePlayerHandler(client, false)) {
            return false;
        }

        Item target = selectedItem();
        if ((returnSlot == PlayerInventory.NOT_FOUND && automatic)
                || client.player.getOffHandStack().isOf(target)) {
            clearBypass();
            return false;
        }

        int targetSlot = findMain(client.player.getInventory(), target);
        ItemStack cursor = client.player.currentScreenHandler.getCursorStack();
        if (targetSlot != PlayerInventory.NOT_FOUND && !passesVulcanBypass(client)) {
            return false;
        }

        if (cursor.isOf(target)) {
            if (!OffhandTransactions.pickupOffhand(client, 0)) {
                return false;
            }
            if (returnSlot != PlayerInventory.NOT_FOUND) {
                OffhandTransactions.pickup(client, returnSlot, 0);
            }
            return false;
        }
        if (targetSlot == PlayerInventory.NOT_FOUND
                || !client.player.currentScreenHandler.getCursorStack().isEmpty()) {
            clearBypass();
            return false;
        }

        if (!OffhandTransactions.pickup(client, targetSlot, 0)
                || !OffhandTransactions.pickupOffhand(client, 0)) {
            return false;
        }
        int destination = automatic ? returnSlot : targetSlot;
        if (destination != PlayerInventory.NOT_FOUND) {
            OffhandTransactions.pickup(client, destination, 0);
        }
        boolean complete = client.player.currentScreenHandler.getCursorStack().isEmpty();
        if (complete) {
            restoreRequested = false;
            clearBypass();
        }
        return complete;
    }

    private boolean maySwap(MinecraftClient client) {
        if (client.player == null || client.world == null || AutoTotem.isSwapInProgress()) {
            return false;
        }
        if (!checkCrystal.enabled()
                || !neededItem.is("Шар (ReallyWorld)")
                || !isEquipped(client.player, selectedItem())) {
            return true;
        }
        return client.world.getEntitiesByClass(
                EndCrystalEntity.class,
                client.player.getBoundingBox().expand(6.0),
                crystal -> crystal.distanceTo(client.player) <= 6.0F
        ).isEmpty();
    }

    private boolean passesVulcanBypass(MinecraftClient client) {
        if (!vulcanBypass.enabled() || shieldCooldownFlow) {
            return true;
        }
        if (!bypassArmed) {
            bypassArmed = true;
            bypassTicks = 0;
        }
        return bypassTicks >= 3;
    }

    private void advanceBypass(MinecraftClient client) {
        if (!bypassArmed || client.player == null) {
            return;
        }
        bypassTicks++;
        if (!client.player.isGliding()
                && !client.player.isTouchingWater()
                && !client.player.hasVehicle()
                && !client.player.getAbilities().flying) {
            var velocity = client.player.getVelocity();
            client.player.setVelocity(velocity.x * 0.7, velocity.y, velocity.z * 0.7);
        }
        if (bypassTicks > 5) {
            clearBypass();
        }
    }

    private void clearBypass() {
        bypassArmed = false;
        bypassTicks = 0;
    }

    private Item selectedItem() {
        if (neededItem.is("Тотем")) {
            return Items.TOTEM_OF_UNDYING;
        }
        if (neededItem.is("Шар (ReallyWorld)")) {
            return Items.PLAYER_HEAD;
        }
        if (neededItem.is("Руна (Sunrise)")) {
            return Items.FIREWORK_STAR;
        }
        return Items.SHIELD;
    }

    private boolean physicalBindPressed(MinecraftClient client) {
        if (!activationKey.isBound()) {
            return false;
        }
        int key = activationKey.key();
        long window = client.getWindow().getHandle();
        return BindSetting.isPressed(window, key);
    }

    private boolean isEatingOffhandApple(MinecraftClient client) {
        ItemStack offhand = client.player.getOffHandStack();
        return isApple(offhand)
                && client.options.useKey.isPressed()
                && !client.player.getItemCooldownManager().isCoolingDown(offhand);
    }

    private static boolean isApple(ItemStack stack) {
        return stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE);
    }

    private static float effectiveHealth(ClientPlayerEntity player) {
        return player.getHealth() + (player.hasStatusEffect(StatusEffects.ABSORPTION)
                ? player.getAbsorptionAmount() : 0.0F);
    }

    private static int findMain(PlayerInventory inventory, Item item) {
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (inventory.getStack(slot).isOf(item)) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static boolean isEquipped(ClientPlayerEntity player, Item item) {
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (player.getEquippedStack(slot).isOf(item)) {
                return true;
            }
        }
        return false;
    }

    private boolean validSession(MinecraftClient client) {
        return ownerPlayer == client.player && ownerWorld == client.world;
    }

    private boolean settingsChanged() {
        String mode = switchingMode.value();
        String item = neededItem.value();
        if (mode.equals(observedMode) && item.equals(observedItem)) {
            return false;
        }
        observedMode = mode;
        observedItem = item;
        return true;
    }

    private void resetState() {
        returnSlot = PlayerInventory.NOT_FOUND;
        shieldCooldownFlow = false;
        eatingApple = false;
        deferredRestore = false;
        cooldownRestoreRequested = false;
        putRequested = false;
        restoreRequested = false;
        clearBypass();
    }

    @Override
    protected void onDisable() {
        resetState();
        keyWasPressed = false;
        ownerPlayer = null;
        ownerWorld = null;
    }
}
