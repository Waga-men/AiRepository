package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;

public final class HitBoxModule extends Module {
    private final NumberSetting size = addSetting(new NumberSetting(
            "size", "Размер", 0.5, 0.1, 1.0, 0.1));

    public HitBoxModule() {
        super("hit_box", "HitBox", "Увеличивает хитбокс игроков", Category.COMBAT);
    }

    public static float targetingMargin(Entity entity) {
        Module candidate = CelestialPortClient.MODULES.find("hit_box").orElse(null);
        if (!(candidate instanceof HitBoxModule hitBox) || !hitBox.enabled()
                || !(entity instanceof PlayerEntity target)
                || target == MinecraftClient.getInstance().player
                || FriendManager.isFriend(target)) {
            return 0.0f;
        }
        return hitBox.size.value().floatValue();
    }
}
