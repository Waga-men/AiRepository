package celestial.port.modules.player;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

public final class ClickFriend extends Module {
    private final BindSetting activationKey = addSetting(new BindSetting(
            "activation_key", "Клавиша",
            BindSetting.forMouseButton(GLFW.GLFW_MOUSE_BUTTON_MIDDLE)
    ));
    private final NumberSetting distance = addSetting(new NumberSetting(
            "distance", "Дистанция", 4.0, 4.0, 64.0, 4.0
    ));
    private boolean activationPressed;

    public ClickFriend() {
        super("click_friend", "Click Friend",
                "Добавляет игрока в друзья по клавише", Category.PLAYER);
    }

    public BindSetting activationKey() {
        return activationKey;
    }

    public NumberSetting distance() {
        return distance;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            activationPressed = false;
            return;
        }
        boolean triggered = pollActivation(client);
        if (!triggered) {
            return;
        }
        if (client.currentScreen != null
                && !BindSetting.isMouseButton(activationKey.key())) {
            return;
        }
        if (CelestialPortClient.MODULES.find("attack_aura")
                .map(Module::enabled)
                .orElse(false)) {
            return;
        }

        double reach = distance.value();
        Vec3d start = client.player.getCameraPosVec(1.0F);
        Vec3d end = start.add(client.player.getRotationVec(1.0F).multiply(reach));
        PlayerEntity target = null;
        for (PlayerEntity candidate : client.world.getPlayers()) {
            if (candidate == client.player) {
                continue;
            }
            if (candidate.getBoundingBox().expand(0.1).raycast(start, end).isPresent()) {
                target = candidate;
                break;
            }
        }
        if (target == null) {
            return;
        }

        boolean friend = FriendManager.toggle(target);
        client.player.sendMessage(Text.literal(
                "Игрок " + target.getName().getString()
                        + (friend ? " был добавлен в список друзей!" : " был удален из списка друзей!")
        ), false);
    }

    private boolean pollActivation(MinecraftClient client) {
        boolean pressed = activationKey.isBound()
                && BindSetting.isPressed(client.getWindow().getHandle(), activationKey.key());
        boolean risingEdge = pressed && !activationPressed;
        activationPressed = pressed;
        return risingEdge;
    }

    @Override
    protected void onDisable() {
        activationPressed = false;
    }
}
