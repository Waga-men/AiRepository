package celestial.port.modules.player;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.NumberSetting;

public final class FastBreak extends Module {
    private static volatile FastBreak instance;

    private final NumberSetting speed = addSetting(new NumberSetting(

            "speed", "Cкорость", 1.0, 0.1, 1.0, 0.05));

    public FastBreak() {
        super("fast_break", "Fast Break", "Позволяет ломать блоки быстрее", Category.PLAYER);
        instance = this;
    }

    public static boolean active() {
        FastBreak module = instance;
        return module != null && module.enabled();
    }

    public static float completionThreshold() {
        FastBreak module = instance;
        return module == null ? 1.0F : module.speed.value().floatValue();
    }
}
