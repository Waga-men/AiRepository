package celestial.port.modules.legacyutility;

import celestial.port.CelestialPortClient;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

final class AutoBuyStore {
    private static final int FORMAT_VERSION = 1;
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create();

    private static final Map<Integer, Identifier> LEGACY_ENCHANTMENTS = Map.ofEntries(
            enchant(0, "protection"), enchant(1, "fire_protection"),
            enchant(2, "feather_falling"), enchant(3, "blast_protection"),
            enchant(4, "projectile_protection"), enchant(5, "respiration"),
            enchant(6, "aqua_affinity"), enchant(7, "thorns"),
            enchant(8, "depth_strider"), enchant(9, "frost_walker"),
            enchant(10, "binding_curse"), enchant(16, "sharpness"),
            enchant(17, "smite"), enchant(18, "bane_of_arthropods"),
            enchant(19, "knockback"), enchant(20, "fire_aspect"),
            enchant(21, "looting"), enchant(22, "sweeping_edge"),
            enchant(32, "efficiency"), enchant(33, "silk_touch"),
            enchant(34, "unbreaking"), enchant(35, "fortune"),
            enchant(48, "power"), enchant(49, "punch"),
            enchant(50, "flame"), enchant(51, "infinity"),
            enchant(61, "luck_of_the_sea"), enchant(62, "lure"),
            enchant(70, "mending"), enchant(71, "vanishing_curse")
    );

    private final AutoBuy owner;
    private final Path file;

    AutoBuyStore(AutoBuy owner, Path file) {
        this.owner = owner;
        this.file = file.toAbsolutePath().normalize();
    }

    void loadWithLegacyFallback(List<Path> fallbackFiles) throws IOException {
        Path source = Files.isRegularFile(file) ? file : firstExisting(fallbackFiles);
        if (source == null) {
            return;
        }

        boolean json = startsWithJsonObject(source);
        if (json) {
            loadJson(source);
        } else {
            loadLegacy(source);
        }

        if (!source.equals(file) || !json) {
            save();
        }
    }

    void save() throws IOException {
        Path parent = file.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }

        JsonObject root = new JsonObject();
        root.addProperty("version", FORMAT_VERSION);

        JsonObject settings = new JsonObject();
        settings.addProperty("delay", owner.clickDelayMs());
        settings.addProperty("addMode", owner.addMode().name());
        settings.addProperty("count", owner.editorCount());
        settings.addProperty("enchantedWithoutNbt", owner.editorEnchantedWithoutNbt());
        root.add("settings", settings);

        var items = new com.google.gson.JsonArray();
        for (AutoBuy.Entry entry : owner.entries()) {
            Identifier itemId = Registries.ITEM.getId(entry.item());
            if (itemId == null || entry.item() == Items.AIR) {
                continue;
            }
            JsonObject item = new JsonObject();
            item.addProperty("item", itemId.toString());
            item.addProperty("count", entry.minimumCount());
            item.addProperty("maxPrice", entry.maximumPrice());
            item.addProperty("enchantedWithoutNbt", entry.enchantedWithoutNbt());

            JsonObject enchantments = new JsonObject();
            entry.enchantments().entrySet().stream()
                    .sorted(Map.Entry.comparingByKey())
                    .forEach(enchantment -> enchantments.addProperty(
                            enchantment.getKey().toString(), enchantment.getValue()));
            item.add("enchantments", enchantments);
            items.add(item);
        }
        root.add("entries", items);

        Path temporary = file.resolveSibling(file.getFileName() + ".tmp");
        try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
            GSON.toJson(root, writer);
        }
        try {
            Files.move(temporary, file, StandardCopyOption.ATOMIC_MOVE,
                    StandardCopyOption.REPLACE_EXISTING);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    private void loadJson(Path source) throws IOException {
        JsonObject root;
        try (Reader reader = Files.newBufferedReader(source, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (!parsed.isJsonObject()) {
                throw new IOException("AutoBuy root must be a JSON object: " + source);
            }
            root = parsed.getAsJsonObject();
        } catch (RuntimeException exception) {
            throw new IOException("Malformed AutoBuy JSON: " + source, exception);
        }

        JsonObject settings = object(root, "settings");
        int delay = integer(settings, "delay", 50);
        int count = integer(settings, "count", 1);
        boolean enchanted = bool(settings, "enchantedWithoutNbt", false);
        AutoBuy.AddMode mode = AutoBuy.AddMode.parse(string(settings, "addMode", "ID"));

        List<AutoBuy.Entry> loaded = new ArrayList<>();
        JsonElement rawEntries = root.get("entries");
        if (rawEntries != null && rawEntries.isJsonArray()) {
            for (JsonElement rawEntry : rawEntries.getAsJsonArray()) {
                if (!rawEntry.isJsonObject()) {
                    continue;
                }
                JsonObject entry = rawEntry.getAsJsonObject();
                Item item = findItem(string(entry, "item", ""));
                if (item == null || item == Items.AIR
                        || loaded.stream().anyMatch(existing -> existing.item() == item)) {
                    continue;
                }
                long minimumCount = longValue(entry, "count", 1L);
                long maximumPrice = longValue(entry, "maxPrice", 1L);
                boolean withoutNbt = bool(entry, "enchantedWithoutNbt", false);
                LinkedHashMap<Identifier, Integer> enchantments = readEnchantments(
                        object(entry, "enchantments"));
                loaded.add(new AutoBuy.Entry(item, minimumCount, maximumPrice,
                        withoutNbt, enchantments));
            }
        }
        owner.replaceLoadedState(loaded, delay, mode, count, enchanted);
    }

    private void loadLegacy(Path source) throws IOException {
        int delay = 50;
        int count = 1;
        boolean enchanted = false;
        AutoBuy.AddMode mode = AutoBuy.AddMode.ID;
        List<AutoBuy.Entry> loaded = new ArrayList<>();

        try (BufferedReader reader = Files.newBufferedReader(source, StandardCharsets.UTF_8)) {
            String line;
            while ((line = reader.readLine()) != null) {
                String value = line.strip();
                if (value.startsWith("PopUpSetting:")) {
                    String[] fields = value.split(":", 3);
                    if (fields.length != 3) {
                        continue;
                    }
                    switch (fields[1]) {
                        case "Задержка" -> delay = parseRoundedInt(fields[2], delay);
                        case "Добавлять по" -> mode = AutoBuy.AddMode.parse(fields[2]);
                        case "Выберите количество от" -> count = parseRoundedInt(fields[2], count);
                        case "Зачарован без NBT" -> enchanted = Boolean.parseBoolean(fields[2]);
                        default -> {

                        }
                    }
                    continue;
                }
                if (!value.startsWith("Item:")) {
                    continue;
                }
                try {
                    String[] fields = value.split(":", 7);
                    if (fields.length < 5) {
                        continue;
                    }
                    Item item = findLegacyItem(fields[1]);
                    if (item == null || item == Items.AIR
                            || loaded.stream().anyMatch(existing -> existing.item() == item)) {
                        continue;
                    }
                    long minimumCount = Long.parseLong(fields[2]);
                    long maximumPrice = Long.parseLong(fields[3]);
                    boolean withoutNbt = Boolean.parseBoolean(fields[4]);
                    LinkedHashMap<Identifier, Integer> enchantments = fields.length > 5
                            ? readLegacyEnchantments(fields[5]) : new LinkedHashMap<>();
                    loaded.add(new AutoBuy.Entry(item, minimumCount, maximumPrice,
                            withoutNbt, enchantments));
                } catch (RuntimeException malformedEntry) {
                    CelestialPortClient.LOGGER.warn("Skipping malformed legacy AutoBuy row: {}", value);
                }
            }
        }
        owner.replaceLoadedState(loaded, delay, mode, count, enchanted);
    }

    private static LinkedHashMap<Identifier, Integer> readEnchantments(JsonObject object) {
        LinkedHashMap<Identifier, Integer> result = new LinkedHashMap<>();
        if (object == null) {
            return result;
        }
        for (Map.Entry<String, JsonElement> entry : object.entrySet()) {
            Identifier id = Identifier.tryParse(entry.getKey());
            try {
                int level = entry.getValue().getAsInt();
                if (id != null) {
                    result.put(id, level);
                }
            } catch (RuntimeException ignored) {

            }
        }
        return result;
    }

    private static LinkedHashMap<Identifier, Integer> readLegacyEnchantments(String encoded) {
        LinkedHashMap<Identifier, Integer> result = new LinkedHashMap<>();
        if (encoded == null || encoded.isBlank()) {
            return result;
        }
        for (String token : encoded.split("-")) {
            int open = token.indexOf('(');
            int close = token.indexOf(')', open + 1);
            if (open <= 0 || close <= open) {
                continue;
            }
            try {
                int oldId = Integer.parseInt(token.substring(0, open));
                int level = Integer.parseInt(token.substring(open + 1, close));
                Identifier modernId = LEGACY_ENCHANTMENTS.get(oldId);
                if (modernId != null) {
                    result.put(modernId, level);
                }
            } catch (NumberFormatException ignored) {

            }
        }
        return result;
    }

    private static Item findLegacyItem(String encoded) {
        Item named = findItem(encoded);
        if (named != null) {
            return named;
        }
        try {
            int rawId = Integer.parseInt(encoded);

            return Registries.ITEM.getEntry(rawId).map(entry -> entry.value()).orElse(null);
        } catch (NumberFormatException ignored) {
            return null;
        }
    }

    private static Item findItem(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        Identifier id = Identifier.tryParse(value.contains(":") ? value : "minecraft:" + value);
        if (id == null || !Registries.ITEM.containsId(id)) {
            return null;
        }
        return Registries.ITEM.get(id);
    }

    private static Path firstExisting(List<Path> candidates) {
        for (Path candidate : candidates) {
            if (candidate == null) {
                continue;
            }
            Path normalized = candidate.toAbsolutePath().normalize();
            if (Files.isRegularFile(normalized)) {
                return normalized;
            }
        }
        return null;
    }

    private static boolean startsWithJsonObject(Path source) throws IOException {
        try (Reader reader = Files.newBufferedReader(source, StandardCharsets.UTF_8)) {
            int character;
            while ((character = reader.read()) != -1) {
                if (!Character.isWhitespace(character)) {
                    return character == '{';
                }
            }
        }
        return false;
    }

    private static JsonObject object(JsonObject parent, String name) {
        if (parent == null) {
            return null;
        }
        JsonElement element = parent.get(name);
        return element != null && element.isJsonObject() ? element.getAsJsonObject() : null;
    }

    private static String string(JsonObject object, String name, String fallback) {
        try {
            return object != null && object.has(name) ? object.get(name).getAsString() : fallback;
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static int integer(JsonObject object, String name, int fallback) {
        try {
            return object != null && object.has(name) ? object.get(name).getAsInt() : fallback;
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static long longValue(JsonObject object, String name, long fallback) {
        try {
            return object != null && object.has(name) ? object.get(name).getAsLong() : fallback;
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static boolean bool(JsonObject object, String name, boolean fallback) {
        try {
            return object != null && object.has(name) ? object.get(name).getAsBoolean() : fallback;
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static int parseRoundedInt(String value, int fallback) {
        try {
            return Math.round(Float.parseFloat(value));
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static Map.Entry<Integer, Identifier> enchant(int legacyId, String modernPath) {
        return Map.entry(legacyId, Identifier.ofVanilla(modernPath));
    }
}
