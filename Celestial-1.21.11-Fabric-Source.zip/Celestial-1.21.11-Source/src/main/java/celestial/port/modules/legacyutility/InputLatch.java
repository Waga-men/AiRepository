package celestial.port.modules.legacyutility;

import celestial.port.core.setting.BindSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

final class InputLatch {
    private boolean previous;

    boolean poll(MinecraftClient client, BindSetting setting, KeyBinding fallback) {
        boolean pressed = setting.isBound()
                ? BindSetting.isPressed(client.getWindow().getHandle(), setting.key())
                : fallback.isPressed();
        boolean rising = pressed && !previous;
        previous = pressed;
        return rising;
    }

    void reset() {
        previous = false;
    }
}
