package celestial.port.modules.legacyutility;

import celestial.port.CelestialPortClient;
import celestial.port.client.ui.AutoBuyScreen;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ActionSetting;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.item.PlayerHeadItem;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.OptionalLong;
import java.util.concurrent.CopyOnWriteArrayList;

public final class AutoBuy extends Module {
    public static final String AUCTION_TITLE = "Аукцион";
    public static final String CONFIRM_TITLE = "Подтвердите покупку";
    public static final int CONFIRM_SLOT = 10;
    public static final int REFRESH_SLOT = 4;

    private final CopyOnWriteArrayList<Entry> entries = new CopyOnWriteArrayList<>();
    private final AutoBuyStore store;
    private final ActionSetting openInterface;

    private volatile int clickDelayMs = 50;
    private volatile AddMode addMode = AddMode.ID;
    private volatile int editorCount = 1;
    private volatile boolean editorEnchantedWithoutNbt;

    private long balance;
    private long lastBuyNanos;
    private long lastConfirmNanos;
    private long lastRefreshNanos;
    private long lastBalanceRequestNanos;
    private boolean awaitingConfirmation;

    public AutoBuy() {
        super("auto_buy", "Auto Buy", "Автоматически покупает вещи на аукционе", Category.UTILITY);
        store = new AutoBuyStore(this, FabricLoader.getInstance().getConfigDir()
                .resolve("celestial").resolve("autobuy.celka"));
        loadEntries();
        openInterface = addSetting(new ActionSetting(
                "open_interface", "Открыть интерфейс", this::openEditor
        ));

        ScreenEvents.AFTER_INIT.register((client, screen, scaledWidth, scaledHeight) -> {
            if (screen instanceof HandledScreen<?>) {
                ScreenEvents.afterRender(screen).register((rendered, context, mouseX, mouseY, delta) ->
                        processScreen(client, rendered));
            }
        });
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) {
                captureBalance(message);
            }
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, parameters, receivedAt) ->
                captureBalance(message));
    }

    public ActionSetting openInterface() {
        return openInterface;
    }

    public List<Entry> entries() {
        return List.copyOf(entries);
    }

    public int clickDelayMs() {
        return clickDelayMs;
    }

    public void setClickDelayMs(int value) {
        clickDelayMs = Math.max(0, Math.min(1000, value));
        saveEntries();
    }

    public AddMode addMode() {
        return addMode;
    }

    public void setAddMode(AddMode mode) {
        addMode = Objects.requireNonNull(mode, "mode");
        saveEntries();
    }

    public int editorCount() {
        return editorCount;
    }

    public void setEditorCount(int value) {
        editorCount = Math.max(1, Math.min(64, value));
        saveEntries();
    }

    public boolean editorEnchantedWithoutNbt() {
        return editorEnchantedWithoutNbt;
    }

    public void setEditorEnchantedWithoutNbt(boolean value) {
        editorEnchantedWithoutNbt = value;
        saveEntries();
    }

    public boolean addEntry(Item item, long minimumCount, long maximumPrice,
                            boolean enchantedWithoutNbt, Map<Identifier, Integer> enchantments) {
        Objects.requireNonNull(item, "item");
        if (item == Items.AIR || entries.stream().anyMatch(entry -> entry.item == item)) {
            return false;
        }
        entries.add(new Entry(item,
                clamp(minimumCount, 1L, 64L),
                clamp(maximumPrice, 1L, Integer.MAX_VALUE),
                enchantedWithoutNbt,
                sanitizeEnchantments(enchantments)));
        saveEntries();
        return true;
    }

    public boolean upsertLegacyCommandEntry(Item item, long minimumCount, long maximumPrice,
                                            Map<Identifier, Integer> enchantments) {
        Objects.requireNonNull(item, "item");
        boolean updated = entries.removeIf(entry -> entry.item == item);
        entries.add(new Entry(item, minimumCount, maximumPrice, false,
                copyEnchantments(enchantments)));
        saveEntries();
        return updated;
    }

    public boolean removeLegacyCommandEntry(Item item) {
        Objects.requireNonNull(item, "item");
        String translationKey = item.getTranslationKey();
        boolean removed = entries.removeIf(entry ->
                entry.item.getTranslationKey().equals(translationKey));
        if (removed) {
            saveEntries();
        }
        return removed;
    }

    public void updateEntry(Entry entry, long minimumCount, long maximumPrice,
                            boolean enchantedWithoutNbt, Map<Identifier, Integer> enchantments) {
        if (!entries.contains(entry)) {
            return;
        }
        entry.minimumCount = clamp(minimumCount, 1L, 64L);
        entry.maximumPrice = clamp(maximumPrice, 1L, Integer.MAX_VALUE);
        entry.enchantedWithoutNbt = enchantedWithoutNbt;
        entry.enchantments = sanitizeEnchantments(enchantments);
        saveEntries();
    }

    public void removeEntry(Entry entry) {
        if (entries.remove(entry)) {
            saveEntries();
        }
    }

    public void clearEntries() {
        if (!entries.isEmpty()) {
            entries.clear();
            saveEntries();
        }
    }

    public void saveEntries() {
        try {
            store.save();
        } catch (IOException exception) {
            CelestialPortClient.LOGGER.error("Unable to save legacy AutoBuy data", exception);
        }
    }

    void replaceLoadedState(List<Entry> loaded, int delay, AddMode mode, int count,
                            boolean enchantedWithoutNbt) {
        entries.clear();
        entries.addAll(loaded);
        clickDelayMs = Math.max(0, Math.min(1000, delay));
        addMode = mode == null ? AddMode.ID : mode;
        editorCount = Math.max(1, Math.min(64, count));
        editorEnchantedWithoutNbt = enchantedWithoutNbt;
    }

    private void loadEntries() {
        try {
            store.loadWithLegacyFallback(List.of(
                    Path.of("Celestial", "autobuy.celka"),
                    Path.of("autobuy.celka")
            ));
        } catch (IOException exception) {
            CelestialPortClient.LOGGER.error("Unable to load legacy AutoBuy data", exception);
        }
    }

    private void openEditor() {
        MinecraftClient client = MinecraftClient.getInstance();
        Screen parent = client.currentScreen;
        client.setScreen(new AutoBuyScreen(parent, this));
    }

    private void processScreen(MinecraftClient client, Screen rendered) {
        if (!enabled() || client.player == null || client.interactionManager == null
                || !(rendered instanceof HandledScreen<?> handled)) {
            return;
        }
        String title = handled.getTitle().getString();
        long now = System.nanoTime();
        if (CONFIRM_TITLE.equals(title)) {
            if (awaitingConfirmation && elapsed(now, lastConfirmNanos, clickDelayMs)) {
                ScreenHandler handler = handled.getScreenHandler();
                if (handler.slots.size() > CONFIRM_SLOT
                        && LegacyContainerActions.click(client, handler,
                        handler.getSlot(CONFIRM_SLOT), SlotActionType.PICKUP)) {
                    awaitingConfirmation = false;
                    lastConfirmNanos = now;
                }
            }
            return;
        }
        if (!AUCTION_TITLE.equals(title)) {
            return;
        }

        if (elapsed(now, lastBalanceRequestNanos, 10_000)) {
            if (client.getNetworkHandler() != null) {
                client.getNetworkHandler().sendChatCommand("balance");
            }
            lastBalanceRequestNanos = now;
        }

        ScreenHandler handler = handled.getScreenHandler();
        List<Offer> offers = new ArrayList<>();
        for (Slot slot : handler.slots) {
            if (LegacyContainerActions.isContainerSlot(client, slot) && slot.hasStack()) {
                OptionalLong parsed = parsePrice(slot.getStack());
                offers.add(new Offer(slot, parsed.orElse(0L), parsed.isPresent()));
            }
        }
        offers.sort(Comparator.comparingLong(Offer::sortPrice));

        int matchingOffers = 0;
        for (Offer offer : offers) {
            ItemStack stack = offer.slot.getStack();
            if (!allowedBlockItem(stack)) {
                continue;
            }
            for (Entry entry : entries) {
                if (entry.item != stack.getItem()
                        || entry.enchantedWithoutNbt && !stack.hasGlint()
                        || entry.minimumCount > stack.getCount()
                        || !matchesEnchantments(entry, stack)) {
                    continue;
                }
                if (offer.hasPrice) {
                    entry.currentPrice = offer.sortPrice;
                }

                if (entry.currentPrice > balance) {
                    return;
                }
                if (entry.currentPrice > entry.maximumPrice) {
                    continue;
                }
                matchingOffers++;
                if (elapsed(now, lastBuyNanos, clickDelayMs)
                        && LegacyContainerActions.click(client, handler, offer.slot, SlotActionType.PICKUP)) {
                    awaitingConfirmation = true;
                    lastBuyNanos = now;
                }
            }
        }

        if (matchingOffers == 0 && elapsed(now, lastRefreshNanos, 400)
                && handler.slots.size() > REFRESH_SLOT) {
            Slot refresh = handler.getSlot(REFRESH_SLOT);
            LegacyContainerActions.click(client, handler, refresh, SlotActionType.PICKUP);
            LegacyContainerActions.click(client, handler, refresh, SlotActionType.PICKUP);
            lastRefreshNanos = now;
        }
    }

    private void captureBalance(Text message) {
        String plain = message.getString();
        if (!plain.contains("Баланс:")) {
            return;
        }
        int dollar = plain.indexOf('$');
        if (dollar < 0) {
            return;
        }
        String digits = plain.substring(dollar + 1).replaceAll("\\D", "");
        if (digits.isEmpty()) {
            return;
        }
        try {
            balance = Long.parseLong(digits);
        } catch (NumberFormatException ignored) {

        }
    }

    private static OptionalLong parsePrice(ItemStack stack) {
        LoreComponent lore = stack.get(DataComponentTypes.LORE);
        if (lore == null) {
            return OptionalLong.empty();
        }
        for (Text line : lore.lines()) {
            String plain = line.getString().trim();
            if (!plain.contains("Цена:")) {
                continue;
            }
            String[] pieces = plain.split(" ");
            if (pieces.length < 2) {
                continue;
            }
            try {
                return OptionalLong.of(Long.parseLong(pieces[1]));
            } catch (NumberFormatException ignored) {
                return OptionalLong.empty();
            }
        }
        return OptionalLong.empty();
    }

    private static boolean allowedBlockItem(ItemStack stack) {
        if (!(stack.getItem() instanceof PlayerHeadItem)) {
            return true;
        }
        LoreComponent lore = stack.get(DataComponentTypes.LORE);
        if (lore == null) {
            return false;
        }
        for (Text line : lore.lines()) {
            String plain = line.getString().trim();
            if (!plain.contains("Название:")) {
                continue;
            }
            String value = plain.substring(plain.indexOf("Название:") + "Название:".length()).trim();
            return value.contains("Шар") || value.contains("Голова Люцифера");
        }
        return false;
    }

    private static boolean matchesEnchantments(Entry entry, ItemStack stack) {
        ItemEnchantmentsComponent component = stack.isOf(Items.ENCHANTED_BOOK)
                ? stack.getOrDefault(DataComponentTypes.STORED_ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT)
                : stack.getOrDefault(DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT);
        if (component.getSize() != entry.enchantments.size()) {
            return false;
        }
        for (var enchantment : component.getEnchantmentEntries()) {
            RegistryEntry<net.minecraft.enchantment.Enchantment> key = enchantment.getKey();
            Identifier id = key.getKey().map(RegistryKey::getValue).orElse(null);
            if (id == null || !Objects.equals(entry.enchantments.get(id), enchantment.getIntValue())) {
                return false;
            }
        }
        return true;
    }

    private static boolean elapsed(long now, long then, int milliseconds) {
        return then == 0L || now - then >= (long) milliseconds * 1_000_000L;
    }

    private static long clamp(long value, long minimum, long maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static LinkedHashMap<Identifier, Integer> sanitizeEnchantments(
            Map<Identifier, Integer> enchantments
    ) {
        LinkedHashMap<Identifier, Integer> result = new LinkedHashMap<>();
        if (enchantments != null) {
            enchantments.forEach((id, level) -> {
                if (id != null && level != null && level > 0) {
                    result.put(id, level);
                }
            });
        }
        return result;
    }

    private static LinkedHashMap<Identifier, Integer> copyEnchantments(
            Map<Identifier, Integer> enchantments
    ) {
        LinkedHashMap<Identifier, Integer> result = new LinkedHashMap<>();
        if (enchantments != null) {
            enchantments.forEach((id, level) -> {
                if (id != null && level != null) {
                    result.put(id, level);
                }
            });
        }
        return result;
    }

    public enum AddMode {
        ID("ID"), NAME("Названию");

        private final String label;

        AddMode(String label) {
            this.label = label;
        }

        public String label() {
            return label;
        }

        static AddMode parse(String value) {
            return "Названию".equalsIgnoreCase(value) ? NAME : ID;
        }
    }

    public static final class Entry {
        private final Item item;
        private long minimumCount;
        private long maximumPrice;
        private long currentPrice;
        private boolean enchantedWithoutNbt;
        private LinkedHashMap<Identifier, Integer> enchantments;

        Entry(Item item, long minimumCount, long maximumPrice, boolean enchantedWithoutNbt,
              Map<Identifier, Integer> enchantments) {
            this.item = Objects.requireNonNull(item, "item");
            this.minimumCount = minimumCount;
            this.maximumPrice = maximumPrice;
            this.enchantedWithoutNbt = enchantedWithoutNbt;
            this.enchantments = copyEnchantments(enchantments);
        }

        public Item item() {
            return item;
        }

        public ItemStack stack() {
            return item.getDefaultStack();
        }

        public long minimumCount() {
            return minimumCount;
        }

        public long maximumPrice() {
            return maximumPrice;
        }

        public long currentPrice() {
            return currentPrice;
        }

        public boolean enchantedWithoutNbt() {
            return enchantedWithoutNbt;
        }

        public Map<Identifier, Integer> enchantments() {
            return Map.copyOf(enchantments);
        }

        public String enchantmentSummary() {
            if (enchantments.isEmpty()) {
                return "\u00A7cПусто";
            }
            return enchantments.entrySet().stream()
                    .map(value -> {
                        String name = localizedEnchantmentName(value.getKey());
                        String prefix = name.substring(0, Math.min(2, name.length()));
                        return "\u00A7c" + prefix
                                + (value.getValue() == 1 ? "" : value.getValue());
                    })
                    .sorted()
                    .reduce((left, right) -> left + ", " + right)
                    .orElse("\u00A7cПусто");
        }

        private static String localizedEnchantmentName(Identifier id) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) {
                return id.getPath();
            }
            var registry = client.player.getRegistryManager()
                    .getOrThrow(RegistryKeys.ENCHANTMENT);
            for (var entry : registry.getEntrySet()) {
                if (entry.getKey().getValue().equals(id)) {
                    return entry.getValue().description().getString();
                }
            }
            return id.getPath();
        }

        @Override
        public boolean equals(Object object) {
            return object instanceof Entry other && item == other.item;
        }

        @Override
        public int hashCode() {
            return System.identityHashCode(item);
        }
    }

    private record Offer(Slot slot, long sortPrice, boolean hasPrice) {
    }
}
