package celestial.port.modules.movement;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ModeSetting;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.GameMode;

import java.util.List;

public final class Spider extends Module {
    private static final String MATRIX = "Matrix";
    private static final String SUNRISE = "Sunrise";

    private static volatile Spider instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", MATRIX, List.of(MATRIX, SUNRISE)
    ));

    private long lastMatrixJump = System.currentTimeMillis();
    private boolean rewritePending;
    private boolean forceOnGround;
    private int preparedAge = Integer.MIN_VALUE;
    private int rewrittenAge = Integer.MIN_VALUE;
    private double packetXOffset;
    private double packetZOffset;

    public Spider() {
        super("spider", "Spider", "Позволяет взбираться по стенам", Category.MOVEMENT);
        instance = this;
    }

    public ModeSetting mode() {
        return mode;
    }

    public static void beforeMovementPackets(ClientPlayerEntity player) {
        Spider module = active();
        if (module != null) {
            module.prepare(player);
        }
    }

    public static Packet<?> rewriteMovementPacket(Packet<?> packet) {
        Spider module = active();
        if (module == null || !(packet instanceof PlayerMoveC2SPacket movement)) {
            return packet;
        }
        return module.rewrite(movement);
    }

    private void prepare(ClientPlayerEntity player) {
        rewritePending = false;
        forceOnGround = false;
        packetXOffset = 0.0;
        packetZOffset = 0.0;
        preparedAge = player.age;

        if (!player.horizontalCollision) {
            return;
        }

        if (mode.is(MATRIX)) {
            if (!hasMovementInput(player)) {
                return;
            }
            long now = System.currentTimeMillis();
            if (now - lastMatrixJump > 150L) {
                forceOnGround = true;
                player.jump();
                lastMatrixJump = now;
            }
            applyPacketPush(player);
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        int blockSlot = findBlockSlot(player);
        if (blockSlot == -1 || client.interactionManager == null
                || client.interactionManager.getCurrentGameMode() == GameMode.ADVENTURE) {
            return;
        }

        if (player.age % 3 == 0) {
            performSunriseInteraction(client, player, blockSlot);
            forceOnGround = true;
            player.jump();
        }
        applyPacketPush(player);
    }

    private void applyPacketPush(ClientPlayerEntity player) {
        float direction = (float) MovementSupport.legacyMovementYaw(player);
        packetXOffset = -(double) (-MathHelper.sin(direction) * 0.1F);
        packetZOffset = -(double) (MathHelper.cos(direction) * 0.1F);
        rewritePending = true;
    }

    private void performSunriseInteraction(MinecraftClient client, ClientPlayerEntity player, int blockSlot) {
        int selected = player.getInventory().getSelectedSlot();
        boolean switched = blockSlot >= 0;
        if (switched) {
            player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(blockSlot));
            player.getInventory().setSelectedSlot(blockSlot);
        }

        float pitch = player.getPitch();
        player.setPitch(-60.0f);
        client.gameRenderer.updateCrosshairTarget(1.0f);
        BlockHitResult hit = client.crosshairTarget instanceof BlockHitResult blockHit ? blockHit : null;

        sendSneakState(player, true);
        if (hit != null) {
            BlockPos aboveHead = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ()).up(2);
            if (player.getEntityWorld().getBlockState(aboveHead).isOf(Blocks.AIR)) {
                client.interactionManager.interactBlock(player, Hand.MAIN_HAND, hit);
            } else {
                player.networkHandler.sendPacket(new PlayerActionC2SPacket(
                        PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, hit.getBlockPos(), hit.getSide()));
                player.networkHandler.sendPacket(new PlayerActionC2SPacket(
                        PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK, hit.getBlockPos(), hit.getSide()));
                player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            }
        }
        sendSneakState(player, false);

        player.setPitch(pitch);
        client.gameRenderer.updateCrosshairTarget(1.0f);
        if (switched) {
            player.getInventory().setSelectedSlot(selected);
            player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(selected));
        }
    }

    private Packet<?> rewrite(PlayerMoveC2SPacket packet) {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (!rewritePending || player == null || player.age != preparedAge || rewrittenAge == preparedAge) {
            return packet;
        }
        rewrittenAge = preparedAge;
        rewritePending = false;

        double x = packet.getX(player.getX()) + packetXOffset;
        double y = packet.getY(player.getY());
        double z = packet.getZ(player.getZ()) + packetZOffset;
        boolean onGround = forceOnGround || packet.isOnGround();
        boolean horizontalCollision = packet.horizontalCollision();

        if (packet.changesLook()) {
            return new PlayerMoveC2SPacket.Full(x, y, z,
                    packet.getYaw(player.getYaw()), packet.getPitch(player.getPitch()),
                    onGround, horizontalCollision);
        }
        return new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, onGround, horizontalCollision);
    }

    private static int findBlockSlot(ClientPlayerEntity player) {
        if (player.getMainHandStack().getItem() instanceof BlockItem) {
            return -2;
        }
        for (int slot = 0; slot < 9; slot++) {
            if (player.getInventory().getStack(slot).getItem() instanceof BlockItem) {
                return slot;
            }
        }
        return -1;
    }

    private static void sendSneakState(ClientPlayerEntity player, boolean sneaking) {
        PlayerInput input = player.input == null ? PlayerInput.DEFAULT : player.input.playerInput;
        player.networkHandler.sendPacket(new PlayerInputC2SPacket(new PlayerInput(
                input.forward(), input.backward(), input.left(), input.right(),
                input.jump(), sneaking, input.sprint())));
    }

    private static boolean hasMovementInput(ClientPlayerEntity player) {
        return player.forwardSpeed != 0.0f || player.sidewaysSpeed != 0.0f;
    }

    private static Spider active() {
        Spider module = instance;
        return module != null && module.enabled() ? module : null;
    }
}
