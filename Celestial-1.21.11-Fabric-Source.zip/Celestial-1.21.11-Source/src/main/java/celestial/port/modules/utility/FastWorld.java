package celestial.port.modules.utility;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;

public final class FastWorld extends Module {
    public FastWorld() {
        super("fast_world", "Fast World", "Быстро прогружает мир", Category.UTILITY);
    }

    public static boolean skipsCrashWorldUnload() {
        return CelestialPortClient.MODULES.find("fast_world")
                .map(Module::enabled)
                .orElse(false);
    }
}
