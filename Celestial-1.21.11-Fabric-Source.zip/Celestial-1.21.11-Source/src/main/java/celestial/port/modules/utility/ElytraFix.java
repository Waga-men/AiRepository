package celestial.port.modules.utility;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.modules.inventory.ElytraSwap;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.ShulkerBoxScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.EquippableComponent;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.util.List;
import java.util.OptionalInt;

public final class ElytraFix extends Module {
    private static final String ELYTRA = "Элитру";
    private static final String CHESTPLATE = "Нагрудник";
    private static final String BALL = "Шар";
    private static final Item[] CHESTPLATE_ORDER = {
            Items.DIAMOND_CHESTPLATE,
            Items.IRON_CHESTPLATE,
            Items.LEATHER_CHESTPLATE,
            Items.GOLDEN_CHESTPLATE,
            Items.CHAINMAIL_CHESTPLATE
    };

    private static ElytraFix instance;

    private final MultiSelectSetting doNotDrop = addSetting(new MultiSelectSetting(
            "do_not_drop", "Не выкидывать",
            List.of(ELYTRA, CHESTPLATE),
            List.of(ELYTRA, CHESTPLATE, BALL)
    ));
    private long nextChestSwapAt;

    public ElytraFix() {
        super("elytra_fix", "Elytra Fix",
                "Автоматически надевает нагрудник вместо элитр", Category.UTILITY);
        instance = this;
    }

    public MultiSelectSetting doNotDrop() {
        return doNotDrop;
    }

    public static boolean shouldCancelClick(int syncId, int slotId, SlotActionType actionType) {
        ElytraFix module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || client.player == null || slotId < 0
                || actionType == SlotActionType.QUICK_MOVE || actionType == SlotActionType.SWAP) {
            return false;
        }
        ScreenHandler handler = client.player.currentScreenHandler;
        if (handler == null || handler.syncId != syncId || slotId >= handler.slots.size()) {
            return false;
        }
        return module.isProtected(handler.getSlot(slotId).getStack());
    }

    public static boolean shouldCancelOutgoing(Packet<?> packet) {
        ElytraFix module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !(packet instanceof CloseHandledScreenC2SPacket)
                || client.player == null
                || !module.isProtected(client.player.currentScreenHandler.getCursorStack())) {
            return false;
        }
        module.recoverProtectedCursor(client);
        return true;
    }

    public boolean shouldProtectFromDrop(ItemStack stack) {
        return enabled() && isProtected(stack);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.interactionManager == null || !client.player.isAlive()) {
            return;
        }

        if (moduleEnabled("elytra_flight") || reallyWorldFlightEnabled()) {
            return;
        }
        recoverProtectedCursor(client);
        if (ElytraSwap.keepingElytra()
                || System.currentTimeMillis() <= nextChestSwapAt) {
            return;
        }
        replaceEquippedElytra(client);
        nextChestSwapAt = System.currentTimeMillis() + 150L;
    }

    private void recoverProtectedCursor(MinecraftClient client) {
        if (client.currentScreen instanceof GenericContainerScreen
                || client.currentScreen instanceof CreativeInventoryScreen
                || client.currentScreen instanceof ShulkerBoxScreen) {
            return;
        }

        ScreenHandler handler = client.player.playerScreenHandler;
        ItemStack cursor = handler.getCursorStack();
        if (cursor.isEmpty()) {
            return;
        }
        PlayerInventory inventory = client.player.getInventory();
        int armor = firstArmor(inventory);
        boolean hasArmor = armor != PlayerInventory.NOT_FOUND;
        if (!hasArmor) {
            return;
        }

        boolean lostLastProtectedStack = doNotDrop.selected(ELYTRA)
                && cursor.isOf(Items.ELYTRA) && first(inventory, Items.ELYTRA) == PlayerInventory.NOT_FOUND;
        lostLastProtectedStack |= doNotDrop.selected(CHESTPLATE)
                && cursor.isOf(Items.DIAMOND_CHESTPLATE)
                && findChestplate(inventory, cursor) == -1;
        lostLastProtectedStack |= doNotDrop.selected(BALL)
                && isBall(cursor) && firstBall(inventory) == PlayerInventory.NOT_FOUND;
        if (!lostLastProtectedStack) {
            return;
        }

        OptionalInt slot = handler.getSlotIndex(inventory, armor);
        slot.ifPresent(value -> click(client, handler, value));
    }

    private void replaceEquippedElytra(MinecraftClient client) {
        if (!client.player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)
                || client.player.currentScreenHandler != client.player.playerScreenHandler) {
            return;
        }
        PlayerInventory inventory = client.player.getInventory();
        ScreenHandler handler = client.player.playerScreenHandler;
        ItemStack cursor = handler.getCursorStack();
        int chestplate = findChestplate(inventory, cursor);
        OptionalInt chestSlot = handler.getSlotIndex(inventory,
                UtilityInventoryActions.CHEST_INVENTORY_INDEX);
        if (chestSlot.isEmpty() || chestplate == -2) {
            return;
        }
        if (chestplate == -1) {
            click(client, handler, chestSlot.getAsInt());
            return;
        }
        OptionalInt inventorySlot = handler.getSlotIndex(inventory, chestplate);
        if (inventorySlot.isEmpty()) {
            return;
        }
        click(client, handler, inventorySlot.getAsInt());
        click(client, handler, chestSlot.getAsInt());
        click(client, handler, inventorySlot.getAsInt());
    }

    private void click(MinecraftClient client, ScreenHandler handler, int slotId) {
        client.interactionManager.clickSlot(handler.syncId, slotId, 1,
                SlotActionType.PICKUP, client.player);
    }

    private static int findChestplate(PlayerInventory inventory, ItemStack cursor) {
        for (Item chestplate : CHESTPLATE_ORDER) {
            if (cursor.isOf(chestplate)) {
                return -1;
            }
            int found = first(inventory, chestplate);
            if (found != PlayerInventory.NOT_FOUND) {
                return found;
            }
        }
        return -2;
    }

    private boolean isProtected(ItemStack stack) {
        return doNotDrop.selected(ELYTRA) && stack.isOf(Items.ELYTRA)
                || doNotDrop.selected(CHESTPLATE) && stack.isOf(Items.DIAMOND_CHESTPLATE)
                || doNotDrop.selected(BALL) && isBall(stack);
    }

    private static boolean isBall(ItemStack stack) {
        return stack.isOf(Items.PLAYER_HEAD)
                || stack.isOf(Items.SKELETON_SKULL)
                || stack.isOf(Items.WITHER_SKELETON_SKULL)
                || stack.isOf(Items.ZOMBIE_HEAD)
                || stack.isOf(Items.CREEPER_HEAD)
                || stack.isOf(Items.DRAGON_HEAD);
    }

    private static int firstArmor(PlayerInventory inventory) {
        for (int index = 9; index < PlayerInventory.MAIN_SIZE; index++) {
            EquippableComponent equippable = inventory.getStack(index).get(DataComponentTypes.EQUIPPABLE);
            if (equippable != null && switch (equippable.slot()) {
                case HEAD, CHEST, LEGS, FEET -> true;
                default -> false;
            }) return index;
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int first(PlayerInventory inventory, Item item) {
        for (int index = 0; index < inventory.size(); index++) {
            if (inventory.getStack(index).isOf(item)) return index;
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int firstBall(PlayerInventory inventory) {
        for (int index = 0; index < inventory.size(); index++) {
            if (isBall(inventory.getStack(index))) return index;
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static ElytraFix active() {
        ElytraFix module = instance;
        return module != null && module.enabled() ? module : null;
    }

    private static boolean moduleEnabled(String id) {
        return CelestialPortClient.MODULES.find(id).filter(Module::enabled).isPresent();
    }

    private static boolean reallyWorldFlightEnabled() {
        Module flight = CelestialPortClient.MODULES.find("flight").orElse(null);
        if (flight == null || !flight.enabled()) return false;
        return flight.setting("mode")
                .map(setting -> String.valueOf(setting.value()))
                .map(value -> value.equalsIgnoreCase("Really World Elytra"))
                .orElse(false);
    }

}
