package celestial.port.modules.visual;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;

public interface WorldVisual {
    void collectVisuals(WorldExtractionContext context);
}
