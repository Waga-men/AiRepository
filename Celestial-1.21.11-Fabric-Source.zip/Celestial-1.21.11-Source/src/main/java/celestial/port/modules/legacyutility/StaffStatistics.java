package celestial.port.modules.legacyutility;

import celestial.port.client.audio.WavPlayer;
import celestial.port.client.ui.ClientFeedback;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.staff.ManualStaffRegistry;
import celestial.port.modules.player.AutoLeave;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.util.Identifier;
import net.minecraft.world.GameMode;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class StaffStatistics extends Module {
    private static final Identifier STAFF_ICON = Identifier.of("celestial", "images/staff.png");
    private static final String JOIN_INFO = "Информация о заходе";
    private static final String ALARM = "Тревога";
    private static final Set<String> RANKS = Set.of(
            "админ", "admin", "ml.admin", "moder", "st.moder", "s.moder",
            "gl.moder", "j.moder", "модератор", "модер", "st.helper",
            "хелпер", "helper", "helper+", "yt", "yt+"
    );

    private final MultiSelectSetting notifications = addSetting(new MultiSelectSetting(
            "notifications", "Уведомления", Set.of(JOIN_INFO), List.of(JOIN_INFO, ALARM)
    ));
    private final BooleanSetting drawTable = addSetting(new BooleanSetting(
            "draw_table", "Рисовать таблицу", true
    ));

    private final Map<UUID, StaffEntry> staff = new LinkedHashMap<>();
    private final Set<UUID> offlineState = new HashSet<>();

    public StaffStatistics() {
        super("staff_statistics", "Staff Statistics",
                "Отображает активность администрации", Category.UTILITY);
    }

    public MultiSelectSetting notifications() {
        return notifications;
    }

    public BooleanSetting drawTable() {
        return drawTable;
    }

    public List<StaffEntry> entries() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (drawTable.enabled() && !client.options.hudHidden
                && client.player != null && client.world != null
                && client.getNetworkHandler() != null) {

            AutoLeave.tickSharedStaffTracker(client, true);
            refreshRenderedStatuses(client);
        }
        synchronized (staff) {
            return staff.values().stream()
                    .sorted(Comparator.comparingInt(entry -> rankPriority(entry.rank())))
                    .toList();
        }
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.getNetworkHandler() == null) {
            clearEntries();
            AutoLeave.clearSharedStaffTracker();
            return;
        }

        AutoLeave.tickSharedStaffTracker(client, false);

        Map<UUID, StaffEntry> detected = new LinkedHashMap<>();
        for (PlayerListEntry tabEntry : client.getNetworkHandler().getListedPlayerListEntries()) {
            if (tabEntry.getProfile().id().equals(client.player.getUuid())) {
                continue;
            }
            String profileName = tabEntry.getProfile().name();
            String decorated = tabEntry.getDisplayName() == null
                    ? profileName : tabEntry.getDisplayName().getString();
            String rank = detectRank(decorated, profileName);
            if (rank == null && !ManualStaffRegistry.matchesFormattedName(decorated)) {
                continue;
            }
            if (rank == null) rank = "";
            Status status = status(client, tabEntry.getProfile().id(), tabEntry);
            detected.put(tabEntry.getProfile().id(), new StaffEntry(
                    tabEntry.getProfile().id(), profileName, rank, decorated, status
            ));
        }

        synchronized (staff) {
            for (StaffEntry entry : detected.values()) {
                StaffEntry previous = staff.put(entry.uuid(), entry);
                if (previous == null) {
                    offlineState.add(entry.uuid());
                    onStaffDetected(client, entry);
                }
            }
            List<StaffEntry> left = new ArrayList<>();
            for (StaffEntry previous : staff.values()) {
                if (!detected.containsKey(previous.uuid())
                        && offlineState.contains(previous.uuid())) {
                    left.add(previous);
                    ClientFeedback.staffLeave(previous.name() + " вышел с сервера!");
                }
            }
            for (StaffEntry entry : left) {
                staff.remove(entry.uuid());
                offlineState.remove(entry.uuid());
            }
        }
    }

    private void refreshRenderedStatuses(MinecraftClient client) {
        Map<UUID, PlayerListEntry> listed = new LinkedHashMap<>();
        for (PlayerListEntry entry : client.getNetworkHandler().getListedPlayerListEntries()) {
            listed.put(entry.getProfile().id(), entry);
        }
        synchronized (staff) {
            for (Map.Entry<UUID, StaffEntry> tracked : staff.entrySet()) {
                UUID uuid = tracked.getKey();
                StaffEntry current = tracked.getValue();
                PlayerListEntry tabEntry = listed.get(uuid);
                Status nextStatus = status(client, uuid, tabEntry);
                if (nextStatus == Status.OFFLINE) {
                    if (offlineState.add(uuid) && notifications.selected(ALARM)
                            && client.isWindowFocused() && isDangerous(current.rank())) {
                        WavPlayer.play("/assets/celestial/sounds/staffstatistics/dangerous.wav", 1.0F);
                    }
                } else {
                    offlineState.remove(uuid);
                }
                if (current.status() != nextStatus) {
                    tracked.setValue(new StaffEntry(
                            current.uuid(), current.name(), current.rank(),
                            current.decoratedName(), nextStatus
                    ));
                }
            }
        }
    }

    private void onStaffDetected(MinecraftClient client, StaffEntry entry) {
        if (notifications.selected(JOIN_INFO)) {
            ClientFeedback.info("Staff Alert Debug",
                    entry.rank().toUpperCase(Locale.ROOT) + " " + entry.name()
                            + " зашел в ваниш/на сервер", 15);
        }
    }

    public HudRenderBounds renderHudAt(DrawContext context, int requestedX, int requestedY) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!drawTable.enabled() || client.options.hudHidden) {
            return HudRenderBounds.EMPTY;
        }
        List<StaffEntry> snapshot = entries();
        TextRenderer renderer = client.textRenderer;
        int width = 100;
        for (StaffEntry entry : snapshot) {
            width = Math.max(width, renderer.getWidth(row(entry)) + 10);
        }
        int height = snapshot.isEmpty() ? 30 : Math.max(27, snapshot.size() * 10 + 15);
        int x = Math.max(0, Math.min(requestedX,
                Math.max(0, context.getScaledWindowWidth() - width)));
        int y = Math.max(0, Math.min(requestedY,
                Math.max(0, context.getScaledWindowHeight() - height)));

        context.fill(x, y, x + width, y + height, 0xD90A0A0A);
        context.fill(x, y, x + width, y + 1, 0xFFBE65FF);
        String title = "Staff Statistics";
        context.drawText(renderer, title, x + (width - renderer.getWidth(title)) / 2,
                y + 3, 0xFFEBEBEB, false);

        if (snapshot.isEmpty()) {
            context.drawTexturedQuad(STAFF_ICON, x + 2, y + 11, x + 18, y + 27,
                    0.0f, 1.0f, 0.0f, 1.0f);
            context.drawText(renderer, "Список пуст", x + 20, y + 12, 0xFFEBEBEB, false);
            context.drawText(renderer, "Персонал ещё не зашел!", x + 20, y + 21,
                    0xFFAAAAAA, false);
            return new HudRenderBounds(x, y, width, height);
        }

        int rowY = y + 15;
        for (StaffEntry entry : snapshot) {
            int statusColor = entry.status() == Status.OFFLINE ? 0xFFFF5555 : 0xFF55FF55;
            String status = entry.status().label();
            context.drawText(renderer, status, x + 1, rowY, statusColor, false);
            context.drawText(renderer, " " + entry.rank() + " " + entry.name(),
                    x + 1 + renderer.getWidth(status), rowY, 0xFFEBEBEB, false);
            rowY += 10;
        }
        return new HudRenderBounds(x, y, width, height);
    }

    private static String row(StaffEntry entry) {
        return entry.status().label() + " " + entry.rank() + " " + entry.name();
    }

    private static Status status(MinecraftClient client, UUID uuid, PlayerListEntry entry) {
        for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
            if (player.getUuid().equals(uuid)) {
                return Status.NEARBY;
            }
        }
        if (entry == null) {
            return Status.OFFLINE;
        }
        if (entry.getGameMode() == GameMode.SPECTATOR) {
            return Status.SPECTATOR;
        }
        return Status.VANISHED;
    }

    private static String detectRank(String decorated, String profileName) {
        String normalized = decorated.toLowerCase(Locale.ROOT)
                .replace('[', ' ').replace(']', ' ').replace(':', ' ').strip();
        String[] words = normalized.split("\\s+");
        for (String word : words) {
            for (String rank : RANKS) {
                if (word.startsWith(rank)) {
                    return word;
                }
            }
        }

        String withoutName = normalized.replace(profileName.toLowerCase(Locale.ROOT), " ");
        for (String rank : RANKS) {
            if (withoutName.contains(rank)) {
                return rank;
            }
        }
        return null;
    }

    private static boolean isDangerous(String rank) {
        String normalized = rank.toLowerCase(Locale.ROOT);
        return normalized.contains("moder") || normalized.contains("admin")
                || normalized.contains("модер") || normalized.contains("админ");
    }

    private static int rankPriority(String rank) {
        return switch (rank.toLowerCase(Locale.ROOT)) {
            case "admin", "админ" -> 0;
            case "ml.admin" -> 1;
            case "gl.moder" -> 2;
            case "st.moder", "s.moder" -> 3;
            case "moder", "модератор", "модер" -> 4;
            case "j.moder" -> 5;
            case "st.helper" -> 6;
            case "helper+", "хелпер+" -> 7;
            case "helper", "хелпер" -> 8;
            case "yt+" -> 9;
            case "yt" -> 10;
            default -> 11;
        };
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        clearEntries();
        AutoLeave.clearSharedStaffTracker();
    }

    @Override
    protected void onDisable() {
        clearEntries();
        AutoLeave.clearSharedStaffTracker();
    }

    @Override
    protected void onEnable() {
        clearEntries();
        AutoLeave.clearSharedStaffTracker();
    }

    private void clearEntries() {
        synchronized (staff) {
            staff.clear();
            offlineState.clear();
        }
    }

    public enum Status {
        NEARBY("[N]"),
        VANISHED(""),
        SPECTATOR("[GM3]"),
        OFFLINE("[S]");

        private final String label;

        Status(String label) {
            this.label = label;
        }

        public String label() {
            return label;
        }
    }

    public record StaffEntry(
            UUID uuid, String name, String rank, String decoratedName, Status status
    ) {
    }

    public record HudRenderBounds(int x, int y, int width, int height) {
        public static final HudRenderBounds EMPTY = new HudRenderBounds(0, 0, 0, 0);

        public boolean visible() {
            return width > 0 && height > 0;
        }
    }
}
