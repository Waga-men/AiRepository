package celestial.port.modules.rendering;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.NumberSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.render.LightmapTextureManager;
import net.minecraft.client.render.WeatherRendering;
import net.minecraft.client.render.state.WeatherRenderState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.Random;

public final class CustomWorld extends Module implements WorldGizmoModule {
    private static volatile CustomWorld instance;

    private final BooleanSetting nightMode = addSetting(new BooleanSetting(
            "night_mode", "Ночной режим", false
    ));
    private final NumberSetting brightness = addSetting(new NumberSetting(
            "brightness", "Яркость", 0.5, 0.0, 0.9, 0.1
    ).visibleWhen(nightMode::enabled));
    private final BooleanSetting fog = addSetting(new BooleanSetting(
            "fog", "Туман", true
    ));
    private final ColorSetting fogColor = addSetting(new ColorSetting(
            "fog_color", "Цвет", 0xFFBE65FF, false
    ).visibleWhen(fog::enabled));
    private final NumberSetting fogDistance = addSetting(new NumberSetting(
            "fog_distance", "Дистанция тумана", 1.0, 0.2, 1.5, 0.1
    ).visibleWhen(fog::enabled));
    private final BooleanSetting snow = addSetting(new BooleanSetting(
            "snow", "Снег", false
    ));

    private Double previousGamma;

    public CustomWorld() {
        super("custom_world", "Custom World", "Кастомная настройка мира", Category.RENDER);
        instance = this;
    }

    public BooleanSetting nightMode() {
        return nightMode;
    }

    public NumberSetting brightness() {
        return brightness;
    }

    public BooleanSetting fog() {
        return fog;
    }

    public ColorSetting fogColor() {
        return fogColor;
    }

    public NumberSetting fogDistance() {
        return fogDistance;
    }

    public BooleanSetting snow() {
        return snow;
    }

    @Override
    protected void onTick() {
        GameOptions options = MinecraftClient.getInstance().options;
        if (nightMode.enabled()) {
            if (previousGamma == null) {
                previousGamma = options.getGamma().getValue();
            }
            options.getGamma().setValue(brightness.value());
        } else {
            restoreGamma(options);
        }
    }

    @Override
    protected void onDisable() {
        restoreGamma(MinecraftClient.getInstance().options);
    }

    private void restoreGamma(GameOptions options) {
        if (previousGamma != null) {
            options.getGamma().setValue(previousGamma);
            previousGamma = null;
        }
    }

    @Override
    public void collectGizmos(WorldExtractionContext context) {
        if (!snow.enabled()) {
            return;
        }

        WeatherRenderState weather = context.worldState().weatherRenderState;
        weather.rainPieces.clear();
        weather.snowPieces.clear();

        MinecraftClient client = MinecraftClient.getInstance();
        int radius = client.options.getPreset().getValue() == GraphicsMode.FAST ? 5 : 10;
        weather.radius = radius;
        weather.intensity = 10.0F;

        BlockPos cameraPos = context.camera().getBlockPos();
        int cameraX = cameraPos.getX();
        int cameraY = cameraPos.getY();
        int cameraZ = cameraPos.getZ();
        int ticks = client.inGameHud.getTicks();
        float partial = context.tickCounter().getTickProgress(false);
        float time = (float) ticks + partial;
        float scroll = -((float) (ticks & 511) + partial) / 512.0F;
        Random random = new Random();

        for (int z = cameraZ - radius; z <= cameraZ + radius; z++) {
            for (int x = cameraX - radius; x <= cameraX + radius; x++) {
                int surfaceY = context.world().getTopY(Heightmap.Type.MOTION_BLOCKING, x, z);
                int bottomY = Math.max(cameraY - radius, surfaceY);
                int topY = Math.max(cameraY + radius, surfaceY);
                if (bottomY == topY) {
                    continue;
                }

                long seed = ((long) x * x * 3121L + (long) x * 45238971L)
                        ^ ((long) z * z * 418711L + (long) z * 13761L);
                random.setSeed(seed);
                float uOffset = (float) (random.nextDouble()
                        + (double) time * 0.01D * (double) (float) random.nextGaussian());
                float vJitter = (float) (random.nextDouble()
                        + (double) (time * (float) random.nextGaussian()) * 0.001D);

                weather.snowPieces.add(new WeatherRendering.Piece(
                        x,
                        z,
                        bottomY,
                        topY,
                        uOffset,
                        scroll + vJitter,
                        LightmapTextureManager.MAX_LIGHT_COORDINATE
                ));
            }
        }
    }

    public static boolean customFogActive() {
        CustomWorld module = instance;
        return module != null && module.enabled() && module.fog.enabled();
    }

    public static int selectedFogColor() {
        CustomWorld module = instance;
        return module == null ? 0xFFFFFFFF : module.fogColor.argb();
    }

    public static float selectedFogDistance() {
        CustomWorld module = instance;
        return module == null ? 1.0F : module.fogDistance.value().floatValue();
    }
}
