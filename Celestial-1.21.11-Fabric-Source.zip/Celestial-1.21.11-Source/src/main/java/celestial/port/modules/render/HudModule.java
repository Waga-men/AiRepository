package celestial.port.modules.render;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;

import java.util.List;
import java.util.Set;

public final class HudModule extends Module {
    private static final List<String> ELEMENT_OPTIONS = List.of(
            "Отладчик убийств", "Кейбинды", "Ватермарк", "Броня", "Зелья", "Координаты");

    private final MultiSelectSetting elements = addSetting(new MultiSelectSetting(
            "elements", "Элементы",
            Set.of("Кейбинды", "Ватермарк", "Броня", "Зелья", "Координаты"),
            ELEMENT_OPTIONS));
    private final ModeSetting potionPosition = addSetting(new ModeSetting(
            "potion_position", "Позиция зелий", "Слева посередине",
            List.of("Слева посередине", "Справа посередине", "Слева сверху", "Справа сверху"))
            .visibleWhen(() -> elements.selected("Зелья")));
    private final BooleanSetting potionBackground = addSetting(new BooleanSetting(
            "potion_background", "Задний фон зелий", true)
            .visibleWhen(() -> elements.selected("Зелья")));

    public HudModule() {
        super("hud", "HUD", "Shows the Celestial HUD branding", Category.RENDER);
    }

    public boolean shows(String element) {
        String visibleName = switch (element) {
            case "Kill Feed" -> "Отладчик убийств";
            case "Keybinds" -> "Кейбинды";
            case "Watermark" -> "Ватермарк";
            case "Armor" -> "Броня";
            case "Potions" -> "Зелья";
            case "Coordinates" -> "Координаты";
            default -> element;
        };
        return elements.selected(visibleName);
    }
    public boolean potionBackground() { return potionBackground.enabled(); }
    public String potionPosition() {
        return switch (potionPosition.value()) {
            case "Справа посередине" -> "Right Middle";
            case "Слева сверху" -> "Left Top";
            case "Справа сверху" -> "Right Top";
            default -> "Left Middle";
        };
    }
}
