package celestial.port.modules.render;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;

import java.util.List;

public final class ArrayListModule extends Module {
    private final ModeSetting colorMode = addSetting(new ModeSetting(
            "color_mode", "Режим", "Fade", List.of("Fade", "Astolfo", "Rainbow", "Static")));
    private final ColorSetting staticColor = addSetting(new ColorSetting(
            "static_color", "Цвет", 0xFFC87DFF, false).visibleWhen(() -> colorMode.is("Static")));
    private final ColorSetting fadeFirst = addSetting(new ColorSetting(
            "fade_first", "Первый цвет", 0xFFBE65FF, false).visibleWhen(() -> colorMode.is("Fade")));
    private final ColorSetting fadeSecond = addSetting(new ColorSetting(
            "fade_second", "Второй цвет", 0xFF3E1568, false).visibleWhen(() -> colorMode.is("Fade")));
    private final NumberSetting colorSpeed = addSetting(new NumberSetting(
            "color_speed", "Скорость цвета", 1.0, 1.0, 5.0, 1.0));
    private final NumberSetting yOffset = addSetting(new NumberSetting(
            "y_offset", "Смещение по Y", 0.7, 0.5, 0.8, 0.1));
    private final BooleanSetting renderFunctions = addSetting(new BooleanSetting(
            "render_functions", "Рендер функции", false));
    private final BooleanSetting lowercase = addSetting(new BooleanSetting(
            "lowercase", "Маленькие буквы", false));

    public ArrayListModule() {
        super("array_list", "Array List", "Shows enabled modules on the HUD", Category.RENDER);
    }

    public String colorMode() { return colorMode.value(); }
    public int staticColor() { return staticColor.argb(); }
    public int fadeFirstColor() { return fadeFirst.argb(); }
    public int fadeSecondColor() { return fadeSecond.argb(); }
    public double colorSpeed() { return colorSpeed.value(); }
    public double yOffset() { return yOffset.value(); }
    public boolean lowercase() { return lowercase.enabled(); }
    public boolean renderFunctions() { return renderFunctions.enabled(); }
}
