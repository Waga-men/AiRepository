package celestial.port.modules.player;

import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.AbstractSignEditScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

public final class InventoryMove extends Module {
    private static InventoryMove instance;

    private final BooleanSetting reallyWorldBypass = addSetting(new BooleanSetting(
            "really_world_bypass", "Обход Really World", true
    ));
    private final BooleanSetting safe = addSetting(new BooleanSetting(
            "safe", "Безопасно", false
    ));

    private final Set<KeyBinding> controlledBindings =
            Collections.newSetFromMap(new IdentityHashMap<>());
    private boolean slotClickArmed;
    private boolean slotClickBypassActive;
    private boolean slotClickWasSneaking;

    public InventoryMove() {
        super("inventory_move", "Inventory Move",
                "Позволяет ходить в инвентаре", Category.PLAYER);
        instance = this;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        Screen screen = client.currentScreen;
        if (screen == null) {
            restoreStates(client);
            slotClickArmed = false;
            return;
        }
        if (screen instanceof ChatScreen || screen instanceof AbstractSignEditScreen) {
            releaseMovementKeys(client);
            return;
        }

        setPhysical(client, client.options.jumpKey, true);
        setPhysical(client, client.options.forwardKey, true);
        setPhysical(client, client.options.backKey, true);
        setPhysical(client, client.options.leftKey, true);
        setPhysical(client, client.options.rightKey, true);
        setPhysical(client, client.options.sneakKey,
                client.player != null && client.player.getAbilities().flying);
    }

    private void releaseMovementKeys(MinecraftClient client) {
        setPhysical(client, client.options.jumpKey, false);
        setPhysical(client, client.options.forwardKey, false);
        setPhysical(client, client.options.backKey, false);
        setPhysical(client, client.options.leftKey, false);
        setPhysical(client, client.options.rightKey, false);
        setPhysical(client, client.options.sneakKey, false);
    }

    private void setPhysical(MinecraftClient client, KeyBinding binding, boolean allowed) {
        controlledBindings.add(binding);
        binding.setPressed(allowed && isPhysicallyPressed(client, binding));
    }

    private static boolean isPhysicallyPressed(MinecraftClient client, KeyBinding binding) {
        InputUtil.Key key = InputUtil.fromTranslationKey(binding.getBoundKeyTranslationKey());
        if (key.getCategory() == InputUtil.Type.MOUSE) {
            return GLFW.glfwGetMouseButton(client.getWindow().getHandle(), key.getCode()) == GLFW.GLFW_PRESS;
        }
        if (key.getCategory() == InputUtil.Type.KEYSYM) {
            return InputUtil.isKeyPressed(client.getWindow(), key.getCode());
        }
        return binding.isPressed();
    }

    private void restoreStates(MinecraftClient client) {
        controlledBindings.forEach(binding -> binding.setPressed(isPhysicallyPressed(client, binding)));
        controlledBindings.clear();
    }

    public static boolean beforeSlotClick() {
        InventoryMove module = instance;
        if (module == null || !module.enabled()) {
            return false;
        }
        module.slotClickBypassActive = false;
        module.slotClickWasSneaking = false;

        MinecraftClient client = MinecraftClient.getInstance();
        if (module.safe.enabled() && safeInventoryState(client) && moving(client.player)) {
            client.player.sendMessage(Text.literal(
                    "InventoryMove: Не двигайтесь когда перетаскиваете предметы!"), false);
            return true;
        }

        if (module.reallyWorldBypass.enabled() && isReallyWorld(client)
                && client.player != null && client.getNetworkHandler() != null) {
            module.slotClickBypassActive = true;
            module.slotClickWasSneaking = client.player.isSneaking();
            client.player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                    client.player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            if (module.slotClickWasSneaking) {
                sendInputState(client, false);
            }
        }
        return false;
    }

    public static void afterSlotClick() {
        InventoryMove module = instance;
        if (module == null || !module.enabled() || !module.slotClickBypassActive) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (module.slotClickWasSneaking) {
            sendInputState(client, true);
        }
        module.slotClickBypassActive = false;
        module.slotClickWasSneaking = false;
        module.slotClickArmed = true;
    }

    public static void onOutgoingPacket(Packet<?> packet) {
        InventoryMove module = instance;
        if (module == null || !module.enabled() || !module.reallyWorldBypass.enabled()
                || !module.slotClickArmed || !(packet instanceof PlayerInteractEntityC2SPacket interact)
                || !isAttack(interact)) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        try {
            if (isReallyWorld(client) && client.player != null) {
                recoverCursorAndClose(client);
            }
        } finally {

            module.slotClickArmed = false;
        }
    }

    private static void sendInputState(MinecraftClient client, boolean sneaking) {
        if (client.player == null || client.player.input == null
                || client.getNetworkHandler() == null) {
            return;
        }
        PlayerInput input = client.player.input.playerInput;
        client.getNetworkHandler().sendPacket(new PlayerInputC2SPacket(new PlayerInput(
                input.forward(), input.backward(), input.left(), input.right(),
                input.jump(), sneaking, false
        )));
    }

    private static void recoverCursorAndClose(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) {
            return;
        }

        ScreenHandler handler = player.currentScreenHandler;
        ItemStack cursor = handler.getCursorStack();
        if (!cursor.isEmpty()) {
            PlayerInventory inventory = player.getInventory();
            for (int inventoryIndex = PlayerInventory.getHotbarSize();
                 inventoryIndex < PlayerInventory.MAIN_SIZE;
                 inventoryIndex++) {
                if (!inventory.getStack(inventoryIndex).isEmpty()) {
                    continue;
                }
                var slotId = handler.getSlotIndex(inventory, inventoryIndex);
                if (slotId.isEmpty()) {
                    continue;
                }
                Slot slot = handler.getSlot(slotId.getAsInt());
                if (!slot.canInsert(cursor)) {
                    continue;
                }
                client.interactionManager.clickSlot(
                        handler.syncId, slot.id, 0, SlotActionType.PICKUP, player);
                break;
            }
        }
        player.closeHandledScreen();
    }

    private static boolean isAttack(PlayerInteractEntityC2SPacket packet) {
        boolean[] attack = {false};
        packet.handle(new PlayerInteractEntityC2SPacket.Handler() {
            @Override
            public void interact(Hand hand) {
            }

            @Override
            public void interactAt(Hand hand, Vec3d pos) {
            }

            @Override
            public void attack() {
                attack[0] = true;
            }
        });
        return attack[0];
    }

    private static boolean safeInventoryState(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        return player != null
                && client.currentScreen instanceof InventoryScreen
                && !player.getAbilities().creativeMode
                && !player.getAbilities().flying
                && !player.hasVehicle()
                && !player.isGliding();
    }

    private static boolean moving(ClientPlayerEntity player) {
        return player != null && (player.forwardSpeed != 0.0F || player.sidewaysSpeed != 0.0F);
    }

    private static boolean isReallyWorld(MinecraftClient client) {
        return LegacyTeleportCoordinator.isReallyWorld(client);
    }

    @Override
    protected void onDisable() {
        restoreStates(MinecraftClient.getInstance());
        slotClickArmed = false;
        slotClickBypassActive = false;
        slotClickWasSneaking = false;
    }
}
