package celestial.port.modules.legacyutility;

import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.client.ui.ClientFeedback;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.NumberSetting;
import celestial.port.core.setting.TextSetting;
import celestial.port.mixin.accessor.PlayerListHudAccessor;
import celestial.port.mixin.accessor.ClientWorldPropertiesAccessor;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.TitleScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.network.CookieStorage;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.Locale;
import java.util.Map;

public final class GriefJoiner extends Module {
    private static final String FULL_SERVER = "К сожалению сервер переполнен";
    private static final String WAIT_TWENTY_SECONDS = "Подождите 20 секунд!";
    private static final String PLAYER_FLOW = "большой поток игроков";

    private final TextSetting grief = addSetting(new TextSetting(
            "grief", "Укажите ваш гриф", "", 32
    ));
    private final NumberSetting delay = addSetting(new NumberSetting(
            "delay", "Задержка", 10.0, 1.0, 20.0, 1.0
    ).visibleWhen(() -> !isReallyWorld(MinecraftClient.getInstance())));

    private HandledScreen<?> lastScreen;
    private int screenTicks;
    private int rwSpawnTicks;
    private long lastSunriseClickMillis;
    private boolean compassUsed;
    private boolean reconnectPending;
    private long reconnectAtMillis;
    private ServerInfo reconnectServer;
    private ClientWorld observedWorld;

    public GriefJoiner() {
        super("grief_joiner", "Grief Joiner",
                "Помогает зайти на сервера рилливорлда/санрайса и т.д", Category.UTILITY);
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) onServerMessage(message.getString());
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, parameters, receivedAt) ->
                onServerMessage(message.getString()));
    }

    public TextSetting grief() {
        return grief;
    }

    public NumberSetting delay() {
        return delay;
    }

    @Override
    protected void onEnable() {
        resetState();
        LegacyTeleportCoordinator.useCompass(true);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (reconnectPending) {
            tickReconnect(client);
            return;
        }
        if (client.player == null || client.world == null || client.getNetworkHandler() == null) {
            return;
        }

        if (client.world != observedWorld) {
            observedWorld = client.world;
            if (isLobbyHeader(client)) {
                announceSuccess(client);
                return;
            }
        }

        String requested = grief.value().strip();
        if (isReallyWorld(client)) {

            if (!((ClientWorldPropertiesAccessor) client.world.getLevelProperties()).celestial$isFlatWorld()) {
                inform(client, "Вы не стоите в хабе!");
                setEnabled(false);
            } else if (requested.isBlank()) {
                inform(client, "Вы не указали гриф!");
                setEnabled(false);
            } else {

                LegacyTeleportCoordinator.setHubSelector(requested);
            }
        } else if (isSunrise(client)) {
            tickSunrise(client, requested);
        }

        if (client.player.getX() == 7.0 && client.player.getY() == 450.0
                && client.player.getZ() == 7.0) {
            if (++rwSpawnTicks > 100) {
                scheduleReconnect(client);
                rwSpawnTicks = 0;
            }
        }

    }

    private void tickReallyWorld(MinecraftClient client, String requested) {
        HandledScreen<?> screen = LegacyContainerActions.currentHandledScreen(client);
        updateScreenAge(screen);
        if (screen == null) {
            return;
        }
        if (requested.equalsIgnoreCase("mega")) {
            clickSlot(client, screen, 20, 2);
            return;
        }
        if (!screen.getTitle().getString().toLowerCase(Locale.ROOT).contains("грифа")) {
            clickSlot(client, screen, 22, 0);
            return;
        }

        Slot target = griefByCount(screen, requested);
        if (target != null && screenTicks > 2) {
            LegacyContainerActions.click(client, screen.getScreenHandler(), target, SlotActionType.PICKUP);
        }
    }

    private void tickSunrise(MinecraftClient client, String requested) {
        HandledScreen<?> screen = LegacyContainerActions.currentHandledScreen(client);
        updateScreenAge(screen);
        if (screen == null || System.currentTimeMillis() - lastSunriseClickMillis
                < delay.value().floatValue() * 50.0F) {
            return;
        }
        String expected = lettersOnly(requested.replaceAll("[0-9]", ""));
        for (Slot slot : screen.getScreenHandler().slots) {
            if (!slot.hasStack() || !isPlayerHead(slot.getStack())) continue;
            String name = lettersOnly(slot.getStack().getName().getString());
            if (name.equalsIgnoreCase(expected)) {
                LegacyContainerActions.click(client, screen.getScreenHandler(), slot, SlotActionType.PICKUP);
                lastSunriseClickMillis = System.currentTimeMillis();
                return;
            }
        }
    }

    private void updateScreenAge(HandledScreen<?> screen) {
        if (screen != lastScreen) {
            lastScreen = screen;
            screenTicks = 0;
        } else if (screen != null) {
            screenTicks++;
        }
    }

    private static Slot griefByCount(HandledScreen<?> screen, String requested) {
        if (screen.getScreenHandler().slots.size() <= 1) return null;
        Slot fallback = screen.getScreenHandler().slots.get(1);
        try {
            int count = Integer.parseInt(requested);
            if (count == 1) return fallback;
            for (Slot slot : screen.getScreenHandler().slots) {
                if (slot.hasStack() && isPlayerHead(slot.getStack()) && slot.getStack().getCount() == count) {
                    return slot;
                }
            }
        } catch (NumberFormatException ignored) {

        }
        return fallback;
    }

    private void clickSlot(MinecraftClient client, HandledScreen<?> screen, int slotId, int minimumAge) {
        if (screenTicks <= minimumAge || slotId < 0 || slotId >= screen.getScreenHandler().slots.size()) return;
        LegacyContainerActions.click(client, screen.getScreenHandler(),
                screen.getScreenHandler().slots.get(slotId), SlotActionType.PICKUP);
        screenTicks = 0;
    }

    private void useCompass(MinecraftClient client, boolean force) {
        if (client.player == null || client.interactionManager == null) return;
        int slot = -1;
        for (int i = 0; i < 9; i++) {
            if (client.player.getInventory().getStack(i).isOf(Items.COMPASS)) {
                slot = i;
                break;
            }
        }
        if (slot < 0 || (!force && client.player.age >= 5)) return;
        client.player.getInventory().setSelectedSlot(slot);
        client.interactionManager.interactItem(client.player, client.player.getActiveHand());
        compassUsed = true;
    }

    private void onServerMessage(String message) {
        if (!enabled() || reconnectPending) return;
        if (message.contains(FULL_SERVER) || message.contains(WAIT_TWENTY_SECONDS)
                || message.contains(PLAYER_FLOW)) {
            scheduleReconnect(MinecraftClient.getInstance());
        }
    }

    private void scheduleReconnect(MinecraftClient client) {
        ServerInfo server = client.getCurrentServerEntry();
        if (server == null || reconnectPending) return;
        reconnectServer = server;
        reconnectAtMillis = System.currentTimeMillis() + 800L;
        reconnectPending = true;
        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().getConnection().disconnect(Text.literal("Перезаходим..."));
        }
    }

    private void tickReconnect(MinecraftClient client) {
        if (System.currentTimeMillis() < reconnectAtMillis || reconnectServer == null) return;
        ServerInfo server = reconnectServer;
        reconnectPending = false;
        reconnectServer = null;
        observedWorld = null;
        MultiplayerScreen parent = new MultiplayerScreen(new TitleScreen());
        ConnectScreen.connect(parent, client, ServerAddress.parse(server.address), server, false,
                new CookieStorage(Map.of(), Map.of(), false));
    }

    private void announceSuccess(MinecraftClient client) {
        String message = "Вы успешно зашли на " + grief.value().strip().toUpperCase(Locale.ROOT) + " гриф!";
        inform(client, message);
        if (!client.isWindowFocused()) {
            ClientFeedback.info("Grief Joiner", message, 5);
        }
        setEnabled(false);
    }

    private static boolean isLobbyHeader(MinecraftClient client) {
        Text header = ((PlayerListHudAccessor) client.inGameHud.getPlayerListHud()).celestial$getHeader();
        return header != null && header.getString().contains("Lobby");
    }

    private static boolean isPlayerHead(ItemStack stack) {
        return stack.getItem() instanceof BlockItem item && item.getBlock() instanceof AbstractSkullBlock;
    }

    private static String lettersOnly(String value) {
        return value.replaceAll("[^a-zA-Zа-яА-Я]", "");
    }

    private static boolean isReallyWorld(MinecraftClient client) {
        return LegacyTeleportCoordinator.isReallyWorld(client);
    }

    private static boolean isSunrise(MinecraftClient client) {
        return LegacyTeleportCoordinator.isSunrise(client);
    }

    private static void inform(MinecraftClient client, String message) {
        if (client.player != null) client.player.sendMessage(Text.literal(message), false);
    }

    @Override
    protected void onDisable() {
        resetState();
    }

    private void resetState() {
        LegacyTeleportCoordinator.clearHubSelector();
        lastScreen = null;
        screenTicks = 0;
        rwSpawnTicks = 0;
        compassUsed = false;
        reconnectPending = false;
        reconnectAtMillis = 0L;
        reconnectServer = null;
        observedWorld = MinecraftClient.getInstance().world;
    }
}
