package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

public final class AutoGAppleModule extends Module {
    private static final Set<Screen> INPUT_ENABLED_SCREENS =
            Collections.newSetFromMap(new WeakHashMap<>());

    private final NumberSetting health = addSetting(new NumberSetting(
            "health", "\u0417\u0434\u043e\u0440\u043e\u0432\u044c\u0435", 15.0, 5.0, 20.0, 0.5
    ));
    private boolean ownsUseKey;

    public AutoGAppleModule() {
        super("auto_gapple", "Auto GApple",
                "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0435\u0441\u0442 \u0437\u043e\u043b\u043e\u0442\u043e\u0435 \u044f\u0431\u043b\u043e\u043a\u043e", Category.COMBAT);
    }

    public boolean activelyEating() {
        return enabled() && ownsUseKey;
    }

    public static boolean allowsScreenInput(Screen screen) {
        return screen != null && INPUT_ENABLED_SCREENS.contains(screen);
    }

    public static boolean ownsBlockInteraction(ClientPlayerEntity player) {
        Module module = CelestialPortClient.MODULES.find("auto_gapple").orElse(null);
        return player != null && player == MinecraftClient.getInstance().player
                && module instanceof AutoGAppleModule autoGApple
                && autoGApple.activelyEating();
    }

    @Override
    protected void onEnable() {
        resetUseState(MinecraftClient.getInstance());
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        resetUseState(MinecraftClient.getInstance());
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        ItemStack apple = heldApple(player);
        boolean shouldEat = player != null
                && player.getHealth() <= health.value().floatValue()
                && apple != null
                && !hasLegacyAppleCooldown(player);

        if (shouldEat) {

            client.options.useKey.setPressed(true);
            ownsUseKey = true;
            if (client.currentScreen != null) {
                INPUT_ENABLED_SCREENS.add(client.currentScreen);
            }
        } else {
            releaseOwnedUse(client);
        }
    }

    private static ItemStack heldApple(ClientPlayerEntity player) {
        if (player == null) {
            return null;
        }
        if (isGoldenApple(player.getMainHandStack())) {
            return player.getMainHandStack();
        }
        return isGoldenApple(player.getOffHandStack()) ? player.getOffHandStack() : null;
    }

    private static boolean isGoldenApple(ItemStack stack) {
        return stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE);
    }

    private static boolean hasLegacyAppleCooldown(ClientPlayerEntity player) {
        var cooldowns = player.getItemCooldownManager();
        return cooldowns.isCoolingDown(Items.GOLDEN_APPLE.getDefaultStack())
                || cooldowns.isCoolingDown(Items.ENCHANTED_GOLDEN_APPLE.getDefaultStack());
    }

    private void releaseOwnedUse(MinecraftClient client) {
        if (!ownsUseKey) {
            return;
        }

        client.options.useKey.setPressed(false);
        ownsUseKey = false;
    }

    private void resetUseState(MinecraftClient client) {
        ownsUseKey = false;

        if (client.options.useKey.isPressed()) {
            client.options.useKey.setPressed(false);
        }
    }

    @Override
    protected void onDisable() {
        resetUseState(MinecraftClient.getInstance());
    }
}
