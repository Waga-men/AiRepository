package celestial.port.modules.inventory;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.AttributeModifiersComponent;
import net.minecraft.component.type.EquippableComponent;

import java.util.OptionalInt;
import java.util.function.Predicate;

public final class InventoryActions {
    public static final int CHEST_INVENTORY_INDEX = 38;

    private InventoryActions() {
    }

    public static boolean canClickPlayerInventory(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        return player != null
                && player.isAlive()
                && client.interactionManager != null
                && client.getNetworkHandler() != null
                && client.currentScreen == null
                && player.currentScreenHandler == player.playerScreenHandler
                && player.currentScreenHandler.getCursorStack().isEmpty();
    }

    public static int findMainInventory(PlayerInventory inventory, Predicate<ItemStack> predicate) {
        for (int index = 0; index < PlayerInventory.MAIN_SIZE; index++) {
            if (predicate.test(inventory.getStack(index))) {
                return index;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    public static int findHotbar(PlayerInventory inventory, Predicate<ItemStack> predicate) {
        for (int index = 0; index < PlayerInventory.getHotbarSize(); index++) {
            if (predicate.test(inventory.getStack(index))) {
                return index;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    public static boolean swapWithOffhand(MinecraftClient client, int sourceInventoryIndex) {
        if (!canClickPlayerInventory(client)) {
            return false;
        }

        ClientPlayerEntity player = client.player;
        ScreenHandler handler = player.currentScreenHandler;
        OptionalInt sourceSlotId = handler.getSlotIndex(player.getInventory(), sourceInventoryIndex);
        if (sourceSlotId.isEmpty()) {
            return false;
        }

        Slot source = handler.getSlot(sourceSlotId.getAsInt());
        if (!source.hasStack() || !source.canTakeItems(player)) {
            return false;
        }

        client.interactionManager.clickSlot(
                handler.syncId,
                source.id,
                PlayerInventory.OFF_HAND_SLOT,
                SlotActionType.SWAP,
                player
        );
        return true;
    }

    public static boolean swapInventorySlots(MinecraftClient client, int sourceInventoryIndex, int destinationInventoryIndex) {
        if (!canClickPlayerInventory(client) || sourceInventoryIndex == destinationInventoryIndex) {
            return false;
        }

        ClientPlayerEntity player = client.player;
        ScreenHandler handler = player.currentScreenHandler;
        OptionalInt sourceSlotId = handler.getSlotIndex(player.getInventory(), sourceInventoryIndex);
        OptionalInt destinationSlotId = handler.getSlotIndex(player.getInventory(), destinationInventoryIndex);
        if (sourceSlotId.isEmpty() || destinationSlotId.isEmpty()) {
            return false;
        }

        Slot source = handler.getSlot(sourceSlotId.getAsInt());
        Slot destination = handler.getSlot(destinationSlotId.getAsInt());
        ItemStack sourceStack = source.getStack();
        ItemStack destinationStack = destination.getStack();
        if (sourceStack.isEmpty()
                || !source.canTakeItems(player)
                || !destination.canInsert(sourceStack)
                || (!destinationStack.isEmpty() && (!destination.canTakeItems(player) || !source.canInsert(destinationStack)))) {
            return false;
        }

        int syncId = handler.syncId;
        client.interactionManager.clickSlot(syncId, source.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(syncId, destination.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(syncId, source.id, 0, SlotActionType.PICKUP, player);
        return handler.getCursorStack().isEmpty();
    }

    public static boolean quickMoveInventorySlot(MinecraftClient client, int inventoryIndex) {
        if (!canClickPlayerInventory(client)) {
            return false;
        }
        ClientPlayerEntity player = client.player;
        ScreenHandler handler = player.currentScreenHandler;
        OptionalInt slotId = handler.getSlotIndex(player.getInventory(), inventoryIndex);
        if (slotId.isEmpty()) {
            return false;
        }
        Slot slot = handler.getSlot(slotId.getAsInt());
        if (!slot.hasStack() || !slot.canTakeItems(player)) {
            return false;
        }
        client.interactionManager.clickSlot(
                handler.syncId, slot.id, 0, SlotActionType.QUICK_MOVE, player);
        return true;
    }

    public static int equipmentInventoryIndex(EquipmentSlot slot) {
        return switch (slot) {
            case HEAD -> 39;
            case CHEST -> CHEST_INVENTORY_INDEX;
            case LEGS -> 37;
            case FEET -> 36;
            case OFFHAND -> PlayerInventory.OFF_HAND_SLOT;
            default -> PlayerInventory.NOT_FOUND;
        };
    }

    public static boolean equips(ItemStack stack, EquipmentSlot slot) {
        EquippableComponent equippable = stack.get(DataComponentTypes.EQUIPPABLE);
        return equippable != null && equippable.slot() == slot;
    }

    public static double armorScore(ItemStack stack, EquipmentSlot slot) {
        if (stack.isEmpty() || !equips(stack, slot)) {
            return Double.NEGATIVE_INFINITY;
        }

        AttributeModifiersComponent modifiers = stack.getOrDefault(
                DataComponentTypes.ATTRIBUTE_MODIFIERS,
                AttributeModifiersComponent.DEFAULT
        );
        double armor = modifiers.applyOperations(EntityAttributes.ARMOR, 0.0, slot);
        double toughness = modifiers.applyOperations(EntityAttributes.ARMOR_TOUGHNESS, 0.0, slot);
        if (armor <= 0.0 && toughness <= 0.0) {
            return Double.NEGATIVE_INFINITY;
        }

        double durability = 1.0;
        if (stack.isDamageable() && stack.getMaxDamage() > 0) {
            durability = (double) (stack.getMaxDamage() - stack.getDamage()) / stack.getMaxDamage();
        }
        return armor * 100.0 + toughness * 10.0 + durability;
    }
}
