package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.network.ClientPlayerEntity;

public final class ReachModule extends Module {
    private static final double DEFAULT_ENTITY_RANGE = 3.0;
    private static final double SURVIVAL_BLOCK_RANGE = 4.5;
    private static final double CREATIVE_BLOCK_RANGE = 5.0;
    private static final double CREATIVE_ENTITY_RANGE = 6.0;
    private static final double CLICK_TP_BLOCK_RANGE = 500.0;

    private static ReachModule instance;

    private final NumberSetting entityRange = addSetting(new NumberSetting(
            "distance", "Р”РёСЃС‚Р°РЅС†РёСЏ", 3.5, 3.1, 5.0, 0.1));

    public ReachModule() {
        super("reach", "Reach", "РЈРІРµР»РёС‡РёРІР°РµС‚ РґРёСЃС‚Р°РЅС†РёСЋ РІР°С€РµРіРѕ СѓРґР°СЂР°", Category.COMBAT);
        instance = this;
    }

    public static boolean requiresLegacyCrosshair() {
        ReachModule module = instance;
        return module != null && module.enabled()
                || moduleEnabled("hit_box")
                || moduleEnabled("click_tp");
    }

    public static double legacyBlockScanRange(ClientPlayerEntity player) {
        if (moduleEnabled("click_tp")) {
            return CLICK_TP_BLOCK_RANGE;
        }
        return player.isCreative() ? CREATIVE_BLOCK_RANGE : SURVIVAL_BLOCK_RANGE;
    }

    public static double legacyEntityScanRange(ClientPlayerEntity player) {
        return player.isCreative() ? CREATIVE_ENTITY_RANGE : legacyBlockScanRange(player);
    }

    public static double legacyEntityCutoff(ClientPlayerEntity player) {
        if (player.isCreative()) {
            return CREATIVE_ENTITY_RANGE;
        }
        ReachModule module = instance;
        double desired = module != null && module.enabled()
                ? module.entityRange.value()
                : DEFAULT_ENTITY_RANGE;
        return Math.min(legacyBlockScanRange(player), desired);
    }

    private static boolean moduleEnabled(String id) {
        return CelestialPortClient.MODULES.find(id).map(Module::enabled).orElse(false);
    }
}
