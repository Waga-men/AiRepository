package celestial.port.modules.visual;

import celestial.port.CelestialPortClient;
import celestial.port.core.Module;
import celestial.port.modules.render.ArrayListModule;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.debug.gizmo.VisibilityConfigurable;

import java.awt.Color;

public final class VisualColors {
    private VisualColors() {
    }

    static int withAlpha(int argb, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (argb & 0x00FF_FFFF);
    }

    static int opaque(int argb) {
        return withAlpha(argb, 255);
    }

    static int rainbow(long milliseconds) {
        double hue = Math.floorMod(milliseconds, 6_000L) / 6_000.0;
        double scaled = hue * 6.0;
        int sector = (int) scaled;
        double fraction = scaled - sector;
        int rising = (int) Math.round(fraction * 255.0);
        int falling = 255 - rising;
        return switch (sector) {
            case 0 -> 0xFFFF0000 | (rising << 8);
            case 1 -> 0xFF00FF00 | (falling << 16);
            case 2 -> 0xFF00FF00 | rising;
            case 3 -> 0xFF0000FF | (falling << 8);
            case 4 -> 0xFF0000FF | (rising << 16);
            default -> 0xFFFF0000 | falling;
        };
    }

    public static int clientColor(float offsetDegrees) {
        Module module = CelestialPortClient.MODULES.find("array_list").orElse(null);
        if (!(module instanceof ArrayListModule array)) {
            return 0xFFC87DFF;
        }

        int divisor = 10 - (int) array.colorSpeed();
        int phase = (int) ((System.currentTimeMillis() / divisor
                + (int) offsetDegrees) % 360L);
        int color = switch (array.colorMode()) {
            case "Static" -> array.staticColor();
            case "Rainbow" -> Color.HSBtoRGB(phase / 360.0F, 0.7F, 1.0F);
            case "Astolfo" -> {
                float hue = phase % 360.0F;
                float normalized = (double) (hue / 360.0F) < 0.5
                        ? -(hue / 360.0F)
                        : (hue % 360.0F) / 360.0F;
                yield Color.HSBtoRGB(normalized, 0.7F, 1.0F);
            }
            default -> {
                int triangle = (phase >= 180 ? 360 - phase : phase) * 2;
                yield blend(array.fadeFirstColor(), array.fadeSecondColor(),
                        triangle / 360.0F);
            }
        };

        return opaque(color);
    }

    private static int blend(int first, int second, float amount) {
        float value = MathHelper.clamp(amount, 0.0F, 1.0F);
        int red = (int) (((first >>> 16) & 255)
                + (((second >>> 16) & 255) - ((first >>> 16) & 255)) * (double) value);
        int green = (int) (((first >>> 8) & 255)
                + (((second >>> 8) & 255) - ((first >>> 8) & 255)) * (double) value);
        int blue = (int) ((first & 255) + ((second & 255) - (first & 255)) * (double) value);
        int alpha = (int) ((first >>> 24)
                + ((second >>> 24) - (first >>> 24)) * (double) value);
        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    static void throughWalls(VisibilityConfigurable visual, boolean enabled) {
        if (enabled) {
            visual.ignoreOcclusion();
        }
    }
}
