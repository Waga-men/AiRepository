package celestial.port.modules.player;

import celestial.port.core.setting.BindSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;

final class KeyInputLatch {
    private boolean previouslyPressed;

    boolean poll(MinecraftClient client, BindSetting binding, KeyBinding fallback) {
        boolean pressed = binding.isBound()
                ? BindSetting.isPressed(client.getWindow().getHandle(), binding.key())
                : fallback.isPressed();
        boolean risingEdge = pressed && !previouslyPressed;
        previouslyPressed = pressed;
        return risingEdge;
    }

    void reset() {
        previouslyPressed = false;
    }
}
