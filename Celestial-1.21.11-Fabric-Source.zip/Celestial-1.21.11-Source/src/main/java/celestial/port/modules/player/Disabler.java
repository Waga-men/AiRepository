package celestial.port.modules.player;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

import java.util.List;

public final class Disabler extends Module {
    private static volatile Disabler instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "\u0420\u0435\u0436\u0438\u043c", "Vulcan Strafe",
            List.of("Vulcan Strafe", "Vulcan Elytra")
    ));
    private long lastStrafeActionMillis = System.currentTimeMillis();
    private long lastElytraActionMillis = System.currentTimeMillis();
    private int rememberedElytraHandlerSlot = PlayerInventory.NOT_FOUND;
    private boolean legacyDispatchReady;
    private ClientPlayerEntity dispatchRefreshPlayer;
    private int dispatchRefreshAge = Integer.MIN_VALUE;

    public Disabler() {
        super("disabler", "Disabler",
                "\u041e\u0442\u043a\u043b\u044e\u0447\u0430\u0435\u0442 \u043d\u0435\u043a\u043e\u0442\u043e\u0440\u044b\u0435 \u043f\u0440\u043e\u0432\u0435\u0440\u043a\u0438 \u0430\u043d\u0442\u0438\u0447\u0438\u0442\u0430 Vulcan", Category.PLAYER);
        instance = this;
    }

    public static boolean vulcanElytraActive() {
        Module raw = CelestialPortClient.MODULES.find("disabler").orElse(null);
        return raw instanceof Disabler module && module.enabled() && module.mode.is("Vulcan Elytra");
    }

    public static boolean legacyDispatchReady() {
        Disabler module = instance;
        return module != null && module.enabled() && module.legacyDispatchReady;
    }

    public static void refreshLegacyModuleDispatch(ClientPlayerEntity player) {
        Disabler owner = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (owner == null || player == null || player != client.player || client.world == null) {
            return;
        }
        if (owner.dispatchRefreshPlayer == player && owner.dispatchRefreshAge == player.age) {
            return;
        }
        owner.dispatchRefreshPlayer = player;
        owner.dispatchRefreshAge = player.age;
        boolean ready = legacyDispatchReady();
        for (Module module : CelestialPortClient.MODULES.modules()) {
            if (module.supportsOnlyWithDisabler()) {
                module.refreshLegacyDisablerDispatch(ready);
            }
        }
    }

    public static void afterAntiLevitationDispatchSlot(ClientPlayerEntity player) {
        Disabler module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module != null && module.enabled()
                && player != null && player == client.player && client.world != null) {
            module.legacyDispatchReady = true;
        }
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return;
        }
        if (client.interactionManager == null) {
            return;
        }
        if (mode.is("Vulcan Strafe")) {
            tickStrafe(client);
        } else {
            tickElytra(client);
        }
    }

    private void tickStrafe(MinecraftClient client) {
        long now = System.currentTimeMillis();
        if (client.interactionManager.isBreakingBlock()
                || now - lastStrafeActionMillis <= 1000L) {
            return;
        }
        client.player.networkHandler.sendPacket(new PlayerActionC2SPacket(
                PlayerActionC2SPacket.Action.STOP_DESTROY_BLOCK,
                new BlockPos(-1, -1, -1), Direction.UP
        ));
        lastStrafeActionMillis = now;
    }

    private void tickElytra(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        int handlerSlot = findElytraHandlerSlot(client, player);
        if (handlerSlot < 0) {
            if (rememberedElytraHandlerSlot != PlayerInventory.NOT_FOUND && !elytraFixActive()) {
                swapChest(player, client, rememberedElytraHandlerSlot);
                rememberedElytraHandlerSlot = PlayerInventory.NOT_FOUND;
            }
            return;
        }

        long now = System.currentTimeMillis();
        if (now - lastElytraActionMillis <= 1000L) {
            return;
        }
        swapChest(player, client, handlerSlot);
        rememberedElytraHandlerSlot = handlerSlot;
        lastElytraActionMillis = now;
    }

    private static int findElytraHandlerSlot(MinecraftClient client, ClientPlayerEntity player) {
        if (player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            return -2;
        }
        if (client.currentScreen instanceof HandledScreen<?> && !(client.currentScreen instanceof InventoryScreen)) {
            return PlayerInventory.NOT_FOUND;
        }
        PlayerInventory inventory = player.getInventory();
        int end = Math.min(36, inventory.size());
        for (int slot = 0; slot < end; slot++) {
            if (inventory.getStack(slot).isOf(Items.ELYTRA)) {
                return slot < 9 ? slot + 36 : slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static void swapChest(
            ClientPlayerEntity player, MinecraftClient client, int handlerSlot
    ) {
        int syncId = player.playerScreenHandler.syncId;
        client.interactionManager.clickSlot(syncId, handlerSlot, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(syncId, 6, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(syncId, handlerSlot, 0, SlotActionType.PICKUP, player);
    }

    private static boolean elytraFixActive() {
        return CelestialPortClient.MODULES.find("elytra_fix").map(Module::enabled).orElse(false);
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        legacyDispatchReady = false;
        resetDispatchRefresh();
    }

    @Override
    protected void onEnable() {
        legacyDispatchReady = false;
        resetDispatchRefresh();
    }

    @Override
    protected void onDisable() {
        legacyDispatchReady = false;
        resetDispatchRefresh();
    }

    private void resetDispatchRefresh() {
        dispatchRefreshPlayer = null;
        dispatchRefreshAge = Integer.MIN_VALUE;
    }
}
