package celestial.port.modules.player;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.decoration.ArmorStandEntity;
import net.minecraft.entity.player.PlayerEntity;
import org.lwjgl.glfw.GLFW;

import java.util.List;
import java.util.Set;

public final class NoInteract extends Module {
    public static final String PLAYERS = "Игроки";
    public static final String ARMOR_STANDS = "Армор стенды";
    public static final String CHESTS = "Сундуки";
    public static final String DOORS = "Двери";
    public static final String HOPPERS = "Воронки";
    public static final String BUTTONS = "Кнопки";
    public static final String DISPENSERS = "Раздатчики";
    public static final String NOTE_BLOCKS = "Нотные блоки";
    public static final String WORKSTATIONS = "Верстаки";
    public static final String TRAPDOORS = "Люки";
    public static final String FURNACES = "Печки";
    public static final String FENCE_GATES = "Калитки";
    public static final String ANVILS = "Наковальни";
    public static final String LEVERS = "Рычаги";
    public static final String OTHER = "Другие";

    private static final List<String> TARGET_OPTIONS = List.of(
            PLAYERS, ARMOR_STANDS, CHESTS, DOORS, HOPPERS, BUTTONS, DISPENSERS,
            NOTE_BLOCKS, WORKSTATIONS, TRAPDOORS, FURNACES, FENCE_GATES, ANVILS, LEVERS, OTHER
    );
    private static final Set<Block> LEGACY_CHESTS = Set.of(
            Blocks.ENDER_CHEST, Blocks.TRAPPED_CHEST, Blocks.CHEST
    );
    private static final Set<Block> LEGACY_DOORS = Set.of(
            Blocks.OAK_DOOR, Blocks.IRON_DOOR, Blocks.SPRUCE_DOOR, Blocks.BIRCH_DOOR,
            Blocks.JUNGLE_DOOR, Blocks.ACACIA_DOOR, Blocks.DARK_OAK_DOOR
    );
    private static final Set<Block> LEGACY_BUTTONS = Set.of(
            Blocks.STONE_BUTTON, Blocks.OAK_BUTTON
    );
    private static final Set<Block> LEGACY_NOTE_BLOCKS = Set.of(
            Blocks.JUKEBOX, Blocks.NOTE_BLOCK
    );
    private static final Set<Block> LEGACY_WORKSTATIONS = Set.of(
            Blocks.CRAFTING_TABLE, Blocks.ENCHANTING_TABLE
    );
    private static final Set<Block> LEGACY_TRAPDOORS = Set.of(
            Blocks.OAK_TRAPDOOR, Blocks.IRON_TRAPDOOR
    );
    private static final Set<Block> LEGACY_FENCE_GATES = Set.of(
            Blocks.OAK_FENCE_GATE, Blocks.SPRUCE_FENCE_GATE, Blocks.BIRCH_FENCE_GATE,
            Blocks.JUNGLE_FENCE_GATE, Blocks.ACACIA_FENCE_GATE
    );
    private static final Set<Block> LEGACY_ANVILS = Set.of(
            Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL
    );
    private static final Set<Block> LEGACY_OTHER = Set.of(
            Blocks.WHITE_SHULKER_BOX, Blocks.ORANGE_SHULKER_BOX, Blocks.MAGENTA_SHULKER_BOX,
            Blocks.LIGHT_BLUE_SHULKER_BOX, Blocks.YELLOW_SHULKER_BOX, Blocks.LIME_SHULKER_BOX,
            Blocks.PINK_SHULKER_BOX, Blocks.GRAY_SHULKER_BOX, Blocks.LIGHT_GRAY_SHULKER_BOX,
            Blocks.CYAN_SHULKER_BOX, Blocks.PURPLE_SHULKER_BOX, Blocks.BLUE_SHULKER_BOX,
            Blocks.BROWN_SHULKER_BOX, Blocks.GREEN_SHULKER_BOX, Blocks.RED_SHULKER_BOX,
            Blocks.BLACK_SHULKER_BOX, Blocks.OAK_WALL_SIGN, Blocks.OAK_SIGN, Blocks.BREWING_STAND
    );
    private static NoInteract instance;

    private final BooleanSetting allBlocks = addSetting(new BooleanSetting(
            "all_blocks", "Все блоки", false
    ));
    private final MultiSelectSetting targets = addSetting(new MultiSelectSetting(
            "targets", "Выбор объектов",
            Set.of(ARMOR_STANDS, DOORS, HOPPERS, BUTTONS, DISPENSERS,
                    WORKSTATIONS, TRAPDOORS, FURNACES, FENCE_GATES),
            TARGET_OPTIONS
    ).visibleWhen(() -> !allBlocks.enabled()));

    public NoInteract() {
        super("no_interact", "No Interact",
                "Не дает нажимать ПКМ по выбранным объектам", Category.PLAYER);
        instance = this;
    }

    public BooleanSetting allBlocks() {
        return allBlocks;
    }

    public MultiSelectSetting targets() {
        return targets;
    }

    public static boolean cancelsBlockBreaking() {
        NoInteract module = instance;
        return module != null && module.enabled() && module.allBlocks.enabled();
    }

    public static boolean skipsBlockRaycast(BlockState state) {
        NoInteract module = instance;
        return module != null && module.enabled()
                && (module.allBlocks.enabled()
                || rightMouseDown() && module.blocks(state));
    }

    public static boolean skipsCrosshairEntity(Entity entity) {
        NoInteract module = instance;
        return module != null && module.enabled() && module.blocks(entity);
    }

    public boolean blocks(BlockState state) {
        if (allBlocks.enabled()) {
            return true;
        }
        Block block = state.getBlock();
        return targets.selected(CHESTS) && LEGACY_CHESTS.contains(block)
                || targets.selected(DOORS) && LEGACY_DOORS.contains(block)
                || targets.selected(HOPPERS) && block == Blocks.HOPPER
                || targets.selected(BUTTONS) && LEGACY_BUTTONS.contains(block)
                || targets.selected(DISPENSERS) && block == Blocks.DISPENSER
                || targets.selected(NOTE_BLOCKS) && LEGACY_NOTE_BLOCKS.contains(block)
                || targets.selected(WORKSTATIONS) && LEGACY_WORKSTATIONS.contains(block)
                || targets.selected(TRAPDOORS) && LEGACY_TRAPDOORS.contains(block)
                || targets.selected(FURNACES) && block == Blocks.FURNACE
                || targets.selected(FENCE_GATES) && LEGACY_FENCE_GATES.contains(block)
                || targets.selected(ANVILS) && LEGACY_ANVILS.contains(block)
                || targets.selected(LEVERS) && block == Blocks.LEVER
                || targets.selected(OTHER) && LEGACY_OTHER.contains(block);
    }

    public boolean blocks(Entity entity) {
        return targets.selected(PLAYERS) && entity instanceof PlayerEntity
                || targets.selected(ARMOR_STANDS) && entity instanceof ArmorStandEntity;
    }

    private static boolean rightMouseDown() {
        MinecraftClient client = MinecraftClient.getInstance();
        return GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT)
                == GLFW.GLFW_PRESS;
    }
}
