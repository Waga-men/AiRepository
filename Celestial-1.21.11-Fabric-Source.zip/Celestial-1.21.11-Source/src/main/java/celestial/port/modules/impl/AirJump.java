package celestial.port.modules.impl;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ModeSetting;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.math.Box;

import java.util.List;

public final class AirJump extends Module {
    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "\u0420\u0435\u0436\u0438\u043c", "Matrix", List.of("Matrix", "Vanilla")
    ));

    public AirJump() {
        super("air_jump", "Air Jump",
                "\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043f\u0440\u044b\u0433\u0430\u0442\u044c \u043f\u043e \u0432\u043e\u0437\u0434\u0443\u0445\u0443", Category.MOVEMENT);
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        Module raw = CelestialPortClient.MODULES.find("air_jump").orElse(null);
        if (!(raw instanceof AirJump module) || !module.enabled() || !module.mode.is("Vanilla")) {
            return;
        }
        if (jumping(player)) {
            player.setOnGround(true);
        }
    }

    public static void beforeMovementPackets(ClientPlayerEntity player) {
        Module raw = CelestialPortClient.MODULES.find("air_jump").orElse(null);
        if (!(raw instanceof AirJump module) || !module.enabled() || !module.mode.is("Matrix")
                || player.getEntityWorld() == null) {
            return;
        }

        Box near = player.getBoundingBox().expand(0.0625);
        boolean touchesCollision = player.getEntityWorld()
                .getBlockCollisions(player, near).iterator().hasNext();
        if (touchesCollision) {
            if (jumping(player)) {
                player.setOnGround(true);
                player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(
                        true, player.horizontalCollision
                ));
            }
            return;
        }

        Box below = player.getBoundingBox().expand(0.5, 0.0, 0.5).offset(0.0, -1.0, 0.0);
        Box slightlyAbove = player.getBoundingBox().offset(0.0, 0.1, 0.0);
        boolean moving = player.input != null
                && (player.input.getMovementInput().x != 0.0F
                || player.input.getMovementInput().y != 0.0F);
        if (player.getEntityWorld().getBlockCollisions(player, below).iterator().hasNext()
                && !player.getEntityWorld().getBlockCollisions(player, slightlyAbove).iterator().hasNext()
                && moving
                && !player.horizontalCollision) {
            player.setOnGround(true);
            player.fallDistance = 0.0F;
        }
    }

    private static boolean jumping(ClientPlayerEntity player) {
        return player.input != null && player.input.playerInput.jump();
    }
}
