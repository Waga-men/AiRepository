package celestial.port.modules.player;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import com.mojang.authlib.GameProfile;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.OtherClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPosition;
import net.minecraft.entity.EntityPose;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.common.ClientOptionsC2SPacket;
import net.minecraft.network.packet.c2s.common.CommonPongC2SPacket;
import net.minecraft.network.packet.c2s.common.CookieResponseC2SPacket;
import net.minecraft.network.packet.c2s.common.CustomClickActionC2SPacket;
import net.minecraft.network.packet.c2s.common.CustomPayloadC2SPacket;
import net.minecraft.network.packet.c2s.common.KeepAliveC2SPacket;
import net.minecraft.network.packet.c2s.common.ResourcePackStatusC2SPacket;
import net.minecraft.network.packet.c2s.play.AcknowledgeChunksC2SPacket;
import net.minecraft.network.packet.c2s.play.AcknowledgeReconfigurationC2SPacket;
import net.minecraft.network.packet.c2s.play.BoatPaddleStateC2SPacket;
import net.minecraft.network.packet.c2s.play.BookUpdateC2SPacket;
import net.minecraft.network.packet.c2s.play.BundleItemSelectedC2SPacket;
import net.minecraft.network.packet.c2s.play.ButtonClickC2SPacket;
import net.minecraft.network.packet.c2s.play.ChangeGameModeC2SPacket;
import net.minecraft.network.packet.c2s.play.ClickSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientStatusC2SPacket;
import net.minecraft.network.packet.c2s.play.ClientTickEndC2SPacket;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.c2s.play.CraftRequestC2SPacket;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.JigsawGeneratingC2SPacket;
import net.minecraft.network.packet.c2s.play.MessageAcknowledgmentC2SPacket;
import net.minecraft.network.packet.c2s.play.PickItemFromBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PickItemFromEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerLoadedC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerSessionC2SPacket;
import net.minecraft.network.packet.c2s.play.RenameItemC2SPacket;
import net.minecraft.network.packet.c2s.play.SelectMerchantTradeC2SPacket;
import net.minecraft.network.packet.c2s.play.SetTestBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.SlotChangedStateC2SPacket;
import net.minecraft.network.packet.c2s.play.SpectatorTeleportC2SPacket;
import net.minecraft.network.packet.c2s.play.TeleportConfirmC2SPacket;
import net.minecraft.network.packet.c2s.play.TestInstanceBlockActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateBeaconC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateCommandBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateCommandBlockMinecartC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateDifficultyC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateDifficultyLockC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateJigsawC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdatePlayerAbilitiesC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSignC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateStructureBlockC2SPacket;
import net.minecraft.network.packet.c2s.play.VehicleMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRotationS2CPacket;
import net.minecraft.util.Identifier;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec3d;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class FreeCameraModule extends Module {
    private static final int CLONE_ENTITY_ID = -1337;

    private static FreeCameraModule activeInstance;
    private static FreeCameraModule pendingInstance;

    private final NumberSetting speed = addSetting(new NumberSetting(
            "speed", "Скорость", 2.0, 1.0, 5.0, 0.5
    ));
    private final BooleanSetting reallyWorldBypass = addSetting(new BooleanSetting(
            "really_world_bypass", "Обход Really World", true
    ));

    private OtherClientPlayerEntity clone;
    private ClientPlayerEntity owner;
    private ClientWorld ownerWorld;
    private Vec3d returnPosition;
    private boolean previousAllowFlying;
    private boolean previousNoClip;

    public FreeCameraModule() {
        super("free_camera", "Free Camera",
                "Позволяет летать в режиме наблюдателя", Category.PLAYER);
        HudElementRegistry.addLast(Identifier.of("celestial", "free_camera_vclip"),
                (context, tickCounter) -> renderHeight(context));
    }

    @Override
    protected void onEnable() {
        pendingInstance = this;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        pendingInstance = this;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (pendingInstance == this) {
            return;
        }
        if (client.player == null || client.world == null) {
            restore(client);
            return;
        }
        if (clone == null || owner != client.player || ownerWorld != client.world) {
            restore(client);
            createClone(client);
        }
        if (owner == null || clone == null) {
            return;
        }

        owner.noClip = true;
        owner.getAbilities().allowFlying = true;
        owner.setVelocity(Vec3d.ZERO);
        clone.getInventory().clone(owner.getInventory());
        clone.setPose(owner.isSneaking() ? EntityPose.CROUCHING : EntityPose.STANDING);
    }

    private void createClone(MinecraftClient client) {
        if (client.player == null || client.world == null) {
            return;
        }
        owner = client.player;
        ownerWorld = client.world;
        returnPosition = owner.getEntityPos();
        previousAllowFlying = owner.getAbilities().allowFlying;
        previousNoClip = owner.noClip;

        GameProfile ownerProfile = owner.getGameProfile();
        UUID cloneUuid = UUID.nameUUIDFromBytes(
                ("celestial-free-camera:" + ownerProfile.id()).getBytes(StandardCharsets.UTF_8));
        GameProfile cloneProfile = new GameProfile(
                cloneUuid, ownerProfile.name(), ownerProfile.properties());
        clone = new OtherClientPlayerEntity(ownerWorld, cloneProfile);
        clone.copyPositionAndRotation(owner);
        clone.getInventory().clone(owner.getInventory());
        clone.setHealth(owner.getHealth());
        clone.setAbsorptionAmount(owner.getAbsorptionAmount());
        clone.bodyYaw = owner.bodyYaw;
        clone.lastBodyYaw = owner.lastBodyYaw;
        clone.headYaw = owner.headYaw;
        clone.lastHeadYaw = owner.lastHeadYaw;
        clone.setId(CLONE_ENTITY_ID);
        ownerWorld.addEntity(clone);

        owner.noClip = true;
        owner.getAbilities().allowFlying = true;
    }

    private void restore(MinecraftClient client) {
        if (ownerWorld != null && clone != null
                && ownerWorld.getEntityById(clone.getId()) == clone) {
            ownerWorld.removeEntity(clone.getId(), Entity.RemovalReason.DISCARDED);
        }
        if (owner != null) {
            if (returnPosition != null && owner.getEntityWorld() == client.world) {
                owner.setPosition(returnPosition);
            }
            owner.setVelocity(Vec3d.ZERO);
            owner.noClip = previousNoClip;
            if (!previousAllowFlying) {
                owner.getAbilities().allowFlying = false;
                owner.getAbilities().flying = false;
            }
        }
        clone = null;
        owner = null;
        ownerWorld = null;
        returnPosition = null;
    }

    public static Vec3d adjustMovement(ClientPlayerEntity player, Vec3d original) {
        FreeCameraModule module = activeInstance;
        if (module == null || !module.controls(player)) {
            return original;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        float forward = player.forwardSpeed;
        float strafe = player.sidewaysSpeed;
        float yaw = player.getYaw();
        if (forward != 0.0F) {
            if (strafe > 0.0F) {
                yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (strafe < 0.0F) {
                yaw += forward > 0.0F ? 45.0F : -45.0F;
            }
            strafe = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
        }

        double radians = Math.toRadians(yaw + 90.0F);
        double horizontalSpeed = module.speed.value();
        double x = forward * horizontalSpeed * Math.cos(radians)
                + strafe * horizontalSpeed * Math.sin(radians);
        double z = forward * horizontalSpeed * Math.sin(radians)
                - strafe * horizontalSpeed * Math.cos(radians);
        double y = 0.0;
        if (client.options.jumpKey.isPressed()) {
            y = 0.6 * horizontalSpeed;
        } else if (client.options.sneakKey.isPressed()) {
            y = -0.6 * horizontalSpeed;
        }
        return new Vec3d(x, y, z);
    }

    public static void reassertNoClip(PlayerEntity player) {
        FreeCameraModule module = activeInstance;
        if (module != null && player instanceof ClientPlayerEntity clientPlayer
                && module.controls(clientPlayer)) {
            clientPlayer.noClip = true;
        }
    }

    public static boolean freezesMovementPackets(ClientPlayerEntity player) {
        FreeCameraModule module = activeInstance;
        return module != null && module.controls(player);
    }

    public static boolean beginActivationBoundary(ClientPlayerEntity player,
                                                  PlayerInput lastPlayerInput,
                                                  boolean lastSprinting) {
        FreeCameraModule module = pendingInstance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || client.player != player
                || client.world == null) {
            return false;
        }
        if (player.hasVehicle()) {
            pendingInstance = null;
            module.setEnabled(false);
            return false;
        }

        if (client.interactionManager != null) {
            if (client.interactionManager.isBreakingBlock()) {
                client.interactionManager.cancelBlockBreaking();
            }
            if (player.isUsingItem()) {
                client.interactionManager.stopUsingItem(player);
            }
        }

        player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                player, ClientCommandC2SPacket.Mode.STOP_SPRINTING));
        player.networkHandler.sendPacket(new PlayerInputC2SPacket(PlayerInput.DEFAULT));
        player.setSprinting(false);

        pendingInstance = null;
        activeInstance = module;
        module.createClone(client);
        return module.controls(player);
    }

    public static boolean cancelsInputSlowdown(ClientPlayerEntity player) {
        FreeCameraModule module = activeInstance;
        return module != null && module.controls(player);
    }

    public static Packet<?> rewriteMovementPacket(Packet<?> packet) {
        return packet;
    }

    public static boolean shouldCancelOutgoing(Packet<?> packet) {
        FreeCameraModule module = activeInstance;
        if (module == null || module.owner == null || !module.controls(module.owner)
                || isConnectionOrSessionPacket(packet)) {
            return false;
        }
        return isPhysicalPlayerPacket(packet);
    }

    private static boolean isConnectionOrSessionPacket(Packet<?> packet) {
        return packet instanceof KeepAliveC2SPacket
                || packet instanceof CommonPongC2SPacket
                || packet instanceof ClientTickEndC2SPacket
                || packet instanceof AcknowledgeChunksC2SPacket
                || packet instanceof AcknowledgeReconfigurationC2SPacket
                || packet instanceof PlayerLoadedC2SPacket
                || packet instanceof MessageAcknowledgmentC2SPacket
                || packet instanceof PlayerSessionC2SPacket
                || packet instanceof ResourcePackStatusC2SPacket
                || packet instanceof CookieResponseC2SPacket
                || packet instanceof ClientOptionsC2SPacket
                || packet instanceof CustomPayloadC2SPacket
                || packet instanceof TeleportConfirmC2SPacket;
    }

    private static boolean isPhysicalPlayerPacket(Packet<?> packet) {
        return packet instanceof PlayerMoveC2SPacket
                || packet instanceof PlayerInputC2SPacket
                || packet instanceof VehicleMoveC2SPacket
                || packet instanceof BoatPaddleStateC2SPacket
                || packet instanceof ClientCommandC2SPacket
                || packet instanceof PlayerActionC2SPacket
                || packet instanceof PlayerInteractBlockC2SPacket
                || packet instanceof PlayerInteractItemC2SPacket
                || packet instanceof PlayerInteractEntityC2SPacket
                || packet instanceof HandSwingC2SPacket
                || packet instanceof UpdateSelectedSlotC2SPacket
                || packet instanceof UpdatePlayerAbilitiesC2SPacket
                || packet instanceof PickItemFromBlockC2SPacket
                || packet instanceof PickItemFromEntityC2SPacket
                || packet instanceof ClickSlotC2SPacket
                || packet instanceof CreativeInventoryActionC2SPacket
                || packet instanceof SlotChangedStateC2SPacket
                || packet instanceof ButtonClickC2SPacket
                || packet instanceof CraftRequestC2SPacket
                || packet instanceof BookUpdateC2SPacket
                || packet instanceof CloseHandledScreenC2SPacket
                || packet instanceof BundleItemSelectedC2SPacket
                || packet instanceof SelectMerchantTradeC2SPacket
                || packet instanceof UpdateBeaconC2SPacket
                || packet instanceof RenameItemC2SPacket
                || packet instanceof UpdateSignC2SPacket
                || packet instanceof SpectatorTeleportC2SPacket
                || packet instanceof ClientStatusC2SPacket
                || packet instanceof ChangeGameModeC2SPacket
                || packet instanceof UpdateCommandBlockC2SPacket
                || packet instanceof UpdateCommandBlockMinecartC2SPacket
                || packet instanceof UpdateStructureBlockC2SPacket
                || packet instanceof UpdateJigsawC2SPacket
                || packet instanceof JigsawGeneratingC2SPacket
                || packet instanceof SetTestBlockC2SPacket
                || packet instanceof TestInstanceBlockActionC2SPacket
                || packet instanceof UpdateDifficultyC2SPacket
                || packet instanceof UpdateDifficultyLockC2SPacket
                || packet instanceof CustomClickActionC2SPacket;
    }

    public static boolean onPlayerPositionLook(PlayerPositionLookS2CPacket packet) {
        FreeCameraModule module = activeInstance;
        if (module == null || module.clone == null || module.owner == null
                || !module.controls(module.owner)) {
            return false;
        }
        EntityPosition resolved = EntityPosition.apply(
                EntityPosition.fromEntity(module.clone), packet.change(), packet.relatives());
        if (NoServerRotationsModule.active()) {
            resolved = resolved.withRotation(module.clone.getYaw(), module.clone.getPitch());
        }
        module.clone.setPosition(resolved.position());
        module.clone.setVelocity(resolved.deltaMovement());
        module.clone.setYaw(resolved.yaw());
        module.clone.setPitch(resolved.pitch());
        module.clone.updateLastAngles();
        module.returnPosition = resolved.position();

        var connection = module.owner.networkHandler.getConnection();
        connection.send(new TeleportConfirmC2SPacket(packet.teleportId()));
        connection.send(new PlayerMoveC2SPacket.Full(
                resolved.position(), resolved.yaw(), resolved.pitch(), false, false));
        return true;
    }

    public static boolean onPlayerRotation(PlayerRotationS2CPacket packet) {
        FreeCameraModule module = activeInstance;
        if (module == null || module.clone == null || module.owner == null
                || !module.controls(module.owner)) {
            return false;
        }

        float yaw = module.clone.getYaw();
        float pitch = module.clone.getPitch();
        if (!NoServerRotationsModule.active()) {
            yaw = packet.relativeYaw() ? yaw + packet.yaw() : packet.yaw();
            pitch = packet.relativePitch() ? pitch + packet.pitch() : packet.pitch();
        }
        module.clone.setYaw(yaw);
        module.clone.setPitch(pitch);
        module.clone.updateLastAngles();
        module.owner.networkHandler.getConnection().send(
                new PlayerMoveC2SPacket.LookAndOnGround(yaw, pitch, false, false));
        return true;
    }

    public static boolean shouldCancelExplosion(ExplosionS2CPacket packet) {
        FreeCameraModule module = activeInstance;
        return module != null && module.enabled() && module.owner != null;
    }

    public static boolean shouldCancelVelocity(EntityVelocityUpdateS2CPacket packet) {
        FreeCameraModule module = activeInstance;
        return module != null && module.enabled() && module.owner != null
                && packet.getEntityId() == module.owner.getId();
    }

    public static void onGameJoin() {
        FreeCameraModule module = activeInstance != null ? activeInstance : pendingInstance;
        if (module != null && module.enabled()) {
            module.setEnabled(false);
        }
    }

    private void renderHeight(DrawContext context) {
        if (!enabled() || owner == null || returnPosition == null) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != owner || client.world != ownerWorld || client.options.hudHidden) {
            return;
        }
        int delta = (int) (owner.getY() - returnPosition.y);
        context.drawCenteredTextWithShadow(client.textRenderer, ".vclip " + delta,
                context.getScaledWindowWidth() / 2,
                context.getScaledWindowHeight() / 2 - 15,
                0xFFEBEBEB);
    }

    private boolean controls(ClientPlayerEntity player) {
        return enabled() && owner == player && clone != null && ownerWorld == player.getEntityWorld();
    }

    @Override
    protected void onDisable() {
        if (pendingInstance == this) {
            pendingInstance = null;
        }
        restore(MinecraftClient.getInstance());
        if (activeInstance == this) {
            activeInstance = null;
        }
    }
}
