package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.mixin.accessor.RenderTickCounterDynamicAccessor;
import celestial.port.modules.player.Disabler;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public final class Speed extends Module {
    private static final String MATRIX_JUMP_BOOST = "Matrix Jump Boost";
    private static final String SUNRISE_DAMAGE = "Sunrise Damage";
    private static final String REALLY_WORLD = "Really World";
    private static final String REALLY_WORLD_2 = "Really World 2";
    private static final String VULCAN = "Vulcan";
    private static final String NCP = "NCP";
    private static final float VANILLA_TICK_MILLIS = 50.0f;

    private static volatile Speed instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", MATRIX_JUMP_BOOST,
            List.of(MATRIX_JUMP_BOOST, SUNRISE_DAMAGE, REALLY_WORLD, REALLY_WORLD_2, VULCAN, NCP)
    ));
    private final BooleanSetting boostWhenHit = addSetting(new BooleanSetting(
            "boost_when_hit", "Буст при ударе", false
    ).visibleWhen(() -> mode.is(REALLY_WORLD)));

    private String observedMode = MATRIX_JUMP_BOOST;
    private ClientPlayerEntity observedPlayer;

    private int ncpStage;
    private double ncpCharge;
    private boolean ncpAlternate;
    private double calculatedSpeed;

    private boolean matrixNearGround;

    private boolean vulcanGroundPulse;
    private float vulcanPacketOffset;
    private boolean packetRewritePending;
    private int preparedAge = Integer.MIN_VALUE;
    private int rewrittenAge = Integer.MIN_VALUE;

    private boolean damageBoost;
    private boolean suppressNextDamageBoost;
    private long damageBoostStarted;

    private float offGroundSpeed = 0.02f;
    private float appliedTimerSpeed = 1.0f;

    public Speed() {
        super("speed", "Speed", "Ускоряет ваше движение", Category.MOVEMENT);
        instance = this;
    }

    public ModeSetting mode() {
        return mode;
    }

    public BooleanSetting boostWhenHit() {
        return boostWhenHit;
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        Disabler.refreshLegacyModuleDispatch(player);
        Speed module = active();
        if (module != null) {
            module.observe(player);
            module.runPreUpdate(player);
        }
    }

    public static void beforePostMotion(ClientPlayerEntity player) {
        Speed module = active();
        if (module != null) {
            module.observe(player);
            module.runPostMotion(player);
        }
    }

    public static void beforeMovementPackets(ClientPlayerEntity player) {
        Speed module = active();
        if (module != null) {
            module.prepareMovementPacket(player);
        }
    }

    public static Vec3d adjustMovement(ClientPlayerEntity player, Vec3d movement) {
        Speed module = active();
        if (module == null) {
            return movement;
        }
        module.observe(player);
        return module.adjust(player, movement);
    }

    public static PlayerInput adjustInput(ClientPlayerEntity player, PlayerInput input) {
        Speed module = active();
        if (module == null) {
            return input;
        }
        module.observe(player);

        boolean jump = input.jump();
        if (module.mode.is(MATRIX_JUMP_BOOST)
                && module.commonGroundModesAllowed(player) && hasMovementInput(player)) {
            jump = true;
        } else if ((module.mode.is(REALLY_WORLD) || module.mode.is(REALLY_WORLD_2))
                && module.commonGroundModesAllowed(player)
                && (!enabled("strafe") || !fluidBelow(player, 0.1))) {
            jump = false;
        }
        if (jump == input.jump()) {
            return input;
        }
        return new PlayerInput(input.forward(), input.backward(), input.left(), input.right(),
                jump, input.sneak(), input.sprint());
    }

    public static Packet<?> rewriteMovementPacket(Packet<?> packet) {
        Speed module = active();
        if (module == null || !(packet instanceof PlayerMoveC2SPacket movement)) {
            return packet;
        }
        return module.rewrite(movement);
    }

    public static Float offGroundSpeed(PlayerEntity player) {
        Speed module = active();
        if (module == null || player != MinecraftClient.getInstance().player) {
            return null;
        }
        return module.offGroundSpeed * (player.isSprinting() ? 1.3f : 1.0f);
    }

    public static void onEntityDamage(EntityDamageS2CPacket packet) {
        Speed module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.boostWhenHit.enabled() || client.player == null || client.world == null
                || packet.entityId() != client.player.getId()) {
            return;
        }
        DamageSource source = packet.createDamageSource(client.world);
        module.suppressNextDamageBoost = isLegacySuppressedDamage(source);
    }

    public static void onExplosion() {
        Speed module = active();
        if (module != null && module.boostWhenHit.enabled()) {
            module.suppressNextDamageBoost = true;
        }
    }

    public static void onEntityStatus(EntityStatusS2CPacket packet) {
        Speed module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.boostWhenHit.enabled() || client.player == null || client.world == null
                || packet.getStatus() != 2 || packet.getEntity(client.world) != client.player) {
            return;
        }
        boolean potionDamage = client.player.hasStatusEffect(StatusEffects.POISON)
                || client.player.hasStatusEffect(StatusEffects.WITHER)
                || client.player.hasStatusEffect(StatusEffects.INSTANT_DAMAGE);
        if (!module.suppressNextDamageBoost && !potionDamage) {
            module.damageBoost = true;
            module.damageBoostStarted = System.currentTimeMillis();
        } else {
            module.damageBoost = false;
        }
        module.suppressNextDamageBoost = false;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        var counter = MinecraftClient.getInstance().getRenderTickCounter();
        if (counter instanceof RenderTickCounter.Dynamic
                && counter instanceof RenderTickCounterDynamicAccessor accessor) {
            accessor.celestial$setTickTime(VANILLA_TICK_MILLIS);
        }
        appliedTimerSpeed = 1.0f;
        offGroundSpeed = 0.02f;
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player != null && mode.is(VULCAN)) {
            Vec3d velocity = player.getVelocity();
            player.setVelocity(0.0, velocity.y, 0.0);
        }
    }

    @Override
    protected void onEnable() {
        observedPlayer = MinecraftClient.getInstance().player;
        observedMode = mode.value();
    }

    @Override
    protected void onTick() {
        observe(MinecraftClient.getInstance().player);
    }

    @Override
    protected void onDisable() {
        damageBoost = false;
        suppressNextDamageBoost = false;
        matrixNearGround = false;
        packetRewritePending = false;
        vulcanGroundPulse = false;
        vulcanPacketOffset = 0.0f;
        offGroundSpeed = 0.02f;
        setTimerSpeed(1.0f);
        observedPlayer = null;
    }

    private void runPreUpdate(ClientPlayerEntity player) {
        if (mode.is(VULCAN)) {
            runVulcan(player);
        }

        if (mode.is(REALLY_WORLD) || mode.is(REALLY_WORLD_2) || mode.is(MATRIX_JUMP_BOOST)) {
            if (!commonGroundModesAllowed(player)) {
                return;
            }
            if ((mode.is(REALLY_WORLD_2) || mode.is(MATRIX_JUMP_BOOST)) && !hasMovementInput(player)) {
                return;
            }
            if (mode.is(MATRIX_JUMP_BOOST)) {
                return;
            }

            boolean forceJumpReleased = !enabled("strafe") || !fluidBelow(player, 0.1);
            if (player.isOnGround()
                    && !(forceJumpReleased ? false : MinecraftClient.getInstance().options.jumpKey.isPressed())) {
                player.jump();
            }
        } else if (mode.is(SUNRISE_DAMAGE)) {
            runSunriseDamage(player);
        }

        if (mode.is(REALLY_WORLD)) {
            runReallyWorld(player);
        }
        if (mode.is(REALLY_WORLD_2)) {
            runReallyWorldTwo(player);
        }
    }

    private void runVulcan(ClientPlayerEntity player) {
        if (!vulcanAllowed(player)) {
            return;
        }
        boolean moving = hasMovementInput(player);
        if (moving) {
            setHorizontalSpeed(player, player.getVelocity().horizontalLength());
        }
        if (vulcanGroundPulse) {
            vulcanGroundPulse = false;
            vulcanPacketOffset = 0.0f;
        }
        if (player.isOnGround() && moving) {
            Vec3d velocity = player.getVelocity();
            player.setVelocity(velocity.x, 0.0, velocity.z);
            vulcanPacketOffset = (float) (0.01 + Math.random() * 0.03);
            setHorizontalSpeed(player, 0.47);
            vulcanGroundPulse = true;
        } else if (moving) {
            setHorizontalSpeed(player, 0.295);
        } else {
            Vec3d velocity = player.getVelocity();
            player.setVelocity(0.0, velocity.y, 0.0);
        }
    }

    private void runSunriseDamage(ClientPlayerEntity player) {
        if (!hasMovementInput(player) || MovementSupport.isInsideCobweb(player) || player.isClimbing()) {
            return;
        }

        double speed;
        if (player.isUsingItem() && !MinecraftClient.getInstance().options.jumpKey.isPressed()
                && player.isOnGround()) {
            speed = 5.8 / 24.5;
        } else if (player.isOnGround()) {
            speed = 9.5 / 24.5;
        } else if (insideFluid(player)) {
            speed = 8.5 / 24.5;
        } else {
            speed = 0.11 / 24.5;
        }
        setHorizontalSpeed(player, speed);
        double resulting = player.getVelocity().horizontalLength();
        setHorizontalSpeed(player, resulting / (player.isUsingItem() ? 1.02 : 1.0));
    }

    private void runReallyWorld(ClientPlayerEntity player) {
        if (!commonGroundModesAllowed(player)) {
            return;
        }

        if (!enabled("strafe") && (player.isOnGround() || !fluidBelow(player, 0.15))) {
            setHorizontalSpeed(player, player.getVelocity().horizontalLength());
        }

        Vec3d velocity = player.getVelocity();
        boolean clearAbove = player.getEntityWorld().isSpaceEmpty(player,
                player.getBoundingBox().offset(0.0, 0.1, 0.0));
        boolean collidesAlongY = !player.getEntityWorld().isSpaceEmpty(player,
                player.getBoundingBox().offset(0.0, velocity.y, 0.0));
        if (!player.isOnGround() && clearAbove && collidesAlongY) {
            boolean boosted = damageBoost;
            double multiplier = boosted ? 4.0 : 2.0;
            player.setVelocity(velocity.x * multiplier, velocity.y, velocity.z * multiplier);
            if (boostWhenHit.enabled() && boosted
                    && System.currentTimeMillis() - damageBoostStarted > 1400L) {
                damageBoost = false;
            }
        } else if (boostWhenHit.enabled() && damageBoost
                && System.currentTimeMillis() - damageBoostStarted > 1400L) {
            damageBoost = false;
        }
    }

    private void runReallyWorldTwo(ClientPlayerEntity player) {
        if (hasMovementInput(player)) {
            if (player.fallDistance <= 0.1f) {
                setTimerSpeed((float) (1.6 - player.getVelocity().horizontalLength()));
                offGroundSpeed = 0.02f;
            } else if (player.fallDistance < 1.3f) {
                setTimerSpeed(0.8f);
                offGroundSpeed = 0.020408f;
            } else {
                setTimerSpeed(1.0f);
            }
        } else {
            offGroundSpeed = 0.020408f;
            setTimerSpeed(1.0f);
        }
    }

    private void runPostMotion(ClientPlayerEntity player) {
        if (!mode.is(MATRIX_JUMP_BOOST)) {
            return;
        }
        boolean collisionOneBelow = !player.getEntityWorld().isSpaceEmpty(player,
                player.getBoundingBox().offset(0.0, -1.0, 0.0));
        if (!player.isSneaking() && collisionOneBelow && hasMovementInput(player)
                && !player.horizontalCollision && matrixNearGround) {
            player.setOnGround(true);
            player.fallDistance = 0.0f;
            return;
        }
        matrixNearGround = !player.getEntityWorld().isSpaceEmpty(player,
                player.getBoundingBox().offset(0.0, -0.1, 0.0));
    }

    private Vec3d adjust(ClientPlayerEntity player, Vec3d movement) {
        if (mode.is(NCP)) {
            return adjustNcp(player, movement);
        }
        if (mode.is(SUNRISE_DAMAGE)) {
            if (!insideFluid(player) || Jesus.hasSurfaceAssist()) {
                return movement;
            }
            if (MinecraftClient.getInstance().options.sneakKey.isPressed()) {
                return new Vec3d(movement.x, -0.5, movement.z);
            }
            if (player.isSubmergedInWater()
                    && MinecraftClient.getInstance().options.jumpKey.isPressed()) {
                return new Vec3d(movement.x, 0.4, movement.z);
            }
            return movement;
        }
        if (mode.is(VULCAN) && sampledJump(player) && !isBreakingBlock()) {
            double multiplier = (player.age & 1) == 0 ? 1.1299 : 1.13;
            return withHorizontalSpeed(player, movement, baseMoveSpeed(player) * multiplier);
        }
        return movement;
    }

    private Vec3d adjustNcp(ClientPlayerEntity player, Vec3d movement) {
        if (player.horizontalCollision) {
            ncpStage = -1;
        }
        ncpCharge -= ncpCharge > 1.0 ? 0.24 : 0.17;
        if (ncpCharge < 0.0) {
            ncpCharge = 0.0;
        }

        double y = movement.y;
        if (!insideFluid(player) && player.isOnGround() && hasMovementInput(player)
                && (ncpStage >= 0 || player.horizontalCollision)) {
            ncpStage = 0;
            Vec3d velocity = player.getVelocity();
            player.setVelocity(velocity.x, 0.42f, velocity.z);
            y = 0.4f;
            ncpCharge += 1.0;
            ncpAlternate = ncpCharge > 1.0 && !ncpAlternate;
            if (ncpCharge > 1.15) {
                ncpCharge = 1.15;
            }
        }

        calculatedSpeed = ncpSpeed(player, ncpStage) + 0.0335;
        calculatedSpeed *= 0.85;
        if (ncpAlternate) {
            calculatedSpeed *= 0.8575;
        }
        if (insideFluid(player)) {
            calculatedSpeed = 0.351;
        }

        Vec3d adjusted = movement;
        if (hasMovementInput(player)) {
            adjusted = withHorizontalSpeed(player, new Vec3d(movement.x, y, movement.z), calculatedSpeed);
        } else if (y != movement.y) {
            adjusted = new Vec3d(movement.x, y, movement.z);
        }
        ncpStage++;
        return adjusted;
    }

    private double ncpSpeed(ClientPlayerEntity player, int stage) {
        int effect = speedEffectLevel(player);
        double base = baseMoveSpeed(player) + 0.028 * effect + effect / 15.0;
        double jump = 0.4145 + effect / 12.5;
        double decay = stage / 500.0 * 1.87;
        if (stage == 0) {
            base = 0.64 + (effect + 0.028 * effect) * 0.134;
        } else if (stage == 1) {
            base = jump;
        } else if (stage >= 2) {
            base = jump - decay;
        }
        return Math.max(base, ncpAlternate ? base : baseMoveSpeed(player) + 0.028 * effect);
    }

    private void prepareMovementPacket(ClientPlayerEntity player) {
        packetRewritePending = false;
        preparedAge = player.age;
        if (!mode.is(VULCAN) || !vulcanAllowed(player)) {
            return;
        }
        packetRewritePending = true;
    }

    private Packet<?> rewrite(PlayerMoveC2SPacket packet) {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (!packetRewritePending || player == null || player.age != preparedAge || rewrittenAge == preparedAge) {
            return packet;
        }
        rewrittenAge = preparedAge;
        packetRewritePending = false;

        double x = packet.getX(player.getX());
        double y = packet.getY(player.getY()) + vulcanPacketOffset;
        double z = packet.getZ(player.getZ());
        boolean onGround = packet.isOnGround();
        boolean horizontalCollision = packet.horizontalCollision();
        if (packet.changesLook()) {
            return new PlayerMoveC2SPacket.Full(x, y, z,
                    packet.getYaw(player.getYaw()), packet.getPitch(player.getPitch()),
                    onGround, horizontalCollision);
        }
        return new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, onGround, horizontalCollision);
    }

    private void observe(ClientPlayerEntity player) {
        if (player != observedPlayer) {
            observedPlayer = player;
            matrixNearGround = false;
            packetRewritePending = false;
            damageBoost = false;
            suppressNextDamageBoost = false;
        }
        String selected = mode.value();
        if (!selected.equals(observedMode)) {
            observedMode = selected;
            offGroundSpeed = 0.02f;
            setTimerSpeed(1.0f);
        }
    }

    private boolean commonGroundModesAllowed(ClientPlayerEntity player) {
        return !MovementSupport.isInsideCobweb(player) && !player.isClimbing() && !insideFluid(player);
    }

    private boolean vulcanAllowed(ClientPlayerEntity player) {
        return !player.horizontalCollision
                && !isBreakingBlock()
                && !MinecraftClient.getInstance().options.jumpKey.isPressed()
                && !MovementSupport.isInsideCobweb(player)
                && !player.isClimbing()
                && !insideFluid(player);
    }

    private void setTimerSpeed(float timerSpeed) {
        if (timerSpeed == appliedTimerSpeed) {
            return;
        }
        var counter = MinecraftClient.getInstance().getRenderTickCounter();
        if (counter instanceof RenderTickCounter.Dynamic
                && counter instanceof RenderTickCounterDynamicAccessor accessor) {
            accessor.celestial$setTickTime(VANILLA_TICK_MILLIS / timerSpeed);
            appliedTimerSpeed = timerSpeed;
        }
    }

    private static Vec3d withHorizontalSpeed(ClientPlayerEntity player, Vec3d movement, double speed) {
        Vec3d direction = MovementSupport.legacyInputDirection(player);
        if (!MovementSupport.hasDirection(direction)) {
            return new Vec3d(0.0, movement.y, 0.0);
        }
        return new Vec3d(direction.x * speed, movement.y, direction.z * speed);
    }

    private static void setHorizontalSpeed(ClientPlayerEntity player, double speed) {
        Vec3d direction = MovementSupport.legacyInputDirection(player);
        Vec3d velocity = player.getVelocity();
        if (!MovementSupport.hasDirection(direction)) {
            player.setVelocity(0.0, velocity.y, 0.0);
        } else {
            player.setVelocity(direction.x * speed, velocity.y, direction.z * speed);
        }
    }

    private static double baseMoveSpeed(ClientPlayerEntity player) {
        return 0.2873 * (1.0 + 0.2 * speedEffectLevel(player));
    }

    private static int speedEffectLevel(ClientPlayerEntity player) {
        StatusEffectInstance effect = player.getStatusEffect(StatusEffects.SPEED);
        return effect == null ? 0 : effect.getAmplifier() + 1;
    }

    private static boolean insideFluid(ClientPlayerEntity player) {
        return player.isTouchingWater() || player.isInLava();
    }

    private static boolean fluidBelow(ClientPlayerEntity player, double offset) {
        BlockPos pos = BlockPos.ofFloored(player.getX(), player.getY() - offset, player.getZ());
        return !player.getEntityWorld().getFluidState(pos).isEmpty();
    }

    private static boolean sampledJump(ClientPlayerEntity player) {
        return player.input != null && player.input.playerInput.jump();
    }

    private static boolean hasMovementInput(ClientPlayerEntity player) {
        return player.forwardSpeed != 0.0f || player.sidewaysSpeed != 0.0f;
    }

    private static boolean isBreakingBlock() {
        var interactionManager = MinecraftClient.getInstance().interactionManager;
        return interactionManager != null && interactionManager.isBreakingBlock();
    }

    private static boolean enabled(String id) {
        return CelestialPortClient.MODULES.find(id).filter(Module::enabled).isPresent();
    }

    private static boolean isLegacySuppressedDamage(DamageSource source) {
        return source.isOf(DamageTypes.FALL)
                || source.isOf(DamageTypes.ENDER_PEARL)
                || source.isOf(DamageTypes.ARROW)
                || source.isOf(DamageTypes.TRIDENT)
                || source.isOf(DamageTypes.SPEAR)
                || source.isOf(DamageTypes.MOB_PROJECTILE)
                || source.isOf(DamageTypes.SPIT)
                || source.isOf(DamageTypes.WIND_CHARGE)
                || source.isOf(DamageTypes.FIREWORKS)
                || source.isOf(DamageTypes.FIREBALL)
                || source.isOf(DamageTypes.UNATTRIBUTED_FIREBALL)
                || source.isOf(DamageTypes.WITHER_SKULL)
                || source.isOf(DamageTypes.THROWN)
                || source.isOf(DamageTypes.EXPLOSION)
                || source.isOf(DamageTypes.PLAYER_EXPLOSION);
    }

    private static Speed active() {
        Speed module = instance;
        return module != null && module.enabled() && module.legacyDispatchActive() ? module : null;
    }
}
