package celestial.port.modules.rendering;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.ColorSetting;
import celestial.port.modules.visual.CustomModel;
import net.minecraft.client.MinecraftClient;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.world.debug.gizmo.VisibilityConfigurable;

import java.nio.charset.StandardCharsets;
import java.util.UUID;

public final class Tracers extends Module implements WorldGizmoModule {
    private final ColorSetting color = addSetting(new ColorSetting(
            "color", "Цвет", 0xFFFFFFFF
    ));

    public Tracers() {
        super("tracers", "Tracers", "Проводит линию к игрокам", Category.RENDER);
    }

    public ColorSetting color() {
        return color;
    }

    @Override
    public void collectGizmos(WorldExtractionContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        PlayerEntity localPlayer = client.player;
        if (localPlayer == null || context.world() != client.world) {
            return;
        }

        float tickProgress = context.tickCounter().getTickProgress(false);
        Vec3d playerPosition = localPlayer.getLerpedPos(tickProgress);
        Vec3d look = localPlayer.getRotationVec(tickProgress);
        double eyeHeight = localPlayer.getEyeHeight(localPlayer.getPose());
        Module modelModule = CelestialPortClient.MODULES.find("custom_model").orElse(null);
        if (!client.options.getPerspective().isFirstPerson()
                && modelModule instanceof CustomModel customModel
                && customModel.enabled() && customModel.mode().is("Mini")) {
            eyeHeight /= 1.6;
        }
        Vec3d source = playerPosition.add(look.x, eyeHeight + look.y, look.z);
        int alpha = color.argb() >>> 24 & 255;

        for (PlayerEntity player : context.world().getPlayers()) {

            if (player == localPlayer || legacyBot(player)) {
                continue;
            }

            int lineColor = FriendManager.isFriend(player)
                    ? alpha << 24 | 0x00FF00
                    : color.argb();
            Vec3d target = player.getLerpedPos(tickProgress).add(0.0, 0.30, 0.0);
            VisibilityConfigurable line = GizmoDrawing.line(source, target, lineColor, 1.5F);

            line.ignoreOcclusion();
        }
    }

    private static boolean legacyBot(PlayerEntity player) {
        UUID offline = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + player.getGameProfile().name()).getBytes(StandardCharsets.UTF_8)
        );
        return !player.getUuid().equals(offline);
    }
}
