package celestial.port.modules.rendering;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.MultiSelectSetting;

import java.util.List;
import java.util.Set;

public final class NoRender extends Module {
    public static final String SCOREBOARD = "\u0421\u043a\u043e\u0440\u0431\u043e\u0440\u0434";
    public static final String TITLE = "\u0417\u0430\u0433\u043e\u043b\u043e\u0432\u043e\u043a";
    public static final String TOTEM_ANIMATION = "\u0410\u043d\u0438\u043c\u0430\u0446\u0438\u044f \u0442\u043e\u0442\u0435\u043c\u0430";
    public static final String LAG_MACHINE = "\u041b\u0430\u0433 \u043c\u0430\u0448\u0438\u043d\u0430";
    public static final String MUSIC_TITLE = "\u0417\u0430\u0433\u043e\u043b\u043e\u0432\u043e\u043a \u043c\u0443\u0437\u044b\u043a\u0438";
    public static final String BOSS_BAR = "\u0411\u043e\u0441\u0441 \u0431\u0430\u0440";
    public static final String FIRE = "\u041e\u0433\u043e\u043d\u044c";
    public static final String BAD_EFFECTS = "\u041f\u043b\u043e\u0445\u0438\u0435 \u044d\u0444\u0444\u0435\u043a\u0442\u044b";

    private static final List<String> ELEMENT_OPTIONS = List.of(
            SCOREBOARD,
            TITLE,
            TOTEM_ANIMATION,
            LAG_MACHINE,
            MUSIC_TITLE,
            BOSS_BAR,
            FIRE,
            BAD_EFFECTS
    );

    private static NoRender instance;

    private final MultiSelectSetting elements = addSetting(new MultiSelectSetting(
            "elements",
            "\u042d\u043b\u0435\u043c\u0435\u043d\u0442\u044b",
            Set.of(SCOREBOARD, TITLE, TOTEM_ANIMATION, MUSIC_TITLE),
            ELEMENT_OPTIONS
    ));

    public NoRender() {
        super(
                "no_render",
                "No Render",
                "\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u0443\u0431\u0440\u0430\u0442\u044c \u043d\u0435\u043d\u0443\u0436\u043d\u044b\u0435 \u044d\u043b\u0435\u043c\u0435\u043d\u0442\u044b \u0438\u0433\u0440\u044b",
                Category.RENDER
        );
        instance = this;
    }

    public MultiSelectSetting elements() {
        return elements;
    }

    public boolean shouldHideScoreboard() {
        return suppresses(SCOREBOARD);
    }

    public boolean shouldHideTitles() {
        return suppresses(TITLE);
    }

    public boolean shouldHideMusicTitle() {
        return suppresses(MUSIC_TITLE);
    }

    public boolean shouldHideBossBar() {
        return suppresses(BOSS_BAR);
    }

    public static boolean shouldHideTotemAnimation() {
        return activeInstanceSuppresses(TOTEM_ANIMATION);
    }

    public static boolean shouldSkipLightRecalculation() {
        return activeInstanceSuppresses(LAG_MACHINE);
    }

    public static boolean shouldHideFireOverlay() {
        return activeInstanceSuppresses(FIRE);
    }

    public static boolean shouldHideBadEffectVisuals() {
        return activeInstanceSuppresses(BAD_EFFECTS);
    }

    private boolean suppresses(String element) {
        return enabled() && elements.selected(element);
    }

    private static boolean activeInstanceSuppresses(String element) {
        NoRender current = instance;
        return current != null && current.suppresses(element);
    }
}
