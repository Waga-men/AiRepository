package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.ClientConnection;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.item.consume.UseAction;

public final class SuperBowModule extends Module {
    private final NumberSetting strength = addSetting(new NumberSetting(
            "strength", "\u0421\u0438\u043b\u0430 \u0432\u044b\u0441\u0442\u0440\u0435\u043b\u0430", 50.0, 10.0, 100.0, 10.0
    ));

    public SuperBowModule() {
        super(
                "super_bow",
                "Super Bow",
                "\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u0443\u0431\u0438\u0432\u0430\u0442\u044c \u0441 \u043e\u0434\u043d\u043e\u0433\u043e \u0432\u044b\u0441\u0442\u0440\u0435\u043b\u0430 \u0438\u0437 \u043b\u0443\u043a\u0430",
                Category.COMBAT
        );
    }

    public static void onOutgoingPacket(Packet<?> packet) {
        if (!(packet instanceof PlayerActionC2SPacket action)
                || action.getAction() != PlayerActionC2SPacket.Action.RELEASE_USE_ITEM) {
            return;
        }

        Module raw = CelestialPortClient.MODULES.find("super_bow").orElse(null);
        if (!(raw instanceof SuperBowModule module) || !module.enabled()) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;

        if (player == null || client.world == null || !player.isUsingItem()
                || player.getActiveItem().getUseAction() != UseAction.BOW
                || player.networkHandler == null) {
            return;
        }

        ClientConnection connection = player.networkHandler.getConnection();
        connection.send(new ClientCommandC2SPacket(
                player, ClientCommandC2SPacket.Mode.START_SPRINTING
        ));

        int repetitions = module.strength.value().intValue();
        for (int i = 0; i < repetitions; i++) {
            connection.send(new PlayerMoveC2SPacket.PositionAndOnGround(
                    player.getX(), player.getY() + 1.0E-10, player.getZ(), false, player.horizontalCollision
            ));
            connection.send(new PlayerMoveC2SPacket.PositionAndOnGround(
                    player.getX(), player.getY() - 1.0E-10, player.getZ(), true, player.horizontalCollision
            ));
        }
    }
}
