package celestial.port.modules.visual;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4fc;

import java.util.ArrayList;
import java.util.List;

public final class ChinaHat extends Module implements WorldVisual {
    private static final int RIM_SEGMENTS = 180;
    private static final int RIM_VERTICES = RIM_SEGMENTS + 1;
    private static final int FILL_VERTICES = RIM_VERTICES + 2;
    private static final float LINE_WIDTH = 3.0F;
    private static final BlendFunction LEGACY_BLEND = new BlendFunction(
            SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA,
            SourceFactor.ONE, DestFactor.ZERO
    );
    private static final RenderLayer RIM_LAYER = createRimLayer();
    private static final RenderLayer FILL_LAYER = createFillLayer();
    private static final RenderFrame EMPTY_FRAME = new RenderFrame(List.of(), List.of());

    private volatile RenderFrame renderFrame = EMPTY_FRAME;

    public ChinaHat() {
        super("china_hat", "China Hat", "\u041a\u0438\u0442\u0430\u0439\u0441\u043a\u0430\u044f \u0448\u043b\u044f\u043f\u043a\u0430 \u043d\u0430\u0434 \u0433\u043e\u043b\u043e\u0432\u043e\u0439", Category.RENDER);
        WorldRenderEvents.END_MAIN.register(this::drawFrame);
    }

    @Override
    protected void onDisable() {
        renderFrame = EMPTY_FRAME;
    }

    @Override
    public void collectVisuals(WorldExtractionContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || !player.isAlive() || context.world() != client.world
                || client.options.getPerspective().isFirstPerson()) {
            renderFrame = EMPTY_FRAME;
            return;
        }

        float tickProgress = context.tickCounter().getTickProgress(false);
        Vec3d origin = player.getLerpedPos(tickProgress);
        double height = (player.isInSneakingPose()
                ? 1.65
                : player.getBoundingBox().getLengthY()) + 0.02;
        double width = player.getBoundingBox().getLengthX();
        boolean sneaking = player.isSneaking() && !player.isSleeping();
        boolean wearingHeadItem = !player.getEquippedStack(EquipmentSlot.HEAD).isEmpty();

        CustomModel customModel = customModel();
        boolean mini = customModel != null && customModel.mode().is("Mini");
        boolean finn = customModel != null && customModel.mode().is("Finn");

        double modelTranslationY = 0.0;
        if (mini) {
            modelTranslationY -= sneaking ? 0.02 : 0.03;
        }
        if (wearingHeadItem) {
            modelTranslationY += 0.03;
        }

        float crouchOffset = finn ? -0.1F : 0.23F;
        double poseOffset = sneaking ? (double) crouchOffset : 0.0;
        double scale = mini ? (double) 0.6F : 1.0;
        double lineY = origin.y + modelTranslationY + scale * (modelTranslationY
                + height - poseOffset - (double) 0.002F);
        double fillY = origin.y + modelTranslationY + scale * (modelTranslationY
                + height - poseOffset);
        double apexY = origin.y + modelTranslationY + scale * (modelTranslationY
                + height + (double) 0.3F - poseOffset);

        List<RimPoint> rim = new ArrayList<>(RIM_VERTICES);
        for (int index = 0; index <= RIM_SEGMENTS; index++) {
            Vec3d position = rimPosition(origin, width, scale, lineY, index);
            rim.add(new RimPoint(position, legacyColor(index * 8, 0.5F)));
        }

        List<LineVertex> lineVertices = new ArrayList<>(RIM_VERTICES * 2);
        for (int index = 0; index <= RIM_SEGMENTS; index++) {
            RimPoint first = rim.get(index);
            RimPoint second = rim.get((index + 1) % RIM_VERTICES);
            appendLine(lineVertices, first, second);
        }

        List<ColorVertex> fillVertices = new ArrayList<>(FILL_VERTICES);
        Vec3d apex = new Vec3d(origin.x, apexY, origin.z);
        fillVertices.add(new ColorVertex(apex, legacyColor(4, 0.7F)));
        for (int index = 0; index <= RIM_SEGMENTS; index++) {
            fillVertices.add(new ColorVertex(
                    rimPosition(origin, width, scale, fillY, index),
                    legacyColor(index * 8, 0.3F)
            ));
        }
        fillVertices.add(new ColorVertex(apex, legacyColor(4, 0.7F)));
        renderFrame = new RenderFrame(List.copyOf(lineVertices), List.copyOf(fillVertices));
    }

    private static CustomModel customModel() {
        Module module = CelestialPortClient.MODULES.find("custom_model").orElse(null);
        return module instanceof CustomModel customModel && customModel.enabled()
                ? customModel : null;
    }

    private static Vec3d rimPosition(Vec3d origin, double width, double scale,
                                     double y, int index) {
        float angle = (float) index * ((float) Math.PI * 2.0F) / 90.0F;
        double localX = -(double) legacySin(angle) * width;
        double localZ = (double) legacyCos(angle) * width;
        return new Vec3d(origin.x + scale * localX, y, origin.z + scale * localZ);
    }

    private static float legacySin(float angle) {
        int index = (int) (angle * 10430.378F) & 0xFFFF;
        return legacySineTable(index);
    }

    private static float legacyCos(float angle) {
        int index = (int) (angle * 10430.378F + 16384.0F) & 0xFFFF;
        return legacySineTable(index);
    }

    private static float legacySineTable(int index) {
        return (float) Math.sin((double) index * Math.PI * 2.0 / 65536.0);
    }

    private static int legacyColor(int offset, float alpha) {
        return VisualColors.withAlpha(VisualColors.clientColor((float) offset),
                (int) (alpha * 255.0F));
    }

    private static void appendLine(List<LineVertex> vertices,
                                   RimPoint first, RimPoint second) {
        double x = second.position.x - first.position.x;
        double y = second.position.y - first.position.y;
        double z = second.position.z - first.position.z;
        double length = Math.sqrt(x * x + y * y + z * z);
        float normalX = length == 0.0 ? 0.0F : (float) (x / length);
        float normalY = length == 0.0 ? 0.0F : (float) (y / length);
        float normalZ = length == 0.0 ? 0.0F : (float) (z / length);
        vertices.add(new LineVertex(first.position, first.color,
                normalX, normalY, normalZ));
        vertices.add(new LineVertex(second.position, second.color,
                normalX, normalY, normalZ));
    }

    private void drawFrame(WorldRenderContext context) {
        if (!enabled()) {
            return;
        }
        RenderFrame frame = renderFrame;
        MatrixStack matrices = context.matrices();
        if (matrices == null || frame == EMPTY_FRAME) {
            return;
        }

        MatrixStack.Entry entry = matrices.peek();
        Matrix4fc matrix = entry.getPositionMatrix();
        Vec3d camera = context.worldState().cameraRenderState.pos;

        if (!frame.rim.isEmpty()) {
            VertexConsumer consumer = context.consumers().getBuffer(RIM_LAYER);
            for (LineVertex vertex : frame.rim) {
                consumer.vertex(matrix,
                                (float) (vertex.position.x - camera.x),
                                (float) (vertex.position.y - camera.y),
                                (float) (vertex.position.z - camera.z))
                        .color(vertex.color)
                        .normal(entry, vertex.normalX, vertex.normalY, vertex.normalZ)
                        .lineWidth(LINE_WIDTH);
            }
        }

        if (!frame.fill.isEmpty()) {
            VertexConsumer consumer = context.consumers().getBuffer(FILL_LAYER);
            for (ColorVertex vertex : frame.fill) {
                consumer.vertex(matrix,
                                (float) (vertex.position.x - camera.x),
                                (float) (vertex.position.y - camera.y),
                                (float) (vertex.position.z - camera.z))
                        .color(vertex.color);
            }
        }
    }

    private static RenderLayer createRimLayer() {
        RenderPipeline pipeline = RenderPipelines.register(RenderPipeline.builder(
                        RenderPipelines.RENDERTYPE_LINES_SNIPPET)
                .withLocation(Identifier.of("celestial", "pipeline/china_hat_rim"))
                .withBlend(LEGACY_BLEND)
                .withCull(false)
                .withDepthWrite(false)
                .withVertexFormat(VertexFormats.POSITION_COLOR_NORMAL_LINE_WIDTH,
                        VertexFormat.DrawMode.LINES)
                .build());
        RenderSetup setup = RenderSetup.builder(pipeline)
                .translucent()
                .expectedBufferSize(RIM_VERTICES * 2
                        * VertexFormats.POSITION_COLOR_NORMAL_LINE_WIDTH.getVertexSize())
                .build();
        return RenderLayer.of("celestial_china_hat_rim", setup);
    }

    private static RenderLayer createFillLayer() {
        RenderPipeline pipeline = RenderPipelines.register(RenderPipeline.builder(
                        RenderPipelines.POSITION_COLOR_SNIPPET)
                .withLocation(Identifier.of("celestial", "pipeline/china_hat_fill"))
                .withBlend(LEGACY_BLEND)
                .withCull(false)
                .withDepthWrite(false)
                .withVertexFormat(VertexFormats.POSITION_COLOR,
                        VertexFormat.DrawMode.TRIANGLE_FAN)
                .build());
        RenderSetup setup = RenderSetup.builder(pipeline)
                .translucent()
                .expectedBufferSize(FILL_VERTICES * VertexFormats.POSITION_COLOR.getVertexSize())
                .build();
        return RenderLayer.of("celestial_china_hat_fill", setup);
    }

    private record RimPoint(Vec3d position, int color) {
    }

    private record LineVertex(Vec3d position, int color,
                              float normalX, float normalY, float normalZ) {
    }

    private record ColorVertex(Vec3d position, int color) {
    }

    private record RenderFrame(List<LineVertex> rim, List<ColorVertex> fill) {
    }
}
