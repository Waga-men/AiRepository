package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.fluid.FluidState;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;

import java.util.List;

public final class Jesus extends Module {
    private static final String REALLY_WORLD = "Really World";
    private static final String SUNRISE = "Sunrise";
    private static final String MATRIX_ZOOM = "Matrix Zoom";
    private static final VoxelShape SURFACE_COLLISION = VoxelShapes.cuboid(0.0, -0.02, 0.0, 1.0, 0.98, 1.0);

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", REALLY_WORLD, List.of(REALLY_WORLD, SUNRISE, MATRIX_ZOOM)
    ));
    private final NumberSetting speed = addSetting(new NumberSetting(
            "speed", "Скорость", 7.0, 2.0, 10.0, 0.5
    ).visibleWhen(() -> mode.is(MATRIX_ZOOM)));
    private final BooleanSetting doNotLand = addSetting(new BooleanSetting(
            "do_not_land", "Не приземляться", false
    ));

    private ClientPlayerEntity observedPlayer;
    private boolean onFluidBlock;
    private boolean surfaceAssist;
    private boolean solidFluidCollision;
    private boolean matrixPacketPending;
    private boolean spoofPacket;
    private int spoofAge = Integer.MIN_VALUE;
    private int rewrittenAge = Integer.MIN_VALUE;
    private double packetYOffset;
    private int matrixTicks;
    private float sunriseRamp;
    private boolean restoreNoClip;
    private boolean previousNoClip;
    private ClientPlayerEntity noClipPlayer;

    public Jesus() {
        super("jesus", "Jesus", "Позволяет ходить по воде", Category.MOVEMENT);
        setDisableOnFlag(false);
    }

    public ModeSetting mode() {
        return mode;
    }

    public NumberSetting speed() {
        return speed;
    }

    public BooleanSetting doNotLand() {
        return doNotLand;
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        Jesus module = activeModule();
        if (module != null) {
            module.observe(player);
            if (module.mode.is(MATRIX_ZOOM) && module.isFluidAt(player, player.getX(), player.getY() - 0.1, player.getZ())) {
                MinecraftClient.getInstance().options.jumpKey.setPressed(false);
            }
        }
    }

    public static Vec3d adjustMovement(ClientPlayerEntity player, Vec3d movement) {
        Jesus module = activeModule();
        return module == null ? movement : module.adjustMatrixMovement(player, movement);
    }

    public static void afterMovement() {
        Jesus module = activeModule();
        if (module != null) {
            module.finishMatrixMovement();
        }
    }

    public static void beforeMovementPackets(ClientPlayerEntity player) {
        Jesus module = activeModule();
        if (module != null) {
            module.prepareMovementPacket(player);
        }
    }

    public static Packet<?> rewriteMovementPacket(Packet<?> packet) {
        Jesus module = activeModule();
        if (module == null || !(packet instanceof PlayerMoveC2SPacket movementPacket)) {
            return packet;
        }
        return module.rewrite(movementPacket);
    }

    public static boolean cancelsInputSlowdown() {
        Jesus module = activeModule();
        return module != null && module.onFluidBlock;
    }

    public static VoxelShape fluidCollisionShape() {
        Jesus module = activeModule();
        return module != null && module.solidFluidCollision ? SURFACE_COLLISION : null;
    }

    public static boolean hasSurfaceAssist() {
        Jesus module = activeModule();
        return module != null && module.surfaceAssist;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        solidFluidCollision = false;
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player != null && intersectsFluid(player, 0.1)) {
            Vec3d velocity = player.getVelocity();
            player.setVelocity(0.0, velocity.y, 0.0);
        }
        surfaceAssist = false;
    }

    @Override
    protected void onEnable() {
        resetTransient(MinecraftClient.getInstance().player, false);
    }

    @Override
    protected void onTick() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player != observedPlayer) {
            resetTransient(player, false);
        }
    }

    @Override
    protected void onDisable() {
        resetTransient(MinecraftClient.getInstance().player, true);
    }

    private Vec3d adjustMatrixMovement(ClientPlayerEntity player, Vec3d movement) {
        observe(player);
        if (!mode.is(MATRIX_ZOOM)) {
            return movement;
        }

        if (isFluidAt(player, player.getX(), player.getY(), player.getZ())) {
            beginCollisionBypass(player);
            return new Vec3d(0.0, 0.19, 0.0);
        }

        Vec3d resolvedTarget = player.getEntityPos().add(movement).add(0.0, 0.05, 0.0);
        if (!isFluidAt(player, resolvedTarget.x, resolvedTarget.y, resolvedTarget.z)) {
            return movement;
        }

        player.setPosition(player.getX(), MathHelper.floor(player.getY()), player.getZ());
        beginCollisionBypass(player);
        boolean integerY = player.getY() % 1.0 == 0.0;
        double matrixSpeed = matrixTicks % 3 == 0 && integerY ? speed.value() - 0.015 : 0.06;
        setMovementSpeed(player, matrixSpeed);
        Vec3d horizontal = player.getVelocity();
        double y = integerY ? 0.0 : movement.y;
        matrixPacketPending = true;
        player.fallDistance = 0.0;
        player.setVelocity(Vec3d.ZERO);
        return new Vec3d(horizontal.x, y, horizontal.z);
    }

    private void beginCollisionBypass(ClientPlayerEntity player) {
        if (!restoreNoClip) {
            previousNoClip = player.noClip;
            noClipPlayer = player;
            restoreNoClip = true;
        }
        player.noClip = true;
    }

    private void finishMatrixMovement() {
        if (restoreNoClip) {
            if (noClipPlayer != null) {
                noClipPlayer.noClip = previousNoClip;
            }
            restoreNoClip = false;
            noClipPlayer = null;
        }
    }

    private void prepareMovementPacket(ClientPlayerEntity player) {
        observe(player);
        spoofPacket = false;
        packetYOffset = 0.0;
        spoofAge = player.age;

        if (mode.is(MATRIX_ZOOM)) {
            if (!matrixPacketPending) {
                return;
            }

            boolean moving = hasMovementInput(player);
            double offset;
            if (moving) {
                offset = switch (matrixTicks % 3) {
                    case 0 -> -0.02;
                    case 1 -> 0.02;
                    default -> 0.03;
                };
                if ((player.getY() + offset) % 1.0 == 0.0) {
                    offset -= 0.02;
                }
            } else {
                offset = (matrixTicks % 2 == 1 ? -0.02 : 0.01) - 0.05;
            }
            matrixTicks++;
            packetYOffset = offset;
            spoofPacket = true;
            player.setOnGround(!doNotLand.enabled()
                    || MinecraftClient.getInstance().options.jumpKey.isPressed());
            matrixPacketPending = false;
            return;
        }

        if (!insideFluid(player)) {

            solidFluidCollision = true;
        }

        BlockPos feet = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ());
        if (!isFluid(player, feet)) {
            onFluidBlock = false;
            return;
        }

        if (!insideFluid(player)) {
            double baseSpeed = 1.133;
            StatusEffectInstance swiftness = player.getStatusEffect(StatusEffects.SPEED);
            if (swiftness != null && swiftness.getAmplifier() > 0 && depthStriderLevel(player) > 0) {
                baseSpeed += 0.45;
            }

            player.fallDistance = 0.0;
            player.setOnGround(false);
            boolean moving = hasMovementInput(player);
            if (MinecraftClient.getInstance().currentScreen == null) {
                if (moving) {
                    packetYOffset = switch (player.age % 3) {
                        case 0 -> -0.04;
                        case 1 -> 0.0;
                        default -> 0.01;
                    };
                } else {
                    packetYOffset = (player.age % 2 == 1 ? -0.02 : 0.01) - 0.1;
                    sunriseRamp = 0.0f;
                }
            }

            if (isFluidAt(player, player.getX(), player.getY() - 0.1, player.getZ())
                    && isFluidAhead(player)) {
                double appliedSpeed = mode.is(SUNRISE) ? ramp(baseSpeed, 30.0f) : baseSpeed;
                setMovementSpeed(player, appliedSpeed);
            } else if (isFluidAt(player, player.getX(), player.getY() - 0.1, player.getZ())) {
                player.setOnGround(!doNotLand.enabled()
                        || MinecraftClient.getInstance().options.jumpKey.isPressed());
            }
            spoofPacket = true;
        }

        if (intersectsFluid(player, 0.1)) {
            surfaceAssist = true;

            double y = intersectsFluid(player, 0.6) ? 0.18 : 0.35;
            player.setVelocity(0.0, y, 0.0);
        }
        onFluidBlock = true;
    }

    private Packet<?> rewrite(PlayerMoveC2SPacket packet) {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (!spoofPacket || player == null || player.age != spoofAge || rewrittenAge == spoofAge) {
            return packet;
        }
        rewrittenAge = spoofAge;

        double x = packet.getX(player.getX());
        double y = packet.getY(player.getY()) + packetYOffset;
        double z = packet.getZ(player.getZ());
        boolean horizontalCollision = packet.horizontalCollision();
        if (packet.changesPosition() || packetYOffset != 0.0) {
            if (packet.changesLook()) {
                return new PlayerMoveC2SPacket.Full(x, y, z,
                        packet.getYaw(player.getYaw()), packet.getPitch(player.getPitch()),
                        false, horizontalCollision);
            }
            return new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, horizontalCollision);
        }
        if (packet.changesLook()) {
            return new PlayerMoveC2SPacket.LookAndOnGround(
                    packet.getYaw(player.getYaw()), packet.getPitch(player.getPitch()),
                    false, horizontalCollision);
        }
        return new PlayerMoveC2SPacket.OnGroundOnly(false, horizontalCollision);
    }

    private boolean isFluidAhead(ClientPlayerEntity player) {
        Vec3d direction = MovementSupport.legacyInputDirection(player);
        if (!MovementSupport.hasDirection(direction)) {
            direction = MovementSupport.facingDirection(player);
        } else {
            direction = direction.normalize();
        }
        return isFluidAt(player,
                player.getX() + direction.x * 0.4,
                player.getY() - 0.35,
                player.getZ() + direction.z * 0.4);
    }

    private boolean intersectsFluid(ClientPlayerEntity player, double down) {
        Box box = player.getBoundingBox().offset(0.0, -down, 0.0).expand(-0.06);
        int minX = MathHelper.floor(box.minX);
        int minY = MathHelper.floor(box.minY);
        int minZ = MathHelper.floor(box.minZ);
        int maxX = MathHelper.floor(box.maxX);
        int maxY = MathHelper.floor(box.maxY);
        int maxZ = MathHelper.floor(box.maxZ);
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    if (isFluid(player, new BlockPos(x, y, z))) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private boolean isFluidAt(ClientPlayerEntity player, double x, double y, double z) {
        return isFluid(player, BlockPos.ofFloored(x, y, z));
    }

    private boolean isFluid(ClientPlayerEntity player, BlockPos pos) {
        FluidState state = player.getEntityWorld().getFluidState(pos);
        return state.isIn(FluidTags.WATER) || state.isIn(FluidTags.LAVA);
    }

    private static boolean insideFluid(ClientPlayerEntity player) {
        return player.isTouchingWater() || player.isInLava();
    }

    private static boolean hasMovementInput(ClientPlayerEntity player) {
        return MovementSupport.hasDirection(MovementSupport.legacyInputDirection(player));
    }

    private static void setMovementSpeed(ClientPlayerEntity player, double value) {
        Vec3d direction = MovementSupport.legacyInputDirection(player);
        Vec3d velocity = player.getVelocity();
        if (MovementSupport.hasDirection(direction)) {
            player.setVelocity(direction.x * value, velocity.y, direction.z * value);
        } else {
            player.setVelocity(0.0, velocity.y, 0.0);
        }
    }

    private int depthStriderLevel(ClientPlayerEntity player) {
        var enchantments = player.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        return EnchantmentHelper.getLevel(
                enchantments.getOrThrow(Enchantments.DEPTH_STRIDER),
                player.getEquippedStack(EquipmentSlot.FEET));
    }

    private double ramp(double target, float increment) {
        sunriseRamp += increment;
        return target * Math.min(sunriseRamp / 100.0f, 1.0f);
    }

    private void observe(ClientPlayerEntity player) {
        if (observedPlayer != player) {
            resetTransient(player, false);
        }
    }

    private void resetTransient(ClientPlayerEntity player, boolean sendReleasePacket) {
        observedPlayer = player;
        onFluidBlock = false;
        surfaceAssist = false;
        solidFluidCollision = false;
        matrixPacketPending = false;
        spoofPacket = false;
        spoofAge = Integer.MIN_VALUE;
        rewrittenAge = Integer.MIN_VALUE;
        packetYOffset = 0.0;
        finishMatrixMovement();

        if (player == null || !isFluidAt(player, player.getX(), player.getY() - 0.1, player.getZ())) {
            return;
        }
        Vec3d velocity = player.getVelocity();
        player.setVelocity(0.0, velocity.y, 0.0);
        if (sendReleasePacket && !insideFluid(player) && player.networkHandler != null) {
            player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    player.getX(), player.getY() + 0.01, player.getZ(), false, player.horizontalCollision));
        }
    }

    private static Jesus activeModule() {
        Module module = CelestialPortClient.MODULES.find("jesus").orElse(null);
        return module instanceof Jesus jesus && jesus.enabled() ? jesus : null;
    }
}
