package celestial.port.modules.visual;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.MultiSelectSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4fc;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class Trails extends Module implements WorldVisual {
    private static final String SELF_AND_FRIENDS = "Ты и друзья";
    private static final String OTHER_PLAYERS = "Другие игроки";
    private static final String NPCS = "НПС / Боты";
    private static final long LIFETIME_MS = 300L;
    private static final RenderFrame EMPTY_FRAME = new RenderFrame(List.of());

    private final MultiSelectSetting targets = addSetting(new MultiSelectSetting(
            "targets", "Выбор целей", Set.of(SELF_AND_FRIENDS),
            List.of(SELF_AND_FRIENDS, OTHER_PLAYERS, NPCS)
    ));

    private final Map<AbstractClientPlayerEntity, Deque<TrailPoint>> trails = new IdentityHashMap<>();
    private ClientWorld trackedWorld;
    private volatile RenderFrame renderFrame = EMPTY_FRAME;

    public Trails() {
        super("trails", "Trails", "Оставляет след за игроками", Category.RENDER);

        WorldRenderEvents.END_MAIN.register(this::drawFrame);
    }

    public MultiSelectSetting targets() {
        return targets;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) {
            clear();
        } else if (client.world != trackedWorld) {
            clear();
            trackedWorld = client.world;
        }
    }

    @Override
    protected void onDisable() {
        clear();
    }

    @Override
    public void collectVisuals(WorldExtractionContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || context.world() != client.world) {
            renderFrame = EMPTY_FRAME;
            return;
        }
        if (trackedWorld != client.world) {
            clear();
            trackedWorld = client.world;
        }

        float tickProgress = context.tickCounter().getTickProgress(false);
        List<AbstractClientPlayerEntity> players = context.world().getPlayers();
        Set<AbstractClientPlayerEntity> presentPlayers = Collections.newSetFromMap(new IdentityHashMap<>());
        presentPlayers.addAll(players);
        List<TrailVertex> vertices = new ArrayList<>();
        for (AbstractClientPlayerEntity player : players) {
            if (!selected(client, player)) {
                continue;
            }

            Deque<TrailPoint> points = trails.computeIfAbsent(player, ignored -> new ArrayDeque<>());
            points.removeIf(point -> Util.getMeasuringTimeMs() - point.createdAt > LIFETIME_MS);

            boolean hiddenFirstPersonSelf = player == client.player
                    && client.options.getPerspective().isFirstPerson();
            if (!hiddenFirstPersonSelf) {
                Vec3d position = player.getLerpedPos(tickProgress).add(0.0, 0.05, 0.0);

                points.addLast(new TrailPoint(position, Util.getMeasuringTimeMs()));
            }

            TrailPoint previous = null;
            int previousColor = 0;
            float playerHeight = legacyHeight(player);
            for (TrailPoint point : points) {
                int currentColor = pointColor(point.progress);
                appendLegacyQuads(vertices, previous, point, playerHeight,
                        previousColor, currentColor);

                point.progress = MathHelper.clamp(
                        (Util.getMeasuringTimeMs() - point.createdAt) / 250.0F, 0.0F, 1.0F
                ) * 255.0F;
                previous = point;
                previousColor = currentColor;
            }
        }

        trails.entrySet().removeIf(entry -> entry.getValue().isEmpty()
                || !presentPlayers.contains(entry.getKey()));
        renderFrame = new RenderFrame(List.copyOf(vertices));
    }

    private boolean selected(MinecraftClient client, AbstractClientPlayerEntity player) {
        if (!player.isAlive()) {
            return false;
        }
        if (player == client.player || FriendManager.isFriend(player)) {
            return targets.selected(SELF_AND_FRIENDS);
        }
        if (!targets.selected(OTHER_PLAYERS)) {
            return false;
        }
        return targets.selected(NPCS) || !legacyBot(player);
    }

    private static int pointColor(float progress) {
        int alpha = MathHelper.clamp(
                (int) (255.0F * (255 - Math.round(progress)) / 220.0F), 0, 255
        );
        return VisualColors.withAlpha(VisualColors.clientColor((int) progress), alpha);
    }

    private static void appendLegacyQuads(List<TrailVertex> vertices,
                                          TrailPoint previous, TrailPoint current,
                                          float height, int previousColor, int currentColor) {
        Vec3d currentBottom = current.position;
        Vec3d currentTop = currentBottom.add(0.0, height, 0.0);
        Vec3d leadingBottom = previous == null ? currentBottom : previous.position;
        Vec3d leadingTop = leadingBottom.add(0.0, height, 0.0);
        int leadingColor = previous == null ? currentColor : previousColor;
        double rim = height * 0.01F;

        addQuad(vertices,
                leadingBottom, leadingColor,
                leadingTop, leadingColor,
                currentTop, currentColor,
                currentBottom, currentColor);
        addQuad(vertices,
                leadingBottom, leadingColor,
                leadingBottom.add(0.0, rim, 0.0), leadingColor,
                currentBottom.add(0.0, rim, 0.0), currentColor,
                currentBottom, currentColor);
        addQuad(vertices,
                leadingTop, leadingColor,
                leadingTop.add(0.0, -rim, 0.0), leadingColor,
                currentTop.add(0.0, -rim, 0.0), currentColor,
                currentTop, currentColor);
    }

    private static void addQuad(List<TrailVertex> vertices,
                                Vec3d first, int firstColor,
                                Vec3d second, int secondColor,
                                Vec3d third, int thirdColor,
                                Vec3d fourth, int fourthColor) {
        vertices.add(new TrailVertex(first, firstColor));
        vertices.add(new TrailVertex(second, secondColor));
        vertices.add(new TrailVertex(third, thirdColor));
        vertices.add(new TrailVertex(fourth, fourthColor));
    }

    private void drawFrame(WorldRenderContext context) {
        if (!enabled()) {
            return;
        }
        RenderFrame frame = renderFrame;
        MatrixStack matrices = context.matrices();
        if (matrices == null || frame.vertices.isEmpty()) {
            return;
        }

        Matrix4fc matrix = matrices.peek().getPositionMatrix();
        Vec3d cameraPosition = context.worldState().cameraRenderState.pos;
        VertexConsumer consumer = context.consumers().getBuffer(RenderLayers.debugQuads());
        for (TrailVertex vertex : frame.vertices) {
            consumer.vertex(matrix,
                            (float) (vertex.position.x - cameraPosition.x),
                            (float) (vertex.position.y - cameraPosition.y),
                            (float) (vertex.position.z - cameraPosition.z))
                    .color(vertex.color);
        }
    }

    private static float legacyHeight(PlayerEntity player) {
        float height;
        if (player.isGliding()) {
            height = 0.6F;
        } else if (player.isSleeping()) {
            height = 0.2F;
        } else if (player.isSneaking()) {
            height = 1.65F;
        } else {
            height = 1.8F;
        }
        Module module = CelestialPortClient.MODULES.find("custom_model").orElse(null);
        if (module instanceof CustomModel customModel && customModel.enabled()
                && customModel.mode().is("Mini")
                && (!customModel.onlySelfAndFriends().enabled()
                || player == MinecraftClient.getInstance().player
                || FriendManager.isFriend(player))) {
            height = 0.9F;
        }
        if (player.isSneaking()) {
            height *= 0.8F;
        }
        return height;
    }

    private static boolean legacyBot(PlayerEntity player) {
        UUID offline = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + player.getGameProfile().name()).getBytes(StandardCharsets.UTF_8)
        );
        return !player.getUuid().equals(offline);
    }

    private void clear() {
        trails.clear();
        trackedWorld = null;
        renderFrame = EMPTY_FRAME;
    }

    private static final class TrailPoint {
        private final Vec3d position;
        private final long createdAt;
        private float progress;

        private TrailPoint(Vec3d position, long createdAt) {
            this.position = position;
            this.createdAt = createdAt;
        }
    }

    private record TrailVertex(Vec3d position, int color) {
    }

    private record RenderFrame(List<TrailVertex> vertices) {
    }
}
