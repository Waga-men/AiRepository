package celestial.port.modules.impl;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.modules.legacyutility.BaritoneBridge;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;

import java.lang.reflect.Method;

public final class AutoSprint extends Module {
    private static volatile AutoSprint instance;

    private final BooleanSetting vulcanBypass = addSetting(new BooleanSetting(
            "vulcan_bypass", "\u041e\u0431\u0445\u043e\u0434 Vulcan", false
    ));
    private final BooleanSetting keepOnHit = addSetting(new BooleanSetting(
            "keep_on_hit", "\u041f\u0440\u0438 \u0443\u0434\u0430\u0440\u0435", true
    ));

    private ClientPlayerEntity controlledPlayer;

    public AutoSprint() {
        super("auto_sprint", "Auto Sprint",
                "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0432\u043a\u043b\u044e\u0447\u0430\u0435\u0442 \u0441\u043f\u0440\u0438\u043d\u0442", Category.MOVEMENT);
        instance = this;
    }

    public BooleanSetting vulcanBypass() {
        return vulcanBypass;
    }

    public BooleanSetting keepOnHit() {
        return keepOnHit;
    }

    public static boolean preserveSprintOnHit() {
        AutoSprint module = instance;
        return module != null && module.enabled() && module.keepOnHit.enabled();
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        AutoSprint module = instance;
        if (module != null && module.enabled()) {
            module.applySprint(player);
        }
    }

    public static boolean shouldCancelOutgoing(Packet<?> packet) {
        AutoSprint module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        return module != null && module.enabled() && module.vulcanBypass.enabled()
                && client.player != null
                && client.player.isOnGround()
                && !sampledJump(client.player)
                && packet instanceof ClientCommandC2SPacket command
                && command.getMode() == ClientCommandC2SPacket.Mode.START_SPRINTING;
    }

    @Override
    protected void onTick() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player == null) {
            release();
            controlledPlayer = null;
        }
    }

    private void applySprint(ClientPlayerEntity player) {
        if (player != controlledPlayer) {
            release();
            controlledPlayer = player;
        }

        boolean sprint = player.input != null && player.input.playerInput.forward();
        Boolean baritoneSprint = baritoneAllowsSprint();
        if (Boolean.FALSE.equals(baritoneSprint) || !BaritoneBridge.mineAllowsSprint()) {
            sprint = false;
        }
        player.setSprinting(sprint);
    }

    private static Boolean baritoneAllowsSprint() {
        try {
            Class<?> api = Class.forName("baritone.api.BaritoneAPI");
            Object provider = api.getMethod("getProvider").invoke(null);
            Object baritone = provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);
            Object process = baritone.getClass().getMethod("getMineProcess").invoke(baritone);
            Method active = findNoArg(process.getClass(), "isActive");
            if (active != null && !Boolean.TRUE.equals(active.invoke(process))) {
                return null;
            }
            Method allowSprint = findNoArg(process.getClass(), "allowSprint");
            return allowSprint == null ? null : (Boolean) allowSprint.invoke(process);
        } catch (ReflectiveOperationException | LinkageError ignored) {
            return null;
        }
    }

    private static Method findNoArg(Class<?> type, String name) {
        try {
            return type.getMethod(name);
        } catch (NoSuchMethodException ignored) {
            return null;
        }
    }

    private static boolean sampledJump(ClientPlayerEntity player) {
        return player.input != null && player.input.playerInput.jump();
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player != null) {
            player.setSprinting(false);
        }
    }

    @Override
    protected void onDisable() {
        release();
        controlledPlayer = null;
    }

    private void release() {
        if (controlledPlayer != null) {
            controlledPlayer.setSprinting(false);
        }
    }
}
