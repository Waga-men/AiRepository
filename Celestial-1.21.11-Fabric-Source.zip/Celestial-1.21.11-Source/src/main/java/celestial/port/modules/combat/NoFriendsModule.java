package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.math.Vec3d;

public final class NoFriendsModule extends Module {
    public NoFriendsModule() {
        super("no_friends", "No Friends",
                "\u041e\u0442\u043c\u0435\u043d\u044f\u0435\u0442 \u0443\u0440\u043e\u043d \u043f\u043e \u0434\u0440\u0443\u0437\u044c\u044f\u043c", Category.COMBAT);
    }

    public static boolean shouldCancelOutgoing(Packet<?> rawPacket) {
        Module raw = CelestialPortClient.MODULES.find("no_friends").orElse(null);
        if (!(raw instanceof NoFriendsModule module) || !module.enabled()
                || !(rawPacket instanceof PlayerInteractEntityC2SPacket packet)) {
            return false;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return false;
        }

        try {
            AttackProbe probe = new AttackProbe();
            packet.handle(probe);
            if (!probe.attack) {
                return false;
            }

            Entity target = client.crosshairTarget instanceof EntityHitResult hit ? hit.getEntity() : null;
            return target != null && FriendManager.names().stream().anyMatch(
                    friend -> friend.equals(target.getName().getString()));
        } catch (Exception exception) {

            exception.printStackTrace();
            return false;
        }
    }

    private static final class AttackProbe implements PlayerInteractEntityC2SPacket.Handler {
        private boolean attack;

        @Override
        public void interact(Hand hand) {
        }

        @Override
        public void interactAt(Hand hand, Vec3d pos) {
        }

        @Override
        public void attack() {
            attack = true;
        }
    }
}
