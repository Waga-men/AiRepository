package celestial.port.modules.visual;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;

public interface HudVisual {
    void renderHud(DrawContext context, RenderTickCounter tickCounter);
}
