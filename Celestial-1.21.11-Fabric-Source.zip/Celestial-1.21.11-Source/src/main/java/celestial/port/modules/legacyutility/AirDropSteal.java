package celestial.port.modules.legacyutility;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.resource.language.I18n;
import net.minecraft.item.BlockItem;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.PotionItem;
import net.minecraft.item.ThrowablePotionItem;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;

public final class AirDropSteal extends Module {
    private static volatile AirDropSteal instance;
    private static final String AIR_DROP = "Аир дроп";
    private static final String CHEST = "Сундук";

    private final MultiSelectSetting targets = addSetting(new MultiSelectSetting(
            "targets", "Выбор целей", Set.of(AIR_DROP), List.of(AIR_DROP, CHEST)
    ));
    private final BindSetting activationKey = addSetting(new BindSetting(
            "activation_key", "Клавиша",
            BindSetting.forMouseButton(GLFW.GLFW_MOUSE_BUTTON_MIDDLE)
    ));
    private final BooleanSetting spamClicks = addSetting(new BooleanSetting(
            "spam_clicks", "Спамить кликами", false
    ));
    private final NumberSetting delay = addSetting(new NumberSetting(
            "delay", "Задержка", 0.0, 0.0, 15.0, 1.0
    ));

    private long lastLootClickMillis = System.currentTimeMillis();

    private GenericContainerScreen capturedScreen;
    private BlockPos lastTarget;

    public AirDropSteal() {
        super("airdrop_steal", "Air Drop Steal",
                "Моментально лутает аирдропы на риливорлде", Category.UTILITY);
        instance = this;
    }

    public static boolean shouldCancelAttackInput() {
        AirDropSteal module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        return module != null && module.enabled()
                && module.spamClicks.enabled()
                && module.lastTarget != null
                && client.player != null
                && client.world != null
                && module.keyPressed(client);
    }

    public MultiSelectSetting targets() {
        return targets;
    }

    public BindSetting activationKey() {
        return activationKey;
    }

    public BooleanSetting spamClicks() {
        return spamClicks;
    }

    public NumberSetting delay() {
        return delay;
    }

    public static void capture(GenericContainerScreen screen) {
        AirDropSteal module = instance;
        if (module != null && module.enabled()) {
            module.capturedScreen = screen;
        }
    }

    public static void onKeyboardPress(MinecraftClient client, int key) {
        AirDropSteal module = instance;
        if (module == null || !module.enabled() || module.spamClicks.enabled()
                || client.currentScreen != null || !module.activationKey.isBound()
                || BindSetting.isMouseButton(module.activationKey.key())
                || module.activationKey.key() != key) {
            return;
        }
        module.openNearestTarget(client);
    }

    public static void onMousePress(MinecraftClient client, int button) {
        AirDropSteal module = instance;
        if (module == null || !module.enabled() || module.spamClicks.enabled()
                || client.currentScreen != null || !module.activationKey.isBound()
                || !BindSetting.isMouseButton(module.activationKey.key())
                || BindSetting.mouseButton(module.activationKey.key()) != button) {
            return;
        }
        module.openNearestTarget(client);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.interactionManager == null) {
            return;
        }

        if (capturedScreen != null && matches(capturedScreen) && hasMainBlockItem(client)) {
            loot(client, capturedScreen);
        }

        if (client.currentScreen instanceof GenericContainerScreen) {
            return;
        }

        if (spamClicks.enabled() && keyPressed(client)) {
            openNearestTarget(client);
        }
    }

    private void loot(MinecraftClient client, GenericContainerScreen screen) {
        List<Slot> slots = new ArrayList<>();
        int containerSlots = screen.getScreenHandler().getInventory().size();
        for (int index = 0; index < containerSlots; index++) {
            Slot slot = screen.getScreenHandler().slots.get(index);
            if (slot.hasStack()) {
                slots.add(slot);
            }
        }
        slots.sort(Comparator.comparingInt((Slot slot) -> priority(slot.getStack())).reversed());

        for (Slot slot : slots) {
            if (delay.value() > 0.0) {
                long now = System.currentTimeMillis();
                if ((double) (now - lastLootClickMillis) <= delay.value() * 20.0) {
                    continue;
                }
                client.interactionManager.clickSlot(
                        screen.getScreenHandler().syncId, slot.id, 0,
                        SlotActionType.QUICK_MOVE, client.player
                );
                lastLootClickMillis = System.currentTimeMillis();
                continue;
            }
            client.interactionManager.clickSlot(
                    screen.getScreenHandler().syncId, slot.id, 0,
                    SlotActionType.QUICK_MOVE, client.player
            );
        }
    }

    private boolean matches(GenericContainerScreen screen) {
        String title = Formatting.strip(screen.getTitle().getString());
        if (title == null) {
            title = "";
        }
        boolean airDrop = title.contains("АирДроп");
        if (airDrop && targets.selected(AIR_DROP)) {
            return true;
        }
        if (airDrop || !targets.selected(CHEST)) {
            return false;
        }
        String chestName = I18n.translate("container.chest");
        return title.contains(chestName);
    }

    private void openNearestTarget(MinecraftClient client) {
        if (client.player == null || client.world == null || client.interactionManager == null) {
            return;
        }
        BlockPos origin = client.player.getBlockPos();
        BlockPos nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (int x = -6; x <= 6; x++) {
            for (int z = -6; z <= 6; z++) {
                for (int y = -6; y < 6; y++) {
                    BlockPos candidate = origin.add(x, y, z);
                    boolean airDrop = targets.selected(AIR_DROP)
                            && client.world.getBlockState(candidate).isOf(Blocks.NOTE_BLOCK);
                    boolean chest = targets.selected(CHEST)
                            && client.world.getBlockState(candidate).isOf(Blocks.CHEST);
                    if (!airDrop && !chest) {
                        continue;
                    }
                    double distance = client.player.squaredDistanceTo(
                            candidate.getX(), candidate.getY(), candidate.getZ());
                    if (distance < nearestDistance) {
                        nearestDistance = distance;
                        nearest = candidate.toImmutable();
                    }
                }
            }
        }

        lastTarget = nearest;
        if (nearest == null) {
            return;
        }

        if (client.world.getBlockState(nearest).isOf(Blocks.CHEST)) {
            Vec3d center = new Vec3d(nearest.getX(), nearest.getY(), nearest.getZ());
            client.interactionManager.interactBlock(client.player, Hand.MAIN_HAND,
                    new net.minecraft.util.hit.BlockHitResult(center, Direction.UP, nearest, false));
        } else if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                    PlayerActionC2SPacket.Action.START_DESTROY_BLOCK, nearest, Direction.UP
            ));
        }
    }

    private boolean keyPressed(MinecraftClient client) {
        return activationKey.isBound()
                && BindSetting.isPressed(client.getWindow().getHandle(), activationKey.key());
    }

    private static boolean hasMainBlockItem(MinecraftClient client) {
        for (int slot = 0; slot < 36; slot++) {
            if (client.player.getInventory().getStack(slot).getItem() instanceof BlockItem) {
                return true;
            }
        }
        return false;
    }

    private static int priority(ItemStack stack) {
        if (stack.isIn(ItemTags.SKULLS)) {
            return 100;
        }
        if (stack.isIn(ItemTags.HEAD_ARMOR) || stack.isIn(ItemTags.CHEST_ARMOR)
                || stack.isIn(ItemTags.LEG_ARMOR) || stack.isIn(ItemTags.FOOT_ARMOR)) {
            return 90;
        }
        if (stack.getItem() instanceof PotionItem
                || stack.getItem() instanceof ThrowablePotionItem) {
            return 80;
        }
        if (stack.isIn(ItemTags.AXES) || stack.isIn(ItemTags.PICKAXES)
                || stack.isIn(ItemTags.SHOVELS)) {
            return 70;
        }
        if (stack.isIn(ItemTags.SWORDS)) {
            return 60;
        }
        if (stack.getItem() instanceof BowItem) {
            return 50;
        }
        return stack.getItem().getName(stack).getString().length();
    }

    @Override
    protected void onDisable() {

    }
}
