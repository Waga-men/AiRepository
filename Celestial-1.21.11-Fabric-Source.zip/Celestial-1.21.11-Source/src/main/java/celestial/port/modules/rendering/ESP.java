package celestial.port.modules.rendering;

import celestial.port.CelestialPortClient;
import celestial.port.client.ui.LegacyHudFont;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.modules.render.ArrayListModule;
import celestial.port.modules.player.ClickTP;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.ItemEnchantmentsComponent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.BowItem;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.tag.ItemTags;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Vector3fc;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

public final class ESP extends Module {
    private static final String PLAYERS = "Игроки";
    private static final String NPCS = "НПС / Боты";
    private static final String MOBS = "Мобы";
    private static final String ITEMS = "Предметы";
    private static final int OUTLINE = 0xB4000000;
    private static final int TEXT = 0xFFEBEBEB;
    private static final int INFO_BACKGROUND = 0xEB191919;
    private static final StyleSpriteSource FONT_DR = LegacyHudFont.font(12);
    private static final StyleSpriteSource FONT_DX = LegacyHudFont.font(18);

    private static ESP instance;

    private final MultiSelectSetting targets = addSetting(new MultiSelectSetting(
            "targets", "Выбор целей", Set.of(PLAYERS), List.of(PLAYERS, NPCS, MOBS, ITEMS)
    ));
    private final BooleanSetting boxes = addSetting(new BooleanSetting(
            "boxes", "Бокс", true
    ));
    private final BooleanSetting health = addSetting(new BooleanSetting(
            "health", "Здоровье", true
    ));
    private final BooleanSetting playerInfo = addSetting(new BooleanSetting(
            "player_info", "Инфо о игроке", true
    ));
    private final BooleanSetting itemTags = addSetting(new BooleanSetting(
            "item_tags", "Теги на предметы", true
    ));

    public ESP() {
        super("esp", "ESP", "Альтернатива WallHack", Category.RENDER);
        instance = this;
    }

    public static boolean suppressesVanillaPlayerLabels() {
        ESP module = instance;
        return module != null && module.enabled()
                && module.targets.selected(PLAYERS)
                && module.playerInfo.enabled();
    }

    public MultiSelectSetting targets() {
        return targets;
    }

    public BooleanSetting boxes() {
        return boxes;
    }

    public BooleanSetting health() {
        return health;
    }

    public BooleanSetting playerInfo() {
        return playerInfo;
    }

    public BooleanSetting itemTags() {
        return itemTags;
    }

    void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || !client.gameRenderer.getCamera().isReady()) {
            return;
        }

        int width = context.getScaledWindowWidth();
        int height = context.getScaledWindowHeight();
        float tickProgress = tickCounter.getTickProgress(false);
        int first = clientColor(0.0F);
        int second = clientColor(90.0F);
        int third = clientColor(180.0F);
        int fourth = clientColor(270.0F);

        for (Entity entity : client.world.getEntities()) {
            if (!isSelected(client, entity)) {
                continue;
            }
            ScreenRect rect = project(client, entity, tickProgress, width, height);
            if (rect == null || rect.right <= 0 || rect.left >= width
                    || rect.bottom <= 0 || rect.top >= height) {
                continue;
            }

            if (boxes.enabled()) {
                drawBox(context, rect, first, second, third, fourth);
            }
            if (health.enabled() && entity instanceof LivingEntity living) {
                drawHealth(context, rect, living, first, third);
            }
            if (entity instanceof ItemEntity item) {
                if (itemTags.enabled()) {
                    drawItemTag(context, client.textRenderer, rect, item);
                }
                continue;
            }
            if (playerInfo.enabled() && entity instanceof PlayerEntity player && player != client.player) {
                drawPlayerInfo(context, client, rect, player);
            }
            if (entity instanceof PlayerEntity player) {
                drawClickTpHint(context, client, rect, player);
            }
        }
    }

    private boolean isSelected(MinecraftClient client, Entity entity) {
        if (entity == null || !entity.isAlive()) {
            return false;
        }
        if (entity == client.player) {
            return !client.options.getPerspective().isFirstPerson() && targets.selected(PLAYERS);
        }
        if (entity instanceof ItemEntity) {
            return targets.selected(ITEMS);
        }
        if (entity instanceof PlayerEntity player) {
            if (!targets.selected(PLAYERS)) {
                return false;
            }
            return targets.selected(NPCS) || !legacyBot(player);
        }
        return entity instanceof MobEntity && targets.selected(MOBS);
    }

    private static ScreenRect project(
            MinecraftClient client, Entity entity, float tickProgress, int width, int height
    ) {
        Vec3d position = entity.getLerpedPos(tickProgress);
        double halfWidth = entity.getWidth() / 1.5;
        double entityHeight = entity.getHeight();
        if (entity instanceof LivingEntity living && living.isBaby()) {
            halfWidth *= 0.6;
            entityHeight *= 0.5;
        }
        if (entity.isSneaking()) {
            entityHeight -= 0.2;
        }
        double y = position.y + (entity instanceof ItemEntity ? -0.1 : 0.1);
        Vec3d[] corners = {
                new Vec3d(position.x - halfWidth, y, position.z - halfWidth),
                new Vec3d(position.x - halfWidth, y + entityHeight, position.z - halfWidth),
                new Vec3d(position.x + halfWidth, y, position.z - halfWidth),
                new Vec3d(position.x + halfWidth, y + entityHeight, position.z - halfWidth),
                new Vec3d(position.x - halfWidth, y, position.z + halfWidth),
                new Vec3d(position.x - halfWidth, y + entityHeight, position.z + halfWidth),
                new Vec3d(position.x + halfWidth, y, position.z + halfWidth),
                new Vec3d(position.x + halfWidth, y + entityHeight, position.z + halfWidth)
        };

        Camera camera = client.gameRenderer.getCamera();
        Vec3d cameraPos = camera.getCameraPos();
        Vector3fc forward = camera.getHorizontalPlane();
        double minX = Double.POSITIVE_INFINITY;
        double minY = Double.POSITIVE_INFINITY;
        double maxX = Double.NEGATIVE_INFINITY;
        double maxY = Double.NEGATIVE_INFINITY;
        boolean found = false;

        for (Vec3d corner : corners) {
            Vec3d relative = corner.subtract(cameraPos);
            double forwardDistance = relative.x * forward.x()
                    + relative.y * forward.y() + relative.z * forward.z();
            if (forwardDistance <= 0.05) {
                continue;
            }
            Vec3d projected = client.gameRenderer.project(corner);
            if (!Double.isFinite(projected.x) || !Double.isFinite(projected.y)) {
                continue;
            }
            double x = (projected.x + 1.0) * width * 0.5;
            double screenY = (1.0 - projected.y) * height * 0.5;
            minX = Math.min(minX, x);
            minY = Math.min(minY, screenY);
            maxX = Math.max(maxX, x);
            maxY = Math.max(maxY, screenY);
            found = true;
        }
        if (!found) {
            return null;
        }
        int left = safeRound(minX);
        int top = safeRound(minY);
        int right = safeRound(maxX);
        int bottom = safeRound(maxY);
        return right - left >= 1 && bottom - top >= 1
                ? new ScreenRect(left, top, right, bottom) : null;
    }

    private static int safeRound(double value) {
        return (int) Math.round(MathHelper.clamp(value, -16_384.0, 16_384.0));
    }

    private static void drawBox(
            DrawContext context, ScreenRect rect, int first, int second, int third, int fourth
    ) {
        int innerWidth = Math.max(0, rect.right - rect.left - 2);
        int innerHeight = Math.max(0, rect.bottom - rect.top + 2);
        context.fill(rect.left + 1, rect.top - 1, rect.right - 1, rect.top + 1, OUTLINE);
        context.fill(rect.left - 1, rect.top - 1, rect.left + 1, rect.bottom + 1, OUTLINE);
        context.fill(rect.left + 1, rect.bottom - 1, rect.right - 1, rect.bottom + 1, OUTLINE);
        context.fill(rect.right - 1, rect.top - 1, rect.right + 1, rect.bottom + 1, OUTLINE);

        horizontalGradient(context, rect.left + 1, rect.top, innerWidth, first, second);
        context.fillGradient(rect.left, rect.top, rect.left + 1, rect.top + innerHeight, first, fourth);
        horizontalGradient(context, rect.left + 1, rect.bottom, Math.max(0, rect.right - rect.left - 1),
                fourth, third);
        context.fillGradient(rect.right, rect.top, rect.right + 1, rect.top + innerHeight, second, third);
    }

    private static void drawHealth(
            DrawContext context, ScreenRect rect, LivingEntity entity, int topColor, int bottomColor
    ) {
        float ratio = MathHelper.clamp(entity.getHealth() / Math.max(0.001F, entity.getMaxHealth()), 0.0F, 1.0F);
        int height = rect.bottom - rect.top;
        int x = rect.left - 4;
        context.fill(x, rect.top - 1, x + 2, rect.bottom + 1, OUTLINE);
        int filled = Math.max(1, Math.round(height * ratio));
        int fillTop = rect.bottom - filled;
        context.fillGradient(x + 1, fillTop, x + 2, rect.bottom + 1, topColor, bottomColor);
    }

    private static void drawItemTag(
            DrawContext context, TextRenderer renderer, ScreenRect rect, ItemEntity entity
    ) {
        ItemStack stack = entity.getStack();
        String label = stack.getName().getString() + (stack.getCount() > 1 ? " x" + stack.getCount() : "");
        int x = (rect.left + rect.right - renderer.getWidth(label)) / 2;
        context.drawText(renderer, label, x, rect.top - 6, 0xFFFFFFFF, false);
    }

    private static void drawPlayerInfo(
            DrawContext context, MinecraftClient client, ScreenRect rect, PlayerEntity player
    ) {
        String label = playerLabel(client.player, player);
        int labelWidth = LegacyHudFont.width(client.textRenderer, label, FONT_DR);
        float center = (rect.left + rect.right) * 0.5F;
        float infoTop = rect.top - 8.0F;
        float labelX = center - labelWidth * 0.5F;
        fillInfoBackground(context, labelX - 3.0F, infoTop - 3.0F,
                labelWidth + 5, 9, INFO_BACKGROUND);
        LegacyHudFont.draw(context, client.textRenderer, label,
                labelX - 1.0F, infoTop + 0.5F, TEXT, FONT_DR, true);

        drawEquipment(context, client, center, infoTop, player);
        drawPotionInfo(context, client.textRenderer,
                rect.right + 2.0F, infoTop + 9.0F, player);
    }

    private static void fillInfoBackground(
            DrawContext context, float x, float y, int width, int height, int color
    ) {
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.fill(0, 0, width, height, color);
        context.getMatrices().popMatrix();
    }

    private static void drawClickTpHint(
            DrawContext context, MinecraftClient client, ScreenRect rect, PlayerEntity player
    ) {
        Module module = CelestialPortClient.MODULES.find("click_tp").orElse(null);
        if (!(module instanceof ClickTP clickTp) || !clickTp.enabled() || clickTp.aimedPlayer() != player) {
            return;
        }
        String label = "Click to TP";
        int x = (rect.left + rect.right - client.textRenderer.getWidth(label)) / 2;
        int y = rect.bottom + (player.getStatusEffects().isEmpty() ? 5 : 10);
        context.drawText(client.textRenderer, label, x, y, TEXT, false);
    }

    private static String playerLabel(PlayerEntity self, PlayerEntity player) {
        int distance = (int) self.distanceTo(player);
        String healthColor = (player.getHealth() >= 15.0F ? Formatting.GREEN
                : player.getHealth() >= 5.0F ? Formatting.YELLOW : Formatting.RED).toString();
        String friend = FriendManager.isFriend(player) ? Formatting.GREEN + "[F] " : "";
        return Formatting.GREEN + "[" + Formatting.WHITE + distance
                + Formatting.GREEN + "] " + Formatting.GRAY + friend + Formatting.GRAY
                + legacyFormattedDisplayName(player.getDisplayName()) + " " + healthColor + "("
                + Formatting.WHITE + String.format(Locale.ROOT, "%.1f", player.getHealth())
                + " HP" + healthColor + ")";
    }

    private static String legacyFormattedDisplayName(Text displayName) {
        StringBuilder result = new StringBuilder();
        displayName.visit((style, value) -> {
            result.append(Formatting.GRAY);
            Formatting color = legacyColor(style.getColor());
            if (color != null) {
                result.append(color);
            }
            result.append(value);
            return Optional.empty();
        }, Style.EMPTY);
        return result.toString();
    }

    private static Formatting legacyColor(TextColor color) {
        if (color == null) {
            return null;
        }
        for (Formatting formatting : Formatting.values()) {
            Integer rgb = formatting.getColorValue();
            if (formatting.isColor() && rgb != null && rgb == color.getRgb()) {
                return formatting;
            }
        }
        return null;
    }

    private static void drawEquipment(
            DrawContext context, MinecraftClient client, float center, float y, PlayerEntity player
    ) {
        List<ItemStack> stacks = new ArrayList<>(5);
        stacks.add(player.getMainHandStack());
        stacks.add(player.getEquippedStack(EquipmentSlot.FEET));
        stacks.add(player.getEquippedStack(EquipmentSlot.LEGS));
        stacks.add(player.getEquippedStack(EquipmentSlot.CHEST));
        stacks.add(player.getEquippedStack(EquipmentSlot.HEAD));
        int itemX = -(stacks.size() * 9) - 12;
        int offhandX = itemX + 95;
        int enchantX = -(stacks.size() * 9) - 11;

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(center, y + 2);
        context.getMatrices().scale(0.5F, 0.5F);

        for (ItemStack stack : stacks) {
            context.drawItem(player, stack, itemX + 6, -28, 0);
            context.drawStackOverlay(client.textRenderer, stack, itemX + 5, -28);
            itemX += 18;
        }
        ItemStack offhand = player.getOffHandStack();
        context.drawItem(player, offhand, offhandX, -28, 0);
        context.drawStackOverlay(client.textRenderer, offhand, offhandX, -28);

        for (ItemStack stack : stacks) {
            List<String> enchants = enchantmentLabels(stack);
            for (int line = 0; line < enchants.size(); line++) {
                LegacyHudFont.draw(context, client.textRenderer, enchants.get(line),
                        enchantX + 6, -35 - line * 8, TEXT, FONT_DX, true);
            }
            enchantX += 18;
        }
        context.getMatrices().popMatrix();
    }

    private static List<String> enchantmentLabels(ItemStack stack) {
        ItemEnchantmentsComponent enchantments = stack.getOrDefault(
                DataComponentTypes.ENCHANTMENTS, ItemEnchantmentsComponent.DEFAULT
        );
        List<String> labels = new ArrayList<>();
        addEnchantmentLabel(labels, enchantments, Enchantments.SHARPNESS, "S");
        addEnchantmentLabel(labels, enchantments, Enchantments.FIRE_ASPECT, "F");

        int knockback = enchantmentLevel(enchantments, Enchantments.KNOCKBACK);
        if (knockback > 0) {
            labels.add("Kb" + knockback);
        } else if (isArmor(stack)) {
            addEnchantmentLabel(labels, enchantments, Enchantments.PROTECTION, "P");
            addEnchantmentLabel(labels, enchantments, Enchantments.THORNS, "Th");
            addEnchantmentLabel(labels, enchantments, Enchantments.UNBREAKING, "U");
        } else if (stack.getItem() instanceof BowItem) {
            addEnchantmentLabel(labels, enchantments, Enchantments.POWER, "P");
            addEnchantmentLabel(labels, enchantments, Enchantments.PUNCH, "P");
            addEnchantmentLabel(labels, enchantments, Enchantments.FLAME, "F");
        }
        return labels;
    }

    private static boolean isArmor(ItemStack stack) {
        return stack.isIn(ItemTags.FOOT_ARMOR)
                || stack.isIn(ItemTags.LEG_ARMOR)
                || stack.isIn(ItemTags.CHEST_ARMOR)
                || stack.isIn(ItemTags.HEAD_ARMOR);
    }

    private static void addEnchantmentLabel(
            List<String> labels, ItemEnchantmentsComponent enchantments,
            RegistryKey<Enchantment> enchantment, String prefix
    ) {
        int level = enchantmentLevel(enchantments, enchantment);
        if (level > 0) {
            labels.add(prefix + level);
        }
    }

    private static int enchantmentLevel(
            ItemEnchantmentsComponent enchantments, RegistryKey<Enchantment> enchantment
    ) {
        for (var entry : enchantments.getEnchantmentEntries()) {
            if (entry.getKey().matchesKey(enchantment)) {
                return entry.getIntValue();
            }
        }
        return 0;
    }

    private static void drawPotionInfo(
            DrawContext context, TextRenderer renderer, float x, float y, PlayerEntity player
    ) {
        for (StatusEffectInstance effect : player.getStatusEffects()) {
            if (effect.getDuration() == 0) continue;
            String name = effect.getEffectType().value().getName().getString();
            String label = name + " " + (effect.getAmplifier() + 1)
                    + Formatting.GRAY + " " + duration(effect);
            LegacyHudFont.draw(context, renderer, label, x, y, TEXT, FONT_DR, false);
            y += 7.0F;
        }
    }

    private static String duration(StatusEffectInstance effect) {
        if (effect.isInfinite()) {
            return "**:**";
        }
        int seconds = Math.max(0, effect.getDuration() / 20);
        return String.format(Locale.ROOT, "%d:%02d", seconds / 60, seconds % 60);
    }

    private static boolean legacyBot(PlayerEntity player) {
        UUID offline = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + player.getGameProfile().name()).getBytes(StandardCharsets.UTF_8)
        );
        return !player.getUuid().equals(offline);
    }

    private static int clientColor(float offsetDegrees) {
        Module module = CelestialPortClient.MODULES.find("array_list").orElse(null);
        if (!(module instanceof ArrayListModule array)) {
            return 0xFFC87DFF;
        }
        double phase = Util.getMeasuringTimeMs() / (1450.0 / array.colorSpeed())
                + (270.0 + offsetDegrees) * 0.018;
        return switch (array.colorMode()) {
            case "Static" -> array.staticColor();
            case "Rainbow" -> 0xFF000000 | (Color.HSBtoRGB(
                    (float) ((phase * 0.12) - Math.floor(phase * 0.12)),
                    0.7F, 1.0F
            ) & 0xFFFFFF);
            case "Astolfo" -> 0xFF000000 | (Color.HSBtoRGB(
                    (float) ((0.82 + Math.sin(phase) * 0.11) % 1.0), 0.45F, 1.0F
            ) & 0xFFFFFF);
            default -> blend(array.fadeFirstColor(), array.fadeSecondColor(),
                    (float) ((Math.sin(phase) + 1.0) * 0.5));
        };
    }

    private static int blend(int first, int second, float amount) {
        float value = MathHelper.clamp(amount, 0.0F, 1.0F);
        int red = Math.round(((first >>> 16) & 255) * (1.0F - value) + ((second >>> 16) & 255) * value);
        int green = Math.round(((first >>> 8) & 255) * (1.0F - value) + ((second >>> 8) & 255) * value);
        int blue = Math.round((first & 255) * (1.0F - value) + (second & 255) * value);
        return 0xFF000000 | red << 16 | green << 8 | blue;
    }

    private static void horizontalGradient(
            DrawContext context, int x, int y, int width, int first, int second
    ) {
        for (int column = 0; column < width; column++) {
            float amount = width <= 1 ? 0.0F : column / (float) (width - 1);
            context.fill(x + column, y, x + column + 1, y + 1, blend(first, second, amount));
        }
    }

    private record ScreenRect(int left, int top, int right, int bottom) {
    }
}
