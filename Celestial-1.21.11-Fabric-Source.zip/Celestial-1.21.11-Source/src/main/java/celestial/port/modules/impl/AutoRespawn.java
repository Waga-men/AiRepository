package celestial.port.modules.impl;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.TextSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.DeathScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;

public final class AutoRespawn extends Module {
    private static volatile AutoRespawn instance;

    private final TextSetting message = addSetting(new TextSetting(
            "message", "\u0421\u043e\u043e\u0431\u0449\u0435\u043d\u0438\u0435", "", 32
    ));

    public AutoRespawn() {
        super("auto_respawn", "Auto Respawn",
                "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0440\u0435\u0441\u043f\u0430\u0432\u043d\u0438\u0442 \u0432\u0430\u0441 \u043f\u043e\u0441\u043b\u0435 \u0441\u043c\u0435\u0440\u0442\u0438", Category.PLAYER);
        instance = this;
    }

    public TextSetting message() {
        return message;
    }

    public static void beforeVanillaPlayerTick(ClientPlayerEntity player) {
        AutoRespawn module = instance;
        if (module == null || !module.enabled()) {
            return;
        }
        module.tickLegacy(player);
    }

    private void tickLegacy(ClientPlayerEntity player) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (player == null || player != client.player || client.world == null
                || !(client.currentScreen instanceof DeathScreen) || player.deathTime > 1) {
            return;
        }

        player.requestRespawn();
        sendConfiguredMessage(client.getNetworkHandler(), message.value());
    }

    private static void sendConfiguredMessage(ClientPlayNetworkHandler networkHandler, String text) {
        if (networkHandler == null || text.isEmpty()) {
            return;
        }
        if (text.startsWith("/")) {
            networkHandler.sendChatCommand(text.substring(1));
        } else {
            networkHandler.sendChatMessage(text);
        }
    }
}
