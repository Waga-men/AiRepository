package celestial.port.modules.rendering;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.modules.visual.VisualColors;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;

import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;

public final class RotationView extends Module {
    private static final RenderLayer TRANSLUCENT_LAYER =
            createFlatLayer("translucent", BlendFunction.TRANSLUCENT);
    private static final RenderLayer GLOW_LAYER =
            createFlatLayer("glow", BlendFunction.LIGHTNING);
    private static volatile RotationView instance;

    private final ModeSetting colorMode = addSetting(new ModeSetting(
            "color_mode", "Режим цвета", "Client", List.of("Client", "Static")
    ));
    private final ColorSetting color = addSetting(new ColorSetting(
            "color", "Цвет", 0xFFBE65FF, false
    ).visibleWhen(() -> colorMode.is("Static")));
    private final BooleanSetting glow = addSetting(new BooleanSetting(
            "glow", "Свечение", true
    ));

    private final Map<PlayerEntityModel, ServerRotationModel> rotationModels = new WeakHashMap<>();
    private float serverYaw;
    private float serverPitch;
    private int capturedPlayerAge = Integer.MIN_VALUE;
    private boolean silentRotation;

    public RotationView() {
        super("rotation_view", "Rotation View",
                "Визуализирует куда вы смотрите на сервере от третьего лица", Category.RENDER);
        instance = this;
    }

    public ModeSetting colorMode() {
        return colorMode;
    }

    public ColorSetting color() {
        return color;
    }

    public BooleanSetting glow() {
        return glow;
    }

    public static void onOutgoingPacket(Packet<?> packet) {
        RotationView module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || client.player == null
                || !(packet instanceof PlayerMoveC2SPacket movement) || !movement.changesLook()) {
            return;
        }

        float yaw = movement.getYaw(client.player.getYaw());
        float pitch = movement.getPitch(client.player.getPitch());
        module.serverYaw = yaw;
        module.serverPitch = pitch;
        module.capturedPlayerAge = client.player.age;
        module.silentRotation = Math.abs(MathHelper.wrapDegrees(yaw - client.player.getYaw())) > 1.0E-3F
                || Math.abs(pitch - client.player.getPitch()) > 1.0E-3F;
    }

    public static void submitServerRotation(PlayerEntityRenderState state,
                                            PlayerEntityModel renderedModel,
                                            MatrixStack matrices,
                                            OrderedRenderCommandQueue queue) {
        RotationView module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || !module.silentRotation
                || client.player == null || state.id != client.player.getId()
                || module.capturedPlayerAge != client.player.age) {
            return;
        }

        ServerRotationModel rotationModel;
        synchronized (module.rotationModels) {
            rotationModel = module.rotationModels.computeIfAbsent(renderedModel,
                    source -> new ServerRotationModel(source.getRootPart()));
        }
        rotationModel.prepare(module.serverPitch);

        matrices.push();

        matrices.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(module.serverYaw - state.bodyYaw));

        RenderLayer layer = module.glow.enabled() ? GLOW_LAYER : TRANSLUCENT_LAYER;
        queue.submitModel(
                rotationModel,
                state,
                matrices,
                layer,
                state.light,
                OverlayTexture.DEFAULT_UV,
                module.selectedColor(),
                null,
                0,
                null
        );
        matrices.pop();
    }

    private int selectedColor() {
        return colorMode.is("Static") ? color.argb() : VisualColors.clientColor(270.0F);
    }

    private static RenderLayer createFlatLayer(String suffix, BlendFunction blend) {
        RenderPipeline pipeline = RenderPipelines.register(RenderPipeline.builder()
                .withLocation(Identifier.of("celestial", "pipeline/rotation_view_" + suffix))
                .withVertexShader("core/position_color")
                .withFragmentShader("core/position_color")
                .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
                .withUniform("Projection", UniformType.UNIFORM_BUFFER)
                .withBlend(blend)
                .withCull(true)
                .withDepthWrite(true)
                .withVertexFormat(VertexFormats.POSITION_COLOR, VertexFormat.DrawMode.QUADS)
                .build());
        RenderSetup setup = RenderSetup.builder(pipeline)
                .translucent()
                .build();
        return RenderLayer.of("celestial_rotation_view_" + suffix, setup);
    }

    private static final class ServerRotationModel extends PlayerEntityModel {
        private float pitch;

        private ServerRotationModel(net.minecraft.client.model.ModelPart root) {
            super(root, false);
        }

        private void prepare(float pitch) {
            this.pitch = pitch;
        }

        @Override
        public void setAngles(PlayerEntityRenderState state) {
            float oldRelativeHeadYaw = state.relativeHeadYaw;
            float oldPitch = state.pitch;
            state.relativeHeadYaw = 0.0F;
            state.pitch = pitch;
            super.setAngles(state);
            state.relativeHeadYaw = oldRelativeHeadYaw;
            state.pitch = oldPitch;
        }
    }
}
