package celestial.port.modules.rendering;

import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Objects;

public final class RenderingCallbacks {
    private static boolean registered;

    private RenderingCallbacks() {
    }

    public static synchronized void register(
            Crosshair crosshair,
            Tracers tracers,
            ESP esp,
            BlockESP blockEsp,
            NoRender noRender,
            CustomWorld customWorld,
            RotationView rotationView
    ) {
        Objects.requireNonNull(crosshair, "crosshair");
        Objects.requireNonNull(tracers, "tracers");
        Objects.requireNonNull(esp, "esp");
        Objects.requireNonNull(blockEsp, "blockEsp");
        Objects.requireNonNull(noRender, "noRender");
        Objects.requireNonNull(customWorld, "customWorld");
        Objects.requireNonNull(rotationView, "rotationView");
        if (registered) {
            throw new IllegalStateException("Rendering callbacks are already registered");
        }
        registered = true;

        List<WorldGizmoModule> worldModules = List.of(
                tracers,
                blockEsp,
                customWorld
        );
        WorldRenderEvents.END_EXTRACTION.register(context -> {
            for (WorldGizmoModule module : worldModules) {
                if (module.enabled()) {
                    module.collectGizmos(context);
                }
            }
        });

        HudElementRegistry.replaceElement(VanillaHudElements.CROSSHAIR, original ->
                (context, tickCounter) -> {
                    if (crosshair.shouldRenderCustom()) {
                        crosshair.render(context, tickCounter);
                    } else {
                        original.render(context, tickCounter);
                    }
                }
        );
        HudElementRegistry.addLast(Identifier.of("celestial", "esp"), (context, tickCounter) -> {
            if (esp.enabled()) {
                esp.render(context, tickCounter);
            }
        });
        HudElementRegistry.replaceElement(VanillaHudElements.SCOREBOARD, original ->
                (context, tickCounter) -> {
                    if (!noRender.shouldHideScoreboard()) {
                        original.render(context, tickCounter);
                    }
                }
        );
        HudElementRegistry.replaceElement(VanillaHudElements.TITLE_AND_SUBTITLE, original ->
                (context, tickCounter) -> {
                    if (!noRender.shouldHideTitles()) {
                        original.render(context, tickCounter);
                    }
                }
        );
        HudElementRegistry.replaceElement(VanillaHudElements.OVERLAY_MESSAGE, original ->
                (context, tickCounter) -> {
                    if (!noRender.shouldHideMusicTitle()) {
                        original.render(context, tickCounter);
                    }
                }
        );
        HudElementRegistry.replaceElement(VanillaHudElements.BOSS_BAR, original ->
                (context, tickCounter) -> {
                    if (!noRender.shouldHideBossBar()) {
                        original.render(context, tickCounter);
                    }
                }
        );
    }
}
