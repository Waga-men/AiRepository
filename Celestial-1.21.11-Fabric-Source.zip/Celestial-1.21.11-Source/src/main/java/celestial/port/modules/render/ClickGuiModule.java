package celestial.port.modules.render;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import net.minecraft.client.MinecraftClient;
import org.lwjgl.glfw.GLFW;

public final class ClickGuiModule extends Module {
    private final ColorSetting primary = addSetting(new ColorSetting(
            "primary", "Первый цвет", 0xFFBF68FF, false));
    private final ColorSetting secondary = addSetting(new ColorSetting(
            "secondary", "Второй цвет", 0xFF110122, false));
    private final BooleanSetting blur = addSetting(new BooleanSetting("blur", "Размытие", true));
    private final BooleanSetting shadows = addSetting(new BooleanSetting("shadows", "Тени", true));

    public ClickGuiModule() {
        super("click_gui", "Click GUI", "Opens the Celestial module screen", Category.RENDER);
        setKey(GLFW.GLFW_KEY_RIGHT_SHIFT);
    }

    @Override
    protected void onEnable() {
        MinecraftClient.getInstance().execute(() -> {
            CelestialPortClient.openClickGui();
            if (enabled()) setEnabled(false);
        });
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        applyLoadedEnabled(false);
    }

    public int primaryColor() {
        return primary.argb();
    }

    public int secondaryColor() {
        return secondary.argb();
    }

    public boolean blurEnabled() {
        return blur.enabled();
    }

    public boolean shadowsEnabled() {
        return shadows.enabled();
    }
}
