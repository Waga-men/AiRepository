package celestial.port.modules.player;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.PvpContext;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInteractItemC2SPacket;
import net.minecraft.network.packet.s2c.play.CooldownUpdateS2CPacket;

import java.util.List;
import java.util.Set;

public final class ItemsCooldownModule extends Module {
    private static final String APPLES = "\u0417\u043e\u043b\u043e\u0442\u044b\u0435 \u044f\u0431\u043b\u043e\u043a\u0438";
    private static final String PEARLS = "\u042d\u043d\u0434\u0435\u0440 \u043f\u0451\u0440\u043b\u044b";

    private final MultiSelectSetting items = addSetting(new MultiSelectSetting(
            "items", "\u0420\u0430\u0431\u043e\u0442\u0430\u0442\u044c \u043d\u0430", Set.of(APPLES, PEARLS), List.of(APPLES, PEARLS)
    ));
    private final BooleanSetting onlyPvp = addSetting(new BooleanSetting(
            "only_pvp", "\u0422\u043e\u043b\u044c\u043a\u043e \u0432 \u041f\u0412\u041f", false
    ));
    private final NumberSetting appleSeconds = addSetting(new NumberSetting(
            "apple_seconds", "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043d\u0430 \u044f\u0431\u043b\u043e\u043a\u043e", 2.3, 0.1, 5.0, 0.1
    ));
    private final NumberSetting pearlSeconds = addSetting(new NumberSetting(
            "pearl_seconds", "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043d\u0430 \u043f\u0451\u0440\u043b", 14.0, 1.5, 15.0, 0.1
    ));

    private long appleStartedAt;
    private long pearlStartedAt;
    private static ItemsCooldownModule instance;

    public ItemsCooldownModule() {
        super("items_cooldown", "Items Cooldown",
                "\u0423\u0441\u0442\u0430\u043d\u0430\u0432\u043b\u0438\u0432\u0430\u0435\u0442 \u0437\u0430\u0434\u0435\u0440\u0436\u043a\u0443 \u043d\u0430 \u043f\u0440\u0435\u0434\u043c\u0435\u0442 \u043f\u043e\u0441\u043b\u0435 \u0435\u0433\u043e \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u043e\u0432\u0430\u043d\u0438\u044f", Category.PLAYER);
        instance = this;
    }

    public static boolean onOutgoingPacket(Packet<?> rawPacket) {
        ItemsCooldownModule module = activeModule();
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (module == null || player == null
                || !(rawPacket instanceof PlayerInteractItemC2SPacket packet)
                || !module.allowedInCurrentContext()) {
            return false;
        }

        ItemStack stack = player.getStackInHand(packet.getHand());
        long now = System.currentTimeMillis();
        if (module.items.selected(APPLES) && isGoldenApple(stack)) {
            if (now - module.appleStartedAt < module.appleSeconds.value() * 1000.0) {
                return true;
            }
        } else if (module.items.selected(PEARLS) && stack.isOf(Items.ENDER_PEARL)) {
            if (now - module.pearlStartedAt < module.pearlSeconds.value() * 1000.0) {
                return true;
            }
        }
        return false;
    }

    public static void onFinishedUsing(ItemStack stack, PlayerEntity user) {
        ItemsCooldownModule module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || user != client.player || !isGoldenApple(stack)) {
            return;
        }
        module.appleStartedAt = System.currentTimeMillis();
    }

    public static void onCooldownUpdate(CooldownUpdateS2CPacket packet) {
        ItemsCooldownModule module = activeModule();
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (module == null || player == null || packet.cooldown() <= 0
                || !module.items.selected(PEARLS)) {
            return;
        }
        ItemCooldownManager manager = player.getItemCooldownManager();
        ItemStack pearl = new ItemStack(Items.ENDER_PEARL);
        if (packet.cooldownGroup().equals(manager.getGroup(pearl))) {
            module.pearlStartedAt = System.currentTimeMillis();
        }
    }

    public static float cooldownProgress(
            ItemCooldownManager manager, ItemStack stack, float vanillaProgress
    ) {
        ItemsCooldownModule module = activeModule();
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (module == null || player == null || manager != player.getItemCooldownManager()) {
            return vanillaProgress;
        }
        if (!module.allowedInCurrentContext()) {
            module.appleStartedAt = 0L;
            module.pearlStartedAt = 0L;
            return vanillaProgress;
        }
        long startedAt;
        double durationMillis;
        if (module.items.selected(APPLES) && isGoldenApple(stack)) {
            startedAt = module.appleStartedAt;
            durationMillis = module.appleSeconds.value() * 1000.0;
        } else if (module.items.selected(PEARLS) && stack.isOf(Items.ENDER_PEARL)) {
            startedAt = module.pearlStartedAt;
            durationMillis = module.pearlSeconds.value() * 1000.0;
        } else {
            return vanillaProgress;
        }
        long elapsed = System.currentTimeMillis() - startedAt;
        if (startedAt == 0L || elapsed >= durationMillis) {
            return vanillaProgress;
        }
        return 1.0F - (float) (elapsed / durationMillis);
    }

    private boolean allowedInCurrentContext() {
        return !onlyPvp.enabled() || PvpContext.active();
    }

    private static ItemsCooldownModule activeModule() {
        Module raw = CelestialPortClient.MODULES.find("items_cooldown").orElse(null);
        return raw instanceof ItemsCooldownModule module && module.enabled() ? module : null;
    }

    private static boolean isGoldenApple(ItemStack stack) {
        return stack.isOf(Items.GOLDEN_APPLE) || stack.isOf(Items.ENCHANTED_GOLDEN_APPLE);
    }

}
