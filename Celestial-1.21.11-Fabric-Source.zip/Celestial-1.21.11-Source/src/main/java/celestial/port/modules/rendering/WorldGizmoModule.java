package celestial.port.modules.rendering;

import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;

interface WorldGizmoModule {
    boolean enabled();

    void collectGizmos(WorldExtractionContext context);
}
