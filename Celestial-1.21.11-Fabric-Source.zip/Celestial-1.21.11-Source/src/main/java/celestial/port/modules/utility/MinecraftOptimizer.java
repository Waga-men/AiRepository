package celestial.port.modules.utility;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.visual.WorldVisual;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.CloudRenderMode;
import net.minecraft.client.option.GameOptions;
import net.minecraft.client.option.GraphicsMode;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.client.render.block.entity.state.BannerBlockEntityRenderState;
import net.minecraft.client.render.block.entity.state.BeaconBlockEntityRenderState;
import net.minecraft.client.render.block.entity.state.SignBlockEntityRenderState;
import net.minecraft.client.render.block.entity.state.SkullBlockEntityRenderState;
import net.minecraft.client.render.entity.state.ArmorStandEntityRenderState;
import net.minecraft.client.render.entity.state.ExperienceOrbEntityRenderState;
import net.minecraft.client.render.entity.state.ItemFrameEntityRenderState;
import net.minecraft.client.render.entity.state.PaintingEntityRenderState;
import net.minecraft.entity.EntityType;
import net.minecraft.particle.ParticlesMode;

import java.util.List;
import java.util.Set;

public final class MinecraftOptimizer extends Module implements WorldVisual {
    public static final String PARTICLES = "Выключение частиц";
    public static final String OPTIFINE = "Настройка Optifine";
    public static final String SKY = "Выключение неба";
    public static final String BLOCKS = "Удаление блоков";
    public static final String ENTITIES = "Удаление энтити";
    private static final Set<Block> LEGACY_CULLED_BLOCKS = Set.of(
            Blocks.AIR,
            Blocks.COCOA,
            Blocks.WHEAT,
            Blocks.CARROTS,
            Blocks.POTATOES,
            Blocks.BEETROOTS,
            Blocks.BROWN_MUSHROOM,
            Blocks.RED_MUSHROOM,
            Blocks.OAK_SAPLING,
            Blocks.SPRUCE_SAPLING,
            Blocks.BIRCH_SAPLING,
            Blocks.JUNGLE_SAPLING,
            Blocks.ACACIA_SAPLING,
            Blocks.DARK_OAK_SAPLING,
            Blocks.PUMPKIN_STEM,
            Blocks.MELON_STEM,
            Blocks.ATTACHED_PUMPKIN_STEM,
            Blocks.ATTACHED_MELON_STEM,
            Blocks.SHORT_GRASS,
            Blocks.FERN,
            Blocks.SUNFLOWER,
            Blocks.LILAC,
            Blocks.TALL_GRASS,
            Blocks.LARGE_FERN,
            Blocks.ROSE_BUSH,
            Blocks.PEONY,
            Blocks.DANDELION,
            Blocks.POPPY,
            Blocks.BLUE_ORCHID,
            Blocks.ALLIUM,
            Blocks.AZURE_BLUET,
            Blocks.RED_TULIP,
            Blocks.ORANGE_TULIP,
            Blocks.WHITE_TULIP,
            Blocks.PINK_TULIP,
            Blocks.OXEYE_DAISY
    );
    private static volatile MinecraftOptimizer instance;

    private final MultiSelectSetting actions = addSetting(new MultiSelectSetting(
            "actions", "Выполнять", Set.of(ENTITIES),
            List.of(PARTICLES, OPTIFINE, SKY, BLOCKS, ENTITIES)
    ));
    private final NumberSetting renderDistance = addSetting(new NumberSetting(
            "render_distance", "Дистанция рендера", 20.0, 16.0, 64.0, 4.0
    ));

    private Snapshot snapshot;
    private String appliedSignature;

    public MinecraftOptimizer() {
        super("minecraft_optimizer", "Minecraft Optimizer", "Оптимизирует майнкрафт", Category.UTILITY);
        instance = this;
    }

    public MultiSelectSetting actions() {
        return actions;
    }

    public NumberSetting renderDistance() {
        return renderDistance;
    }

    @Override
    protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!clientReady(client)) {
            snapshot = null;
            appliedSignature = null;
            return;
        }
        snapshot = Snapshot.capture(client.options);
        appliedSignature = null;
        applyOptions(client);
        client.worldRenderer.scheduleTerrainUpdate();
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!clientReady(client)) {
            return;
        }
        if (snapshot == null) {
            snapshot = Snapshot.capture(client.options);
        }
        applyOptions(client);
    }

    private void applyOptions(MinecraftClient client) {
        if (!clientReady(client)) {
            return;
        }
        String signature = actions.value().toString();
        if (signature.equals(appliedSignature) || snapshot == null) {
            return;
        }
        GameOptions options = client.options;
        boolean preset = actions.selected(OPTIFINE);
        options.getParticles().setValue(actions.selected(PARTICLES) ? ParticlesMode.MINIMAL : snapshot.particles);
        options.getPreset().setValue(preset ? GraphicsMode.FAST : snapshot.graphics);
        options.getCloudRenderMode().setValue(actions.selected(SKY) && !preset
                ? CloudRenderMode.OFF : snapshot.clouds);
        options.getBiomeBlendRadius().setValue(preset ? 0 : snapshot.biomeBlendRadius);
        options.getCutoutLeaves().setValue(preset ? false : snapshot.cutoutLeaves);
        options.getEntityShadows().setValue(preset ? false : snapshot.entityShadows);
        appliedSignature = signature;
        client.worldRenderer.scheduleTerrainUpdate();
    }

    @Override
    public void collectVisuals(WorldExtractionContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || context.world() != client.world) {
            return;
        }
        if (actions.selected(OPTIFINE)) {
            context.worldState().weatherRenderState.rainPieces.clear();
            context.worldState().weatherRenderState.snowPieces.clear();
        }
        if (actions.selected(SKY)) {
            context.worldState().skyRenderState.clear();
        }

        double maximumSquared = renderDistance.value() * renderDistance.value();
        context.worldState().entityRenderStates.removeIf(state ->
                state.entityType != EntityType.PLAYER
                        && squaredDistance(client.player.getX(), client.player.getY(), client.player.getZ(),
                        state.x, state.y, state.z) > maximumSquared
                        || actions.selected(ENTITIES) && (
                        state instanceof ExperienceOrbEntityRenderState
                                || state instanceof ArmorStandEntityRenderState
                                || state instanceof ItemFrameEntityRenderState
                                || state instanceof PaintingEntityRenderState
                )
        );
        if (actions.selected(ENTITIES)) {
            context.worldState().blockEntityRenderStates.removeIf(state ->
                    state instanceof BeaconBlockEntityRenderState
                            || state instanceof BannerBlockEntityRenderState
                            || state instanceof SignBlockEntityRenderState
                            || state instanceof SkullBlockEntityRenderState
            );
        }
    }

    private static double squaredDistance(
            double x1, double y1, double z1, double x2, double y2, double z2
    ) {
        double x = x1 - x2;
        double y = y1 - y2;
        double z = z1 - z2;
        return x * x + y * y + z * z;
    }

    public static boolean shouldSkipParticles() {
        MinecraftOptimizer module = instance;
        return module != null && module.enabled() && module.actions.selected(PARTICLES);
    }

    public static boolean shouldCullBlock(BlockState state) {
        MinecraftOptimizer module = instance;
        if (module == null || !module.enabled() || !module.actions.selected(BLOCKS)) {
            return false;
        }
        return LEGACY_CULLED_BLOCKS.contains(state.getBlock());
    }

    @Override
    protected void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (snapshot != null && client != null && client.options != null) {
            snapshot.restore(client.options);
        }
        snapshot = null;
        appliedSignature = null;
        if (client != null && client.worldRenderer != null) {
            client.worldRenderer.scheduleTerrainUpdate();
        }
    }

    private static boolean clientReady(MinecraftClient client) {
        return client != null && client.options != null && client.worldRenderer != null;
    }

    private record Snapshot(
            ParticlesMode particles,
            GraphicsMode graphics,
            CloudRenderMode clouds,
            int biomeBlendRadius,
            boolean cutoutLeaves,
            boolean entityShadows
    ) {
        private static Snapshot capture(GameOptions options) {
            return new Snapshot(
                    options.getParticles().getValue(), options.getPreset().getValue(),
                    options.getCloudRenderMode().getValue(),
                    options.getBiomeBlendRadius().getValue(), options.getCutoutLeaves().getValue(),
                    options.getEntityShadows().getValue()
            );
        }

        private void restore(GameOptions options) {
            options.getParticles().setValue(particles);
            options.getPreset().setValue(graphics);
            options.getCloudRenderMode().setValue(clouds);
            options.getBiomeBlendRadius().setValue(biomeBlendRadius);
            options.getCutoutLeaves().setValue(cutoutLeaves);
            options.getEntityShadows().setValue(entityShadows);
        }
    }
}
