package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;

public final class VelocityModule extends Module {
    public VelocityModule() {
        super("velocity", "Velocity",
                "\u0423\u0431\u0438\u0440\u0430\u0435\u0442 \u043e\u0442\u043a\u0438\u0434\u044b\u0432\u0430\u043d\u0438\u0435 \u043e\u0442 \u0443\u0434\u0430\u0440\u0430", Category.COMBAT);
    }

    public static boolean active() {
        Module raw = CelestialPortClient.MODULES.find("velocity").orElse(null);
        return raw instanceof VelocityModule velocity && velocity.enabled();
    }

}
