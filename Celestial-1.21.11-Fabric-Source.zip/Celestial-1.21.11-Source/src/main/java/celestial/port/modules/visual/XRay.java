package celestial.port.modules.visual;

import celestial.port.CelestialPortClient;
import celestial.port.client.ui.XRayScreen;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ActionSetting;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.render.ClickGuiModule;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.world.debug.gizmo.VisibilityConfigurable;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CopyOnWriteArraySet;

public final class XRay extends Module implements WorldVisual, HudVisual {
    private static final int DEFAULT_COLOR = 0x96FFFFFF;
    private static final float BOX_LINE_WIDTH = 1.5F;

    private static volatile XRay instance;

    private final ActionSetting openInterface;
    private final NumberSetting renderDistance;
    private final BooleanSetting bypass;
    private final NumberSetting scanRadius;
    private final NumberSetting scanSpeed;

    private final List<BlockPos> detectedPositions = new CopyOnWriteArrayList<>();
    private final List<BlockPos> scanQueue = new CopyOnWriteArrayList<>();
    private final Set<BlockPos> normalPositions = new CopyOnWriteArraySet<>();
    private final List<BlockSelection> selections = createLegacySelections();
    private final Path selectionFile = FabricLoader.getInstance().getConfigDir()
            .resolve("celestial").resolve("xray.celka");

    private volatile Set<Block> selectedBlocks = Set.of();
    private ClientWorld activeWorld;
    private boolean previousBypass;
    private float totalBlocks;
    private float scannedBlocks;
    private volatile boolean scanning;
    private boolean scanPrepared;
    private float animatedProgressWidth;
    private long lastHudFrameNanos;

    public XRay() {
        super("xray", "XRay", "Позволяет видеть блоки через стены", Category.RENDER);
        bypass = new BooleanSetting("bypass", "Обход", false);
        openInterface = addSetting(new ActionSetting(
                "open_interface", "Открыть интерфейс", this::openInterface));
        renderDistance = addSetting(new NumberSetting(
                "render_distance", "Дистанция рендера", 16.0, 8.0, 64.0, 4.0)
                .visibleWhen(() -> !bypass.enabled()));
        addSetting(bypass);
        scanRadius = addSetting(new NumberSetting(
                "scan_radius", "Радиус скана", 15.0, 1.0, 60.0, 1.0)
                .visibleWhen(bypass::enabled));
        scanSpeed = addSetting(new NumberSetting(
                "scan_speed", "Скорость скана", 1.0, 1.0, 5.0, 1.0)
                .visibleWhen(bypass::enabled));
        instance = this;
        loadSelections();
        rebuildSelectedBlocks();
        previousBypass = bypass.enabled();
    }

    @Override
    protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        activeWorld = client.world;
        previousBypass = bypass.enabled();
        if (previousBypass) {
            beginBypassScan(client);
        } else {
            normalPositions.clear();
            reloadWorldRenderer(client);
        }
    }

    @Override
    protected void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (bypass.enabled()) {
            clearBypassState();
        } else {
            normalPositions.clear();
            reloadWorldRenderer(client);
        }
        activeWorld = null;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean bypassNow = bypass.enabled();

        if (bypassNow != previousBypass) {
            previousBypass = bypassNow;
            normalPositions.clear();
            clearBypassState();
            reloadWorldRenderer(client);
            activeWorld = client.world;
            if (bypassNow) {
                beginBypassScan(client);
            }
        }

        if (client.world != activeWorld) {
            normalPositions.clear();
            clearBypassState();
            activeWorld = client.world;
            if (bypassNow) {
                beginBypassScan(client);
            } else if (client.world != null) {
                reloadWorldRenderer(client);
            }
        }

        if (bypassNow && !scanPrepared && client.world != null && client.player != null) {
            beginBypassScan(client);
        }

        if (!bypassNow || client.world == null || client.player == null) {
            return;
        }

        if (totalBlocks > scannedBlocks) {
            scanning = true;
            int count = scanSpeed.value().intValue();
            for (int index = 0; index < count; index++) {
                if (scanQueue.isEmpty()) {
                    continue;
                }
                BlockPos position = scanQueue.remove(0);
                if (client.getNetworkHandler() != null) {
                    client.getNetworkHandler().sendPacket(new PlayerActionC2SPacket(
                            PlayerActionC2SPacket.Action.ABORT_DESTROY_BLOCK,
                            position,
                            Direction.UP
                    ));
                }
                scannedBlocks += 1.0F;
            }
        } else {
            if (totalBlocks > 0.0F && scanning) {
                finishBypassScan(client);
            }
            scanning = false;
        }

        if (scanning && client.player.getMainHandStack().getItem() instanceof BlockItem) {
            int slot = firstNonBlockHotbarSlot(client.player.getInventory());
            if (slot != PlayerInventory.NOT_FOUND) {
                client.player.getInventory().setSelectedSlot(slot);
            }
        }

        detectedPositions.removeIf(position -> !isSelected(client.world.getBlockState(position).getBlock()));
    }

    @Override
    public void collectVisuals(WorldExtractionContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (context.world() != client.world) {
            return;
        }

        if (bypass.enabled()) {
            for (BlockPos position : detectedPositions) {
                drawLegacyBox(position, context.world().getBlockState(position).getBlock());
            }
            return;
        }

        if (client.player == null) {
            return;
        }
        double maximumDistance = renderDistance.value();
        double maximumSquaredDistance = maximumDistance * maximumDistance;
        for (BlockPos position : normalPositions) {
            BlockState state = context.world().getBlockState(position);
            if (state.isAir()) {
                normalPositions.remove(position);
                continue;
            }
            if (client.player.squaredDistanceTo(
                    position.getX(), position.getY(), position.getZ()) > maximumSquaredDistance) {
                continue;
            }
            drawLegacyBox(position, state.getBlock());
        }
    }

    @Override
    public void renderHud(DrawContext context, RenderTickCounter tickCounter) {
        if (!bypass.enabled()) {
            return;
        }

        float targetWidth = scannedBlocks / totalBlocks * 80.0F;
        long now = System.nanoTime();
        double seconds = lastHudFrameNanos == 0L ? 1.0 / 60.0
                : Math.min(0.1, Math.max(0.0, (now - lastHudFrameNanos) / 1_000_000_000.0));
        lastHudFrameNanos = now;
        float interpolation = (float) (1.0 - Math.exp(-seconds * 14.0));
        animatedProgressWidth += (targetWidth - animatedProgressWidth) * interpolation;
        if (Float.isNaN(animatedProgressWidth)) {
            animatedProgressWidth = 0.0F;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        int x = context.getScaledWindowWidth() / 2 - 42;
        int y = context.getScaledWindowHeight() - 100;
        context.fill(x - 2, y + 2, x + 78, y + 21, 0x641E0000);
        context.fill(x + 2, y + 2, x + 82, y + 10, 0xFF282828);

        int progressEnd = x + 2 + Math.max(0, Math.min(80, Math.round(animatedProgressWidth)));
        if (progressEnd > x + 2) {
            int accent = CelestialPortClient.MODULES.find("click_gui")
                    .filter(ClickGuiModule.class::isInstance)
                    .map(ClickGuiModule.class::cast)
                    .map(ClickGuiModule::primaryColor)
                    .orElse(0xFFBF68FF);
            context.fillGradient(x + 2, y + 2, progressEnd, y + 10, accent, 0xFFD2D2D2);
        }
        context.fill(x + 12, y + 14, x + 74, y + 24, 0xFF282828);

        String progressText = (int) scannedBlocks + " / " + (int) totalBlocks;
        String statusText = "Status: " + (totalBlocks != scannedBlocks ? "Scanning" : "Finished");
        context.drawText(client.textRenderer, progressText,
                x + 41 - client.textRenderer.getWidth(progressText) / 2, y + 5, 0xFFEBEBEB, false);
        context.drawText(client.textRenderer, statusText,
                x + 43 - client.textRenderer.getWidth(statusText) / 2, y + 18, 0xFFEBEBEB, false);
    }

    public List<BlockSelection> selections() {
        return List.copyOf(selections);
    }

    public void toggleSelection(BlockSelection selection) {
        if (!selections.contains(selection)) {
            return;
        }
        selection.selected = !selection.selected;
        rebuildSelectedBlocks();
        saveSelections();
        normalPositions.clear();
        reloadWorldRenderer(MinecraftClient.getInstance());
    }

    public long selectedCount() {
        return selections.stream().filter(BlockSelection::selected).count();
    }

    public static void onBlockTessellated(BlockState state, BlockPos position) {
        XRay current = instance;
        if (current == null || !current.enabled() || current.bypass.enabled()) {
            return;
        }
        if (current.isSelected(state.getBlock())) {
            current.normalPositions.add(position.toImmutable());
        }
    }

    public static void onBlockUpdate(BlockPos position, BlockState state) {
        XRay current = instance;
        if (current == null || !current.enabled() || !current.bypass.enabled()) {
            return;
        }
        if (current.isSelected(state.getBlock())) {
            current.detectedPositions.add(position.toImmutable());
        }
    }

    public static boolean shouldCancelOutgoing(Packet<?> packet) {
        XRay current = instance;
        return current != null
                && current.enabled()
                && current.bypass.enabled()
                && current.scanning
                && packet instanceof PlayerActionC2SPacket action
                && action.getAction() == PlayerActionC2SPacket.Action.START_DESTROY_BLOCK;
    }

    private void openInterface() {
        MinecraftClient client = MinecraftClient.getInstance();
        client.setScreen(new XRayScreen(client.currentScreen, this));
    }

    private void beginBypassScan(MinecraftClient client) {
        clearBypassState();
        if (client.world == null || client.player == null) {
            return;
        }

        int radius = scanRadius.value().intValue();
        BlockPos center = client.player.getBlockPos();
        List<BlockPos> positions = new ArrayList<>();
        BlockPos.Mutable cursor = new BlockPos.Mutable();
        for (int offsetX = -radius; offsetX <= radius; offsetX++) {
            for (int offsetY = -radius; offsetY <= radius; offsetY++) {
                int y = center.getY() + offsetY;
                if (y < client.world.getBottomY() || y > client.world.getTopYInclusive()) {
                    continue;
                }
                for (int offsetZ = -radius; offsetZ <= radius; offsetZ++) {
                    cursor.set(center.getX() + offsetX, y, center.getZ() + offsetZ);
                    BlockState state = client.world.getBlockState(cursor);
                    if (!state.isAir() && isSelected(state.getBlock())) {
                        positions.add(cursor.toImmutable());
                    }
                }
            }
        }
        positions.sort(Comparator.comparingDouble(position -> client.player.squaredDistanceTo(
                position.getX(), position.getY(), position.getZ())));
        scanQueue.addAll(positions);
        totalBlocks = scanQueue.size();
        scanPrepared = true;
    }

    private void finishBypassScan(MinecraftClient client) {
        if (client.player != null && client.getNetworkHandler() != null) {
            client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(
                    client.player.getInventory().getSelectedSlot()));
        }
        if (client.interactionManager != null) {
            client.interactionManager.cancelBlockBreaking();
        }
    }

    private static int firstNonBlockHotbarSlot(PlayerInventory inventory) {
        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            if (!(inventory.getStack(slot).getItem() instanceof BlockItem)) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private void clearBypassState() {
        scanQueue.clear();
        detectedPositions.clear();
        totalBlocks = 0.0F;
        scannedBlocks = 0.0F;
        scanning = false;
        scanPrepared = false;
        animatedProgressWidth = 0.0F;
        lastHudFrameNanos = 0L;
    }

    private boolean isSelected(Block block) {
        return selectedBlocks.contains(block);
    }

    private void rebuildSelectedBlocks() {
        Set<Block> blocks = new LinkedHashSet<>();
        for (BlockSelection selection : selections) {
            if (selection.selected) {
                blocks.addAll(selection.matches);
            }
        }
        selectedBlocks = Set.copyOf(blocks);
    }

    private void loadSelections() {
        if (!Files.isRegularFile(selectionFile)) {
            return;
        }
        Map<Integer, Boolean> saved = new LinkedHashMap<>();
        try {
            for (String line : Files.readAllLines(selectionFile, StandardCharsets.UTF_8)) {
                String[] parts = line.strip().split(":", 2);
                if (parts.length == 2) {
                    saved.put(Integer.parseInt(parts[0]), Boolean.parseBoolean(parts[1]));
                }
            }
            for (BlockSelection selection : selections) {
                Boolean selected = saved.get(selection.legacyId);
                if (selected != null) {
                    selection.selected = selected;
                }
            }
        } catch (IOException | RuntimeException exception) {
            CelestialPortClient.LOGGER.warn("Unable to load XRay block selection from {}", selectionFile, exception);
        }
    }

    private void saveSelections() {
        try {
            Files.createDirectories(selectionFile.getParent());
            List<String> lines = selections.stream()
                    .map(selection -> selection.legacyId + ":" + selection.selected)
                    .toList();
            Files.write(selectionFile, lines, StandardCharsets.UTF_8);
        } catch (IOException exception) {
            CelestialPortClient.LOGGER.warn("Unable to save XRay block selection to {}", selectionFile, exception);
        }
    }

    private static void reloadWorldRenderer(MinecraftClient client) {
        if (client.world != null) {
            client.worldRenderer.reload();
        }
    }

    private static void drawLegacyBox(BlockPos position, Block block) {
        VisibilityConfigurable box = GizmoDrawing.box(
                position,
                DrawStyle.stroked(colorFor(block), BOX_LINE_WIDTH)
        );
        box.ignoreOcclusion();
    }

    private static int colorFor(Block block) {
        if (block == Blocks.GOLD_ORE || block == Blocks.DEEPSLATE_GOLD_ORE) return 0x96FFFF00;
        if (block == Blocks.IRON_ORE || block == Blocks.DEEPSLATE_IRON_ORE) return 0x96AF5B46;
        if (block == Blocks.COAL_ORE || block == Blocks.DEEPSLATE_COAL_ORE) return 0x96050505;
        if (block == Blocks.LAPIS_ORE || block == Blocks.DEEPSLATE_LAPIS_ORE) return 0x960000FF;
        if (block == Blocks.DIAMOND_ORE || block == Blocks.DEEPSLATE_DIAMOND_ORE) return 0x9600FFFF;
        if (block == Blocks.REDSTONE_ORE || block == Blocks.DEEPSLATE_REDSTONE_ORE) return 0x96FF0000;
        if (block == Blocks.EMERALD_ORE || block == Blocks.DEEPSLATE_EMERALD_ORE) return 0x9600FF00;
        if (block == Blocks.NETHER_QUARTZ_ORE) return 0x96000000;
        return DEFAULT_COLOR;
    }

    private static List<BlockSelection> createLegacySelections() {
        return new ArrayList<>(List.of(
                selection(16, Blocks.COAL_ORE, Blocks.DEEPSLATE_COAL_ORE),
                selection(56, Blocks.DIAMOND_ORE, Blocks.DEEPSLATE_DIAMOND_ORE),
                selection(129, Blocks.EMERALD_ORE, Blocks.DEEPSLATE_EMERALD_ORE),
                selection(14, Blocks.GOLD_ORE, Blocks.DEEPSLATE_GOLD_ORE),
                selection(15, Blocks.IRON_ORE, Blocks.DEEPSLATE_IRON_ORE),
                selection(21, Blocks.LAPIS_ORE, Blocks.DEEPSLATE_LAPIS_ORE),
                selection(153, Blocks.NETHER_QUARTZ_ORE),
                selection(73, Blocks.REDSTONE_ORE, Blocks.DEEPSLATE_REDSTONE_ORE),
                selection(49, Blocks.OBSIDIAN),
                selection(86, Blocks.CARVED_PUMPKIN),
                selection(61, Blocks.FURNACE),
                selection(145, Blocks.ANVIL, Blocks.CHIPPED_ANVIL, Blocks.DAMAGED_ANVIL),
                selection(58, Blocks.CRAFTING_TABLE),
                selection(47, Blocks.BOOKSHELF),
                selection(216, Blocks.BONE_BLOCK),
                selection(110, Blocks.MYCELIUM),
                selection(66, Blocks.RAIL),
                selection(30, Blocks.COBWEB),
                selection(138, Blocks.BEACON),
                selection(133, Blocks.EMERALD_BLOCK),
                selection(57, Blocks.DIAMOND_BLOCK),
                selection(41, Blocks.GOLD_BLOCK),
                selection(173, Blocks.COAL_BLOCK),
                selection(42, Blocks.IRON_BLOCK),
                selection(155, Blocks.QUARTZ_BLOCK, Blocks.CHISELED_QUARTZ_BLOCK, Blocks.QUARTZ_PILLAR),
                selection(154, Blocks.HOPPER),
                selection(20, Blocks.GLASS),
                selection(116, Blocks.ENCHANTING_TABLE),
                selection(22, Blocks.LAPIS_BLOCK),
                selection(152, Blocks.REDSTONE_BLOCK),
                selection(123, Blocks.REDSTONE_LAMP),
                selection(89, Blocks.GLOWSTONE),
                selection(130, Blocks.ENDER_CHEST),
                selection(54, Blocks.CHEST),
                selection(25, Blocks.NOTE_BLOCK)
        ));
    }

    private static BlockSelection selection(int legacyId, Block primary, Block... aliases) {
        List<Block> matches = new ArrayList<>(1 + aliases.length);
        matches.add(primary);
        matches.addAll(Arrays.asList(aliases));
        return new BlockSelection(legacyId, primary, Set.copyOf(matches));
    }

    public static final class BlockSelection {
        private final int legacyId;
        private final Block block;
        private final Set<Block> matches;
        private volatile boolean selected;

        private BlockSelection(int legacyId, Block block, Set<Block> matches) {
            this.legacyId = legacyId;
            this.block = block;
            this.matches = matches;
        }

        public Block block() {
            return block;
        }

        public boolean selected() {
            return selected;
        }
    }
}
