package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;

public final class ItemsFixModule extends Module {
    public ItemsFixModule() {
        super("items_fix", "Items Fix",
                "\u0423\u0431\u0438\u0440\u0430\u0435\u0442 \u043f\u0435\u0440\u0435\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435 \u0441\u043b\u043e\u0442\u043e\u0432 \u0430\u043d\u0442\u0438\u0447\u0438\u0442\u043e\u043c", Category.COMBAT);
    }

    public static boolean cancelServerSlotChange(UpdateSelectedSlotS2CPacket packet) {
        Module module = CelestialPortClient.MODULES.find("items_fix").orElse(null);
        MinecraftClient client = MinecraftClient.getInstance();
        var player = client.player;
        if (module == null || !module.enabled() || player == null || client.world == null) {
            return false;
        }
        int selectedSlot = player.getInventory().getSelectedSlot();
        if (packet.slot() == selectedSlot) {
            return false;
        }
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(selectedSlot));
        return true;
    }
}
