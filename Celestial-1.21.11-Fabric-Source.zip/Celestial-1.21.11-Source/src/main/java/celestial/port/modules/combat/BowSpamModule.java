package celestial.port.modules.combat;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.consume.UseAction;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerActionC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;

public final class BowSpamModule extends Module {
    private static volatile BowSpamModule instance;

    private final NumberSetting delay = addSetting(new NumberSetting(
            "delay", "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", 1.5, 1.5, 11.0, 0.5
    ));

    public BowSpamModule() {
        super("bow_spam", "Bow Spam",
                "\u0411\u044b\u0441\u0442\u0440\u043e \u0441\u0442\u0440\u0435\u043b\u044f\u0435\u0442 \u0438\u0437 \u043b\u0443\u043a\u0430", Category.COMBAT);
        instance = this;
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        BowSpamModule module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled()
                || player == null || client.player != player
                || client.getNetworkHandler() == null
                || !player.isUsingItem()
                || player.getActiveItem().getUseAction() != UseAction.BOW) {
            return;
        }
        if ((float) player.getItemUseTime() >= module.delay.value().floatValue()) {

            player.networkHandler.sendPacket(new PlayerActionC2SPacket(
                    PlayerActionC2SPacket.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, Direction.DOWN));
            player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            player.stopUsingItem();
        }
    }
}
