package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.UseEffectsComponent;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.consume.UseAction;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Locale;

public final class NoSlow extends Module {
    private static final String MATRIX = "Matrix";
    private static final String REALLY_WORLD = "Really World";
    private static final String OLD_SUNRISE = "Старый Sunrise";
    private static final String VANILLA = "Vanilla";

    private static volatile NoSlow instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", MATRIX, List.of(MATRIX, REALLY_WORLD, OLD_SUNRISE, VANILLA)
    ));
    private final NumberSetting speed = addSetting(new NumberSetting(
            "speed", "Скорость", 100.0, 10.0, 100.0, 10.0
    ).visibleWhen(() -> mode.is(VANILLA)));

    public NoSlow() {
        super("no_slow", "No Slow", "Убирает замедление при использовании предмета", Category.MOVEMENT);
        instance = this;
    }

    public ModeSetting mode() {
        return mode;
    }

    public NumberSetting speed() {
        return speed;
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        NoSlow module = active();
        if (module == null || !hasLegacyActiveUse(player) || !module.canBypassSlowdown(player)) {
            return;
        }

        Vec3d velocity = player.getVelocity();
        double multiplier = 1.0;
        if (module.mode.is(REALLY_WORLD)) {
            if (player.isOnGround() && !sampledJump(player)) {
                multiplier = ((1.0f - player.getMovementSpeed()) * 0.9f) * 0.3f + 0.055;
            }
        } else if (module.mode.is(MATRIX)) {
            if (player.isOnGround() && !sampledJump(player)) {
                if ((player.age & 1) == 0) {
                    multiplier = player.sidewaysSpeed == 0.0f ? 0.5f : 0.4f;
                }
            } else if (player.fallDistance > 0.725f) {
                multiplier = player.fallDistance > 1.4f ? 0.95f : 0.97f;
            }
        } else if (module.mode.is(OLD_SUNRISE)) {
            MinecraftClient client = MinecraftClient.getInstance();
            if (player.isOnGround() && !client.options.jumpKey.isPressed()) {
                if ((player.age & 1) == 0) {
                    multiplier = 0.47;
                }
            } else if (player.fallDistance > 0.2f) {
                multiplier = 0.93f;
            }
        }

        if (multiplier != 1.0) {
            player.setVelocity(velocity.x * multiplier, velocity.y, velocity.z * multiplier);
        }
    }

    public static void beforeMovementPackets(ClientPlayerEntity player) {
        NoSlow module = active();
        if (module == null || !module.mode.is(REALLY_WORLD) || !isReallyWorldServer()
                || !hasLegacyActiveUse(player) || player.getItemUseTime() != 2) {
            return;
        }

        int selected = player.getInventory().getSelectedSlot();
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(selected % 8 + 1));
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(selected));
    }

    public static float activeItemSpeedMultiplier(ClientPlayerEntity player) {
        NoSlow module = active();
        if (module == null) {
            return player.getActiveItem()
                    .getOrDefault(DataComponentTypes.USE_EFFECTS, UseEffectsComponent.DEFAULT)
                    .speedMultiplier();
        }
        if (!module.canBypassSlowdown(player)) {
            return 0.2f;
        }
        return module.mode.is(VANILLA) ? (float) (module.speed.value() / 100.0) : 1.0f;
    }

    private static boolean hasLegacyActiveUse(ClientPlayerEntity player) {
        if (!player.isUsingItem()) {
            return false;
        }
        UseAction action = player.getActiveItem().getUseAction();
        return action == UseAction.BLOCK
                || action == UseAction.BOW
                || action == UseAction.DRINK
                || action == UseAction.EAT;
    }

    private boolean canBypassSlowdown(ClientPlayerEntity player) {
        if (player.hasStatusEffect(StatusEffects.LEVITATION)) {
            return false;
        }
        if (enabled("water_speed") || enabled("strafe")) {
            return false;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        return client.options.jumpKey.isPressed()
                || player.isOnGround()
                || sampledJump(player)
                || player.fallDistance >= 1.0f;
    }

    private static boolean sampledJump(ClientPlayerEntity player) {
        return player.input != null && player.input.playerInput.jump();
    }

    private static boolean enabled(String id) {
        return CelestialPortClient.MODULES.find(id).filter(Module::enabled).isPresent();
    }

    private static boolean isReallyWorldServer() {
        var entry = MinecraftClient.getInstance().getCurrentServerEntry();
        return entry != null && entry.address.toLowerCase(Locale.ROOT).contains("reallyworld");
    }

    private static NoSlow active() {
        NoSlow module = instance;
        return module != null && module.enabled() ? module : null;
    }
}
