package celestial.port.modules.visual;

import celestial.port.CelestialPortClient;
import celestial.port.client.ui.CelestialHud;
import celestial.port.client.ui.SmoothRoundedGui;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.client.util.Window;
import net.minecraft.client.util.memory.ObjectAllocator;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.ScoreboardEntry;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.scoreboard.Team;
import net.minecraft.scoreboard.number.NumberFormat;
import net.minecraft.scoreboard.number.StyledNumberFormat;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class BlurVisuals extends Module {
    private static final List<String> ELEMENT_OPTIONS = List.of("Хотбар", "Скорборд");
    private static final ThreadLocal<FramebufferScissor> ACTIVE_SCISSOR = new ThreadLocal<>();

    private final MultiSelectSetting elements = addSetting(new MultiSelectSetting(
            "elements", "Элементы", Set.of("Хотбар", "Скорборд"), ELEMENT_OPTIONS
    ));
    private final NumberSetting strength = addSetting(new NumberSetting(
            "strength", "Сила размытия", 5.0, 1.0, 8.0, 1.0
    ));

    public BlurVisuals() {
        super("blur_visuals", "Blur Visuals",
                "Эффект размытия на визуальную 2D часть", Category.RENDER);
    }

    public boolean hotbarEnabled() {
        return elements.selected("Хотбар");
    }

    public boolean scoreboardEnabled() {
        return elements.selected("Скорборд");
    }

    public int strength() {
        return (int) Math.round(strength.value());
    }

    public static void renderHotbarBlur(DrawContext context) {
        BlurVisuals module = activeModule();
        if (module == null || !module.hotbarEnabled()) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        int centerX = context.getScaledWindowWidth() / 2;
        int bottom = context.getScaledWindowHeight();
        int left = centerX - 91;
        float offset = CelestialHud.legacyHotbarOffset();
        module.blurRegion(left, bottom - 22.0F - offset,
                centerX + 91, bottom - offset, 4.0F);
        HotbarGlow.draw(context, left, bottom - 22, 182, 22, 4.0F);

        Entity camera = client.getCameraEntity();
        if (camera instanceof PlayerEntity player) {
            int selected = player.getInventory().getSelectedSlot();
            SmoothRoundedGui.fill(context, left + 2 + selected * 20, bottom - 20,
                    18, 18, 3.0F, 0x73141414);
        }
    }

    public static void renderScoreboardBlur(DrawContext context, ScoreboardObjective objective) {
        BlurVisuals module = activeModule();
        if (module == null || !module.scoreboardEnabled() || objective == null) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer renderer = client.textRenderer;
        Scoreboard scoreboard = objective.getScoreboard();
        NumberFormat numberFormat = objective.getNumberFormatOr(StyledNumberFormat.RED);
        List<ScoreboardEntry> entries = scoreboard.getScoreboardEntries(objective).stream()
                .filter(entry -> !entry.hidden())
                .sorted((first, second) -> {
                    int score = Integer.compare(second.value(), first.value());
                    return score != 0 ? score : first.owner().compareToIgnoreCase(second.owner());
                })
                .limit(15)
                .toList();

        int width = renderer.getWidth(objective.getDisplayName());
        int separatorWidth = renderer.getWidth(":");
        for (ScoreboardEntry entry : entries) {
            Text name = Team.decorateName(scoreboard.getScoreHolderTeam(entry.owner()), entry.name());
            Text score = entry.formatted(numberFormat);
            int scoreWidth = renderer.getWidth(score);
            width = Math.max(width, renderer.getWidth(name) + (scoreWidth > 0 ? separatorWidth + scoreWidth : 0));
        }

        int count = entries.size();
        int bottom = context.getScaledWindowHeight() / 2 + count * 3;
        int top = bottom - count * renderer.fontHeight - renderer.fontHeight - 1;
        int left = context.getScaledWindowWidth() - width - 5;
        int right = context.getScaledWindowWidth() - 1;
        module.blurRegion(left, top, right, bottom, 0.0F);
    }

    public static boolean suppressHotbarTexture(Identifier texture) {
        BlurVisuals module = activeModule();
        if (module == null || !module.hotbarEnabled()
                || !"minecraft".equals(texture.getNamespace())) {
            return false;
        }

        return switch (texture.getPath()) {
            case "hud/hotbar", "hud/hotbar_selection",
                    "hud/hotbar_offhand_left", "hud/hotbar_offhand_right" -> true;
            default -> false;
        };
    }

    public static FramebufferScissor activeScissor() {
        return ACTIVE_SCISSOR.get();
    }

    public static void renderLegacyChatBlur(
            float left, float top, float right, float bottom
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (right <= left || bottom <= top) return;

        Window window = client.getWindow();
        int scale = Math.max(1, window.getScaleFactor());
        FramebufferScissor scissor = rectangularScissor(
                window, left, top, right, bottom, scale);
        if (scissor == null) return;

        PostEffectProcessor processor = client.getShaderLoader().loadPostEffect(
                Identifier.of("celestial", "legacy_chat_blur"),
                Set.of(PostEffectProcessor.MAIN));
        if (processor == null) return;

        ACTIVE_SCISSOR.set(scissor);
        try {
            processor.render(client.getFramebuffer(), ObjectAllocator.TRIVIAL);
        } finally {
            ACTIVE_SCISSOR.remove();
        }
    }

    public static void renderLegacyMenuBlurRegion(
            float left, float top, float right, float bottom,
            float maskCornerRadius, int framebufferBlurRadius
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (right <= left || bottom <= top) return;

        Identifier effectId = switch (framebufferBlurRadius) {
            case 5 -> Identifier.of("celestial", "legacy_menu_blur_5");
            case 10 -> Identifier.of("celestial", "legacy_menu_blur");
            default -> null;
        };
        if (effectId == null) return;

        Window window = client.getWindow();
        int scale = Math.max(1, window.getScaleFactor());
        FramebufferScissor scissor = maskCornerRadius > 0.0F
                ? legacyRoundedScissor(window, left, top, right, bottom,
                maskCornerRadius, scale)
                : rectangularScissor(window, left, top, right, bottom, scale);
        if (scissor == null) return;

        PostEffectProcessor processor = client.getShaderLoader().loadPostEffect(
                effectId, Set.of(PostEffectProcessor.MAIN));
        if (processor == null) return;

        ACTIVE_SCISSOR.set(scissor);
        try {
            processor.render(client.getFramebuffer(), ObjectAllocator.TRIVIAL);
        } finally {
            ACTIVE_SCISSOR.remove();
        }
    }

    private static BlurVisuals activeModule() {
        return CelestialPortClient.MODULES.find("blur_visuals")
                .filter(BlurVisuals.class::isInstance)
                .map(BlurVisuals.class::cast)
                .filter(Module::enabled)
                .orElse(null);
    }

    private void blurRegion(
            float left, float top, float right, float bottom, float cornerRadius
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null || right <= left || bottom <= top) {
            return;
        }

        Window window = client.getWindow();
        int scale = Math.max(1, window.getScaleFactor());
        FramebufferScissor scissor = cornerRadius > 0.0F
                ? legacyRoundedScissor(window, left, top, right, bottom,
                cornerRadius, scale)
                : rectangularScissor(window, left, top, right, bottom, scale);
        if (scissor == null) {
            return;
        }

        int width = scissor.width();
        int height = scissor.height();
        if (width <= 0 || height <= 0) {
            return;
        }

        Identifier effectId = Identifier.of("celestial", "blur_visuals_" + strength());
        PostEffectProcessor processor = client.getShaderLoader().loadPostEffect(
                effectId, Set.of(PostEffectProcessor.MAIN));
        if (processor == null) {
            return;
        }

        ACTIVE_SCISSOR.set(scissor);
        try {
            processor.render(client.getFramebuffer(), ObjectAllocator.TRIVIAL);
        } finally {
            ACTIVE_SCISSOR.remove();
        }
    }

    private static FramebufferScissor rectangularScissor(
            Window window, float left, float top, float right, float bottom, int scale
    ) {
        int x = Math.max(0, (int) Math.floor(left * scale));
        int y = Math.max(0, (int) Math.floor(
                window.getFramebufferHeight() - bottom * scale));
        int rightPixel = Math.min(window.getFramebufferWidth(),
                (int) Math.ceil(right * scale));
        int topPixel = Math.min(window.getFramebufferHeight(),
                (int) Math.ceil(window.getFramebufferHeight() - top * scale));
        if (rightPixel <= x || topPixel <= y) return null;
        return new FramebufferScissor(
                x, y, rightPixel - x, topPixel - y, null);
    }

    private static FramebufferScissor legacyRoundedScissor(
            Window window, float left, float top, float right, float bottom,
            float radius, int scale
    ) {
        double quadLeft = (left - 1.0) * scale;
        double quadBottom = window.getFramebufferHeight() - (bottom + 1.0) * scale;
        double quadRight = (right + 1.0) * scale;
        double quadTop = window.getFramebufferHeight() - (top - 1.0) * scale;

        int rawLeft = (int) Math.ceil(quadLeft - 0.5);
        int rawBottom = (int) Math.ceil(quadBottom - 0.5);
        int rawRight = (int) Math.ceil(quadRight - 0.5);
        int rawTop = (int) Math.ceil(quadTop - 0.5);
        int x = Math.max(0, rawLeft);
        int y = Math.max(0, rawBottom);
        int clippedRight = Math.min(window.getFramebufferWidth(), rawRight);
        int clippedTop = Math.min(window.getFramebufferHeight(), rawTop);
        if (clippedRight <= x || clippedTop <= y) return null;

        RoundedStencil stencil = new RoundedStencil(
                quadLeft, quadBottom, quadRight - quadLeft, quadTop - quadBottom,
                (right - left) * scale, (bottom - top) * scale, radius * scale);
        return new FramebufferScissor(
                x, y, clippedRight - x, clippedTop - y, stencil);
    }

    public record FramebufferScissor(
            int x, int y, int width, int height, RoundedStencil roundedStencil
    ) {
    }

    public record RoundedStencil(
            double quadX, double quadY, double quadWidth, double quadHeight,
            double rectWidth, double rectHeight, double radius
    ) {
        public boolean containsPixel(int pixelX, int pixelY) {
            double u = (pixelX + 0.5 - quadX) / quadWidth;
            double v = (pixelY + 0.5 - quadY) / quadHeight;
            if (u < 0.0 || u > 1.0 || v < 0.0 || v > 1.0) return false;

            double halfWidth = rectWidth * 0.5;
            double halfHeight = rectHeight * 0.5;
            double pointX = halfWidth - u * rectWidth;
            double pointY = halfHeight - v * rectHeight;
            double boundX = halfWidth - radius - 1.0;
            double boundY = halfHeight - radius - 1.0;
            double dx = Math.max(Math.abs(pointX) - boundX, 0.0);
            double dy = Math.max(Math.abs(pointY) - boundY, 0.0);
            double distance = Math.sqrt(dx * dx + dy * dy) - radius;

            double t = Math.max(0.0, Math.min(1.0, distance * 0.5));
            double alpha = 1.0 - t * t * (3.0 - 2.0 * t);
            return alpha > 0.1;
        }
    }

    private static final class HotbarGlow {
        private static final int BLUR_RADIUS = 5;
        private static final double SIGMA = 5.0;
        private static final double NORMALIZER =
                1.0 / Math.sqrt(2.0 * Math.PI * SIGMA * SIGMA);
        private static final Map<GlowKey, CachedGlow> CACHE = new HashMap<>();
        private static final VertexFormat FORMAT = VertexFormat.builder()
                .add("Position", VertexFormatElement.POSITION)
                .add("Color", VertexFormatElement.COLOR)
                .add("UV0", VertexFormatElement.UV0)
                .build();
        private static final BlendFunction LEGACY_BLEND = new BlendFunction(
                SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA,
                SourceFactor.ONE, DestFactor.ZERO);
        private static final RenderPipeline PIPELINE = RenderPipeline.builder()
                .withLocation(Identifier.of("celestial",
                        "pipeline/blur_visuals_hotbar_glow"))
                .withVertexShader(Identifier.of("celestial",
                        "core/legacy_hud_shadow_texture"))
                .withFragmentShader(Identifier.of("celestial",
                        "core/legacy_hud_shadow_texture"))
                .withSampler("Sampler0")
                .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
                .withUniform("Projection", UniformType.UNIFORM_BUFFER)
                .withBlend(LEGACY_BLEND)
                .withCull(false)
                .withDepthWrite(false)
                .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
                .withVertexFormat(FORMAT, VertexFormat.DrawMode.QUADS)
                .build();

        private HotbarGlow() {
        }

        static void draw(
                DrawContext context, float x, float y, int width, int height, float radius
        ) {
            int scale = Math.max(1, MinecraftClient.getInstance()
                    .getWindow().getScaleFactor());
            GlowKey key = new GlowKey(width, height, radius, scale);
            CachedGlow glow = CACHE.computeIfAbsent(key, HotbarGlow::create);
            float padding = 1.0F + BLUR_RADIUS / (float) scale;
            float drawX = x - padding;
            float drawY = y - padding;
            float drawWidth = glow.pixelWidth / (float) scale;
            float drawHeight = glow.pixelHeight / (float) scale;

            Matrix3x2f pose = new Matrix3x2f(context.getMatrices());
            ScreenRect inheritedScissor = context.scissorStack.peekLast();
            ScreenRect transformed = new ScreenRect(
                    (int) Math.floor(drawX), (int) Math.floor(drawY),
                    (int) Math.ceil(drawX + drawWidth) - (int) Math.floor(drawX),
                    (int) Math.ceil(drawY + drawHeight) - (int) Math.floor(drawY))
                    .transformEachVertex(pose);
            ScreenRect bounds = inheritedScissor == null ? transformed
                    : inheritedScissor.intersection(transformed);
            context.state.addSimpleElement(new GlowState(
                    pose, drawX, drawY, drawWidth, drawHeight,
                    glow.textureSetup, inheritedScissor, bounds));
        }

        private static CachedGlow create(GlowKey key) {
            int scale = key.scale;
            int expandedWidth = (key.width + 2) * scale;
            int expandedHeight = (key.height + 2) * scale;
            int textureWidth = expandedWidth + BLUR_RADIUS * 2;
            int textureHeight = expandedHeight + BLUR_RADIUS * 2;
            float[] source = new float[textureWidth * textureHeight];
            double rectWidth = key.width * (double) scale;
            double rectHeight = key.height * (double) scale;
            double scaledRadius = key.radius * scale;
            double halfWidth = rectWidth * 0.5;
            double halfHeight = rectHeight * 0.5;
            double boundX = halfWidth - scaledRadius - 1.0;
            double boundY = halfHeight - scaledRadius - 1.0;

            for (int y = 0; y < expandedHeight; y++) {
                double v = (y + 0.5) / expandedHeight;
                double pointY = halfHeight - v * rectHeight;
                double dy = Math.max(Math.abs(pointY) - boundY, 0.0);
                int row = (y + BLUR_RADIUS) * textureWidth + BLUR_RADIUS;
                for (int x = 0; x < expandedWidth; x++) {
                    double u = (x + 0.5) / expandedWidth;
                    double pointX = halfWidth - u * rectWidth;
                    double dx = Math.max(Math.abs(pointX) - boundX, 0.0);
                    double distance = Math.sqrt(dx * dx + dy * dy) - scaledRadius;
                    double t = Math.max(0.0, Math.min(1.0, distance * 0.5));
                    float alpha = (float) (1.0 - t * t * (3.0 - 2.0 * t));
                    if (alpha > 0.1F) {

                        source[row + x] = quantizeFramebuffer(alpha);
                    }
                }
            }

            float[] weights = new float[BLUR_RADIUS + 1];
            for (int distance = 0; distance <= BLUR_RADIUS; distance++) {
                weights[distance] = (float) (NORMALIZER * Math.exp(
                        -(distance * distance) / (2.0 * SIGMA * SIGMA)));
            }
            float[] horizontal = convolve(
                    source, textureWidth, textureHeight, weights, true);
            for (int index = 0; index < horizontal.length; index++) {
                horizontal[index] = quantizeFramebuffer(horizontal[index]);
            }
            float[] blurred = convolve(
                    horizontal, textureWidth, textureHeight, weights, false);

            NativeImageBackedTexture texture = new NativeImageBackedTexture(
                    "Celestial BlurVisuals hotbar glow " + key,
                    textureWidth, textureHeight, false);
            NativeImage image = texture.getImage();
            if (image == null) {
                throw new IllegalStateException("Hotbar glow image was not allocated");
            }
            for (int y = 0; y < textureHeight; y++) {
                int row = y * textureWidth;
                for (int x = 0; x < textureWidth; x++) {
                    int index = row + x;
                    float alpha = source[index] != 0.0F ? 0.0F : blurred[index];
                    int alphaByte = Math.max(0, Math.min(255,
                            Math.round(alpha * 255.0F)));
                    image.setColorArgb(x, y, alphaByte << 24 | 0x00FFFFFF);
                }
            }
            texture.upload();
            Identifier id = Identifier.of("celestial", "dynamic/blur_visuals/hotbar_"
                    + key.width + "x" + key.height + "_r"
                    + Float.floatToIntBits(key.radius) + "_s" + scale);
            MinecraftClient.getInstance().getTextureManager().registerTexture(id, texture);
            TextureSetup textureSetup = TextureSetup.of(
                    texture.getGlTextureView(), RenderSystem.getSamplerCache()
                            .getRepeated(FilterMode.LINEAR));
            return new CachedGlow(texture, textureSetup, textureWidth, textureHeight);
        }

        private static float[] convolve(
                float[] input, int width, int height, float[] weights, boolean horizontal
        ) {
            float[] output = new float[input.length];
            for (int y = 0; y < height; y++) {
                for (int x = 0; x < width; x++) {
                    float value = input[y * width + x] * weights[0];
                    for (int distance = 1; distance < weights.length; distance++) {
                        int negativeX = horizontal ? x - distance : x;
                        int negativeY = horizontal ? y : y - distance;
                        int positiveX = horizontal ? x + distance : x;
                        int positiveY = horizontal ? y : y + distance;
                        if (negativeX >= 0 && negativeY >= 0) {
                            value += input[negativeY * width + negativeX]
                                    * weights[distance];
                        }
                        if (positiveX < width && positiveY < height) {
                            value += input[positiveY * width + positiveX]
                                    * weights[distance];
                        }
                    }
                    output[y * width + x] = value;
                }
            }
            return output;
        }

        private static float quantizeFramebuffer(float value) {
            return Math.max(0, Math.min(255, Math.round(value * 255.0F)))
                    / 255.0F;
        }

        private record GlowKey(int width, int height, float radius, int scale) {
        }

        private record CachedGlow(
                NativeImageBackedTexture texture, TextureSetup textureSetup,
                int pixelWidth, int pixelHeight
        ) {
        }

        private record GlowState(
                Matrix3x2f pose, float x, float y, float width, float height,
                TextureSetup textureSetup, ScreenRect scissorArea, ScreenRect bounds
        ) implements SimpleGuiElementRenderState {
            @Override
            public void setupVertices(VertexConsumer vertices) {
                vertex(vertices, x, y, 0.0F, 0.0F);
                vertex(vertices, x, y + height, 0.0F, 1.0F);
                vertex(vertices, x + width, y + height, 1.0F, 1.0F);
                vertex(vertices, x + width, y, 1.0F, 0.0F);
            }

            private void vertex(
                    VertexConsumer vertices, float pointX, float pointY, float u, float v
            ) {
                float transformedX = pose.m00() * pointX
                        + pose.m10() * pointY + pose.m20();
                float transformedY = pose.m01() * pointX
                        + pose.m11() * pointY + pose.m21();
                vertices.vertex(transformedX, transformedY, 0.0F)
                        .color(0xFF000000).texture(u, v);
            }

            @Override
            public RenderPipeline pipeline() {
                return PIPELINE;
            }
        }
    }
}
