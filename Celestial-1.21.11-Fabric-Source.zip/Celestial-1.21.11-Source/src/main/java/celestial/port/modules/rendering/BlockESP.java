package celestial.port.modules.rendering;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.MultiSelectSetting;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.impl.event.lifecycle.LoadedChunksCache;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.SkullBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.DispenserBlockEntity;
import net.minecraft.block.entity.EnderChestBlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.block.entity.SkullBlockEntity;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.entity.Entity;
import net.minecraft.entity.vehicle.ChestMinecartEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.world.debug.gizmo.VisibilityConfigurable;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class BlockESP extends Module implements WorldGizmoModule {
    private static final String SPAWNERS = "Спавнера";
    private static final String SHULKERS = "Шалкера";
    private static final String CHESTS = "Сундуки";
    private static final String DISPENSERS = "Раздатчики";
    private static final String GIFTS = "Подарки";
    private static final int GIFT_COLOR = 0xFFFFD700;

    private static volatile BlockESP instance;

    private final MultiSelectSetting blocks = addSetting(new MultiSelectSetting(
            "blocks", "Выбор блоков", Set.of(SPAWNERS, SHULKERS),
            List.of(SPAWNERS, SHULKERS, CHESTS, DISPENSERS, GIFTS)
    ));
    private final ColorSetting spawnerColor = addSetting(new ColorSetting(
            "spawner_color", "Цвет спавнеров", 0xFFFF00FF, false
    ).visibleWhen(() -> blocks.selected(SPAWNERS)));
    private final ColorSetting shulkerColor = addSetting(new ColorSetting(
            "shulker_color", "Цвет шалкеров", 0xFFFF00FF, false
    ).visibleWhen(() -> blocks.selected(SHULKERS)));
    private final ColorSetting chestColor = addSetting(new ColorSetting(
            "chest_color", "Цвет сундуков", 0xFFFF00FF, false
    ).visibleWhen(() -> blocks.selected(CHESTS)));
    private final ColorSetting dispenserColor = addSetting(new ColorSetting(
            "dispenser_color", "Цвет раздатчиков", 0xFFFF00FF, false
    ).visibleWhen(() -> blocks.selected(DISPENSERS)));

    private final Set<BlockPos> brokenPositions = new HashSet<>();

    public BlockESP() {
        super("block_esp", "Block ESP", "WallHack на блоки", Category.RENDER);
        instance = this;
    }

    public MultiSelectSetting blocks() {
        return blocks;
    }

    public ColorSetting spawnerColor() {
        return spawnerColor;
    }

    public ColorSetting shulkerColor() {
        return shulkerColor;
    }

    public ColorSetting chestColor() {
        return chestColor;
    }

    public ColorSetting dispenserColor() {
        return dispenserColor;
    }

    public static void onBlockBroken(BlockPos pos) {
        BlockESP module = instance;
        if (module != null && module.enabled() && pos != null) {
            module.brokenPositions.add(pos.toImmutable());
        }
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        brokenPositions.clear();
    }

    @Override
    protected void onDisable() {
        brokenPositions.clear();
    }

    @Override
    public void collectGizmos(WorldExtractionContext context) {
        for (WorldChunk chunk : ((LoadedChunksCache) context.world()).fabric_getLoadedChunks()) {
            for (BlockEntity blockEntity : chunk.getBlockEntities().values()) {
                Kind kind = classify(blockEntity);
                if (kind == null || !selected(kind)) {
                    continue;
                }
                BlockPos pos = blockEntity.getPos();
                if (kind == Kind.GIFT && brokenPositions.contains(pos)) {
                    continue;
                }
                drawBox(pos, colorFor(kind));
            }
        }

        if (blocks.selected(CHESTS)) {
            for (Entity entity : context.world().getEntities()) {
                if (entity instanceof ChestMinecartEntity) {
                    drawBox(entity.getBlockPos(), chestColor.argb());
                }
            }
        }
    }

    private Kind classify(BlockEntity blockEntity) {
        if (blockEntity instanceof MobSpawnerBlockEntity) {
            return Kind.SPAWNER;
        }
        if (blockEntity instanceof ShulkerBoxBlockEntity) {
            return Kind.SHULKER;
        }
        if (blockEntity instanceof ChestBlockEntity || blockEntity instanceof EnderChestBlockEntity) {
            return Kind.CHEST;
        }
        if (blockEntity instanceof DispenserBlockEntity) {
            return Kind.DISPENSER;
        }
        if (blockEntity instanceof SkullBlockEntity
                && blockEntity.getCachedState().getBlock() instanceof AbstractSkullBlock skull
                && skull.getSkullType() == SkullBlock.Type.PLAYER) {
            return Kind.GIFT;
        }
        return null;
    }

    private boolean selected(Kind kind) {
        return switch (kind) {
            case SPAWNER -> blocks.selected(SPAWNERS);
            case SHULKER -> blocks.selected(SHULKERS);
            case CHEST -> blocks.selected(CHESTS);
            case DISPENSER -> blocks.selected(DISPENSERS);
            case GIFT -> blocks.selected(GIFTS);
        };
    }

    private int colorFor(Kind kind) {
        return switch (kind) {
            case SPAWNER -> spawnerColor.argb();
            case SHULKER -> shulkerColor.argb();
            case CHEST -> chestColor.argb();
            case DISPENSER -> dispenserColor.argb();
            case GIFT -> GIFT_COLOR;
        };
    }

    private static void drawBox(BlockPos pos, int color) {
        VisibilityConfigurable box = GizmoDrawing.box(pos, DrawStyle.stroked(color, 1.5F));

        box.ignoreOcclusion();
    }

    private enum Kind {
        SPAWNER,
        SHULKER,
        CHEST,
        DISPENSER,
        GIFT
    }
}
