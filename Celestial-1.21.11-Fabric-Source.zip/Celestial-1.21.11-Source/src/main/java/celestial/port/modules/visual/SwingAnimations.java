package celestial.port.modules.visual;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.math.MatrixStack;
import celestial.port.modules.combat.AttackAuraModule;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import net.minecraft.util.math.RotationAxis;
import org.joml.Vector3f;

import java.util.List;

public final class SwingAnimations extends Module {
    public static final String NO_ANIMATION = "Без анимации";
    public static final String SMOOTH_TRANSLATE = "Smooth Translate";

    private static SwingAnimations instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", SMOOTH_TRANSLATE, List.of(
                    NO_ANIMATION,
                    SMOOTH_TRANSLATE,
                    "Jump Translate",
                    "Smooth Block",
                    "Smooth Old",
                    "Smooth",
                    "Default",
                    "Big",
                    "Fap"
            )
    ));
    private final NumberSetting smoothness = addSetting(new NumberSetting(
            "smoothness", "Плавность анимации", 5.0, 0.0, 5.0, 1.0
    ).visibleWhen(() -> !mode.is(NO_ANIMATION)));
    private final NumberSetting strength = addSetting(new NumberSetting(
            "strength", "Сила анимации", 70.0, 10.0, 100.0, 10.0
    ).visibleWhen(() -> !mode.is(NO_ANIMATION)));
    private final NumberSetting rightX = addSetting(new NumberSetting("right_x", "RightX", 0.0, -2.0, 2.0, 0.1));
    private final NumberSetting rightY = addSetting(new NumberSetting("right_y", "RightY", 0.0, -2.0, 2.0, 0.1));
    private final NumberSetting rightZ = addSetting(new NumberSetting("right_z", "RightZ", 0.0, -2.0, 2.0, 0.1));
    private final NumberSetting leftX = addSetting(new NumberSetting("left_x", "LeftX", 0.0, -2.0, 2.0, 0.1));
    private final NumberSetting leftY = addSetting(new NumberSetting("left_y", "LeftY", 0.0, -2.0, 2.0, 0.1));
    private final NumberSetting leftZ = addSetting(new NumberSetting("left_z", "LeftZ", 0.0, -2.0, 2.0, 0.1));
    private final NumberSetting rotationAngle = addSetting(new NumberSetting(
            "rotation_angle", "Угол поворота", 40.0, 0.0, 70.0, 1.0
    ).visibleWhen(() -> mode.is(SMOOTH_TRANSLATE)));
    private final BooleanSetting item360 = addSetting(new BooleanSetting("item_360", "Item 360", false));
    private final ModeSetting hand = addSetting(new ModeSetting(
            "hand", "Работать на", "Правую руку",
            List.of("Все руки", "Правую руку", "Левую руку")
    ).visibleWhen(item360::enabled));
    private final NumberSetting speed = addSetting(new NumberSetting(
            "speed", "Speed", 2.0, 1.0, 5.0, 1.0
    ).visibleWhen(item360::enabled));
    private final BooleanSetting onlyKillAura = addSetting(new BooleanSetting(
            "only_kill_aura", "Только с киллаурой", false
    ).visibleWhen(() -> !mode.is(NO_ANIMATION)));

    public SwingAnimations() {
        super("swing_animations", "Swing Animations", "Анимирует предмет при ударе",
                Category.RENDER);
        instance = this;
    }

    public static SwingAnimations instance() {
        return instance;
    }

    public ModeSetting mode() {
        return mode;
    }

    public NumberSetting smoothness() {
        return smoothness;
    }

    public NumberSetting strength() {
        return strength;
    }

    public BooleanSetting onlyKillAura() {
        return onlyKillAura;
    }

    public BooleanSetting item360() {
        return item360;
    }

    public ModeSetting hand() {
        return hand;
    }

    public NumberSetting speed() {
        return speed;
    }

    public NumberSetting rightX() {
        return rightX;
    }

    public NumberSetting rightY() {
        return rightY;
    }

    public NumberSetting rightZ() {
        return rightZ;
    }

    public NumberSetting leftX() {
        return leftX;
    }

    public NumberSetting leftY() {
        return leftY;
    }

    public NumberSetting leftZ() {
        return leftZ;
    }

    public NumberSetting rotationAngle() {
        return rotationAngle;
    }

    public void applyHandOffset(MatrixStack matrices, Hand renderedHand) {
        if (!enabled()) {
            return;
        }
        if (renderedHand == Hand.MAIN_HAND) {
            matrices.translate(rightX.value().floatValue(), rightY.value().floatValue(), rightZ.value().floatValue());
        } else {
            matrices.translate(leftX.value().floatValue(), leftY.value().floatValue(), leftZ.value().floatValue());
        }
    }

    public boolean replacesIdleTransform(AbstractClientPlayerEntity player, Arm arm) {
        if (!enabled() || !passesKillAuraGate(player)) {
            return false;
        }
        return arm == Arm.RIGHT && !mode.is(NO_ANIMATION) || spins(arm);
    }

    public void applyIdleTransform(MatrixStack matrices, AbstractClientPlayerEntity player,
                                   Arm arm, float swingProgress, float equipProgress) {
        if (arm == Arm.RIGHT && !mode.is(NO_ANIMATION)) {
            switch (mode.value()) {
                case SMOOTH_TRANSLATE -> applySmoothTranslate(matrices, swingProgress);
                case "Jump Translate" -> applyJumpTranslate(matrices, swingProgress);
                case "Smooth Block" -> applySmoothBlock(matrices, swingProgress, equipProgress);
                case "Smooth Old" -> applySmoothOld(matrices, legacyGlobalSwing(player));
                case "Smooth" -> applySmooth(matrices, swingProgress, arm);
                case "Default" -> applyDefault(matrices, swingProgress);
                case "Big" -> applyBig(matrices, legacyGlobalSwing(player));
                case "Fap" -> applyFap(matrices, player, swingProgress);
                default -> applyLegacyVanilla(matrices, arm, swingProgress, equipProgress);
            }
        } else {
            applyLegacyVanilla(matrices, arm, swingProgress, equipProgress);
        }

        if (spins(arm)) {
            int divisor = 6 - speed.value().intValue();
            float angle = (float)(System.currentTimeMillis() % (360L * divisor) / divisor);
            rotate(matrices, angle, -1.0f, 0.0f, 0.0f);
        }
    }

    public int swingDuration() {
        return 6 + smoothness.value().intValue();
    }

    public boolean changesSwingDuration() {
        return enabled() && !mode.is(NO_ANIMATION);
    }

    private boolean spins(Arm arm) {
        if (!item360.enabled()) {
            return false;
        }
        return hand.is("Все руки")
                || hand.is("Правую руку") && arm == Arm.RIGHT
                || hand.is("Левую руку") && arm == Arm.LEFT;
    }

    private boolean passesKillAuraGate(AbstractClientPlayerEntity player) {
        return !onlyKillAura.enabled() || AttackAuraModule.hasTarget();
    }

    private float legacyGlobalSwing(AbstractClientPlayerEntity player) {
        float tickProgress = MinecraftClient.getInstance().getRenderTickCounter().getTickProgress(true);
        return player.getHandSwingProgress(tickProgress);
    }

    private void applySmoothOld(MatrixStack matrices, float swing) {
        matrices.translate(0.4f, 0.0f, -0.8f);
        matrices.translate(0.56f, -0.44f, -0.71999997f);
        rotate(matrices, 72.0f, 0.0f, 1.0f, 0.0f);
        float wave = sinSqrt(swing);
        rotate(matrices, wave * -10.0f, 0.0f, 0.0f, 1.0f);
        rotate(matrices, wave * -strength.value().intValue(), 0.01f, 0.0f, 0.0f);
        rotate(matrices, -20.0f, 0.01f, 0.0f, 0.0f);
        matrices.translate(-0.5f, 0.08f, 0.0f);
        rotate(matrices, 20.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, -80.0f, 1.0f, 0.0f, 0.0f);
        rotate(matrices, 20.0f, 0.0f, 1.0f, 0.0f);
    }

    private void applyFap(MatrixStack matrices, AbstractClientPlayerEntity player, float swing) {
        matrices.translate(1.2f, -0.1f, -0.71999997f);
        matrices.translate(0.0f, 0.0f, 0.0f);
        rotate(matrices, 45.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, 0.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, 0.0f, 0.0f, 0.0f, 1.0f);
        rotate(matrices, 0.0f, 1.0f, 0.0f, 0.0f);
        matrices.translate(-0.5f, 0.2f, 0.0f);
        rotate(matrices, 30.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, -80.0f, 1.0f, 0.0f, 0.0f);
        rotate(matrices, 60.0f, 0.0f, 1.0f, 0.0f);

        long now = System.currentTimeMillis();
        long remainder = now % 255L;
        int pulse = (int)Math.min(255L, (remainder > 127L ? Math.abs(remainder - 255L) : remainder) * 2L);
        float legacySwingOffset = -0.2f * (float)Math.sin(swing * Math.PI);
        float folded = legacySwingOffset > 0.5f ? 1.0f - legacySwingOffset : legacySwingOffset;
        matrices.translate(0.3f, 0.0f, 0.4f);
        rotate(matrices, 0.0f, 0.0f, 0.0f, 1.0f);
        matrices.translate(0.0f, 0.5f, 0.0f);
        rotate(matrices, 90.0f, 1.0f, 0.0f, -1.0f);
        matrices.translate(0.6f, 0.5f, 0.0f);
        rotate(matrices, -90.0f, 1.0f, 0.0f, -1.0f);
        rotate(matrices, -10.0f, 1.0f, 0.0f, -1.0f);
        rotate(matrices, -folded * 10.0f, 10.0f, 10.0f, -9.0f);
        rotate(matrices, 10.0f, -1.0f, 0.0f, 0.0f);
        matrices.translate(0.0, 0.0, -0.5);
        float angle = player.handSwinging ? -pulse / (110.0f - strength.value().floatValue()) : 1.0f;
        rotate(matrices, angle, 1.0f, 0.0f, 1.0f);
        matrices.translate(0.0, 0.0, 0.5);
    }

    private void applyDefault(MatrixStack matrices, float swing) {
        float strengthValue = strength.value().floatValue();
        float angle = -strengthValue * (float)Math.sin(swing * Math.PI) * strengthValue / 100.0f;
        matrices.translate(1.2f, -0.1f, -0.71999997f);
        matrices.translate(0.0f, 0.0f, 0.0f);
        rotate(matrices, 45.0f, 0.0f, 1.0f, 0.0f);
        matrices.translate(-0.5f, 0.2f, 0.0f);
        rotate(matrices, 30.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, -80.0f, 1.0f, 0.0f, 0.0f);
        rotate(matrices, 60.0f, 0.0f, 1.0f, 0.0f);
        matrices.translate(0.3f, 0.0f, 0.4f);
        rotate(matrices, 0.0f, 0.0f, 0.0f, 0.0f);
        matrices.translate(0.0f, 0.5f, 0.0f);
        rotate(matrices, 90.0f, 1.0f, 0.0f, -1.0f);
        matrices.translate(0.6f, 0.5f, 0.0f);
        rotate(matrices, -90.0f, 1.0f, 0.0f, -1.0f);
        rotate(matrices, -10.0f, 1.0f, 0.0f, -1.0f);
        rotate(matrices, 10.0f, -1.0f, 0.0f, 0.0f);
        matrices.translate(0.0f, 0.0f, -0.5f);
        rotate(matrices, angle, 1.0f, 0.0f, 1.0f);
        matrices.translate(0.0f, 0.0f, 0.5f);
    }

    private void applyBig(MatrixStack matrices, float swing) {
        matrices.translate(0.5f, -0.3f, -0.65f);
        matrices.translate(0.0f, 0.0f, 0.0f);
        rotate(matrices, 45.0f, 0.0f, 1.0f, 0.0f);
        float squareWave = (float)Math.sin(swing * swing * Math.PI);
        float rootWave = sinSqrt(swing);
        rotate(matrices, squareWave * -20.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, rootWave * -20.0f, 0.0f, 0.0f, 1.0f);
        rotate(matrices, rootWave * -strength.value().intValue(), 1.0f, 0.0f, 0.0f);
        matrices.scale(0.5f, 0.5f, 0.5f);
        matrices.translate(-0.5f, 0.2f, 0.0f);
        rotate(matrices, 30.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, -80.0f, 1.0f, 0.0f, 0.0f);
        rotate(matrices, 60.0f, 0.0f, 1.0f, 0.0f);
    }

    private void applySmooth(MatrixStack matrices, float swing, Arm arm) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        matrices.translate(side * 0.56f, -0.52f, -0.72f);
        float rootWave = sinSqrt(swing);
        rotate(matrices, side * (45.0f + (float)Math.sin(swing * swing * Math.PI) / 4.0f * -20.0f),
                0.0f, 1.0f, 0.0f);
        rotate(matrices, side * rootWave * -20.0f, 0.0f, 0.0f, 1.0f);
        rotate(matrices, rootWave * -strength.value().intValue(), 1.0f, 0.0f, 0.0f);
        rotate(matrices, side * -45.0f, 0.0f, 1.0f, 0.0f);
    }

    private void applyJumpTranslate(MatrixStack matrices, float swing) {

        float offset = -0.2f * (float)Math.sin(swing * Math.PI);
        float phase = (float)Math.sqrt(Math.max(0.0f, -offset)) * (float)Math.PI;
        matrices.translate(0.4f, -0.15f, -0.5f);
        matrices.translate(0.0f, offset * -strength.value().floatValue() / 100.0f, 0.0f);
        rotate(matrices, 45.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, (float)Math.sin(offset * offset * Math.PI) * -34.0f, 0.0f, 1.0f, 0.2f);
        rotate(matrices, (float)Math.sin(phase) * -20.7f, 0.2f, 0.1f, 1.0f);
        rotate(matrices, (float)Math.sin(phase) * -68.6f, 1.3f, 0.1f, 0.2f);
        matrices.scale(0.4f, 0.4f, 0.4f);
        rotate(matrices, 30.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, -80.0f, 1.0f, 0.0f, 0.0f);
        rotate(matrices, 60.0f, 0.0f, 1.0f, 0.0f);
    }

    private void applySmoothBlock(MatrixStack matrices, float swing, float equipProgress) {
        matrices.translate(0.6f, 0.0f, -0.8f);
        matrices.translate(0.56f, -1.0f, -0.82f);
        rotate(matrices, 90.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, -60.0f, 0.0f, 0.0f, 1.0f);
        float angle = -rotationAngle.value().intValue()
                - 40.0f * (float)Math.sin(swing * Math.PI) * strength.value().floatValue() / 50.0f;
        rotate(matrices, angle, 1.0f, equipProgress, 0.0f);
        rotate(matrices, -40.0f, 0.01f, 0.0f, 0.0f);
        matrices.translate(-0.5, 0.08, 0.0);
    }

    private void applySmoothTranslate(MatrixStack matrices, float swing) {
        matrices.translate(0.6f, 0.0f, -0.8f);
        matrices.translate(0.56f, -1.0f, -0.82f);
        rotate(matrices, 90.0f, 0.0f, 1.0f, 0.0f);
        rotate(matrices, -60.0f, 0.0f, 0.0f, 1.0f);
        float angle = -rotationAngle.value().intValue()
                - 40.0f * (float)Math.sin(swing * Math.PI) * strength.value().floatValue() / 50.0f;
        rotate(matrices, angle, 1.0f, 0.0f, 0.0f);
        rotate(matrices, -20.0f, 0.01f, 0.0f, 0.0f);
        matrices.translate(-0.5, 0.08, 0.0);
    }

    private static void applyLegacyVanilla(MatrixStack matrices, Arm arm, float swing, float equipProgress) {
        int side = arm == Arm.RIGHT ? 1 : -1;
        float root = (float)Math.sqrt(swing);
        matrices.translate(
                side * -0.4f * (float)Math.sin(root * Math.PI),
                0.2f * (float)Math.sin(root * Math.PI * 2.0),
                -0.2f * (float)Math.sin(swing * Math.PI)
        );
        matrices.translate(side * 0.56f, -0.52f + equipProgress * -0.6f, -0.72f);
        float squareWave = (float)Math.sin(swing * swing * Math.PI);
        float rootWave = (float)Math.sin(root * Math.PI);
        rotate(matrices, side * (45.0f + squareWave * -20.0f), 0.0f, 1.0f, 0.0f);
        rotate(matrices, side * rootWave * -20.0f, 0.0f, 0.0f, 1.0f);
        rotate(matrices, rootWave * -80.0f, 1.0f, 0.0f, 0.0f);
        rotate(matrices, side * -45.0f, 0.0f, 1.0f, 0.0f);
    }

    private static float sinSqrt(float swing) {
        return (float)Math.sin(Math.sqrt(swing) * Math.PI);
    }

    private static void rotate(MatrixStack matrices, float degrees, float axisX, float axisY, float axisZ) {
        float lengthSquared = axisX * axisX + axisY * axisY + axisZ * axisZ;
        if (lengthSquared == 0.0f || degrees == 0.0f) {
            return;
        }
        float inverseLength = 1.0f / (float)Math.sqrt(lengthSquared);
        RotationAxis axis = RotationAxis.of(new Vector3f(
                axisX * inverseLength,
                axisY * inverseLength,
                axisZ * inverseLength
        ));
        matrices.multiply(axis.rotationDegrees(degrees));
    }
}
