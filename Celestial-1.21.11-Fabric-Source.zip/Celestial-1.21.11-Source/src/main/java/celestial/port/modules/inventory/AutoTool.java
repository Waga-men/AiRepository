package celestial.port.modules.inventory;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.modules.impl.NoClip;
import celestial.port.modules.legacyutility.BaritoneBridge;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.tag.FluidTags;
import net.minecraft.util.hit.BlockHitResult;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class AutoTool extends Module {
    private static volatile AutoTool instance;

    private final BooleanSetting silent = addSetting(new BooleanSetting(
            "silent", "Незаметно", false
    ));

    private final List<Integer> restoreSlots = new ArrayList<>();

    private volatile int effectiveSlot;

    private boolean switched;

    public AutoTool() {
        super("auto_tool", "Auto Tool",
                "Автоматически ломает блок инструментом", Category.UTILITY);
        instance = this;
    }

    public BooleanSetting silent() {
        return silent;
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        AutoTool module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || client.player != player) {
            return;
        }
        try {
            module.tickLegacy(client);
        } catch (Exception ignored) {

        }
    }

    private void tickLegacy(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) {

            return;
        }

        if (BaritoneBridge.isMineProcessActive()) {
            return;
        }

        if (!(client.crosshairTarget instanceof BlockHitResult hit)) {
            return;
        }

        BlockState state = client.world.getBlockState(hit.getBlockPos());
        PlayerInventory inventory = player.getInventory();
        List<Integer> candidates = new ArrayList<>();
        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            if (legacyMiningSpeed(player, inventory.getStack(slot), state) > 1.0F) {
                candidates.add(slot);
            }
        }

        candidates.sort(Comparator.comparingDouble(
                slot -> -legacyMiningSpeed(player, inventory.getStack(slot), state)));
        List<Integer> suitable = candidates.stream()
                .filter(slot -> inventory.getStack(slot).isSuitableFor(state))
                .toList();
        if (!suitable.isEmpty()) {
            candidates.set(0, suitable.get(0));
        }

        if (!candidates.isEmpty() && client.options.attackKey.isPressed()) {

            inventory.getSelectedStack();
            restoreSlots.add(inventory.getSelectedSlot());
            int bestSlot = candidates.get(0);
            select(client, bestSlot);
            effectiveSlot = bestSlot;
            switched = true;
        } else if (switched && !restoreSlots.isEmpty()) {
            int originalSlot = restoreSlots.get(0);
            select(client, originalSlot);
            effectiveSlot = originalSlot;
            restoreSlots.clear();
            switched = false;
        }
    }

    private void select(MinecraftClient client, int slot) {
        if (silent.enabled()) {
            client.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
        } else {
            client.player.getInventory().setSelectedSlot(slot);
        }
    }

    public static float legacyMiningSpeed(PlayerEntity player, ItemStack stack, BlockState state) {
        float speed = stack.getMiningSpeedMultiplier(state);
        if (speed > 1.0F) {
            int efficiency = enchantmentLevel(player, Enchantments.EFFICIENCY, stack);
            if (efficiency > 0 && !stack.isEmpty()) {
                speed += efficiency * efficiency + 1.0F;
            }
        }

        if (StatusEffectUtil.hasHaste(player)) {
            speed *= 1.0F + (StatusEffectUtil.getHasteAmplifier(player) + 1) * 0.2F;
        }

        StatusEffectInstance fatigue = player.getStatusEffect(StatusEffects.MINING_FATIGUE);
        if (fatigue != null) {
            speed *= switch (fatigue.getAmplifier()) {
                case 0 -> 0.3F;
                case 1 -> 0.09F;
                case 2 -> 0.0027F;
                default -> 8.1E-4F;
            };
        }

        speed *= (float) player.getAttributeValue(EntityAttributes.BLOCK_BREAK_SPEED);
        if (player.isSubmergedIn(FluidTags.WATER)) {
            speed *= (float) player.getAttributeValue(EntityAttributes.SUBMERGED_MINING_SPEED);
        }
        if (!player.isOnGround()) {
            speed /= 5.0F;
        }
        return speed;
    }

    public static ItemStack effectiveMiningStack(PlayerEntity player) {
        AutoTool module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || client.player != player || client.world == null
                || BaritoneBridge.isAnyProcessActive()
                || NoClip.blocksAutoTool()) {
            return null;
        }

        int slot = module.effectiveSlot;
        if (slot < 0 || slot >= PlayerInventory.getHotbarSize()) {
            return null;
        }
        return player.getInventory().getStack(slot);
    }

    private static int enchantmentLevel(PlayerEntity player,
                                        RegistryKey<Enchantment> key,
                                        ItemStack stack) {
        var enchantments = player.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        return EnchantmentHelper.getLevel(enchantments.getOrThrow(key), stack);
    }

}
