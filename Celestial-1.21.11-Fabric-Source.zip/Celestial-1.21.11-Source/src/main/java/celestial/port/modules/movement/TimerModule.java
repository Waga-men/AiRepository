package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.mixin.accessor.RenderTickCounterDynamicAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;

public final class TimerModule extends Module {
    private static final float VANILLA_TICK_MILLIS = 50.0F;
    private static final float BALANCE_CAPACITY = 100.0F;

    private final NumberSetting speed = addSetting(new NumberSetting(
            "speed", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 1.8, 1.1, 5.0, 0.1
    ));
    private final BooleanSetting smart = addSetting(new BooleanSetting(
            "smart", "\u0423\u043c\u043d\u044b\u0439", true
    ));
    private final BooleanSetting indicator = addSetting(new BooleanSetting(
            "indicator", "\u0418\u043d\u0434\u0438\u043a\u0430\u0442\u043e\u0440", true
    ).visibleWhen(smart::enabled));
    private final NumberSetting decaySpeed = addSetting(new NumberSetting(
            "decay_speed", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0443\u0431\u044b\u0432\u0430\u043d\u0438\u044f", 1.0, 0.5, 3.0, 0.1
    ).visibleWhen(smart::enabled));
    private final NumberSetting movingIncrement = addSetting(new NumberSetting(
            "moving_increment", "\u0414\u043e\u0431\u0430\u0432\u043b\u044f\u0442\u044c \u0432 \u0434\u0432\u0438\u0436\u0435\u043d\u0438\u0438", 0.0, 0.0, 1.0, 0.05
    ).visibleWhen(smart::enabled));

    private static float balance;
    private double sampledX;
    private double sampledY;
    private double sampledZ;
    private float sampledYaw;
    private float sampledPitch;
    private RenderTickCounter.Dynamic ownedCounter;
    private float previousTickTime;
    private float appliedTickTime;
    private boolean ownsTickTime;

    public TimerModule() {
        super("timer", "Timer", "\u0423\u0441\u043a\u043e\u0440\u044f\u0435\u0442 \u0438\u0433\u0440\u0443", Category.MOVEMENT);
    }

    @Override
    protected void onTick() {
        if (!applySpeed()) {
            return;
        }
        if (!smart.enabled() || speed.value() <= 1.0) {
            return;
        }
        float multiplier = speed.value().floatValue();
        if (balance < (BALANCE_CAPACITY - 10.0F) / multiplier) {
            balance = Math.min(BALANCE_CAPACITY / multiplier,
                    balance + decaySpeed.value().floatValue());
        } else {
            setEnabled(false);
        }
    }

    public static void sampleMovement(ClientPlayerEntity player) {
        Module raw = CelestialPortClient.MODULES.find("timer").orElse(null);
        if (!(raw instanceof TimerModule module) || !module.enabled() || !module.smart.enabled()) {
            return;
        }
        boolean unchanged = module.sampledX == player.getX()
                && module.sampledY == player.getY()
                && module.sampledZ == player.getZ()
                && module.sampledYaw == player.getYaw()
                && module.sampledPitch == player.getPitch();
        if (unchanged) {
            balance -= module.decaySpeed.value().floatValue() + 0.4F;
        } else {
            balance -= module.movingIncrement.value().floatValue() / 10.0F;
        }
        float limit = (float) Math.floor(BALANCE_CAPACITY / module.speed.value());
        balance = Math.max(0.0F, Math.min(limit, balance));
        module.sampledX = player.getX();
        module.sampledY = player.getY();
        module.sampledZ = player.getZ();
        module.sampledYaw = player.getYaw();
        module.sampledPitch = player.getPitch();
    }

    public static boolean indicatorVisible() {
        Module raw = CelestialPortClient.MODULES.find("timer").orElse(null);
        return raw instanceof TimerModule module && module.enabled()
                && module.smart.enabled() && module.indicator.enabled();
    }

    public static float indicatorProgress() {
        Module raw = CelestialPortClient.MODULES.find("timer").orElse(null);
        if (!(raw instanceof TimerModule module)) {
            return 0.0F;
        }
        float maximum = BALANCE_CAPACITY / module.speed.value().floatValue();
        return maximum <= 0.0F ? 0.0F : 1.0F - Math.min(balance, maximum) / maximum;
    }

    public static void forceVanillaAfterServerCorrection() {
        var counter = MinecraftClient.getInstance().getRenderTickCounter();
        if (counter instanceof RenderTickCounter.Dynamic
                && counter instanceof RenderTickCounterDynamicAccessor accessor) {
            accessor.celestial$setTickTime(VANILLA_TICK_MILLIS);
        }
    }

    private boolean applySpeed() {
        var counter = MinecraftClient.getInstance().getRenderTickCounter();
        if (!(counter instanceof RenderTickCounter.Dynamic dynamic)
                || !(counter instanceof RenderTickCounterDynamicAccessor accessor)) {
            restoreOwnedCounter();
            return false;
        }
        if (ownedCounter != dynamic) {
            restoreOwnedCounter();
            ownedCounter = dynamic;
            previousTickTime = accessor.celestial$getTickTime();
            ownsTickTime = true;
        }
        appliedTickTime = VANILLA_TICK_MILLIS / speed.value().floatValue();
        accessor.celestial$setTickTime(appliedTickTime);
        return true;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        var counter = MinecraftClient.getInstance().getRenderTickCounter();
        if (counter instanceof RenderTickCounter.Dynamic
                && counter instanceof RenderTickCounterDynamicAccessor accessor) {
            accessor.celestial$setTickTime(VANILLA_TICK_MILLIS);
        }
        ownedCounter = null;
        ownsTickTime = false;
    }

    @Override
    protected void onDisable() {
        restoreOwnedCounter();
    }

    private void restoreOwnedCounter() {
        if (ownsTickTime && ownedCounter instanceof RenderTickCounterDynamicAccessor accessor
                && Math.abs(accessor.celestial$getTickTime() - appliedTickTime) < 0.0001F) {
            accessor.celestial$setTickTime(previousTickTime);
        }
        ownedCounter = null;
        ownsTickTime = false;
    }
}
