package celestial.port.modules.movement;

import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

final class MovementSupport {
    private static final double EPSILON = 1.0E-6;

    private MovementSupport() {
    }

    static ClientPlayerEntity playablePlayer(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || !player.isAlive() || player.isRemoved() || player.isSpectator()) {
            return null;
        }
        return player;
    }

    static boolean acceptsMovementInput(MinecraftClient client) {
        return client.currentScreen == null;
    }

    static Vec3d inputDirection(MinecraftClient client, ClientPlayerEntity player) {
        if (!acceptsMovementInput(client)) {
            return Vec3d.ZERO;
        }

        double forward = (client.options.forwardKey.isPressed() ? 1.0 : 0.0)
                - (client.options.backKey.isPressed() ? 1.0 : 0.0);
        double strafe = (client.options.leftKey.isPressed() ? 1.0 : 0.0)
                - (client.options.rightKey.isPressed() ? 1.0 : 0.0);
        double inputLength = Math.hypot(forward, strafe);
        if (inputLength < EPSILON) {
            return Vec3d.ZERO;
        }

        forward /= inputLength;
        strafe /= inputLength;
        double yaw = Math.toRadians(player.getYaw());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        return new Vec3d(-sin * forward + cos * strafe, 0.0, cos * forward + sin * strafe);
    }

    static Vec3d legacyInputDirection(ClientPlayerEntity player) {
        float forward = player.forwardSpeed;
        float strafe = player.sidewaysSpeed;
        float yaw = player.getYaw();
        if (forward != 0.0f) {
            if (strafe > 0.0f) {
                yaw += forward > 0.0f ? -45.0f : 45.0f;
            } else if (strafe < 0.0f) {
                yaw += forward > 0.0f ? 45.0f : -45.0f;
            }
            strafe = 0.0f;
            forward = forward > 0.0f ? 1.0f : -1.0f;
        }
        double radians = Math.toRadians(yaw + 90.0f);
        double cosine = Math.cos(radians);
        double sine = Math.sin(radians);
        return new Vec3d(forward * cosine + strafe * sine, 0.0,
                forward * sine - strafe * cosine);
    }

    static double legacyMovementYaw(ClientPlayerEntity player) {
        float yaw = player.getYaw();
        float forward = player.forwardSpeed;
        float strafe = player.sidewaysSpeed;
        float strafeScale = 1.0f;
        if (forward < 0.0f) {
            yaw += 180.0f;
            strafeScale = -0.5f;
        } else if (forward > 0.0f) {
            strafeScale = 0.5f;
        }
        if (strafe > 0.0f) {
            yaw -= 90.0f * strafeScale;
        } else if (strafe < 0.0f) {
            yaw += 90.0f * strafeScale;
        }
        return Math.toRadians(yaw);
    }

    static Vec3d facingDirection(ClientPlayerEntity player) {
        double yaw = Math.toRadians(player.getYaw());
        return new Vec3d(-Math.sin(yaw), 0.0, Math.cos(yaw));
    }

    static Vec3d horizontalDirection(Vec3d velocity) {
        double length = velocity.horizontalLength();
        if (length < EPSILON) {
            return Vec3d.ZERO;
        }
        return new Vec3d(velocity.x / length, 0.0, velocity.z / length);
    }

    static boolean hasDirection(Vec3d direction) {
        return direction.horizontalLengthSquared() >= EPSILON;
    }

    static void setHorizontalVelocity(ClientPlayerEntity player, Vec3d direction, double speed) {
        if (!hasDirection(direction)) {
            return;
        }
        Vec3d velocity = player.getVelocity();
        player.setVelocity(direction.x * speed, velocity.y, direction.z * speed);
    }

    static boolean isInsideCobweb(ClientPlayerEntity player) {
        Box box = player.getBoundingBox();
        int minimumX = MathHelper.floor(box.minX + EPSILON);
        int minimumY = MathHelper.floor(box.minY + EPSILON);
        int minimumZ = MathHelper.floor(box.minZ + EPSILON);
        int maximumX = MathHelper.floor(box.maxX - EPSILON);
        int maximumY = MathHelper.floor(box.maxY - EPSILON);
        int maximumZ = MathHelper.floor(box.maxZ - EPSILON);

        for (int x = minimumX; x <= maximumX; x++) {
            for (int y = minimumY; y <= maximumY; y++) {
                for (int z = minimumZ; z <= maximumZ; z++) {
                    if (player.getEntityWorld().getBlockState(new BlockPos(x, y, z)).isOf(Blocks.COBWEB)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }
}
