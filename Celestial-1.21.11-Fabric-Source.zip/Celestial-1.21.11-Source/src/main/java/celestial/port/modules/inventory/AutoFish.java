package celestial.port.modules.inventory;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.item.Items;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;

public final class AutoFish extends Module {
    public AutoFish() {
        super("auto_fish", "Auto Fish", "Авто рыбалка", Category.UTILITY);
    }

    public static void onPlaySound(PlaySoundS2CPacket packet) {
        Module module = CelestialPortClient.MODULES.find("auto_fish").orElse(null);
        if (!(module instanceof AutoFish autoFish) || !autoFish.enabled()) {
            return;
        }
        if (packet.getSound().value() != SoundEvents.ENTITY_FISHING_BOBBER_SPLASH) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.interactionManager == null) {
            return;
        }

        for (Hand hand : Hand.values()) {
            if (!client.player.getStackInHand(hand).isOf(Items.FISHING_ROD)) {
                continue;
            }
            client.interactionManager.interactItem(client.player, hand);
            client.interactionManager.interactItem(client.player, hand);
        }
    }
}
