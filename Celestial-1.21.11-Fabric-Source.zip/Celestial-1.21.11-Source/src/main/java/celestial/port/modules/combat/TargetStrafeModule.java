package celestial.port.modules.combat;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public final class TargetStrafeModule extends Module {
    private final NumberSetting distance = addSetting(new NumberSetting(
            "distance", "Дистанция", 2.4, 0.1, 6.0, 0.1
    ));
    private final NumberSetting speed = addSetting(new NumberSetting(
            "speed", "Скорость", 0.23, 0.1, 1.0, 0.01
    ));
    private final BooleanSetting hitBoost = addSetting(new BooleanSetting(
            "hit_boost", "Буст при ударе", false
    ));
    private final NumberSetting boostSpeed = addSetting(new NumberSetting(
            "boost_speed", "Скорость буста", 0.5, 0.1, 1.5, 0.1
    ).visibleWhen(hitBoost::enabled));

    private boolean clockwise = true;
    private static volatile boolean orbiting;

    public TargetStrafeModule() {
        super("target_strafe", "Target Strafe",
                "Кружится вокруг цели", Category.COMBAT);
    }

    public NumberSetting distance() {
        return distance;
    }

    public NumberSetting speed() {
        return speed;
    }

    public BooleanSetting hitBoost() {
        return hitBoost;
    }

    public NumberSetting boostSpeed() {
        return boostSpeed;
    }

    public static boolean orbiting() {
        return orbiting;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            orbiting = false;
            return;
        }
        LivingEntity target = AttackAuraModule.target();
        if (target == null || !target.isAlive()) {
            orbiting = false;
            return;
        }

        if (client.player.isOnGround()) {
            client.options.jumpKey.setPressed(false);
            client.player.jump();
            return;
        }

        double targetDistance = client.player.distanceTo(target);
        client.options.forwardKey.setPressed(false);
        double movementSpeed = speed.value();
        if (hitBoost.enabled() && client.player.hurtTime > 0 && client.player.isAlive()) {
            movementSpeed += boostSpeed.value();
        }

        double clampedDistance = Math.max(0.01, targetDistance);
        double angle = Math.atan2(
                client.player.getZ() - target.getZ(),
                client.player.getX() - target.getX()
        );
        double angularStep = MathHelper.clamp(movementSpeed / clampedDistance, 0.01, 1.0);
        angle += clockwise ? angularStep : -angularStep;

        double pointX = target.getX() + distance.value() * Math.cos(angle);
        double pointZ = target.getZ() + distance.value() * Math.sin(angle);
        if (unsafe(client, pointX, pointZ)) {
            clockwise = !clockwise;
            angle += 2.0 * (clockwise ? angularStep : -angularStep);
            pointX = target.getX() + distance.value() * Math.cos(angle);
            pointZ = target.getZ() + distance.value() * Math.sin(angle);
        }

        float yaw = (float) (Math.toDegrees(Math.atan2(
                pointZ - client.player.getZ(), pointX - client.player.getX())) - 90.0);
        double velocityX = movementSpeed * -Math.sin(Math.toRadians(yaw));
        double velocityZ = movementSpeed * Math.cos(Math.toRadians(yaw));
        if (!Double.isFinite(velocityX) || !Double.isFinite(velocityZ)) {
            orbiting = false;
            return;
        }
        Vec3d current = client.player.getVelocity();
        client.player.setVelocity(velocityX, current.y, velocityZ);
        orbiting = true;
    }

    private static boolean unsafe(MinecraftClient client, double x, double z) {
        if (client.player.horizontalCollision
                || client.options.leftKey.isPressed()
                || client.options.rightKey.isPressed()) {
            return true;
        }
        if (voidBelow(client, client.player.getX(), client.player.getZ())) {
            return true;
        }

        int top = MathHelper.floor(client.player.getY() + 4.0);
        int bottom = client.world.getBottomY();
        for (int y = top; y >= bottom; y--) {
            BlockState state = client.world.getBlockState(BlockPos.ofFloored(x, y, z));
            if (state.isOf(Blocks.LAVA) || state.isOf(Blocks.FIRE)
                    || state.isOf(Blocks.SOUL_FIRE) || state.isOf(Blocks.COBWEB)) {
                return true;
            }
            if (!state.isAir()) {
                return false;
            }
        }
        return true;
    }

    private static boolean voidBelow(MinecraftClient client, double x, double z) {
        for (int y = MathHelper.floor(client.player.getY()); y >= client.world.getBottomY(); y--) {
            if (!client.world.getBlockState(BlockPos.ofFloored(x, y, z)).isAir()) {
                return false;
            }
        }
        return true;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        orbiting = false;
    }

    @Override
    protected void onDisable() {
        orbiting = false;
    }
}
