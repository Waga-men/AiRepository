package celestial.port.modules.legacyutility;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.block.ShulkerBoxBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.Registries;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Array;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Optional;
import java.util.Set;

public final class BaritoneBridge extends Module {
    private static final Set<String> LEGACY_VARIANT_TRASH = Set.of(
            "stone", "granite", "polished_granite", "diorite", "polished_diorite",
            "andesite", "polished_andesite",
            "dirt", "coarse_dirt", "podzol", "grass_block",
            "oak_planks", "spruce_planks", "birch_planks", "jungle_planks", "acacia_planks", "dark_oak_planks",
            "oak_sapling", "spruce_sapling", "birch_sapling", "jungle_sapling", "acacia_sapling", "dark_oak_sapling",
            "sand", "red_sand",
            "oak_log", "spruce_log", "birch_log", "jungle_log", "acacia_log", "dark_oak_log",
            "sponge", "wet_sponge",
            "sandstone", "chiseled_sandstone", "cut_sandstone",
            "short_grass", "fern",
            "dandelion", "poppy", "blue_orchid", "allium", "azure_bluet",
            "red_tulip", "orange_tulip", "white_tulip", "pink_tulip", "oxeye_daisy",
            "infested_stone", "infested_cobblestone", "infested_stone_bricks",
            "infested_mossy_stone_bricks", "infested_cracked_stone_bricks", "infested_chiseled_stone_bricks",
            "stone_bricks", "mossy_stone_bricks", "cracked_stone_bricks", "chiseled_stone_bricks",
            "vine", "cobblestone_wall", "mossy_cobblestone_wall",
            "quartz_block", "chiseled_quartz_block", "quartz_pillar",
            "sunflower", "lilac", "tall_grass", "large_fern", "rose_bush", "peony",
            "prismarine", "prismarine_bricks", "dark_prismarine",
            "red_sandstone", "chiseled_red_sandstone", "cut_red_sandstone"
    );

    private static BaritoneBridge instance;

    private final BooleanSetting dropTrash = addSetting(new BooleanSetting(
            "drop_trash", "Выкидывать мусор", false
    ));
    private final BooleanSetting autoRepair = addSetting(new BooleanSetting(
            "auto_repair", "Авто починка", false
    ));
    private final BaritoneApi api = new BaritoneApi();

    private boolean rotatedForDrop;
    private boolean rotateNextMovementPacket;
    private boolean rotationPacketContext;
    private float appliedMovementYaw = Float.NaN;
    private ClientPlayerEntity rotationPlayer;
    private int debugSendTime;

    public BaritoneBridge() {
        super("baritone", "Baritone", "Искусственный интеллект для Minecraft", Category.UTILITY);
        instance = this;
        ClientTickEvents.START_CLIENT_TICK.register(this::tickIntegration);
    }

    public BooleanSetting dropTrash() {
        return dropTrash;
    }

    public BooleanSetting autoRepair() {
        return autoRepair;
    }

    public boolean available() {
        return api.available();
    }

    public String baritoneVersion() {
        return api.version();
    }

    public String lastError() {
        return api.lastError();
    }

    public boolean isMining() {
        return api.isMineProcessActive();
    }

    public static boolean isMineProcessActive() {
        BaritoneBridge bridge = instance;
        return bridge != null && bridge.api.isMineProcessActive();
    }

    public static boolean isAnyProcessActive() {
        BaritoneBridge bridge = instance;
        return bridge != null && bridge.api.anyProcessActive();
    }

    public static boolean mineAllowsSprint() {
        BaritoneBridge bridge = instance;
        return bridge == null || !bridge.api.isMineProcessActive() || !bridge.rotatedForDrop;
    }

    public static void cancelPathing() {
        BaritoneBridge bridge = instance;
        if (bridge != null) {
            bridge.api.cancelPathing();
        }
    }

    public static boolean shouldAutoRepair() {
        BaritoneBridge bridge = instance;

        return bridge != null && bridge.autoRepair.enabled();
    }

    public static void beginMovementPackets(ClientPlayerEntity player) {
        BaritoneBridge bridge = instance;
        if (bridge == null) {
            return;
        }
        bridge.rotationPacketContext = bridge.rotateNextMovementPacket
                && MinecraftClient.getInstance().player == player
                && bridge.api.isMineProcessActive();
        bridge.appliedMovementYaw = Float.NaN;
        bridge.rotationPlayer = bridge.rotationPacketContext ? player : null;
    }

    public static float movementPacketYaw(ClientPlayerEntity player, float vanillaYaw) {
        BaritoneBridge bridge = instance;
        if (bridge == null || !bridge.rotationPacketContext || bridge.rotationPlayer != player) {
            return vanillaYaw;
        }
        return vanillaYaw - 180.0F;
    }

    public static Packet<?> rewriteMovementPacket(Packet<?> packet) {
        BaritoneBridge bridge = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (bridge == null || !bridge.rotationPacketContext
                || bridge.rotationPlayer == null || client.player != bridge.rotationPlayer
                || !(packet instanceof PlayerMoveC2SPacket movement)) {
            return packet;
        }

        ClientPlayerEntity player = bridge.rotationPlayer;
        float packetYaw = movement.getYaw(player.getYaw()) - 180.0F;
        float packetPitch = movement.getPitch(player.getPitch());
        bridge.appliedMovementYaw = packetYaw;

        player.setBodyYaw(packetYaw);
        player.setHeadYaw(packetYaw);

        if (movement.changesPosition()) {
            return new PlayerMoveC2SPacket.Full(
                    movement.getX(player.getX()), movement.getY(player.getY()),
                    movement.getZ(player.getZ()), packetYaw, packetPitch,
                    movement.isOnGround(), movement.horizontalCollision());
        }
        return new PlayerMoveC2SPacket.LookAndOnGround(
                packetYaw, packetPitch,
                movement.isOnGround(), movement.horizontalCollision());
    }

    public static float appliedMovementYaw(ClientPlayerEntity player) {
        BaritoneBridge bridge = instance;
        return bridge != null && bridge.rotationPlayer == player
                ? bridge.appliedMovementYaw : Float.NaN;
    }

    public static void endMovementPackets(ClientPlayerEntity player) {
        BaritoneBridge bridge = instance;
        if (bridge == null || bridge.rotationPlayer != player) {
            return;
        }

        if (bridge.rotationPacketContext) {
            bridge.rotateNextMovementPacket = false;
            bridge.rotatedForDrop = true;
        }
        bridge.rotationPacketContext = false;
        bridge.appliedMovementYaw = Float.NaN;
        bridge.rotationPlayer = null;
    }

    @Override
    protected void onEnable() {

        applyLoadedEnabled(false);
    }

    private void tickIntegration(MinecraftClient client) {

        if (!dropTrash.enabled() || !api.isMineProcessActive()) {
            return;
        }

        ClientPlayerEntity player = client.player;
        if (player == null || client.interactionManager == null) {
            return;
        }

        ScreenHandler handler = player.currentScreenHandler;
        ItemStack cursorStack = handler.getCursorStack();
        if (!isShulkerBox(cursorStack) || inventoryContainsShulker(player)) {
            resetDropRotation();
            return;
        }

        boolean hasTrash = false;
        Item[] legacyOuterOrder = {
                Items.COBBLESTONE, Items.GRAVEL, Items.GRASS_BLOCK, Items.DIRT
        };
        for (Item baseItem : legacyOuterOrder) {
            for (int inventorySlot = 0;
                 inventorySlot < player.getInventory().getMainStacks().size();
                 inventorySlot++) {
                ItemStack stack = player.getInventory().getStack(inventorySlot);
                if (!matchesLegacyTrashPass(stack, baseItem)) {
                    continue;
                }
                hasTrash = true;

                rotateNextMovementPacket = true;
                if (!rotatedForDrop) {
                    continue;
                }
                var handlerSlot = handler.getSlotIndex(player.getInventory(), inventorySlot);
                if (handlerSlot.isEmpty()) {
                    continue;
                }
                client.interactionManager.clickSlot(
                        handler.syncId, handlerSlot.getAsInt(), 1,
                        SlotActionType.THROW, player);
            }
        }

        if (++debugSendTime < 2 && hasTrash) {
            String message = "\u0418\u043d\u0432\u0435\u043d\u0442\u0430\u0440\u044c \u0431\u044b\u043b \u0443\u0441\u043f\u0435\u0448\u043d\u043e \u043e\u0447\u0438\u0449\u0435\u043d!";
            if (!api.logDirect(message)) {
                player.sendMessage(net.minecraft.text.Text.literal(message), false);
            }
        } else if (debugSendTime >= 2) {
            debugSendTime = 0;
        }
    }

    private void resetDropRotation() {
        rotatedForDrop = false;
        rotateNextMovementPacket = false;
        rotationPacketContext = false;
        appliedMovementYaw = Float.NaN;
        rotationPlayer = null;
    }

    private static boolean inventoryContainsShulker(ClientPlayerEntity player) {
        return player.getInventory().getMainStacks().stream().anyMatch(BaritoneBridge::isShulkerBox);
    }

    private static boolean isShulkerBox(ItemStack stack) {
        return stack.getItem() instanceof BlockItem blockItem
                && blockItem.getBlock() instanceof ShulkerBoxBlock;
    }

    private static boolean matchesLegacyTrashPass(ItemStack stack, Item baseItem) {
        if (stack.isEmpty()) {
            return false;
        }
        Item item = stack.getItem();
        if (item == baseItem) {
            return true;
        }
        var id = Registries.ITEM.getId(item);
        return "minecraft".equals(id.getNamespace())
                && LEGACY_VARIANT_TRASH.contains(id.getPath());
    }

    private static final class BaritoneApi {
        private boolean resolutionAttempted;
        private Object mineProcess;
        private Method mineProcessIsActive;
        private Object commandManager;
        private Method commandExecute;
        private Object pathingControlManager;
        private Method getProcesses;
        private Field processSetField;
        private Method mostRecentInControl;
        private Object logHelper;
        private Method helperLogDirect;
        private Object logAsToastSetting;
        private Field settingValueField;
        private String version = "";
        private String lastError = "Fabric Baritone mod is not installed";

        boolean available() {
            resolve();
            return mineProcess != null && mineProcessIsActive != null;
        }

        String version() {
            resolve();
            return version.isBlank() ? "unknown" : version;
        }

        String lastError() {
            resolve();
            return lastError;
        }

        boolean isMineProcessActive() {
            if (!available()) {
                return false;
            }
            try {
                Object active = mineProcessIsActive.invoke(mineProcess);
                lastError = "";
                return active instanceof Boolean value && value;
            } catch (ReflectiveOperationException | RuntimeException exception) {
                lastError = readable(exception);
                return false;
            }
        }

        boolean anyProcessActive() {
            if (!available()) {
                return false;
            }
            boolean mineActive = isMineProcessActive();
            if (pathingControlManager == null) {
                return mineActive;
            }
            try {
                Boolean exact = exactProcessesActive();
                if (exact != null) {
                    lastError = "";
                    return exact;
                }
                if (mostRecentInControl != null) {
                    Object recent = mostRecentInControl.invoke(pathingControlManager);
                    if (recent instanceof Optional<?> optional) {
                        return (optional.isPresent() && processActive(optional.get())) || mineActive;
                    }
                    return (recent != null && processActive(recent)) || mineActive;
                }
            } catch (ReflectiveOperationException | RuntimeException exception) {
                lastError = readable(exception);
            }
            return mineActive;
        }

        void cancelPathing() {
            resolve();
            if (commandManager == null || commandExecute == null || !anyProcessActive()) {
                return;
            }
            try {
                commandExecute.invoke(commandManager, "cancel");
                lastError = "";
            } catch (ReflectiveOperationException | RuntimeException exception) {
                lastError = readable(exception);
            }
        }

        boolean logDirect(String message) {
            resolve();
            if (logHelper == null || helperLogDirect == null
                    || logAsToastSetting == null || settingValueField == null) {
                return false;
            }
            try {
                boolean asToast = Boolean.TRUE.equals(settingValueField.get(logAsToastSetting));
                helperLogDirect.invoke(logHelper, message, asToast);
                lastError = "";
                return true;
            } catch (ReflectiveOperationException | RuntimeException exception) {
                lastError = readable(exception);
                return false;
            }
        }

        private void resolve() {
            if (resolutionAttempted) {
                return;
            }
            resolutionAttempted = true;

            FabricLoader loader = FabricLoader.getInstance();
            if (!loader.isModLoaded("baritone")) {
                return;
            }
            version = loader.getModContainer("baritone")
                    .map(container -> container.getMetadata().getVersion().getFriendlyString())
                    .orElse("unknown");
            try {
                Class<?> apiClass = Class.forName(
                        "baritone.api.BaritoneAPI", false, BaritoneBridge.class.getClassLoader());
                Object provider = apiClass.getMethod("getProvider").invoke(null);
                Object primaryBaritone = provider.getClass().getMethod("getPrimaryBaritone").invoke(provider);
                mineProcess = primaryBaritone.getClass().getMethod("getMineProcess").invoke(primaryBaritone);
                mineProcessIsActive = mineProcess.getClass().getMethod("isActive");
                lastError = "";

                try {
                    Class<?> helperClass = Class.forName(
                            "baritone.api.utils.Helper", false, BaritoneBridge.class.getClassLoader());
                    logHelper = helperClass.getField("HELPER").get(null);
                    helperLogDirect = helperClass.getMethod("logDirect", String.class, boolean.class);
                    Object settings = apiClass.getMethod("getSettings").invoke(null);
                    logAsToastSetting = settings.getClass().getField("logAsToast").get(settings);
                    settingValueField = logAsToastSetting.getClass().getField("value");
                } catch (ReflectiveOperationException | LinkageError | RuntimeException ignored) {
                    logHelper = null;
                    helperLogDirect = null;
                    logAsToastSetting = null;
                    settingValueField = null;
                }

                try {
                    commandManager = primaryBaritone.getClass()
                            .getMethod("getCommandManager").invoke(primaryBaritone);
                    commandExecute = commandManager.getClass().getMethod("execute", String.class);
                } catch (ReflectiveOperationException | LinkageError | RuntimeException ignored) {
                    commandManager = null;
                    commandExecute = null;
                }
                try {
                    pathingControlManager = primaryBaritone.getClass()
                            .getMethod("getPathingControlManager").invoke(primaryBaritone);
                    try {
                        pathingControlManager = pathingControlManager.getClass()
                                .getMethod("getManager").invoke(pathingControlManager);
                    } catch (NoSuchMethodException ignored) {

                    }
                    try {
                        getProcesses = pathingControlManager.getClass().getMethod("getProcesses");
                    } catch (NoSuchMethodException ignored) {

                        processSetField = findProcessSetField(pathingControlManager);
                        mostRecentInControl = pathingControlManager.getClass()
                                .getMethod("mostRecentInControl");
                    }
                } catch (ReflectiveOperationException | LinkageError | RuntimeException ignored) {
                    pathingControlManager = null;
                    getProcesses = null;
                    processSetField = null;
                    mostRecentInControl = null;
                }
            } catch (ReflectiveOperationException | LinkageError | RuntimeException exception) {
                mineProcess = null;
                mineProcessIsActive = null;
                lastError = "unsupported Baritone API " + version + ": " + readable(exception);
            }
        }

        private Boolean exactProcessesActive() throws ReflectiveOperationException {
            Object processes = null;
            if (getProcesses != null) {
                processes = getProcesses.invoke(pathingControlManager);
            } else if (processSetField != null) {
                processes = processSetField.get(pathingControlManager);
            }
            if (processes instanceof Iterable<?> iterable) {
                for (Object process : iterable) {
                    if (processActive(process)) {
                        return true;
                    }
                }
                return false;
            }
            if (processes != null && processes.getClass().isArray()) {
                for (int index = 0; index < Array.getLength(processes); index++) {
                    if (processActive(Array.get(processes, index))) {
                        return true;
                    }
                }
                return false;
            }
            return null;
        }

        private static Field findProcessSetField(Object manager) {
            Field candidate = null;
            for (Class<?> type = manager.getClass();
                 type != null && type != Object.class;
                 type = type.getSuperclass()) {
                for (Field field : type.getDeclaredFields()) {
                    if (Modifier.isStatic(field.getModifiers())
                            || !Set.class.isAssignableFrom(field.getType())
                            || !field.trySetAccessible()) {
                        continue;
                    }
                    try {
                        Object value = field.get(manager);
                        if (!(value instanceof Set<?> set)
                                || !set.isEmpty() && set.stream().anyMatch(
                                process -> !exposesIsActive(process))) {
                            continue;
                        }
                    } catch (IllegalAccessException | RuntimeException ignored) {
                        continue;
                    }

                    if (candidate != null) {
                        return null;
                    }
                    candidate = field;
                }
            }
            return candidate;
        }

        private static boolean exposesIsActive(Object process) {
            if (process == null) {
                return false;
            }
            try {
                Class<?> returnType = process.getClass().getMethod("isActive").getReturnType();
                return returnType == boolean.class || returnType == Boolean.class;
            } catch (NoSuchMethodException | RuntimeException ignored) {
                return false;
            }
        }

        private static boolean processActive(Object process) throws ReflectiveOperationException {
            if (process == null
                    || !Boolean.TRUE.equals(
                    process.getClass().getMethod("isActive").invoke(process))) {
                return false;
            }
            return !isNonOwningInventoryPauser(process);
        }

        private static boolean isNonOwningInventoryPauser(Object process) {
            try {

                return Boolean.TRUE.equals(process.getClass()
                        .getMethod("isTemporary").invoke(process))
                        && "inventory pauser".equals(process.getClass()
                        .getMethod("displayName0").invoke(process));
            } catch (ReflectiveOperationException | RuntimeException ignored) {

                return false;
            }
        }

        private static String readable(Throwable throwable) {
            Throwable cause = throwable instanceof InvocationTargetException invocation
                    && invocation.getCause() != null ? invocation.getCause() : throwable;
            String message = cause.getMessage();
            return cause.getClass().getSimpleName()
                    + (message == null || message.isBlank() ? "" : ": " + message);
        }
    }
}
