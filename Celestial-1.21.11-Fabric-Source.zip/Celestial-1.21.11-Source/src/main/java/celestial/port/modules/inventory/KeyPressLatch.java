package celestial.port.modules.inventory;

import celestial.port.core.setting.BindSetting;
import net.minecraft.client.MinecraftClient;

final class KeyPressLatch {
    private boolean previouslyPressed;

    boolean poll(MinecraftClient client, BindSetting binding) {
        boolean pressed = binding.isBound()
                && BindSetting.isPressed(client.getWindow().getHandle(), binding.key());
        boolean risingEdge = pressed && !previouslyPressed;
        previouslyPressed = pressed;
        return risingEdge;
    }

    void reset() {
        previouslyPressed = false;
    }
}
