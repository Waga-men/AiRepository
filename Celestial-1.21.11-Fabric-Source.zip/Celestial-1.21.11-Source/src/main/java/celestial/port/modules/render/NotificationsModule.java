package celestial.port.modules.render;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.MultiSelectSetting;

import java.util.List;
import java.util.Set;

public final class NotificationsModule extends Module {
    private static final String MODULES = "Включении модулей";
    private static final String SHIELD = "Сносе щита";
    private static final String STAFF = "Выходе стаффа";

    private final MultiSelectSetting events = addSetting(new MultiSelectSetting(
            "events", "Сообщать об", Set.of(MODULES, SHIELD, STAFF),
            List.of(MODULES, SHIELD, STAFF)));

    public NotificationsModule() {
        super("notifications", "Notifications", "Shows client event notifications", Category.RENDER);
    }

    public boolean moduleToggleNotifications() { return events.selected(MODULES); }
    public boolean shieldBreakNotifications() { return events.selected(SHIELD); }
    public boolean staffLeaveNotifications() { return events.selected(STAFF); }
}
