package celestial.port.modules.render;

import celestial.port.CelestialPortClient;
import celestial.port.client.ui.ClientFeedback;
import celestial.port.core.Module;
import celestial.port.modules.combat.AttackAuraModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.sound.SoundEvents;

public final class ShieldBreakNotifications {
    private static final byte SHIELD_BROKEN = 30;
    private static final long DUPLICATE_WINDOW_NANOS = 250_000_000L;
    private static int matchingStatusCount;
    private static int lastNotifiedEntityId = Integer.MIN_VALUE;
    private static long lastNotificationNanos;

    private ShieldBreakNotifications() {
    }

    public static void onEntityStatus(EntityStatusS2CPacket packet) {
        if (!enabled() || packet.getStatus() != SHIELD_BROKEN) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        LivingEntity target = AttackAuraModule.target();
        if (client.world == null || target == null) {
            return;
        }
        Entity entity = packet.getEntity(client.world);
        if (entity != target) {
            return;
        }

        matchingStatusCount++;
        if (matchingStatusCount < 2) {
            notifyAuthoritativeStatus(entity);
        } else {
            matchingStatusCount = 0;
        }
    }

    public static void onPlaySound(PlaySoundS2CPacket packet) {
        if (!enabled() || !packet.getSound().matches(SoundEvents.ITEM_SHIELD_BREAK)) {
            return;
        }
        LivingEntity target = AttackAuraModule.target();
        if (target == null || target.squaredDistanceTo(
                packet.getX(), packet.getY(), packet.getZ()) > 4.0) {
            return;
        }
        notifySoundFallback(target);
    }

    private static boolean enabled() {
        Module candidate = CelestialPortClient.MODULES.find("notifications").orElse(null);
        return candidate instanceof NotificationsModule notifications
                && notifications.enabled()
                && notifications.shieldBreakNotifications();
    }

    private static void notifyAuthoritativeStatus(Entity entity) {
        deliver(entity, System.nanoTime());
    }

    private static void notifySoundFallback(Entity entity) {
        long now = System.nanoTime();
        if (lastNotifiedEntityId == entity.getId()
                && now - lastNotificationNanos < DUPLICATE_WINDOW_NANOS) {
            return;
        }
        deliver(entity, now);
    }

    private static void deliver(Entity entity, long now) {
        lastNotifiedEntityId = entity.getId();
        lastNotificationNanos = now;
        ClientFeedback.shieldBreak(entity.getName().getString() + " shield destroyed");
    }
}
