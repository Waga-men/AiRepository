package celestial.port.modules.visual;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.Std140Builder;
import com.mojang.blaze3d.buffers.Std140SizeCalculator;
import com.mojang.blaze3d.systems.CommandEncoder;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import org.lwjgl.system.MemoryStack;

import java.nio.ByteBuffer;
import java.util.List;
import java.util.Map;

public final class ShaderESP extends Module {
    private static final Identifier POST_EFFECT = Identifier.of("celestial", "shader_esp");
    private static final String CONFIG_BUFFER = "CelestialGlowConfig";
    private static final int CONFIG_SIZE = new Std140SizeCalculator()
            .putVec4().putVec4().putVec4().putVec4().putVec4().putVec4().get();

    private static ShaderESP instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", "Client", List.of("Client", "Static")
    ));
    private final ColorSetting color = addSetting(new ColorSetting(
            "color", "Цвет", 0xFFBE65FF, false
    ).visibleWhen(() -> mode.is("Static")));
    private final NumberSetting radius = addSetting(new NumberSetting(
            "radius", "Радиус", 10.0, 3.0, 50.0, 1.0
    ));
    private final NumberSetting opacity = addSetting(new NumberSetting(
            "opacity", "Прозрачность", 3.0, 1.0, 3.0, 0.5
    ));

    public ShaderESP() {
        super("shader_esp", "Shader ESP", "Обводка игроков", Category.RENDER);
        instance = this;
    }

    public static Identifier selectPostEffect(Identifier vanillaEffect) {
        return active() ? POST_EFFECT : vanillaEffect;
    }

    public static boolean shouldOutline(Entity entity) {
        ShaderESP module = instance;
        if (module == null || !module.enabled() || !(entity instanceof PlayerEntity)) {
            return false;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        return entity != client.player || !client.options.getPerspective().isFirstPerson();
    }

    public static boolean active() {
        return instance != null && instance.enabled();
    }

    public static void configureUniforms(Map<String, GpuBuffer> uniformBuffers) {
        ShaderESP module = instance;
        GpuBuffer current = uniformBuffers.get(CONFIG_BUFFER);
        if (module == null || !module.enabled() || current == null) {
            return;
        }

        long now = System.currentTimeMillis();
        int[] colors = {
                module.resolveColor(0),
                module.resolveColor(90),
                module.resolveColor(180),
                module.resolveColor(270),
                module.resolveColor(360)
        };

        try (MemoryStack stack = MemoryStack.stackPush()) {
            Std140Builder builder = Std140Builder.onStack(stack, CONFIG_SIZE);
            for (int argb : colors) {
                builder.putVec4(
                        ((argb >>> 16) & 0xFF) / 255.0F,
                        ((argb >>> 8) & 0xFF) / 255.0F,
                        (argb & 0xFF) / 255.0F,
                        1.0F
                );
            }
            builder.putVec4(
                    module.radius.value().floatValue(),
                    module.opacity.value().floatValue(),
                    (float) ((now % 1_000_000L) / 500.0),
                    0.0F
            );
            ByteBuffer data = builder.get();

            if (current.size() != CONFIG_SIZE || (current.usage() & GpuBuffer.USAGE_COPY_DST) == 0) {
                GpuBuffer replacement = RenderSystem.getDevice().createBuffer(
                        () -> "Celestial ShaderESP config",
                        GpuBuffer.USAGE_UNIFORM | GpuBuffer.USAGE_COPY_DST,
                        data.duplicate()
                );
                uniformBuffers.put(CONFIG_BUFFER, replacement);
                current.close();
                return;
            }

            CommandEncoder encoder = RenderSystem.getDevice().createCommandEncoder();
            encoder.writeToBuffer(current.slice(), data.duplicate());
        }
    }

    private int resolveColor(int offset) {
        if (mode.is("Static")) {
            return color.argb();
        }
        return VisualColors.clientColor(offset);
    }
}
