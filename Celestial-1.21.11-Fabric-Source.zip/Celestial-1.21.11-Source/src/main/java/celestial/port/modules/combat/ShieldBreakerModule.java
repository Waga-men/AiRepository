package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.AxeItem;
import net.minecraft.item.Items;
import net.minecraft.item.consume.UseAction;
import net.minecraft.network.packet.c2s.play.HandSwingC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;

import java.util.OptionalInt;

public final class ShieldBreakerModule extends Module {
    private final BooleanSetting onlyWithAura = addSetting(new BooleanSetting(
            "only_with_aura", "Только с киллаурой", false
    ));

    public ShieldBreakerModule() {
        super("shield_breaker", "Shield Breaker",
                "Ломает щит при ударе", Category.COMBAT);
        AttackEntityCallback.EVENT.register(this::onAttackEntity);
    }

    private ActionResult onAttackEntity(
            PlayerEntity player, World world, Hand hand, Entity entity, EntityHitResult hitResult
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!enabled()
                || onlyWithAura.enabled()
                || world != client.world
                || player != client.player
                || hand != Hand.MAIN_HAND
                || !(player instanceof ClientPlayerEntity local)
                || !(entity instanceof PlayerEntity target)
                || client.interactionManager == null
                || auraEnabled()
                || AttackAuraModule.attackInProgress()
                || !usesShieldDirectly(target)) {
            return ActionResult.PASS;
        }

        attackWithAxe(client, local, target, true);
        return ActionResult.PASS;
    }

    public static void breakWithAura(
            MinecraftClient client, ClientPlayerEntity player, PlayerEntity target
    ) {
        Module raw = CelestialPortClient.MODULES.find("shield_breaker").orElse(null);
        if (!(raw instanceof ShieldBreakerModule module)
                || !module.enabled()
                || !usesShieldWithAura(target)
                || client.interactionManager == null) {
            return;
        }
        module.attackWithAxe(client, player, target, false);
    }

    private void attackWithAxe(
            MinecraftClient client,
            ClientPlayerEntity player,
            PlayerEntity target,
            boolean rawDirectAttack
    ) {
        PlayerInventory inventory = player.getInventory();
        int selected = inventory.getSelectedSlot();
        int axe = findAxe(inventory, true);
        if (axe >= 0) {
            player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(axe));
            try {
                attack(client, player, target, rawDirectAttack);
            } finally {
                player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(selected));
            }
            return;
        }

        axe = findAxe(inventory, false);
        if (axe < PlayerInventory.getHotbarSize()) {
            return;
        }

        ScreenHandler handler = player.currentScreenHandler;
        OptionalInt handlerSlot = handler.getSlotIndex(inventory, axe);
        if (handlerSlot.isEmpty()) {
            return;
        }

        boolean swapped = false;
        try {
            clickSwap(client, player, handler, handlerSlot.getAsInt(), selected);
            swapped = true;
            attack(client, player, target, rawDirectAttack);
        } finally {
            if (swapped) {
                clickSwap(client, player, handler, handlerSlot.getAsInt(), selected);
            }
        }
    }

    private static void attack(
            MinecraftClient client,
            ClientPlayerEntity player,
            PlayerEntity target,
            boolean rawDirectAttack
    ) {
        if (rawDirectAttack) {
            player.networkHandler.sendPacket(PlayerInteractEntityC2SPacket.attack(
                    target, player.isSneaking()
            ));
            player.networkHandler.sendPacket(new HandSwingC2SPacket(Hand.MAIN_HAND));
            return;
        }

        client.interactionManager.attackEntity(player, target);
        player.swingHand(Hand.MAIN_HAND);
    }

    private static void clickSwap(
            MinecraftClient client, ClientPlayerEntity player, ScreenHandler handler,
            int handlerSlot, int hotbarSlot
    ) {
        client.interactionManager.clickSlot(
                handler.syncId,
                handlerSlot,
                hotbarSlot,
                SlotActionType.SWAP,
                player
        );
    }

    private static int findAxe(PlayerInventory inventory, boolean hotbarOnly) {
        int end = hotbarOnly ? PlayerInventory.getHotbarSize() : PlayerInventory.MAIN_SIZE;
        int start = hotbarOnly ? 0 : PlayerInventory.getHotbarSize();
        for (int slot = start; slot < end; slot++) {
            if (inventory.getStack(slot).getItem() instanceof AxeItem) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static boolean usesShieldDirectly(PlayerEntity target) {
        return target.isUsingItem()
                && target.getActiveItem().isOf(Items.SHIELD)
                && hasShieldInHand(target);
    }

    private static boolean usesShieldWithAura(PlayerEntity target) {
        return target.isUsingItem()
                && target.getActiveItem().getUseAction() == UseAction.BLOCK
                && target.getItemUseTime() >= 2
                && hasShieldInHand(target);
    }

    private static boolean hasShieldInHand(PlayerEntity target) {
        return target.getMainHandStack().isOf(Items.SHIELD)
                || target.getOffHandStack().isOf(Items.SHIELD);
    }

    private static boolean auraEnabled() {
        Module aura = CelestialPortClient.MODULES.find("attack_aura").orElse(null);
        return aura != null && aura.enabled();
    }
}
