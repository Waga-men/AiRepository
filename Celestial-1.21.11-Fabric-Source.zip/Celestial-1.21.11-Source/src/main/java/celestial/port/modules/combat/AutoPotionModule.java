package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.PvpContext;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.mixin.accessor.ClientPlayerInteractionManagerSlotInvoker;
import celestial.port.mixin.accessor.InGameHudTitleAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.PotionContentsComponent;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.shape.VoxelShape;

import java.util.List;
import java.util.OptionalInt;
import java.util.Set;

public final class AutoPotionModule extends Module {
    private static final String STRENGTH = "Сила";
    private static final String SPEED = "Скорость";
    private static final String FIRE_RESISTANCE = "Защита от огня";
    private static final long REFRESH_DELAY_MILLIS = 500L;
    private static final ThreadLocal<UseRotation> USE_ROTATION = new ThreadLocal<>();

    private final MultiSelectSetting potions;
    private final BooleanSetting onlyPvp;
    private final BooleanSetting autoDisable;
    private final List<PotionRequest> requests;

    private long lastUseMillis = System.currentTimeMillis();

    private int lastUsedSlot;
    private float desiredPitch;
    private boolean attemptedUse;

    public AutoPotionModule() {
        super("auto_pot", "Auto Pot", "Автоматически кидает зелья", Category.COMBAT);
        potions = addSetting(new MultiSelectSetting("potions", "Выбор зелий",
                Set.of(STRENGTH, SPEED, FIRE_RESISTANCE),
                List.of(STRENGTH, SPEED, FIRE_RESISTANCE)));
        onlyPvp = addSetting(new BooleanSetting("only_pvp", "Только в ПВП", false));
        autoDisable = addSetting(new BooleanSetting("auto_disable", "Авто выключение", false));
        requests = List.of(
                new PotionRequest(STRENGTH, StatusEffects.STRENGTH),
                new PotionRequest(SPEED, StatusEffects.SPEED),
                new PotionRequest(FIRE_RESISTANCE, StatusEffects.FIRE_RESISTANCE)
        );
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null || !player.isAlive()) {
            return;
        }

        boolean freeCamera = CelestialPortClient.MODULES.find("free_camera")
                .filter(Module::enabled).isPresent();
        boolean canThrow = !freeCamera
                && (!onlyPvp.enabled() || PvpContext.active())
                && !hasNumericReallyWorldTitle(client)
                && hasSafeThrowFloor(client, player);

        if (canThrow && hasArmedRequest()) {
            Aim aim = collisionAim(client, player);
            desiredPitch = aim.pitch;
            throwArmedBatch(client, player, aim.yaw, desiredPitch);
        }

        if (System.currentTimeMillis() - lastUseMillis > REFRESH_DELAY_MILLIS) {
            refreshAvailability(player);
            lastUsedSlot = -2;
        }
        if (autoDisable.enabled() && attemptedUse && lastUsedSlot == -2) {
            attemptedUse = false;
            disableFromServerCorrection();
        }
    }

    private boolean hasArmedRequest() {
        for (PotionRequest request : requests) {
            if (potions.selected(request.option) && request.armed) {
                return true;
            }
        }
        return false;
    }

    private void refreshAvailability(ClientPlayerEntity player) {
        PlayerInventory inventory = player.getInventory();
        for (PotionRequest request : requests) {
            if (!potions.selected(request.option)) {
                continue;
            }
            StatusEffectInstance active = player.getStatusEffect(request.effect);
            boolean present = active != null
                    && (active.getDuration() == -1 || active.getDuration() >= 200);
            request.armed = !present && findPotion(inventory, request.effect) != -1;
        }
    }

    private void throwArmedBatch(MinecraftClient client, ClientPlayerEntity player,
                                 float yaw, float pitch) {
        PlayerInventory inventory = player.getInventory();
        int originalSelected = inventory.getSelectedSlot();
        ClientPlayerInteractionManagerSlotInvoker slotSync =
                (ClientPlayerInteractionManagerSlotInvoker) client.interactionManager;
        UseTransaction transaction = new UseTransaction();

        slotSync.celestial$syncSelectedSlot();
        lastUsedSlot = -1;
        try {
            for (PotionRequest request : requests) {
                if (!potions.selected(request.option) || !request.armed) {
                    continue;
                }
                attemptedUse = true;
                int slot = findPotion(inventory, request.effect);
                boolean used = slot >= 0 && throwFromSlot(
                        client, player, request.effect, slot, originalSelected, yaw, pitch,
                        transaction);
                int resultSlot = used ? slot : -1;
                if (lastUsedSlot == -1) {
                    lastUsedSlot = resultSlot;
                }
                if (used) {
                    request.armed = false;
                    lastUseMillis = System.currentTimeMillis();
                }
            }
        } finally {
            USE_ROTATION.remove();
            inventory.setSelectedSlot(originalSelected);
            try {
                slotSync.celestial$syncSelectedSlot();
            } finally {
                if (transaction.interacted) {
                    player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                            player.getYaw(), player.getPitch(), player.isOnGround(),
                            player.horizontalCollision));
                }
            }
        }
    }

    private static boolean throwFromSlot(MinecraftClient client, ClientPlayerEntity player,
                                         RegistryEntry<StatusEffect> effect, int inventorySlot,
                                         int originalSelected, float yaw, float pitch,
                                         UseTransaction transaction) {
        PlayerInventory inventory = player.getInventory();
        if (inventorySlot < PlayerInventory.getHotbarSize()) {
            inventory.setSelectedSlot(inventorySlot);
            if (!isMatchingPotion(inventory.getSelectedStack(), effect)) {
                return false;
            }
            transaction.interacted = true;
            interactWithRotation(client, player, yaw, pitch);
            return true;
        }

        inventory.setSelectedSlot(originalSelected);
        ScreenHandler handler = player.currentScreenHandler;
        OptionalInt clickedSlot = handler.getSlotIndex(inventory, inventorySlot);
        if (clickedSlot.isEmpty()) {
            return false;
        }

        boolean swapped = false;
        try {
            client.interactionManager.clickSlot(handler.syncId, clickedSlot.getAsInt(),
                    originalSelected, SlotActionType.SWAP, player);
            swapped = true;
            if (!isMatchingPotion(inventory.getSelectedStack(), effect)) {
                return false;
            }
            transaction.interacted = true;
            interactWithRotation(client, player, yaw, pitch);
            return true;
        } finally {
            if (swapped) {
                client.interactionManager.clickSlot(handler.syncId, clickedSlot.getAsInt(),
                        originalSelected, SlotActionType.SWAP, player);
            }
        }
    }

    private static void interactWithRotation(MinecraftClient client, ClientPlayerEntity player,
                                             float yaw, float pitch) {
        USE_ROTATION.set(new UseRotation(yaw, pitch));
        try {
            client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        } finally {
            USE_ROTATION.remove();
        }
    }

    public static boolean hasScopedUseRotation() {
        return USE_ROTATION.get() != null;
    }

    public static float scopedUseYaw() {
        UseRotation rotation = USE_ROTATION.get();
        return rotation == null ? 0.0F : rotation.yaw;
    }

    public static float scopedUsePitch() {
        UseRotation rotation = USE_ROTATION.get();
        return rotation == null ? 0.0F : rotation.pitch;
    }

    private static int findPotion(PlayerInventory inventory, RegistryEntry<StatusEffect> wanted) {
        for (int slot = 0; slot < 36; slot++) {
            if (isMatchingPotion(inventory.getStack(slot), wanted)) {
                return slot;
            }
        }
        return -1;
    }

    private static boolean isMatchingPotion(ItemStack stack, RegistryEntry<StatusEffect> wanted) {
        if (!stack.isOf(Items.SPLASH_POTION)) {
            return false;
        }
        PotionContentsComponent contents = stack.getOrDefault(
                DataComponentTypes.POTION_CONTENTS, PotionContentsComponent.DEFAULT);
        for (StatusEffectInstance effect : contents.getEffects()) {
            if (effect.getEffectType().equals(wanted)) {
                return true;
            }
        }
        return false;
    }

    private static Aim collisionAim(MinecraftClient client, ClientPlayerEntity player) {
        Vec3d eye = player.getEyePos();
        Vec3d feet = player.getEntityPos();
        Vec3d closest = null;
        double closestDistance = Double.POSITIVE_INFINITY;
        for (VoxelShape shape : client.world.getCollisions(player,
                player.getBoundingBox().expand(0.0, 0.5, 0.0))) {
            for (Box box : shape.getBoundingBoxes()) {
                Vec3d candidate = new Vec3d(
                        MathHelper.clamp(eye.x, box.minX, box.maxX),
                        MathHelper.clamp(eye.y, box.minY, box.maxY),
                        MathHelper.clamp(eye.z, box.minZ, box.maxZ));
                double distance = candidate.squaredDistanceTo(feet);
                if (distance < closestDistance) {
                    closestDistance = distance;
                    closest = candidate;
                }
            }
        }
        if (closest == null) {
            return new Aim(player.getYaw(), 90.0F);
        }

        Vec3d delta = closest.subtract(eye);
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float targetYaw = (float) Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0F;
        float targetPitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        float yaw = player.getYaw() + snapToMouseGcd(client,
                MathHelper.wrapDegrees(targetYaw - player.getYaw()));
        float pitch = MathHelper.clamp(player.getPitch() + snapToMouseGcd(client,
                MathHelper.wrapDegrees(targetPitch - player.getPitch())), -90.0F, 90.0F);
        return new Aim(yaw, pitch);
    }

    private static float snapToMouseGcd(MinecraftClient client, float delta) {
        double sensitivity = client.options.getMouseSensitivity().getValue();
        float base = (float) (sensitivity * 0.6 + 0.2);
        float gcd = base * base * base * 8.0F * 0.15F;
        return Math.round(delta / gcd) * gcd;
    }

    private static boolean hasNumericReallyWorldTitle(MinecraftClient client) {
        if (!LegacyTeleportCoordinator.isReallyWorld(client)) {
            return false;
        }
        Text title = ((InGameHudTitleAccessor) client.inGameHud).celestial$getTitle();
        if (title == null) {
            return false;
        }
        String stripped = Formatting.strip(title.getString());
        return stripped != null && stripped.matches("\\d+");
    }

    private static boolean hasSafeThrowFloor(MinecraftClient client, ClientPlayerEntity player) {
        BlockPos below = BlockPos.ofFloored(player.getX(), player.getY() - 0.5, player.getZ());
        if (!client.world.getFluidState(below).isEmpty()) {
            return false;
        }
        return client.world.getBlockCollisions(player,
                player.getBoundingBox().offset(0.0, -0.5, 0.0)).iterator().hasNext();
    }

    private static final class PotionRequest {
        private final String option;
        private final RegistryEntry<StatusEffect> effect;
        private boolean armed;

        private PotionRequest(String option, RegistryEntry<StatusEffect> effect) {
            this.option = option;
            this.effect = effect;
        }
    }

    private record Aim(float yaw, float pitch) {
    }

    private record UseRotation(float yaw, float pitch) {
    }

    private static final class UseTransaction {
        private boolean interacted;
    }
}
