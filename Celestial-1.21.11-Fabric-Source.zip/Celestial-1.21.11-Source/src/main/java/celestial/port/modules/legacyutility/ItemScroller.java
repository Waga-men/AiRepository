package celestial.port.modules.legacyutility;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.NumberSetting;
import celestial.port.mixin.accessor.HandledScreenAccessor;
import celestial.port.modules.utility.ElytraFix;
import net.fabricmc.fabric.api.client.screen.v1.ScreenEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.inventory.Inventory;
import net.minecraft.item.BlockItem;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

import java.util.Map;
import java.util.WeakHashMap;

public final class ItemScroller extends Module {
    private final NumberSetting delayMs = addSetting(new NumberSetting(
            "delay_ms", "Задержка", 30.0, 0.0, 100.0, 10.0
    ));
    private final Map<Screen, LegacyTimer> screenTimers = new WeakHashMap<>();

    public ItemScroller() {
        super("item_scroller", "Item Scroller", "Позволяет быстро лутать сундуки", Category.UTILITY);
        ScreenEvents.AFTER_INIT.register((client, screen, width, height) -> attach(screen));
    }

    public NumberSetting delayMs() {
        return delayMs;
    }

    private void attach(Screen screen) {
        if (!(screen instanceof HandledScreen<?>)) {
            return;
        }
        LegacyTimer timer = screenTimers.computeIfAbsent(screen, ignored -> new LegacyTimer());
        ScreenEvents.afterRender(screen).register((current, context, mouseX, mouseY, tickDelta) ->
                handleRenderedScreen(current, timer));
    }

    private void handleRenderedScreen(Screen screen, LegacyTimer timer) {
        if (!enabled() || !(screen instanceof HandledScreen<?> handled)) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.interactionManager == null) {
            return;
        }

        Slot hovered = ((HandledScreenAccessor) handled).celestial$getFocusedSlot();
        double delay = delayMs.value();

        if (hovered != null && timer.ready(delay)) {
            if (canQuickMove(client, screen, handled.getScreenHandler(), hovered)) {
                click(client, handled.getScreenHandler(), hovered, 0, SlotActionType.QUICK_MOVE);
            }
            timer.reset();
        }

        if (timer.ready(delay)) {
            if (canThrow(client, hovered)
                    && !ElytraFix.shouldCancelClick(
                    handled.getScreenHandler().syncId, hovered.id, SlotActionType.THROW)) {
                click(client, handled.getScreenHandler(), hovered, 1, SlotActionType.THROW);
            }
            timer.reset();
        }
    }

    private static boolean canQuickMove(
            MinecraftClient client, Screen screen, ScreenHandler handler, Slot hovered
    ) {
        if (screen instanceof GenericContainerScreen
                && !genericContainerContainsBlock(handler)) {
            return false;
        }
        if (!hovered.isEnabled() || !hovered.hasStack()
                || !client.isShiftPressed() || !leftMouseHeld(client)) {
            return false;
        }

        PlayerInventory inventory = client.player.getInventory();

        boolean playerInventoryScreen = screen instanceof InventoryScreen;
        if (hovered.id < 54 && !containsBlock(inventory, 0, PlayerInventory.MAIN_SIZE)) {
            return false;
        }
        if (playerInventoryScreen && hovered.id < 36 && !hotbarContainsEmptySlot(inventory)) {
            return false;
        }
        return !playerInventoryScreen || hovered.id <= 35
                || containsBlock(inventory, PlayerInventory.getHotbarSize(), PlayerInventory.MAIN_SIZE);
    }

    private static boolean canThrow(MinecraftClient client, Slot hovered) {
        return hovered != null
                && hovered.isEnabled()
                && hovered.hasStack()
                && (client.isShiftPressed() || client.isCtrlPressed())
                && client.options.dropKey.isPressed();
    }

    private static boolean genericContainerContainsBlock(ScreenHandler handler) {
        if (!(handler instanceof net.minecraft.screen.GenericContainerScreenHandler genericHandler)) {
            return false;
        }
        Inventory container = genericHandler.getInventory();
        for (int index = 0; index < container.size(); index++) {
            if (container.getStack(index).getItem() instanceof BlockItem) {
                return true;
            }
        }
        return false;
    }

    private static boolean containsBlock(PlayerInventory inventory, int start, int end) {
        int limit = Math.min(end, inventory.getMainStacks().size());
        for (int index = Math.max(0, start); index < limit; index++) {
            if (inventory.getStack(index).getItem() instanceof BlockItem) {
                return true;
            }
        }
        return false;
    }

    private static boolean hotbarContainsEmptySlot(PlayerInventory inventory) {
        int limit = Math.min(PlayerInventory.getHotbarSize(), inventory.getMainStacks().size());
        for (int index = 0; index < limit; index++) {
            if (inventory.getStack(index).isEmpty()) {
                return true;
            }
        }
        return false;
    }

    private static boolean leftMouseHeld(MinecraftClient client) {
        return GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT)
                == GLFW.GLFW_PRESS;
    }

    private static void click(
            MinecraftClient client, ScreenHandler handler, Slot slot, int button, SlotActionType action
    ) {
        client.interactionManager.clickSlot(handler.syncId, slot.id, button, action, client.player);
    }

    private static final class LegacyTimer {
        private long resetAt = System.currentTimeMillis();

        private boolean ready(double delay) {
            return delay == 0.0 || System.currentTimeMillis() - resetAt > delay;
        }

        private void reset() {
            resetAt = System.currentTimeMillis();
        }
    }
}
