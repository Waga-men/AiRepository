package celestial.port.modules.legacyutility;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.client.ui.ClientFeedback;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.modules.render.ClickGuiModule;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.network.packet.c2s.play.CloseHandledScreenC2SPacket;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class RWHelper extends Module {
    private static final String SECRET_TRADER = "Тайный торговец";
    private static final String AIR_DROP = "Аир дроп";
    private static final String TALISMAN = "Талисман";
    private static final String SCROOGE = "Скрудж";
    private static final String TRADER_MESSAGE = "Появился тайный торговец:";
    private static final ZoneId MOSCOW = ZoneId.of("Europe/Moscow");
    private static final StyleSpriteSource MONTSERRAT = new StyleSpriteSource.Font(
            Identifier.of("celestial", "montserrat"));
    private static final List<Schedule> SCHEDULES = List.of(
            new Schedule(SECRET_TRADER, new int[]{240, 300, 480, 660, 840, 1020, 1200, 1380}),
            new Schedule(AIR_DROP, new int[]{540, 660, 780, 900, 1020, 1140, 1260, 1380, 1500}),
            new Schedule(TALISMAN, new int[]{1170}),
            new Schedule(SCROOGE, new int[]{930})
    );
    private static RWHelper instance;

    private final MultiSelectSetting graphics = addSetting(new MultiSelectSetting(
            "graphics", "Графики",
            List.of(SECRET_TRADER, AIR_DROP, TALISMAN, SCROOGE),
            List.of(SECRET_TRADER, AIR_DROP, TALISMAN, SCROOGE)
    ));
    private final BooleanSetting closeMenu = addSetting(new BooleanSetting(
            "close_menu", "Закрытие меню", true
    ));
    private final BooleanSetting notifyTrader = addSetting(new BooleanSetting(
            "notify_trader", "Писать о торговце", true
    ));
    private final BooleanSetting snowKickFix = addSetting(new BooleanSetting(
            "snow_kick_fix", "Фикс кика на снегу", true
    ));
    private final BooleanSetting dragonFly = addSetting(new BooleanSetting(
            "dragon_fly", "Драгон флай", true
    ));

    private ClientWorld observedWorld;
    private boolean onSnowTrap;
    private boolean wasDragonFlying;
    private String lastMessage = "";
    private long lastMessageAt;

    public RWHelper() {
        super("rw_helper", "RW Helper",
                "Вспомогательная функция для ReallyWorld", Category.UTILITY);
        instance = this;
        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) onMessage(message);
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, parameters, receivedAt) ->
                onMessage(message));
    }

    public MultiSelectSetting graphics() {
        return graphics;
    }

    public BooleanSetting closeMenu() {
        return closeMenu;
    }

    public BooleanSetting notifyTrader() {
        return notifyTrader;
    }

    public BooleanSetting snowKickFix() {
        return snowKickFix;
    }

    public BooleanSetting dragonFly() {
        return dragonFly;
    }

    public boolean hasScheduleGraphics() {
        return enabled() && !graphics.value().isEmpty();
    }

    public static boolean onOpenScreen(OpenScreenS2CPacket packet) {
        RWHelper module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.closeMenu.enabled() || !LegacyTeleportCoordinator.isReallyWorld(client)
                || !packet.getName().getString().equals("Меню")
                || client.getNetworkHandler() == null) {
            return false;
        }
        client.getNetworkHandler().sendPacket(new CloseHandledScreenC2SPacket(packet.getSyncId()));
        return true;
    }

    private void onMessage(Text message) {
        if (!enabled() || !notifyTrader.enabled()) return;
        String plain = message.getString();
        if (!plain.contains(TRADER_MESSAGE)) return;
        long now = System.nanoTime();
        synchronized (this) {
            if (plain.equals(lastMessage) && now - lastMessageAt < 500_000_000L) return;
            lastMessage = plain;
            lastMessageAt = now;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (!client.isWindowFocused()) {
            ClientFeedback.info("ReallyWorldHelper",
                    "Появился тайный торговец!", 5);
        }
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != observedWorld) {
            observedWorld = client.world;
            onSnowTrap = false;
            wasDragonFlying = false;
        }
        if (client.player == null || client.world == null) return;

        if (snowKickFix.enabled()) updateSnowFix(client);
        else onSnowTrap = false;

        boolean flying = dragonFly.enabled() && client.player.getAbilities().flying;
        if (flying) {
            applyDragonFlight(client);
        } else if (wasDragonFlying) {
            Vec3d velocity = client.player.getVelocity();
            client.player.setVelocity(velocity.x, 0.0, velocity.z);
        }
        wasDragonFlying = flying;
    }

    private void updateSnowFix(MinecraftClient client) {
        Box below = client.player.getBoundingBox().offset(0.0, -1.0, 0.0);
        boolean soulSand = false;
        boolean snowLayer = false;
        for (BlockPos pos : BlockPos.iterate(below)) {
            BlockState state = client.world.getBlockState(pos);
            soulSand |= state.isOf(Blocks.SOUL_SAND);
            snowLayer |= state.isOf(Blocks.SNOW);
            if (soulSand && snowLayer) break;
        }
        onSnowTrap = soulSand && snowLayer;
        if (!onSnowTrap) return;

        client.options.jumpKey.setPressed(true);
        boolean collisionBelow = !client.world.isSpaceEmpty(client.player, below);
        boolean clearAbove = client.world.isSpaceEmpty(
                client.player, client.player.getBoundingBox().offset(0.0, 0.1, 0.0));
        Vec2f movement = client.player.input == null
                ? Vec2f.ZERO : client.player.input.getMovementInput();
        if (collisionBelow && clearAbove && (movement.x != 0.0f || movement.y != 0.0f)) {
            client.player.setOnGround(true);
            client.player.fallDistance = 0.0f;
        }
    }

    private void applyDragonFlight(MinecraftClient client) {
        Vec2f movement = client.player.input == null
                ? Vec2f.ZERO : client.player.input.getMovementInput();
        float strafe = movement.x;
        float forward = movement.y;
        float yaw = client.player.getYaw();
        if (forward != 0.0f) {
            if (strafe > 0.0f) yaw += forward > 0.0f ? -45.0f : 45.0f;
            else if (strafe < 0.0f) yaw += forward > 0.0f ? 45.0f : -45.0f;
            strafe = 0.0f;
            forward = forward > 0.0f ? 1.0f : -1.0f;
        }
        double cosine = Math.cos(Math.toRadians(yaw + 90.0f));
        double sine = Math.sin(Math.toRadians(yaw + 90.0f));
        double x = forward * 1.15 * cosine + strafe * 1.15 * sine;
        double z = forward * 1.15 * sine - strafe * 1.15 * cosine;
        double y = client.options.jumpKey.isPressed() ? 1.0
                : client.options.sneakKey.isPressed() ? -1.0 : 0.0;
        client.player.setVelocity(x, y, z);
    }

    public ScheduleBounds renderSchedules(DrawContext context, int requestedX, int requestedY) {
        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer renderer = client.textRenderer;
        List<Schedule> visible = new ArrayList<>(SCHEDULES.stream()
                .filter(schedule -> graphics.selected(schedule.label)).toList());
        visible.sort(Comparator.comparingInt((Schedule schedule) ->
                renderer.getWidth(fontText(schedule.label))).reversed());
        if (visible.isEmpty()) return new ScheduleBounds(requestedX, requestedY, 0, 0);

        int width = Math.max(100, visible.stream().mapToInt(schedule ->
                renderer.getWidth(fontText(schedule.label)) + 60).max().orElse(100));
        int height = Math.max(27, visible.size() * 10 + 15);
        int x = Math.max(4, Math.min(requestedX,
                context.getScaledWindowWidth() - width - 1));
        int y = Math.max(6, Math.min(requestedY,
                context.getScaledWindowHeight() - height - 3));
        drawLegacyFrame(context, x, y, width, height);

        String title = "Schedules";
        drawFont(context, renderer, title,
                x + width / 2 - renderer.getWidth(fontText(title)) / 2 - 1,
                y + 3, 0xFFEBEBEB);
        ZonedDateTime now = ZonedDateTime.now(MOSCOW);
        int rowY = y + 15;
        for (Schedule schedule : visible) {
            String countdown = countdown(schedule.minutes, now);
            drawFont(context, renderer, schedule.label, x + 3, rowY, 0xFFEBEBEB);
            drawFont(context, renderer, countdown,
                    x + width - renderer.getWidth(fontText(countdown)) - 7,
                    rowY, 0xFFEBEBEB);
            rowY += 10;
        }
        return new ScheduleBounds(x, y, width, height);
    }

    private static String countdown(int[] schedule, ZonedDateTime now) {
        int current = now.getHour() * 60 + now.getMinute();
        int remaining = schedule[0] + 1440 - current;
        for (int minute : schedule) {
            if (minute >= current) {
                remaining = minute - current;
                break;
            }
        }
        int hours = remaining / 60;
        int minutes = remaining % 60;
        int seconds = 59 - now.getSecond();
        if (minutes > 0) minutes--;
        return hours + "h " + minutes + "m " + seconds + "s";
    }

    private static void drawLegacyFrame(
            DrawContext context, int x, int y, int width, int height
    ) {
        int first = themeColor(0);
        int second = themeColor(90);
        int third = themeColor(180);
        int fourth = themeColor(270);
        fillFourCornerRounded(context, x - 4, y - 6, width + 4, height + 9, 3,
                first, second, third, fourth);
        fillRounded(context, x - 3, y - 4, width + 2, height + 6, 3, 0xFF0A0A0A);
        fillFourCornerRounded(context, x - 2, y - 3, width, 2, 1,
                second, fourth, fourth, second);
    }

    private static int themeColor(int offset) {
        int base = CelestialPortClient.MODULES.find("click_gui")
                .filter(ClickGuiModule.class::isInstance)
                .map(ClickGuiModule.class::cast)
                .map(ClickGuiModule::primaryColor)
                .orElse(0xFFBF68FF);
        if (offset == 0) return base;
        float amount = offset / 360.0f;
        int red = (base >>> 16) & 0xFF;
        int green = (base >>> 8) & 0xFF;
        int blue = base & 0xFF;
        int rotated = java.awt.Color.HSBtoRGB(
                (java.awt.Color.RGBtoHSB(red, green, blue, null)[0] + amount) % 1.0f,
                0.72f, 1.0f);
        return 0xFF000000 | rotated & 0xFFFFFF;
    }

    private static Text fontText(String text) {
        return Text.literal(text).styled(style -> style.withFont(MONTSERRAT));
    }

    private static void drawFont(
            DrawContext context, TextRenderer renderer, String text, int x, int y, int color
    ) {
        context.drawText(renderer, fontText(text), x, y, color, false);
    }

    private static void fillRounded(
            DrawContext context, int x, int y, int width, int height, int radius, int color
    ) {
        int effective = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
        for (int line = 0; line < height; line++) {
            int inset = 0;
            if (line < effective) {
                double delta = effective - line - 0.5;
                inset = (int) Math.ceil(effective
                        - Math.sqrt(effective * effective - delta * delta));
            } else if (line >= height - effective) {
                double delta = line - (height - effective) + 0.5;
                inset = (int) Math.ceil(effective
                        - Math.sqrt(effective * effective - delta * delta));
            }
            context.fill(x + inset, y + line, x + width - inset, y + line + 1, color);
        }
    }

    private static void fillFourCornerRounded(
            DrawContext context, int x, int y, int width, int height, int radius,
            int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        int effective = Math.max(0, Math.min(radius, Math.min(width, height) / 2));
        int segments = Math.min(16, Math.max(1, width));
        for (int line = 0; line < height; line++) {
            int inset = 0;
            if (line < effective) {
                double delta = effective - line - 0.5;
                inset = (int) Math.ceil(effective
                        - Math.sqrt(effective * effective - delta * delta));
            } else if (line >= height - effective) {
                double delta = line - (height - effective) + 0.5;
                inset = (int) Math.ceil(effective
                        - Math.sqrt(effective * effective - delta * delta));
            }
            int start = x + inset;
            int end = x + width - inset;
            float vertical = height <= 1 ? 0.0f : line / (float) (height - 1);
            for (int segment = 0; segment < segments; segment++) {
                int segmentStart = start + (end - start) * segment / segments;
                int segmentEnd = start + (end - start) * (segment + 1) / segments;
                if (segmentEnd <= segmentStart) continue;
                float horizontal = ((segmentStart + segmentEnd) * 0.5f - x)
                        / Math.max(1.0f, width - 1.0f);
                int top = blend(topLeft, topRight, horizontal);
                int bottom = blend(bottomLeft, bottomRight, horizontal);
                context.fill(segmentStart, y + line, segmentEnd, y + line + 1,
                        blend(top, bottom, vertical));
            }
        }
    }

    private static int blend(int first, int second, float amount) {
        float value = Math.max(0.0f, Math.min(1.0f, amount));
        int alpha = Math.round(((first >>> 24) & 0xFF) * (1.0f - value)
                + ((second >>> 24) & 0xFF) * value);
        int red = Math.round(((first >>> 16) & 0xFF) * (1.0f - value)
                + ((second >>> 16) & 0xFF) * value);
        int green = Math.round(((first >>> 8) & 0xFF) * (1.0f - value)
                + ((second >>> 8) & 0xFF) * value);
        int blue = Math.round((first & 0xFF) * (1.0f - value)
                + (second & 0xFF) * value);
        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    private static RWHelper active() {
        RWHelper module = instance;
        return module != null && module.enabled() ? module : null;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        onSnowTrap = false;
    }

    @Override
    protected void onDisable() {
        observedWorld = null;
        onSnowTrap = false;
        wasDragonFlying = false;
        lastMessage = "";
        lastMessageAt = 0L;
    }

    private record Schedule(String label, int[] minutes) {
    }

    public record ScheduleBounds(int x, int y, int width, int height) {
    }
}
