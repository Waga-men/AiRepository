package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class WaterSpeed extends Module {
    private final BooleanSetting onlyWithPotion;
    private final NumberSetting speed;
    private final BooleanSetting reallyWorldBypass;

    private ClientPlayerEntity observedPlayer;
    private boolean movingInFluid;
    private int groundDelay;
    private int surfaceTicks;
    private double ramp;

    public WaterSpeed() {
        super("water_speed", "Water Speed",
                "Горизонтально и вертикально ускоряет вас в воде", Category.MOVEMENT);
        onlyWithPotion = addSetting(new BooleanSetting(
                "only_with_potion", "Только с зельем", true));
        reallyWorldBypass = new BooleanSetting(
                "really_world_bypass", "Обход Really World", false);
        speed = addSetting(new NumberSetting(
                "speed", "Скорость", 0.6, 0.1, 1.0, 0.01)
                .visibleWhen(() -> !reallyWorldBypass.enabled()));
        addSetting(reallyWorldBypass);
    }

    public boolean movingInFluid() {
        return enabled() && movingInFluid;
    }

    public boolean allowsServerCorrection(ClientPlayerEntity player) {
        return !onlyWithPotion.enabled() || player.hasStatusEffect(StatusEffects.SPEED);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = MovementSupport.playablePlayer(client);
        if (player != observedPlayer) {
            reset(player);
        }
        if (player == null || player.hasVehicle()) {
            return;
        }
        if (!requirementsMet(player)) {
            movingInFluid = false;
            return;
        }

        boolean intersectsFluid = player.isTouchingWater() || player.isInLava();
        if (!intersectsFluid) {
            movingInFluid = false;
            return;
        }
        movingInFluid = true;

        Vec3d velocity = player.getVelocity();
        if (client.options.jumpKey.isPressed()) {
            double y = reallyWorldBypass.enabled() ? 0.13 : 0.19;
            player.setVelocity(velocity.x, y, velocity.z);
            velocity = player.getVelocity();
        } else if (client.options.sneakKey.isPressed()) {
            double y = reallyWorldBypass.enabled() ? -0.19 : -0.4;
            player.setVelocity(velocity.x, y, velocity.z);
            velocity = player.getVelocity();
        }

        if (reallyWorldBypass.enabled()) {
            if (player.horizontalCollision) {
                groundDelay = 7;
            } else if (groundDelay > 0) {
                groundDelay--;
                return;
            }
        }

        double target = reallyWorldBypass.enabled() ? 0.35 : speed.value();
        if (reallyWorldBypass.enabled()) {
            target *= surfaceMultiplier(player);
        }
        Vec3d direction = MovementSupport.legacyInputDirection(player);
        if (!MovementSupport.hasDirection(direction) || player.horizontalCollision) {
            ramp = 0.0;
            return;
        }
        if (reallyWorldBypass.enabled()) {
            ramp = Math.min(100.0, ramp + 15.0);
            target = (player.age % 2 == 0 ? target : target - 0.04) * ramp / 100.0;
        }
        MovementSupport.setHorizontalVelocity(player, direction, Math.max(0.0, target));
    }

    private double surfaceMultiplier(ClientPlayerEntity player) {
        boolean fluidAbove = intersectsFluid(player.getBoundingBox().offset(0.0, 0.8, 0.0), player);
        if (fluidAbove) {
            surfaceTicks++;
            if (surfaceTicks <= 3) {
                return 1.0;
            }
        } else {
            surfaceTicks = 0;
            if (player.isOnGround()) {
                return 0.0;
            }
        }
        return player.isOnGround() ? 1.165 : 1.2;
    }

    private boolean requirementsMet(ClientPlayerEntity player) {
        if (CelestialPortClient.MODULES.find("jesus").filter(Module::enabled).isPresent()) {
            return false;
        }
        if (!onlyWithPotion.enabled()) {
            return true;
        }
        StatusEffectInstance swiftness = player.getStatusEffect(StatusEffects.SPEED);
        if (swiftness == null || swiftness.getAmplifier() < 1) {
            return false;
        }
        var registry = player.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        return EnchantmentHelper.getLevel(registry.getOrThrow(Enchantments.DEPTH_STRIDER),
                player.getEquippedStack(EquipmentSlot.FEET)) > 0;
    }

    private boolean intersectsFluid(Box box, ClientPlayerEntity player) {
        return player.getEntityWorld().containsFluid(box);
    }

    @Override
    protected void onDisable() {
        reset(null);
    }

    private void reset(ClientPlayerEntity player) {
        observedPlayer = player;
        movingInFluid = false;
        groundDelay = 0;
        surfaceTicks = 0;
        ramp = 0.0;
    }
}
