package celestial.port.modules.movement;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

public final class DamageSpeed extends Module {
    private static DamageSpeed instance;
    private static final double LEGACY_DAMAGE_SPEED = 9.0 / 24.5;
    private static final long DAMAGE_WINDOW_MS = 1_400L;

    private final BooleanSetting onlyOnDamage = addSetting(new BooleanSetting(
            "only_on_damage", "Только при дамаге", true
    ));
    private final BooleanSetting superSpeed = addSetting(new BooleanSetting(
            "super_speed", "Супер скорость", false
    ));
    private final BooleanSetting autoDisable = addSetting(new BooleanSetting(
            "auto_disable", "Авто выключение", true
    ));

    private ClientPlayerEntity observedPlayer;
    private long damageStartedAt;
    private boolean excludedDamage;

    public DamageSpeed() {
        super("damage_speed", "Damage Speed",
                "Ускоряет вас при ударе", Category.MOVEMENT);
        instance = this;
    }

    public boolean damageActive() {
        return damageStartedAt != 0L
                && System.currentTimeMillis() - damageStartedAt <= DAMAGE_WINDOW_MS;
    }

    public static void onEntityStatus(EntityStatusS2CPacket packet) {
        DamageSpeed module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || client.player == null || client.world == null
                || packet.getStatus() != 2 || packet.getEntity(client.world) != client.player) {
            return;
        }
        boolean potionDamage = client.player.hasStatusEffect(StatusEffects.POISON)
                || client.player.hasStatusEffect(StatusEffects.WITHER)
                || client.player.hasStatusEffect(StatusEffects.INSTANT_DAMAGE);
        if (!module.excludedDamage && !potionDamage) {
            module.damageStartedAt = System.currentTimeMillis();
        } else {
            module.damageStartedAt = 0L;
        }
        module.excludedDamage = false;
    }

    public static void onEntityDamage(EntityDamageS2CPacket packet) {
        DamageSpeed module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || client.player == null || client.world == null
                || packet.entityId() != client.player.getId()) {
            return;
        }
        DamageSource source = packet.createDamageSource(client.world);
        module.excludedDamage = source.isIn(DamageTypeTags.IS_FALL)
                || source.isIn(DamageTypeTags.IS_PROJECTILE)
                || source.isIn(DamageTypeTags.IS_EXPLOSION)
                || source.isOf(DamageTypes.ENDER_PEARL);
    }

    public static void onExplosion() {
        DamageSpeed module = active();
        if (module != null) {
            module.excludedDamage = true;
        }
    }

    private static DamageSpeed active() {
        return instance != null && instance.enabled() ? instance : null;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        damageStartedAt = 0L;
        excludedDamage = false;
    }

    @Override
    protected void onEnable() {
        reset(MinecraftClient.getInstance().player);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = MovementSupport.playablePlayer(client);
        if (player != observedPlayer) {
            reset(player);
        }
        if (player == null) {
            return;
        }

        long elapsed = damageStartedAt == 0L ? Long.MAX_VALUE
                : System.currentTimeMillis() - damageStartedAt;
        if (damageStartedAt != 0L && elapsed > DAMAGE_WINDOW_MS) {
            if (autoDisable.enabled()) {
                setEnabled(false);
                return;
            }
            damageStartedAt = 0L;
        }
        if (onlyOnDamage.enabled() && !damageActive()) {
            return;
        }

        Vec3d direction = MovementSupport.legacyInputDirection(player);
        if (!MovementSupport.hasDirection(direction)
                || !player.isOnGround()
                || client.options.jumpKey.isPressed()
                || player.isClimbing()
                || player.isTouchingWater()
                || player.isInLava()
                || projectedPathIsClear(player)) {
            return;
        }

        player.addVelocity(direction.x * LEGACY_DAMAGE_SPEED, 0.0,
                direction.z * LEGACY_DAMAGE_SPEED);
        if (superSpeed.enabled()) {
            player.setOnGround(false);
        }

        double speed = player.getVelocity().horizontalLength();
        MovementSupport.setHorizontalVelocity(player, direction, speed);
    }

    private boolean projectedPathIsClear(ClientPlayerEntity player) {
        Vec3d velocity = player.getVelocity();
        Box projected = player.getBoundingBox().offset(0.0, velocity.y, 0.0);
        return !player.getEntityWorld().getBlockCollisions(player, projected).iterator().hasNext();
    }

    @Override
    protected void onDisable() {
        reset(null);
    }

    private void reset(ClientPlayerEntity player) {
        observedPlayer = player;
        damageStartedAt = 0L;
        excludedDamage = false;
    }
}
