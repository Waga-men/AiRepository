package celestial.port.modules.visual;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.model.Dilation;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerSkinType;
import net.minecraft.util.Identifier;

import java.util.List;

public final class CustomModel extends Module {
    public static final Identifier FINN_TEXTURE = Identifier.of("celestial", "custommodels/finn.png");

    private static volatile CustomModel instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", "Finn", List.of("Finn", "Mini")
    ));
    private final BooleanSetting onlySelfAndFriends = addSetting(new BooleanSetting(
            "only_self_and_friends", "Только я и друзья", true
    ));

    private final PlayerEntityModel finnModel = createFinnModel();
    private final PlayerEntityModel miniWideModel = createMiniModel(false);
    private final PlayerEntityModel miniSlimModel = createMiniModel(true);

    public CustomModel() {
        super("custom_model", "Custom Model", "Изменяет модель персонажа", Category.RENDER);
        instance = this;
    }

    public ModeSetting mode() {
        return mode;
    }

    public BooleanSetting onlySelfAndFriends() {
        return onlySelfAndFriends;
    }

    public static boolean applies(PlayerEntityRenderState state) {
        CustomModel module = instance;
        if (module == null || !module.enabled()) {
            return false;
        }
        if (!module.onlySelfAndFriends.enabled()) {
            return true;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && state.id == client.player.getId()) {
            return true;
        }
        if (client.world == null) {
            return false;
        }
        Entity entity = client.world.getEntityById(state.id);
        return entity instanceof PlayerEntity player && FriendManager.isFriend(player);
    }

    public static boolean isFinn(PlayerEntityRenderState state) {
        CustomModel module = instance;
        return applies(state) && module != null && module.mode.is("Finn");
    }

    public static boolean isMini(PlayerEntityRenderState state) {
        CustomModel module = instance;
        return applies(state) && module != null && module.mode.is("Mini");
    }

    public static PlayerEntityModel replacement(PlayerEntityRenderState state) {
        CustomModel module = instance;
        if (!applies(state) || module == null) {
            return null;
        }
        if (module.mode.is("Finn")) {
            return module.finnModel;
        }
        boolean slim = state.skinTextures != null && state.skinTextures.model() == PlayerSkinType.SLIM;
        return slim ? module.miniSlimModel : module.miniWideModel;
    }

    private static PlayerEntityModel createMiniModel(boolean slim) {
        ModelData data = PlayerEntityModel.getTexturedModelData(Dilation.NONE, slim)
                .transform(BipedEntityModel.BABY_TRANSFORMER);
        ModelPartData head = data.getRoot().getChild("head");
        head.addChild("hat", head.getChild("hat")
                .applyTransformer(transform -> transform.scaled(2.0F / 3.0F)));
        return new MiniPlayerEntityModel(data.getRoot().createPart(64, 64), slim);
    }

    private static PlayerEntityModel createFinnModel() {
        ModelData data = PlayerEntityModel.getTexturedModelData(Dilation.NONE, false);
        ModelPartData root = data.getRoot();

        ModelPartData head = root.addChild("head", ModelPartBuilder.create().uv(0, 0)
                .cuboid(-4.0F, -8.0F, -4.0F, 8.0F, 8.0F, 8.0F), ModelTransform.NONE);
        root.addChild("hat", ModelPartBuilder.create(), ModelTransform.NONE);

        ModelPartData body = root.addChild("body", ModelPartBuilder.create().uv(16, 16)
                .cuboid(-4.0F, 0.0F, -2.0F, 8.0F, 12.0F, 4.0F), ModelTransform.NONE);
        body.addChild("jacket", ModelPartBuilder.create(), ModelTransform.NONE);

        ModelPartData rightArm = root.addChild("right_arm", ModelPartBuilder.create().uv(40, 16)
                .cuboid(-3.0F, -2.0F, -2.0F, 2.0F, 12.0F, 2.0F),
                ModelTransform.origin(-3.0F, 2.0F, 1.0F));
        rightArm.addChild("right_sleeve", ModelPartBuilder.create(), ModelTransform.NONE);

        ModelPartData leftArm = root.addChild("left_arm", ModelPartBuilder.create().uv(40, 16)
                .cuboid(-1.0F, -2.0F, -2.0F, 2.0F, 12.0F, 2.0F),
                ModelTransform.origin(5.0F, 2.0F, 1.0F));
        leftArm.addChild("left_sleeve", ModelPartBuilder.create(), ModelTransform.NONE);

        ModelPartData rightLeg = root.addChild("right_leg", ModelPartBuilder.create().uv(0, 16)
                .cuboid(-2.0F, 0.0F, -2.0F, 2.0F, 12.0F, 2.0F),
                ModelTransform.origin(-2.0F, 12.0F, 1.0F));
        rightLeg.addChild("right_pants", ModelPartBuilder.create(), ModelTransform.NONE);

        ModelPartData leftLeg = root.addChild("left_leg", ModelPartBuilder.create().uv(0, 16)
                .cuboid(-2.0F, 0.0F, -2.0F, 2.0F, 12.0F, 2.0F),
                ModelTransform.origin(4.0F, 12.0F, 1.0F));
        leftLeg.addChild("left_pants", ModelPartBuilder.create(), ModelTransform.NONE);

        detail(root, "finn_back", 48, 0, 0, 0, 0, 8, 8, 3, -4, 0, 2);
        detail(root, "finn_back_inner", 33, 0, 0, 0, 0, 6, 6, 1, -3, 1, 5);
        detail(root, "finn_right_upper", 49, 17, 0, 0, 0, 1, 1, 2, 4, -1, -1);
        detail(root, "finn_right_middle", 49, 21, 0, 0, 0, 1, 1, 1, 4, 0, 1);
        detail(root, "finn_left_upper", 49, 24, 0, 0, 0, 1, 1, 2, -5, -1, -1);
        detail(root, "finn_right_lower", 49, 28, 0, 0, 0, 1, 1, 1, 4, 1, 2);
        detail(root, "finn_left_middle", 57, 17, 0, 0, 0, 1, 1, 1, -5, 0, 1);
        detail(root, "finn_left_lower", 57, 21, 0, 0, 0, 1, 1, 1, -5, 1, 2);
        detail(root, "finn_left_side", 57, 24, 0, 0, 0, 1, 6, 1, -5, 0, -2);
        detail(root, "finn_left_foot", 63, 17, 0, 0, 0, 1, 1, 2, -5, 6, 1);
        detail(root, "finn_right_foot", 63, 21, 0, 0, 0, 1, 1, 2, 4, 6, 1);
        detail(root, "finn_right_side", 63, 25, 0, 0, 0, 1, 6, 1, 4, 0, -2);

        head.addChild("finn_right_ear", ModelPartBuilder.create().uv(57, 12)
                .cuboid(2.0F, -10.0F, -1.0F, 2.0F, 2.0F, 2.0F), ModelTransform.NONE);
        head.addChild("finn_left_ear", ModelPartBuilder.create().uv(48, 12)
                .cuboid(-4.0F, -10.0F, -1.0F, 2.0F, 2.0F, 2.0F), ModelTransform.NONE);

        ModelPart baked = root.createPart(128, 128);
        return new FinnPlayerEntityModel(baked);
    }

    private static void detail(ModelPartData root, String name, int u, int v,
                               float x, float y, float z, float width, float height, float depth,
                               float originX, float originY, float originZ) {
        root.addChild(name, ModelPartBuilder.create().uv(u, v)
                        .cuboid(x, y, z, width, height, depth),
                ModelTransform.origin(originX, originY, originZ));
    }

    private static final class FinnPlayerEntityModel extends PlayerEntityModel {
        private final PlayerEntityModel animationModel;

        private FinnPlayerEntityModel(ModelPart root) {
            super(root, false);
            ModelData data = PlayerEntityModel.getTexturedModelData(Dilation.NONE, false);
            animationModel = new PlayerEntityModel(data.getRoot().createPart(64, 64), false);
        }

        @Override
        public void setAngles(PlayerEntityRenderState state) {
            animationModel.setAngles(state);
            copyAngles(animationModel.head, head);
            copyAngles(animationModel.rightArm, rightArm);
            copyAngles(animationModel.leftArm, leftArm);
            copyAngles(animationModel.rightLeg, rightLeg);
            copyAngles(animationModel.leftLeg, leftLeg);
        }

        private static void copyAngles(ModelPart source, ModelPart target) {
            target.pitch = source.pitch;
            target.yaw = source.yaw;
            target.roll = source.roll;
        }
    }

    private static final class MiniPlayerEntityModel extends PlayerEntityModel {
        private MiniPlayerEntityModel(ModelPart root, boolean slim) {
            super(root, slim);
        }

        @Override
        public void setAngles(PlayerEntityRenderState state) {
            float animationProgress = state.limbSwingAnimationProgress;
            state.limbSwingAnimationProgress = animationProgress * 3.0F;
            try {
                super.setAngles(state);
            } finally {
                state.limbSwingAnimationProgress = animationProgress;
            }
        }
    }
}
