package celestial.port.modules.combat;

import celestial.port.client.audio.WavPlayer;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.event.SuccessfulAttackCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;

import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public final class HitSoundsModule extends Module {
    private static final String MOANS = "РЎС‚РѕРЅС‹";
    private static final String MARKER = "РњР°СЂРєРµСЂ";
    private static HitSoundsModule instance;

    static {
        SuccessfulAttackCallback.EVENT.register(HitSoundsModule::onSuccessfulAttack);
    }

    private final ModeSetting mode = addSetting(new ModeSetting("mode", "Р РµР¶РёРј", MOANS,
            List.of(MOANS, MARKER, "UwU", "Skeet")));
    private final NumberSetting volume = addSetting(new NumberSetting(
            "volume", "Р“СЂРѕРјРєРѕСЃС‚СЊ", 0.3, 0.1, 1.0, 0.1));

    public HitSoundsModule() {
        super("hit_sounds", "Hit Sounds", "Р’РѕСЃРїСЂРѕРёР·РІРѕРґРёС‚ Р·РІСѓРєРё РїСЂРё СѓРґР°СЂРµ", Category.COMBAT);
        instance = this;
    }

    @Deprecated
    public static void onAttackAttempt(Entity target) {

    }

    @Deprecated
    public static void onEntityDamage(EntityDamageS2CPacket packet) {

    }

    @Deprecated
    public static void onEntityStatus(EntityStatusS2CPacket packet) {

    }

    public static void onSuccessfulAttack(PlayerEntity attacker, Entity target) {
        HitSoundsModule sounds = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (sounds == null || !sounds.enabled() || attacker != client.player
                || !(target instanceof LivingEntity)) {
            return;
        }
        WavPlayer.play(sounds.resource(), sounds.volume.value().floatValue());
    }

    private String resource() {
        if (mode.is(MARKER)) return "/assets/celestial/sounds/hitsounds/marker.wav";
        if (mode.is("UwU")) return "/assets/celestial/sounds/hitsounds/uwu.wav";
        if (mode.is("Skeet")) return "/assets/celestial/sounds/hitsounds/skeet.wav";
        int sample = ThreadLocalRandom.current().nextInt(1, 5);
        return "/assets/celestial/sounds/hitsounds/moan" + sample + ".wav";
    }
}
