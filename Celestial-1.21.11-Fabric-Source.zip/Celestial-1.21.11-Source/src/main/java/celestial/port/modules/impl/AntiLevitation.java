package celestial.port.modules.impl;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ModeSetting;
import celestial.port.modules.player.Disabler;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.item.consume.UseAction;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;

import java.util.List;

public final class AntiLevitation extends Module {
    private static final String CONTROL = "\u041a\u043e\u043d\u0442\u0440\u043e\u043b\u044c";
    private static final String REMOVE = "\u0423\u0434\u0430\u043b\u0435\u043d\u0438\u0435 \u044d\u0444\u0444\u0435\u043a\u0442\u0430";
    private static final double LEGACY_BASE_SPEED = 0.2873;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "\u0420\u0435\u0436\u0438\u043c", CONTROL, List.of(CONTROL, REMOVE)
    ));
    private float acceleration;
    private boolean activeSnapshot;
    private ClientPlayerEntity snapshotPlayer;
    private boolean movementPacketContext;
    private ClientPlayerEntity movementPacketPlayer;
    private double movementPacketYOffset;

    public AntiLevitation() {
        super("anti_levitation", "Anti Levitation",
                "\u0423\u0431\u0438\u0440\u0430\u0435\u0442 \u044d\u0444\u0444\u0435\u043a\u0442 \u043b\u0435\u0432\u0438\u0442\u0430\u0446\u0438\u0438", Category.PLAYER);

        setOnlyWithDisabler(true);
    }

    public static void beginPlayerTick(ClientPlayerEntity player) {
        Disabler.refreshLegacyModuleDispatch(player);
        AntiLevitation module = registeredModule();
        if (module == null) {
            return;
        }
        module.snapshotPlayer = player;
        boolean dispatched = module.enabled() && module.disablerGatePasses();
        module.activeSnapshot = dispatched && isEligible(player);
        if (dispatched) {
            module.applyLegacyUpdate(player);
        }
    }

    public static boolean cancelsInputSlowdown() {
        AntiLevitation module = activeControlModule();
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        return module != null && module.hasActiveSnapshot(player);
    }

    public static Vec3d adjustMovement(ClientPlayerEntity player, Vec3d movement) {
        AntiLevitation module = activeControlModule();
        if (module == null || !module.hasActiveSnapshot(player)) {
            return movement;
        }
        return module.applyLegacyHorizontal(player, movement);
    }

    public static void beginMovementPackets(ClientPlayerEntity player) {
        AntiLevitation module = activeModule();
        if (module == null || !module.hasActiveSnapshot(player)) {
            return;
        }
        module.movementPacketContext = true;
        module.movementPacketPlayer = player;
        module.movementPacketYOffset = player.age % 8 == 0
                ? (float) (Math.random() * (0.0055F - 0.0045F) + 0.0045F)
                : 1.0E-5;
    }

    public static void endMovementPackets() {
        AntiLevitation module = registeredModule();
        if (module != null) {
            module.clearMovementPacketContext();
        }
    }

    public static boolean packetOnGround(ClientPlayerEntity player, boolean vanillaOnGround) {
        AntiLevitation module = activeModule();
        return module != null && module.hasMovementPacketContext(player) ? false : vanillaOnGround;
    }

    public static Vec3d packetPosition(ClientPlayerEntity player, Vec3d vanillaPosition) {
        AntiLevitation module = activeModule();
        if (module == null || !module.hasMovementPacketContext(player)) {
            return vanillaPosition;
        }
        return vanillaPosition.add(0.0, module.movementPacketYOffset, 0.0);
    }

    public static double packetY(ClientPlayerEntity player, double vanillaY) {
        AntiLevitation module = activeModule();
        return module != null && module.hasMovementPacketContext(player)
                ? vanillaY + module.movementPacketYOffset : vanillaY;
    }

    public static double packetPositionThreshold(double vanillaThreshold) {
        AntiLevitation module = activeModule();
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        return module != null && module.hasMovementPacketContext(player)
                ? 0.03 : vanillaThreshold;
    }

    public static Packet<?> rewriteOutgoing(Packet<?> packet) {
        AntiLevitation module = activeControlModule();
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (module == null || !module.hasActiveSnapshot(player)) {
            return packet;
        }

        if (packet instanceof PlayerInputC2SPacket inputPacket) {
            PlayerInput input = inputPacket.input();
            if (input.sneak()) {
                return new PlayerInputC2SPacket(new PlayerInput(
                        input.forward(), input.backward(), input.left(), input.right(),
                        input.jump(), false, input.sprint()
                ));
            }
            return packet;
        }

        return packet;
    }

    private void applyLegacyUpdate(ClientPlayerEntity player) {
        MinecraftClient client = MinecraftClient.getInstance();
        StatusEffectInstance effect = player.getStatusEffect(StatusEffects.LEVITATION);
        if (player != client.player || !activeSnapshot || effect == null) {
            if (mode.is(CONTROL)) {
                acceleration = 0.0F;
            }
            return;
        }

        if (mode.is(REMOVE)) {
            player.removeStatusEffect(StatusEffects.LEVITATION);
            return;
        }

        Vec3d velocity = player.getVelocity();
        if (player.isOnGround() || player.input.playerInput.jump()) {
            player.setVelocity(velocity.x, velocity.y + 0.024999, velocity.z);
        } else if (effect.getAmplifier() < 2) {
            player.setVelocity(velocity.x, 0.0, velocity.z);
        }
    }

    private Vec3d applyLegacyHorizontal(ClientPlayerEntity player, Vec3d movement) {
        Vec2f sampledInput = player.input.getMovementInput();
        float strafe = sampledInput.x;
        float forward = sampledInput.y;
        if ((forward == 0.0F && strafe == 0.0F) || player.horizontalCollision) {
            acceleration = 0.0F;
        }

        acceleration = Math.min(1.0F, acceleration + 0.25F);
        double baseSpeed = LEGACY_BASE_SPEED;
        StatusEffectInstance speedEffect = player.getStatusEffect(StatusEffects.SPEED);
        if (speedEffect != null) {
            baseSpeed *= 1.0 + 0.2 * (speedEffect.getAmplifier() + 1);
        }
        float targetSpeed = (float) baseSpeed * 1.2F;
        if (player.age % 2 == 0) {
            targetSpeed -= 1.0E-4F;
            if (hasLegacyActiveUse(player)) {
                targetSpeed *= 0.93F;
            }
        }

        float yaw = player.getYaw();
        if (forward != 0.0F) {
            if (strafe > 0.0F) {
                yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (strafe < 0.0F) {
                yaw += forward > 0.0F ? 45.0F : -45.0F;
            }
            strafe = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
        }
        double radians = Math.toRadians(yaw + 90.0F);
        double cos = Math.cos(radians);
        double sin = Math.sin(radians);
        float speed = targetSpeed * acceleration;
        return new Vec3d(
                forward * speed * cos + strafe * speed * sin,
                movement.y,
                forward * speed * sin - strafe * speed * cos
        );
    }

    @Override
    protected void onTick() {
        if (MinecraftClient.getInstance().player == null) {
            clearSnapshot();
        }
    }

    private static boolean hasLegacyActiveUse(ClientPlayerEntity player) {
        if (!player.isUsingItem()) {
            return false;
        }
        UseAction action = player.getActiveItem().getUseAction();
        return action == UseAction.BLOCK
                || action == UseAction.BOW
                || action == UseAction.DRINK
                || action == UseAction.EAT;
    }

    private static boolean isEligible(ClientPlayerEntity player) {
        return player != null
                && player.hasStatusEffect(StatusEffects.LEVITATION)
                && !player.isTouchingWater()
                && !player.isInLava()
                && !player.hasVehicle()
                && !isInsideCobweb(player);
    }

    private static boolean isInsideCobweb(ClientPlayerEntity player) {
        Box box = player.getBoundingBox();
        for (int x = MathHelper.floor(box.minX + 1.0E-6); x <= MathHelper.floor(box.maxX - 1.0E-6); x++) {
            for (int y = MathHelper.floor(box.minY + 1.0E-6); y <= MathHelper.floor(box.maxY - 1.0E-6); y++) {
                for (int z = MathHelper.floor(box.minZ + 1.0E-6); z <= MathHelper.floor(box.maxZ - 1.0E-6); z++) {
                    if (player.getEntityWorld().getBlockState(new BlockPos(x, y, z)).isOf(Blocks.COBWEB)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static AntiLevitation activeControlModule() {
        AntiLevitation module = activeModule();
        return module != null && module.mode.is(CONTROL) ? module : null;
    }

    private static AntiLevitation activeModule() {
        AntiLevitation module = registeredModule();
        return module != null && module.enabled() && module.disablerGatePasses()
                ? module : null;
    }

    private static AntiLevitation registeredModule() {
        Module module = CelestialPortClient.MODULES.find("anti_levitation").orElse(null);
        return module instanceof AntiLevitation antiLevitation ? antiLevitation : null;
    }

    private boolean hasActiveSnapshot(ClientPlayerEntity player) {
        return activeSnapshot && snapshotPlayer == player;
    }

    private boolean hasMovementPacketContext(ClientPlayerEntity player) {
        return movementPacketContext && movementPacketPlayer == player;
    }

    private boolean disablerGatePasses() {
        return legacyDispatchActive();
    }

    private void clearMovementPacketContext() {
        movementPacketContext = false;
        movementPacketPlayer = null;
        movementPacketYOffset = 0.0;
    }

    private void clearSnapshot() {
        activeSnapshot = false;
        snapshotPlayer = null;
        clearMovementPacketContext();
    }

    @Override
    protected void onEnable() {
        clearSnapshot();
    }

    @Override
    protected void onDisable() {
        clearSnapshot();
    }
}
