package celestial.port.modules.impl;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.inventory.InventoryActions;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerInputC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.OptionalInt;

public final class Flight extends Module {
    private static final int EQUIPPED_ELYTRA = -2;
    private static final Item[] LEGACY_CHESTPLATES = {
            Items.DIAMOND_CHESTPLATE,
            Items.IRON_CHESTPLATE,
            Items.LEATHER_CHESTPLATE,
            Items.GOLDEN_CHESTPLATE,
            Items.CHAINMAIL_CHESTPLATE
    };
    private static volatile Flight instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Р РµР¶РёРј", "Glide",
            List.of("Glide", "Really World Elytra", "Sunrise Elytra", "Vanilla")
    ));
    private final NumberSetting horizontalSpeed = addSetting(new NumberSetting(
            "horizontal_speed", "РЎРєРѕСЂРѕСЃС‚СЊ РїРѕ XZ", 0.85, 0.5, 3.0, 0.01
    ));
    private final NumberSetting verticalSpeed = addSetting(new NumberSetting(
            "vertical_speed", "РЎРєРѕСЂРѕСЃС‚СЊ РїРѕ Y", 0.5, 0.1, 1.0, 0.01
    ));
    private final BooleanSetting superBow = addSetting(new BooleanSetting(
            "super_bow", "РЎСѓРїРµСЂ Р»СѓРє", false
    ).visibleWhen(() -> mode.is("Sunrise Elytra")));

    private ClientPlayerEntity controlledPlayer;

    private boolean removeChestItem;

    private boolean sunriseFlying;

    private int sunriseTicks;

    private int sunriseRamp;

    private long lastPulse;
    private boolean initialized;

    public Flight() {
        super("flight", "Flight",
                "РџРѕР·РІРѕР»СЏРµС‚ Р»РµС‚Р°С‚СЊ Р±РµР· РєСЂРµР°С‚РёРІ СЂРµР¶РёРјР°", Category.MOVEMENT);
        setDisableOnFlag(false);
        instance = this;
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        Flight module = active();
        if (module == null || player != MinecraftClient.getInstance().player || !player.isAlive()) {
            return;
        }
        if (module.controlledPlayer != player) {
            module.controlledPlayer = player;
            if (!module.initialized && !module.initializeForPlayer(player)) {
                return;
            }
        }

        switch (module.mode.value()) {
            case "Really World Elytra" -> module.tickReallyWorld(player);
            case "Sunrise Elytra" -> module.tickSunrise(player);
            case "Glide" -> module.tickGlide(player);
            case "Vanilla" -> module.tickVanilla(player);
            default -> {
            }
        }
    }

    public static Vec3d adjustMovement(ClientPlayerEntity player, Vec3d movement) {
        Flight module = active();
        if (module == null || player != module.controlledPlayer
                || !module.mode.is("Sunrise Elytra") || !module.sunriseFlying
                || player.hasVehicle() || player.isOnGround()) {
            return movement;
        }
        return module.adjustSunriseMovement(player, movement);
    }

    public static boolean cancelsInputSlowdown(ClientPlayerEntity player) {
        Flight module = active();
        return module != null && player == MinecraftClient.getInstance().player;
    }

    public static Packet<?> rewriteOutgoing(Packet<?> packet) {
        Flight module = active();
        if (module == null || !module.sunriseFlying
                || !(packet instanceof PlayerInputC2SPacket inputPacket)) {
            return packet;
        }
        PlayerInput input = inputPacket.input();
        if (!input.sneak()) {
            return packet;
        }
        return new PlayerInputC2SPacket(new PlayerInput(
                input.forward(), input.backward(), input.left(), input.right(),
                input.jump(), false, input.sprint()
        ));
    }

    public static boolean sunriseFlying() {
        Flight module = active();
        return module != null && module.mode.is("Sunrise Elytra") && module.sunriseFlying;
    }

    public static boolean legacyFallFlying(ClientPlayerEntity player) {
        return player != null && (player.isGliding()
                || player == MinecraftClient.getInstance().player && sunriseFlying());
    }

    public static boolean forcesLegacyEyeHeight(ClientPlayerEntity player) {
        Flight module = active();
        return module != null
                && player == MinecraftClient.getInstance().player
                && module.mode.value().contains("Elytra");
    }

    @Override
    protected void onEnable() {
        resetRuntimeState();
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        controlledPlayer = player;
        if (player != null) {
            initializeForPlayer(player);
        }
    }

    private boolean initializeForPlayer(ClientPlayerEntity player) {
        initialized = true;
        if (mode.is("Sunrise Elytra")) {
            if (!moduleEnabled("elytra_fix")) {
                player.sendMessage(Text.literal(
                        "Используйте ElytraFix вместе с этим модом флая!"), false);
            }
            if (findSunriseElytra(player) == PlayerInventory.NOT_FOUND) {
                failNoElytra(player);
                return false;
            }
        } else if (mode.is("Really World Elytra")) {
            if (!hasAnyElytra(player) || findBlockSlot(player) == PlayerInventory.NOT_FOUND) {
                player.sendMessage(Text.literal(
                        "Нет элитры в инвентаре, или заполнен инвентарь!"), false);
                setEnabled(false);
                return false;
            }
            ItemStack chest = player.getEquippedStack(EquipmentSlot.CHEST);
            removeChestItem = !chest.isEmpty() && !chest.isOf(Items.ELYTRA);
        }
        return true;
    }

    private void tickVanilla(ClientPlayerEntity player) {
        setVerticalFromKeys(player, 0.0);
        setHorizontalVelocity(player, horizontalSpeed.value().floatValue());
    }

    private void tickGlide(ClientPlayerEntity player) {
        if (player.isOnGround()) {
            player.jump();
            return;
        }
        setVerticalFromKeys(player, -0.01);
        setHorizontalVelocity(player, horizontalSpeed.value().floatValue());
    }

    private void tickSunrise(ClientPlayerEntity player) {
        if (player.isTouchingWater() || player.isInLava()) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (!sunriseFlying) {
            client.options.jumpKey.setPressed(false);
        } else {
            sunriseTicks++;
        }
        if (!hasMovementInput(player)) {
            sunriseRamp = 0;
        }
        if (sunriseTicks < 2) {
            client.options.jumpKey.setPressed(false);
        }
        if (player.isOnGround()) {
            player.jump();
            return;
        }
        if (player.getVelocity().y < 0.0) {
            player.setVelocity(0.0, player.getVelocity().y, 0.0);
            sunriseFlying = true;
        }
    }

    private Vec3d adjustSunriseMovement(ClientPlayerEntity player, Vec3d movement) {
        int elytra = findSunriseElytra(player);
        if (elytra == PlayerInventory.NOT_FOUND) {
            failNoElytra(player);
            return movement;
        }
        pulseSunriseElytra(player, elytra);

        MinecraftClient client = MinecraftClient.getInstance();
        float horizontal = horizontalSpeed.value().floatValue();
        float vertical = verticalSpeed.value().floatValue();
        double idleY = -0.01F - ((player.age & 1) == 0 ? 1.0E-4F : 0.006F);
        double y = client.options.jumpKey.isPressed()
                ? jitterAndWriteVelocityY(player, vertical)
                : client.options.sneakKey.isPressed()
                ? jitterAndWriteVelocityY(player, -vertical)
                : superBow.enabled() && clearBelow(player, 2.0F)
                ? ((player.age & 1) == 0 ? 0.42F : -0.42F)
                : idleY;
        setVelocityY(player, y);

        double x = movement.x;
        double z = movement.z;
        if (!player.horizontalCollision) {
            sunriseRamp = (int) ((float) sunriseRamp + 11.0F / horizontal);
            horizontal *= Math.min((float) sunriseRamp / 100.0F, 1.0F);
            float randomizedSpeed = jitterAndWriteVelocityY(player, horizontal);
            Vec3d horizontalVector = horizontalVector(player, randomizedSpeed);
            x = horizontalVector.x;
            z = horizontalVector.z;
        } else if (hasMovementInput(player)) {
            sunriseRamp = 0;
            y = 0.42F;
            setVelocityY(player, y);
        }

        if (!clearBelow(player, 1.0F)) {
            y = 0.42F;
            setVelocityY(player, y);
        }
        return new Vec3d(x, y, z);
    }

    private void tickReallyWorld(ClientPlayerEntity player) {
        if (player.isOnGround()) {
            player.jump();
        }
        if (player.fallDistance <= 0.05F) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (removeChestItem) {
            quickMoveInventorySlot(client, InventoryActions.CHEST_INVENTORY_INDEX);
            removeChestItem = false;
        }

        long now = System.currentTimeMillis();
        if (now - lastPulse > 73L) {
            setHorizontalVelocity(player, horizontalSpeed.value().floatValue());
            if (!player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
                int source = findMainElytra(player);
                if (source != PlayerInventory.NOT_FOUND) {
                    quickMoveInventorySlot(client, source);
                }
                player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                        player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                setVelocityY(player, 0.1);
            } else {
                quickMoveInventorySlot(client, InventoryActions.CHEST_INVENTORY_INDEX);
                setVelocityY(player, -1.0E-4);
                lastPulse = now;
            }
        }

        if (client.options.sneakKey.isPressed()) {
            setVelocityY(player, -verticalSpeed.value());
        } else if (client.options.jumpKey.isPressed()) {
            setVelocityY(player, verticalSpeed.value());
        }
    }

    private void pulseSunriseElytra(ClientPlayerEntity player, int elytra) {
        long now = System.currentTimeMillis();
        if (now - lastPulse <= 80L) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        ScreenHandler handler = playerInventoryHandler(client);
        OptionalInt sourceSlot = elytra == EQUIPPED_ELYTRA || handler == null
                ? OptionalInt.empty()
                : handler.getSlotIndex(player.getInventory(), elytra);
        OptionalInt chestSlot = handler == null
                ? OptionalInt.empty()
                : handler.getSlotIndex(player.getInventory(), InventoryActions.CHEST_INVENTORY_INDEX);
        boolean temporaryEquip = elytra != EQUIPPED_ELYTRA
                && sourceSlot.isPresent() && chestSlot.isPresent();

        if (temporaryEquip) {
            clickSlot(client, handler, sourceSlot.getAsInt(), 1, SlotActionType.PICKUP);
            clickSlot(client, handler, chestSlot.getAsInt(), 1, SlotActionType.PICKUP);
        }
        player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
        if (temporaryEquip) {
            clickSlot(client, handler, chestSlot.getAsInt(), 1, SlotActionType.PICKUP);
            clickSlot(client, handler, sourceSlot.getAsInt(), 1, SlotActionType.PICKUP);
        }
        lastPulse = now;
    }

    private void setVerticalFromKeys(ClientPlayerEntity player, double idleY) {
        MinecraftClient client = MinecraftClient.getInstance();
        double y = client.options.sneakKey.isPressed()
                ? -verticalSpeed.value()
                : client.options.jumpKey.isPressed() ? verticalSpeed.value() : idleY;
        setVelocityY(player, y);
    }

    private static void setHorizontalVelocity(ClientPlayerEntity player, float speed) {
        Vec3d horizontal = horizontalVector(player, speed);
        player.setVelocity(horizontal.x, player.getVelocity().y, horizontal.z);
    }

    private static Vec3d horizontalVector(ClientPlayerEntity player, float speed) {
        float yaw = player.getYaw();
        float forward = player.forwardSpeed;
        float strafe = player.sidewaysSpeed;
        if (forward != 0.0F) {
            if (strafe > 0.0F) {
                yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (strafe < 0.0F) {
                yaw += forward > 0.0F ? 45.0F : -45.0F;
            }
            strafe = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
        }
        double cosine = Math.cos(Math.toRadians(yaw + 90.0F));
        double sine = Math.sin(Math.toRadians(yaw + 90.0F));
        return new Vec3d(
                (double) (forward * speed) * cosine + (double) (strafe * speed) * sine,
                0.0,
                (double) (forward * speed) * sine - (double) (strafe * speed) * cosine
        );
    }

    private static float jitterAndWriteVelocityY(ClientPlayerEntity player, double value) {
        float randomized = (float) (value + Math.random() / 500.0);
        setVelocityY(player, randomized);
        return randomized;
    }

    private static void setVelocityY(ClientPlayerEntity player, double y) {
        Vec3d velocity = player.getVelocity();
        player.setVelocity(velocity.x, y, velocity.z);
    }

    private static boolean clearBelow(ClientPlayerEntity player, float distance) {
        if (player.getY() < 0.0) {
            return false;
        }
        Box below = player.getBoundingBox().offset(0.0, -distance, 0.0);
        return !player.getEntityWorld().getBlockCollisions(player, below).iterator().hasNext();
    }

    private static boolean hasMovementInput(ClientPlayerEntity player) {
        return player.forwardSpeed != 0.0F || player.sidewaysSpeed != 0.0F;
    }

    private static int findSunriseElytra(ClientPlayerEntity player) {
        if (player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            return EQUIPPED_ELYTRA;
        }
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (LivingEntity.canGlideWith(inventory.getStack(slot), EquipmentSlot.CHEST)) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int findMainElytra(ClientPlayerEntity player) {
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (inventory.getStack(slot).isOf(Items.ELYTRA)) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static boolean hasAnyElytra(ClientPlayerEntity player) {
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < inventory.size(); slot++) {
            if (inventory.getStack(slot).isOf(Items.ELYTRA)) {
                return true;
            }
        }
        return false;
    }

    private static int findBlockSlot(ClientPlayerEntity player) {
        PlayerInventory inventory = player.getInventory();
        for (int slot = 9; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (inventory.getStack(slot).getItem() instanceof BlockItem) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int findLegacyChestplate(ClientPlayerEntity player) {
        PlayerInventory inventory = player.getInventory();
        for (Item chestplate : LEGACY_CHESTPLATES) {
            for (int slot = 0; slot < inventory.size(); slot++) {
                if (inventory.getStack(slot).isOf(chestplate)) {
                    return slot;
                }
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static ScreenHandler playerInventoryHandler(MinecraftClient client) {
        ClientPlayerEntity player = client.player;
        if (player == null || !player.isAlive() || client.interactionManager == null
                || client.getNetworkHandler() == null
                || player.currentScreenHandler != player.playerScreenHandler) {
            return null;
        }
        return player.playerScreenHandler;
    }

    private static boolean quickMoveInventorySlot(MinecraftClient client, int inventoryIndex) {
        ScreenHandler handler = playerInventoryHandler(client);
        ClientPlayerEntity player = client.player;
        if (handler == null || player == null || !handler.getCursorStack().isEmpty()) {
            return false;
        }
        OptionalInt slot = handler.getSlotIndex(player.getInventory(), inventoryIndex);
        if (slot.isEmpty()) {
            return false;
        }
        clickSlot(client, handler, slot.getAsInt(), 0, SlotActionType.QUICK_MOVE);
        return true;
    }

    private static void clickSlot(
            MinecraftClient client, ScreenHandler handler, int slot,
            int button, SlotActionType action
    ) {
        if (client.player != null && client.interactionManager != null) {
            client.interactionManager.clickSlot(
                    handler.syncId, slot, button, action, client.player);
        }
    }

    @Override
    protected void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = controlledPlayer;
        if (player != null && player == client.player) {
            player.getAbilities().flying = false;
            if (mode.is("Sunrise Elytra")) {
                sunriseRamp = 0;
                sunriseTicks = 0;
                if (sunriseFlying) {
                    setVelocityY(player, 0.0);
                    sunriseFlying = false;
                }
            } else if (mode.is("Really World Elytra")) {
                Vec3d velocity = player.getVelocity();
                player.setVelocity(0.0, velocity.y, 0.0);
                restoreReallyWorldInventory(client, player);
            }
        }
        controlledPlayer = null;
        resetRuntimeState();
    }

    private static void restoreReallyWorldInventory(
            MinecraftClient client, ClientPlayerEntity player
    ) {
        ScreenHandler handler = playerInventoryHandler(client);
        if (handler == null) {
            return;
        }
        int chestplate = findLegacyChestplate(player);
        OptionalInt chest = handler.getSlotIndex(
                player.getInventory(), InventoryActions.CHEST_INVENTORY_INDEX);
        OptionalInt source = chestplate == PlayerInventory.NOT_FOUND
                ? OptionalInt.empty()
                : handler.getSlotIndex(player.getInventory(), chestplate);
        if (chest.isEmpty()) {
            return;
        }

        if (source.isPresent() && source.getAsInt() != chest.getAsInt()) {
            clickSlot(client, handler, source.getAsInt(), 1, SlotActionType.PICKUP);
        }
        clickSlot(client, handler, chest.getAsInt(), 1, SlotActionType.PICKUP);

        if (handler.getCursorStack().isOf(Items.ELYTRA)) {
            int block = findBlockSlot(player);
            OptionalInt blockSlot = block == PlayerInventory.NOT_FOUND
                    ? OptionalInt.empty()
                    : handler.getSlotIndex(player.getInventory(), block);
            blockSlot.ifPresent(value ->
                    clickSlot(client, handler, value, 0, SlotActionType.PICKUP));
        }
    }

    private void failNoElytra(ClientPlayerEntity player) {
        player.sendMessage(Text.literal("Нету элитр в инвентаре!"), false);
        setEnabled(false);
    }

    private void resetRuntimeState() {
        removeChestItem = false;
        sunriseFlying = false;
        sunriseTicks = 0;
        sunriseRamp = 0;
        lastPulse = 0L;
        initialized = false;
    }

    private static boolean moduleEnabled(String id) {
        return CelestialPortClient.MODULES.find(id).filter(Module::enabled).isPresent();
    }

    private static Flight active() {
        Flight module = instance;
        return module != null && module.enabled() ? module : null;
    }
}
