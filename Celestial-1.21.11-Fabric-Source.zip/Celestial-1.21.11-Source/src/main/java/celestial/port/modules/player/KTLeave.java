package celestial.port.modules.player;

import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.core.Category;
import celestial.port.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public final class KTLeave extends Module {
    public KTLeave() {
        super("kt_leave", "KT Leave",
                "\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u0443\u0435\u0442 \u0432\u0430\u0441 \u0432 \u041a\u0422 \u0432 \u0434\u0440\u0443\u0433\u043e\u0435 \u043c\u0435\u0441\u0442\u043e", Category.PLAYER);
    }

    @Override
    protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            return;
        }
        int x = 8000 + (int) (Math.random() * 13000.0 - 6500.0);
        int z = 8000 + (int) (Math.random() * 13000.0 - 6500.0);
        if (LegacyTeleportCoordinator.isReallyWorld(client)) {
            boolean horizontalCollision = player.horizontalCollision;
            for (int i = 0; i < 12; i++) {
                sendPosition(player, x, 180.0, z, horizontalCollision);
                sendPosition(player, x, 180.0, z, horizontalCollision);
            }
            for (int i = 0; i < 12; i++) {
                sendPosition(player, player.getX(), 180.0, player.getZ(), horizontalCollision);
                sendPosition(player, player.getX(), 180.0, player.getZ(), horizontalCollision);
            }
        } else {
            player.setPosition(x, 3.0, z);
        }
    }

    private static void sendPosition(
            ClientPlayerEntity player, double x, double y, double z, boolean horizontalCollision
    ) {
        player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                x, y, z, true, horizontalCollision
        ));
    }

}
