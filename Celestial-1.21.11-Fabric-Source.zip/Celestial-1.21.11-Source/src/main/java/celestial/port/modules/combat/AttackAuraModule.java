package celestial.port.modules.combat;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.client.ui.CelestialHud;
import celestial.port.client.ui.LegacyTargetHud;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.impl.Flight;
import celestial.port.modules.impl.NoClip;
import celestial.port.modules.inventory.ClickPearl;
import celestial.port.modules.legacyutility.BaritoneBridge;
import celestial.port.modules.render.ArrayListModule;
import celestial.port.modules.movement.LongJump;
import celestial.port.modules.movement.Strafe;
import celestial.port.modules.player.FreeCameraModule;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.Identifier;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.world.debug.gizmo.VisibilityConfigurable;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ThreadLocalRandom;

public final class AttackAuraModule extends Module {

    private static boolean attackInProgress;
    private static final int DEFERRED_NONE = 0;
    private static final int DEFERRED_QUEUED = 1;
    private static final int DEFERRED_ARMED = 2;
    private static final int DEFERRED_STOPPING = 3;
    private static final int DEFERRED_POST_MOVE = 4;
    private static final int DEFERRED_READY = 5;
    public static final String ALL = "Всему сразу";
    public static final String FOV = "Вашему FOV";
    public static final String DISTANCE = "Дистанции";
    public static final String HEALTH = "Здоровью";
    public static final String RW_VULCAN = "RW | Vulcan";
    public static final String SUNRISE_MATRIX = "Sunrise | Matrix";

    private static final String PLAYERS = "Игроки";
    private static final String UNARMORED = "Игроки без брони";
    private static final String BOTS = "НПС / Боты";
    private static final String MOBS = "Мобы";

    private static AttackAuraModule instance;

    private final ModeSetting sorting;
    private final ModeSetting rotationMode;
    private final MultiSelectSetting targets;
    private final ModeSetting targetHudType;
    private final NumberSetting attackDistance;
    private final NumberSetting rotationDistance;
    private final BooleanSetting onlyCriticals;
    private final BooleanSetting criticalsInWater;
    private final BooleanSetting onlyWithSpace;
    private final BooleanSetting wallBypass;
    private final BooleanSetting doNotAttackWhileEating;
    private final BooleanSetting obstructionCheck;
    private final BooleanSetting shieldSpam;
    private final BooleanSetting onlyWeapon;
    private final BooleanSetting attackBacktrack;
    private final BooleanSetting targetHud;
    private final BooleanSetting targetEsp;

    private LivingEntity selectedTarget;
    private float serverYaw;
    private float serverPitch;
    private float previousYawStep;
    private LivingEntity previousRotationTarget;
    private int attackDelay;
    private ClientPlayerEntity preparedRotationPlayer;
    private LivingEntity preparedRotationTarget;
    private ClientWorld preparedRotationWorld;
    private int preparedRotationAge = Integer.MIN_VALUE;
    private boolean preparedRotationActive;
    private boolean preparedAutoExplosionSuppressed;
    private ClientPlayerEntity movementRotationPlayer;
    private ClientWorld movementRotationWorld;
    private int movementRotationAge = Integer.MIN_VALUE;
    private boolean movementRotationActive;
    private ClientPlayerEntity focusedYawPlayer;
    private ClientWorld focusedYawWorld;
    private int focusedYawAge = Integer.MIN_VALUE;
    private int focusedYawDepth;
    private ClientPlayerEntity deferredCriticalPlayer;
    private LivingEntity deferredCriticalTarget;
    private ClientWorld deferredCriticalWorld;
    private int deferredCriticalAge = Integer.MIN_VALUE;
    private int deferredCriticalStage = DEFERRED_NONE;
    private boolean deferredCriticalSprintApplied;

    public AttackAuraModule() {
        super("attack_aura", "Attack Aura", "Бьет окружающих вас существ", Category.COMBAT);

        sorting = addSetting(new ModeSetting("sorting", "Сортировать по", ALL,
                List.of(ALL, FOV, DISTANCE, HEALTH)));
        rotationMode = addSetting(new ModeSetting("rotation_mode", "Режим ротации", RW_VULCAN,
                List.of(RW_VULCAN, SUNRISE_MATRIX)));
        targets = addSetting(new MultiSelectSetting("targets", "Выбор целей",
                Set.of(PLAYERS, UNARMORED), List.of(PLAYERS, UNARMORED, BOTS, MOBS)));

        targetHudType = addSetting(new ModeSetting("target_hud_type", "Выбор таргет худа", "Тип 1",
                List.of("Тип 1", "Тип 2")));
        attackDistance = addSetting(new NumberSetting("attack_distance", "Дистанция удара",
                3.0, 2.5, 6.0, 0.1));
        rotationDistance = addSetting(new NumberSetting("rotation_distance", "Дистанция ротации",
                1.0, 0.0, 2.0, 0.1));
        onlyCriticals = addSetting(new BooleanSetting("only_criticals", "Только криты", true));
        criticalsInWater = addSetting(new BooleanSetting("criticals_in_water", "Криты в воде", true)
                .visibleWhen(onlyCriticals::enabled));
        onlyWithSpace = addSetting(new BooleanSetting("only_with_space", "Только с пробелом", false)
                .visibleWhen(onlyCriticals::enabled));
        wallBypass = addSetting(new BooleanSetting("wall_bypass", "Обход через стену", true));
        doNotAttackWhileEating = addSetting(new BooleanSetting(
                "do_not_attack_while_eating", "Не бить если ешь", false));
        obstructionCheck = addSetting(new BooleanSetting("obstruction_check", "Проверка на обссу", false)
                .visibleWhen(onlyCriticals::enabled));
        shieldSpam = addSetting(new BooleanSetting("shield_spam", "Спам щитом", false));
        onlyWeapon = addSetting(new BooleanSetting("only_weapon", "Только с оружием", false));
        attackBacktrack = addSetting(new BooleanSetting("attack_backtrack", "Бить в бектрек", false));
        targetHud = addSetting(new BooleanSetting("target_hud", "Таргет худ", true));
        targetEsp = addSetting(new BooleanSetting("target_esp", "Таргет есп", false));
        targetHudType.visibleWhen(targetHud::enabled);

        instance = this;
        HudElementRegistry.addLast(Identifier.of("celestial", "attack_aura_target_hud"),
                (context, tickCounter) -> renderTargetHud(
                        context, tickCounter.getTickProgress(false)));
        WorldRenderEvents.END_EXTRACTION.register(context ->
                collectTargetEsp(context.tickCounter().getTickProgress(false)));
    }

    public static LivingEntity target() {
        AttackAuraModule aura = instance;
        return aura != null && aura.enabled() ? aura.selectedTarget : null;
    }

    public static boolean hasTarget() {
        return target() != null;
    }

    public static void applyThirdPersonRotation(
            PlayerLikeEntity renderedPlayer, PlayerEntityRenderState state
    ) {
        AttackAuraModule aura = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        LivingEntity target = aura == null ? null : aura.selectedTarget;
        if (aura == null || !aura.enabled()
                || renderedPlayer == null || state == null
                || player == null || client.world == null
                || renderedPlayer != player
                || !player.isAlive() || player.isRemoved()
                || player.getEntityWorld() != client.world
                || target == null || !target.isAlive() || target.isRemoved()
                || target.getEntityWorld() != client.world
                || moduleEnabled("rotation_view")
                || AutoExplosionModule.ownsRenderRotation(player)) {
            return;
        }
        state.bodyYaw = aura.serverYaw;
        state.relativeHeadYaw = 0.0F;
        state.pitch = aura.serverPitch;
    }

    public static void prepareFocusedMovement(ClientPlayerEntity player) {
        AttackAuraModule aura = instance;
        if (aura != null) {
            aura.prepareCombatTick(MinecraftClient.getInstance(), player);
        }
    }

    public static void beforePlayerTick(ClientPlayerEntity player) {
        AttackAuraModule aura = instance;
        if (aura != null) {
            aura.prepareDeferredCriticalStopTick(MinecraftClient.getInstance(), player);
        }
    }

    public static void beforeVehicleDecision(ClientPlayerEntity player) {
        AttackAuraModule aura = instance;
        if (aura != null) {
            aura.finishCombatTick(MinecraftClient.getInstance(), player);
        }
    }

    public static boolean beginFocusedMovementYaw(ClientPlayerEntity player) {
        AttackAuraModule aura = instance;
        return aura != null && aura.openFocusedYaw(player);
    }

    public static void endFocusedMovementYaw(ClientPlayerEntity player) {
        AttackAuraModule aura = instance;
        if (aura != null) {
            aura.closeFocusedYaw(player);
        }
    }

    public static float focusedMovementYaw(Entity entity, float original) {
        AttackAuraModule aura = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        return aura != null
                && aura.focusedYawDepth > 0
                && entity == aura.focusedYawPlayer
                && entity == client.player
                && client.world != null
                && aura.focusedYawWorld == client.world
                && entity.getEntityWorld() == client.world
                && entity.age == aura.focusedYawAge
                ? aura.serverYaw : original;
    }

    public static PlayerInput correctPlayerInput(ClientPlayerEntity player, PlayerInput input) {
        AttackAuraModule aura = instance;
        return aura != null && aura.isDeferredCriticalStopTick(player)
                ? withoutSprint(input) : input;
    }

    public static boolean canStartSprintingDuringCriticalStop(
            ClientPlayerEntity player, boolean canStart
    ) {
        AttackAuraModule aura = instance;
        return aura != null && aura.isDeferredCriticalStopTick(player)
                ? false : canStart;
    }

    private static PlayerInput withoutSprint(PlayerInput input) {
        return new PlayerInput(
                input.forward(), input.backward(), input.left(), input.right(),
                input.jump(), input.sneak(), false);
    }

    public static void beginMovementPackets(ClientPlayerEntity player) {
        AttackAuraModule aura = instance;
        if (aura == null) {
            return;
        }
        aura.resetMovementContext();
        boolean usePreparedRotation = aura.enabled()
                && player != null
                && player == MinecraftClient.getInstance().player
                && aura.preparedRotationPlayer == player
                && aura.preparedRotationWorld == MinecraftClient.getInstance().world
                && aura.preparedRotationAge == player.age
                && aura.preparedRotationActive;
        ClientWorld preparedWorld = aura.preparedRotationWorld;
        int preparedAge = aura.preparedRotationAge;
        aura.resetPreparedRotation();
        if (usePreparedRotation) {
            aura.movementRotationPlayer = player;
            aura.movementRotationWorld = preparedWorld;
            aura.movementRotationAge = preparedAge;
            aura.movementRotationActive = true;
        }
    }

    public static float movementPacketYaw(ClientPlayerEntity player, float original) {
        AttackAuraModule aura = instance;
        return aura != null && aura.movementRotationActive
                && aura.movementRotationPlayer == player ? aura.serverYaw : original;
    }

    public static float movementPacketPitch(ClientPlayerEntity player, float original) {
        AttackAuraModule aura = instance;
        return aura != null && aura.movementRotationActive
                && aura.movementRotationPlayer == player ? aura.serverPitch : original;
    }

    public static Packet<?> rewriteScheduledMovementPacket(
            ClientPlayerEntity player, Packet<?> packet
    ) {
        AttackAuraModule aura = instance;
        if (aura == null || !aura.movementRotationActive
                || aura.movementRotationPlayer != player
                || !(packet instanceof PlayerMoveC2SPacket movement)) {
            return packet;
        }
        float pitch = movement.getPitch(player.getPitch());
        if (movement instanceof PlayerMoveC2SPacket.Full) {
            return new PlayerMoveC2SPacket.Full(
                    movement.getX(player.getX()), movement.getY(player.getY()),
                    movement.getZ(player.getZ()), aura.serverYaw, pitch,
                    movement.isOnGround(), movement.horizontalCollision());
        }
        if (movement instanceof PlayerMoveC2SPacket.LookAndOnGround) {
            return new PlayerMoveC2SPacket.LookAndOnGround(
                    aura.serverYaw, pitch,
                    movement.isOnGround(), movement.horizontalCollision());
        }
        return packet;
    }

    public static void endMovementPackets(ClientPlayerEntity player) {
        AttackAuraModule aura = instance;
        if (aura != null) {
            aura.resetMovementContext();
            aura.finishDeferredCriticalMovementStage(player);
        }
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        cancelDeferredCriticalAttack();
        resetPreparedRotation();
        resetMovementContext();
        resetFocusedYawContext();
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            selectedTarget = null;
            serverYaw = client.player.getYaw();
            serverPitch = client.player.getPitch();
            attackDelay = 0;
        }
    }

    @Override
    protected void onEnable() {
        cancelDeferredCriticalAttack();
        resetPreparedRotation();
        resetMovementContext();
        resetFocusedYawContext();
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            serverYaw = client.player.getYaw();
            serverPitch = client.player.getPitch();
        }
        attackDelay = 0;
        previousYawStep = 0.0f;
    }

    private void prepareCombatTick(MinecraftClient client, ClientPlayerEntity player) {
        resetPreparedRotation();
        resetMovementContext();
        resetFocusedYawContext();

        if (deferredCriticalStage != DEFERRED_NONE
                && deferredCriticalStage != DEFERRED_ARMED
                && deferredCriticalStage != DEFERRED_READY) {
            cancelDeferredCriticalAttack();
        }

        if (!enabled() || player == null || player != client.player
                || client.world == null || client.interactionManager == null
                || player.networkHandler == null || !player.networkHandler.isLoaded()
                || !player.isAlive() || player.isRemoved()
                || player.getEntityWorld() != client.world) {
            clearTarget();
            return;
        }

        if (deferredCriticalStage == DEFERRED_ARMED
                && !validDeferredCriticalState(
                        client, player, DEFERRED_ARMED, true)) {
            cancelDeferredCriticalAttack();
        }
        if (deferredCriticalStage == DEFERRED_READY
                && !validDeferredCriticalState(client, player, DEFERRED_READY)) {
            cancelDeferredCriticalAttack();
        }

        preparedRotationPlayer = player;
        preparedRotationWorld = client.world;
        preparedRotationAge = player.age;

        if (hasDeferredCriticalTransaction(player)) {
            preparedAutoExplosionSuppressed =
                    AutoExplosionModule.consumeAuraRotationSuppression(player);
            prepareRotation(client, player, deferredCriticalTarget);
            return;
        }

        if (onlyWeapon.enabled() && !isLegacyWeapon(player.getMainHandStack())) {
            clearTarget();
            return;
        }

        preparedAutoExplosionSuppressed =
                AutoExplosionModule.consumeAuraRotationSuppression(player);
        if (attackDelay > 0) attackDelay--;

        LivingEntity next = selectTarget(client, player);
        selectedTarget = next;
        preparedRotationTarget = next;
        if (next == null) {
            serverYaw = player.getYaw();
            serverPitch = player.getPitch();
            previousRotationTarget = null;
            return;
        }
        prepareRotation(client, player, next);
    }

    private void prepareRotation(
            MinecraftClient client, ClientPlayerEntity player, LivingEntity target
    ) {
        if (target == null || !target.isAlive() || target.isRemoved()
                || target.getEntityWorld() != client.world) {
            preparedRotationActive = false;
            return;
        }
        selectedTarget = target;
        preparedRotationTarget = target;
        updateRotation(client, player, target);
        preparedRotationActive = !preparedAutoExplosionSuppressed
                && focusedOwnersClear(player);
        if (!AutoExplosionModule.ownsRenderRotation(player)) {
            player.setHeadYaw(serverYaw);
            player.bodyYaw = serverYaw;
        }
    }

    private void finishCombatTick(MinecraftClient client, ClientPlayerEntity player) {
        boolean readyCritical = deferredCriticalStage == DEFERRED_READY;
        if (!enabled() || player == null || player != client.player
                || client.world == null || client.interactionManager == null
                || preparedRotationPlayer != player
                || preparedRotationWorld != client.world
                || preparedRotationAge != player.age) {
            if (readyCritical) {
                cancelDeferredCriticalAttack();
            }
            return;
        }

        LivingEntity target = preparedRotationTarget;
        if (target == null || !target.isAlive() || target.isRemoved()
                || target.getEntityWorld() != client.world) {
            if (readyCritical) {
                cancelDeferredCriticalAttack();
                return;
            }

            if (!hasDeferredCriticalTransaction(player)) {
                selectedTarget = null;
                previousRotationTarget = null;
            }
            return;
        }

        selectedTarget = target;
        if (readyCritical) {
            if (!validReadyDeferredCriticalState(client, player, target)) {
                cancelDeferredCriticalAttack();
                return;
            }
            previousRotationTarget = target;
            flushReadyDeferredCriticalAttack(client);
            return;
        }

        if (shieldSpam.enabled() && player.isBlocking()
                && player.getItemUseTime() >= ThreadLocalRandom.current().nextInt(4, 8)) {
            client.interactionManager.stopUsingItem(player);
        }
        if (!hasDeferredCriticalTransaction(player) && preparedRotationActive) {
            attackIfReady(client, player, target);
        }
        previousRotationTarget = target;
    }

    private boolean focusedOwnersClear(ClientPlayerEntity player) {
        return !player.hasVehicle()
                && !Flight.legacyFallFlying(player)
                && !FreeCameraModule.cancelsInputSlowdown(player)
                && !ClickPearl.ownsMovementRotation(player)
                && !LegacyTeleportCoordinator.hasPendingTeleport()
                && !BaritoneBridge.isAnyProcessActive();
    }

    private boolean openFocusedYaw(ClientPlayerEntity player) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (player == null || player != client.player || client.world == null) {
            return false;
        }
        boolean prepared = preparedRotationActive
                && preparedRotationPlayer == player
                && preparedRotationWorld == client.world
                && preparedRotationAge == player.age;
        boolean moving = movementRotationActive
                && movementRotationPlayer == player
                && movementRotationWorld == client.world
                && movementRotationAge == player.age;
        if (!prepared && !moving) {
            return false;
        }
        boolean validPlayer = player.getEntityWorld() == client.world
                && player.networkHandler != null && player.networkHandler.isLoaded()
                && player.isAlive() && !player.isRemoved();
        if (!validPlayer || !focusedOwnersClear(player)) {
            if (prepared) {
                preparedRotationActive = false;
            }
            if (moving) {
                movementRotationActive = false;
            }
            return false;
        }
        if (focusedYawDepth > 0) {
            if (focusedYawPlayer != player || focusedYawWorld != client.world
                    || focusedYawAge != player.age) {
                return false;
            }
            focusedYawDepth++;
            return true;
        }
        focusedYawPlayer = player;
        focusedYawWorld = client.world;
        focusedYawAge = player.age;
        focusedYawDepth = 1;
        return true;
    }

    private void closeFocusedYaw(ClientPlayerEntity player) {
        if (focusedYawDepth <= 0 || focusedYawPlayer != player) {
            return;
        }
        focusedYawDepth--;
        if (focusedYawDepth == 0) {
            resetFocusedYawContext();
        }
    }

    private LivingEntity selectTarget(MinecraftClient client, ClientPlayerEntity player) {
        double attackRange = attackDistance.value();
        double forcedRotationRange = legacyRotationOverride(player);
        double acquisitionRange = attackRange + (forcedRotationRange >= 0.0
                ? forcedRotationRange : rotationDistance.value());
        List<LivingEntity> candidates = new ArrayList<>();

        for (Entity entity : client.world.getEntities()) {
            if (!(entity instanceof LivingEntity living) || living == player
                    || living.isRemoved() || !validKind(living)) {
                continue;
            }
            if (player.distanceTo(living) > acquisitionRange) continue;
            if (!living.isAlive()) {
                if (living == selectedTarget) CelestialHud.recordAuraKill(living, player);
                continue;
            }
            candidates.add(living);
        }
        if (candidates.isEmpty()) return null;

        if (forcedRotationRange >= 0.0
                && candidates.stream().anyMatch(entity -> player.distanceTo(entity) < attackRange)) {
            candidates.removeIf(entity -> player.distanceTo(entity) > attackRange);
        }
        if (candidates.isEmpty()) return null;

        if (candidates.size() == 1) {
            attackDelay = 0;
            return candidates.getFirst();
        }

        if (selectedTarget != null && candidates.contains(selectedTarget) && !sorting.is(FOV)) {
            return selectedTarget;
        }

        Comparator<LivingEntity> comparator = switch (sorting.value()) {
            case DISTANCE -> Comparator.<LivingEntity>comparingDouble(player::distanceTo)
                    .thenComparingDouble(this::weightedHealth);
            case HEALTH -> Comparator.comparingDouble(this::weightedHealth)
                    .thenComparingDouble(player::distanceTo);
            case FOV -> (first, second) -> (int) (
                    yawDistance(player, first) - yawDistance(player, second));
            default -> Comparator.<LivingEntity>comparingDouble(entity -> -armor(entity))
                    .thenComparingDouble(this::weightedHealth)
                    .thenComparingDouble(player::distanceTo);
        };
        candidates.sort(comparator);
        return candidates.getFirst();
    }

    private double legacyRotationOverride(ClientPlayerEntity player) {
        if (player.isGliding() || moduleEnabled("flight")) return 6.0;
        MinecraftClient client = MinecraftClient.getInstance();
        BlockPos below = BlockPos.ofFloored(player.getX(), player.getY() - 0.1, player.getZ());
        if (moduleEnabled("jesus") && client.world != null
                && !client.world.getFluidState(below).isEmpty()) return 6.0;
        if (player.fallDistance > 2.5f) return 5.0;
        if (Strafe.elytraBoostActive()) return 1.0;
        if (moduleEnabled("water_speed") && player.isTouchingWater()) return 3.0;
        return -1.0;
    }

    private static boolean moduleEnabled(String id) {
        return CelestialPortClient.MODULES.find(id).filter(Module::enabled).isPresent();
    }

    private boolean validKind(LivingEntity entity) {
        if (entity instanceof PlayerEntity player) {
            if (!targets.selected(PLAYERS) || FriendManager.isFriend(player)) return false;
            if (!targets.selected(UNARMORED) && player.getArmor() < 1) return false;
            return targets.selected(BOTS) || !legacyBot(player);
        }
        return entity instanceof MobEntity && targets.selected(MOBS);
    }

    private static boolean legacyBot(PlayerEntity player) {
        UUID offline = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + player.getGameProfile().name()).getBytes(StandardCharsets.UTF_8));
        return !player.getUuid().equals(offline);
    }

    private static int armor(LivingEntity entity) {
        return entity instanceof PlayerEntity player ? player.getArmor() : 0;
    }

    private double weightedHealth(LivingEntity entity) {
        double health = entity.getHealth() + entity.getAbsorptionAmount();
        return entity instanceof PlayerEntity ? health * (armor(entity) / 20.0) : health;
    }

    private static double yawDistance(ClientPlayerEntity player, LivingEntity entity) {
        Vec3d delta = entity.getEntityPos().subtract(player.getEntityPos());
        float desired = (float) Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0f;
        return Math.abs(MathHelper.wrapDegrees(desired - player.getYaw()));
    }

    private void updateRotation(MinecraftClient client, ClientPlayerEntity player, LivingEntity target) {
        Vec3d aim = bestAimPoint(client, player, target);
        double dx = aim.x - player.getX();
        double dy = aim.y - player.getEyeY();
        double dz = aim.z - player.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        float desiredYaw = MathHelper.wrapDegrees((float) Math.toDegrees(Math.atan2(dz, dx)) - 90.0f);
        float desiredPitch = (float) -Math.toDegrees(Math.atan2(dy, horizontal));

        float yawDelta = MathHelper.wrapDegrees(desiredYaw - serverYaw);
        float pitchDelta = desiredPitch - serverPitch;
        boolean changedTarget = previousRotationTarget != target;

        if (rotationMode.is(SUNRISE_MATRIX)) {
            float yawStep = Math.min(Math.max(Math.abs((int) yawDelta), 1.0f), 80.0f);
            float pitchStep = Math.max(changedTarget ? Math.abs(pitchDelta) : 1.0f, 2.0f);
            if (Math.abs(yawStep - previousYawStep) <= 3.0f) yawStep = previousYawStep + 3.1f;
            serverYaw += Math.copySign(yawStep * 1.0001f, yawDelta);
            serverPitch = MathHelper.clamp(serverPitch + Math.copySign(pitchStep * 1.0001f, pitchDelta),
                    -90.0f, 90.0f);
            previousYawStep = yawStep;
            return;
        }

        float random = ThreadLocalRandom.current().nextFloat();
        float yawStep = Math.min(Math.max(Math.abs(yawDelta), 1.0f), 60.0f - random * 2.0f);
        float pitchStep = Math.max(changedTarget ? Math.abs(pitchDelta) : 1.0f, 2.0f + random * 2.0f);
        if (Math.abs(yawStep - previousYawStep) <= 3.0f) yawStep = previousYawStep + 3.1f;

        float nextYaw = serverYaw + Math.copySign(yawStep, yawDelta);
        float nextPitch = serverPitch + Math.copySign(pitchStep, pitchDelta);
        serverYaw += snapToMouseGcd(client, MathHelper.wrapDegrees(nextYaw - serverYaw));
        serverPitch = MathHelper.clamp(serverPitch + snapToMouseGcd(client, nextPitch - serverPitch),
                -90.0f, 90.0f);
        previousYawStep = yawStep;
    }

    private Vec3d bestAimPoint(MinecraftClient client, ClientPlayerEntity player, LivingEntity target) {
        Box box = target.getBoundingBox();
        List<Vec3d> points = List.of(
                new Vec3d(target.getX(), target.getEyeY(), target.getZ()),
                new Vec3d(target.getX(), box.minY + box.getLengthY() * 0.5, target.getZ()),
                new Vec3d(target.getX(), box.minY + 0.05, target.getZ())
        );
        Vec3d eye = player.getEyePos();
        return points.stream()
                .filter(point -> wallBypass.enabled() || unobstructed(client, player, eye, point))
                .min(Comparator.comparingDouble(point -> pitchDifference(player, point)))
                .orElse(points.getFirst());
    }

    private static double pitchDifference(ClientPlayerEntity player, Vec3d point) {
        Vec3d delta = point.subtract(player.getEyePos());
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y,
                Math.sqrt(delta.x * delta.x + delta.z * delta.z)));
        return Math.abs(pitch - player.getPitch());
    }

    private static boolean unobstructed(MinecraftClient client, Entity source, Vec3d start, Vec3d end) {
        HitResult result = client.world.raycast(new RaycastContext(start, end,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, source));
        return result.getType() == HitResult.Type.MISS;
    }

    private static float snapToMouseGcd(MinecraftClient client, float delta) {
        double sensitivity = client.options.getMouseSensitivity().getValue();
        float base = (float) (sensitivity * 0.6 + 0.2);
        float gcd = base * base * base * 8.0f * 0.15f;
        return Math.round(delta / gcd) * gcd;
    }

    private void attackIfReady(MinecraftClient client, ClientPlayerEntity player, LivingEntity target) {
        if (player.distanceTo(target) > attackDistance.value()
                || attackDelay > 0
                || player.getAttackCooldownProgress(1.5f) < 0.93f
                || doNotAttackWhileEating.enabled() && player.isUsingItem() && !player.isBlocking()) {
            return;
        }

        boolean fallingCriticalRequired = requiresFallingCritical(client, player);
        if ((fallingCriticalRequired && (player.isOnGround() || player.fallDistance <= 0.0f))
                || !rotationHits(client, player, target)) {
            return;
        }
        if (fallingCriticalRequired) {

            if (!isVanillaCriticalDomainExceptSprint(player)
                    || !canDeferCriticalSprintStop(player)) {
                return;
            }
            if (player.isSprinting()) {
                deferCriticalAttack(client, player, target);
            } else {
                deferPostMoveCriticalAttack(client, player, target);
            }
            return;
        }

        performAttack(client, player, target);
    }

    private void performAttack(MinecraftClient client, ClientPlayerEntity player, LivingEntity target) {
        if (player.isBlocking()) client.interactionManager.stopUsingItem(player);
        boolean ownsAttackFlag = !attackInProgress;
        attackInProgress = true;
        try {
            client.interactionManager.attackEntity(player, target);
            player.swingHand(Hand.MAIN_HAND);
            breakShieldWithAura(client, player, target);
        } finally {
            if (ownsAttackFlag) {
                attackInProgress = false;
            }
        }
        attackDelay = 10;
    }

    private static boolean canDeferCriticalSprintStop(ClientPlayerEntity player) {

        return !player.hasVehicle()
                && !LongJump.shouldSpoofSprint()
                && !moduleEnabled("strafe");
    }

    private void deferCriticalAttack(
            MinecraftClient client, ClientPlayerEntity player, LivingEntity target
    ) {
        cancelDeferredCriticalAttack();
        deferredCriticalPlayer = player;
        deferredCriticalTarget = target;
        deferredCriticalWorld = client.world;
        deferredCriticalAge = player.age;
        deferredCriticalStage = DEFERRED_QUEUED;
    }

    private void deferPostMoveCriticalAttack(
            MinecraftClient client, ClientPlayerEntity player, LivingEntity target
    ) {
        cancelDeferredCriticalAttack();
        deferredCriticalPlayer = player;
        deferredCriticalTarget = target;
        deferredCriticalWorld = client.world;
        deferredCriticalAge = player.age;
        deferredCriticalStage = DEFERRED_POST_MOVE;
    }

    private boolean hasDeferredCriticalTransaction(ClientPlayerEntity player) {
        return deferredCriticalStage != DEFERRED_NONE
                && deferredCriticalPlayer == player
                && deferredCriticalTarget != null;
    }

    private boolean isDeferredCriticalStopTick(ClientPlayerEntity player) {
        return deferredCriticalStage == DEFERRED_STOPPING
                && deferredCriticalPlayer == player
                && deferredCriticalTarget != null
                && deferredCriticalAge == player.age;
    }

    private void prepareDeferredCriticalStopTick(
            MinecraftClient client, ClientPlayerEntity player
    ) {
        if (deferredCriticalStage == DEFERRED_NONE
                || deferredCriticalStage == DEFERRED_READY) {
            return;
        }
        if (deferredCriticalStage != DEFERRED_ARMED
                || !validDeferredCriticalState(
                        client, player, DEFERRED_ARMED, true)
                || !preparedRotationActive
                 || preparedRotationPlayer != player
                 || preparedRotationWorld != client.world
                 || preparedRotationAge != player.age
                 || preparedRotationTarget != deferredCriticalTarget
                 || !focusedOwnersClear(player)) {
            cancelDeferredCriticalAttack();
            return;
        }

        deferredCriticalStage = DEFERRED_STOPPING;
        deferredCriticalSprintApplied = true;
        attackInProgress = true;
        player.setSprinting(false);
    }

    private void finishDeferredCriticalMovementStage(ClientPlayerEntity player) {
        if (deferredCriticalStage == DEFERRED_NONE) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (deferredCriticalStage == DEFERRED_POST_MOVE) {
            if (validDeferredCriticalState(
                        client, player, DEFERRED_POST_MOVE, false)
                    && rotationHits(client, player, deferredCriticalTarget)) {

                transitionDeferredCriticalReady(player);
            } else {
                cancelDeferredCriticalAttack();
            }
            return;
        }

        if (deferredCriticalStage == DEFERRED_QUEUED) {
            if (validDeferredCriticalState(client, player, DEFERRED_QUEUED, true)
                    && rotationHits(client, player, deferredCriticalTarget)) {

                deferredCriticalStage = DEFERRED_ARMED;
                deferredCriticalAge = player.age + 1;
            } else {
                cancelDeferredCriticalAttack();
            }
            return;
        }

        if (deferredCriticalStage != DEFERRED_STOPPING
                || !validDeferredCriticalState(
                        client, player, DEFERRED_STOPPING, false)
                || !rotationHits(client, player, deferredCriticalTarget)) {
            cancelDeferredCriticalAttack();
            return;
        }

        transitionDeferredCriticalReady(player);
    }

    private void transitionDeferredCriticalReady(ClientPlayerEntity player) {
        boolean restoreSprint = deferredCriticalSprintApplied;
        deferredCriticalStage = DEFERRED_READY;
        deferredCriticalAge = player.age + 1;

        if (restoreSprint) {
            try {

                player.setSprinting(true);
            } finally {
                deferredCriticalSprintApplied = false;
                attackInProgress = false;
            }
        }
    }

    private void flushReadyDeferredCriticalAttack(MinecraftClient client) {
        ClientPlayerEntity queuedPlayer = deferredCriticalPlayer;
        LivingEntity queuedTarget = deferredCriticalTarget;
        boolean restoreSprint = queuedPlayer.isSprinting();

        clearDeferredCriticalState();
        try {

            queuedPlayer.setSprinting(false);
            performAttack(client, queuedPlayer, queuedTarget);
        } finally {
            queuedPlayer.setSprinting(restoreSprint);
        }
    }

    private boolean validDeferredCriticalState(
            MinecraftClient client, ClientPlayerEntity player,
            int expectedStage, boolean expectedSprinting
    ) {
        return validDeferredCriticalState(client, player, expectedStage)
                && player.isSprinting() == expectedSprinting;
    }

    private boolean validDeferredCriticalState(
            MinecraftClient client, ClientPlayerEntity player, int expectedStage
    ) {
        LivingEntity target = deferredCriticalTarget;
        return deferredCriticalStage == expectedStage
                && enabled()
                && player != null
                && player == deferredCriticalPlayer
                && player == client.player
                && player.age == deferredCriticalAge
                && client.world != null
                && client.world == deferredCriticalWorld
                && client.interactionManager != null
                && player.networkHandler != null
                && player.networkHandler.isLoaded()
                && player.isAlive()
                && !player.isRemoved()
                && player.getEntityWorld() == deferredCriticalWorld
                && target != null
                && target == selectedTarget
                && target.isAlive()
                && !target.isRemoved()
                && target.getEntityWorld() == deferredCriticalWorld
                && player.distanceTo(target) <= attackDistance.value()
                && attackDelay <= 0
                && player.getAttackCooldownProgress(1.5f) >= 0.93f
                && !(doNotAttackWhileEating.enabled()
                        && player.isUsingItem() && !player.isBlocking())
                && (!onlyWeapon.enabled()
                        || isLegacyWeapon(player.getMainHandStack()))
                && requiresFallingCritical(client, player)
                && isVanillaCriticalDomainExceptSprint(player)
                && canDeferCriticalSprintStop(player);
    }

    private boolean validReadyDeferredCriticalState(
            MinecraftClient client, ClientPlayerEntity player, LivingEntity target
    ) {
        return validDeferredCriticalState(client, player, DEFERRED_READY)
                && preparedRotationActive
                && preparedRotationPlayer == player
                && preparedRotationWorld == client.world
                && preparedRotationAge == player.age
                && preparedRotationTarget == target
                && focusedOwnersClear(player)
                && rotationHits(client, player, target);
    }

    private void cancelDeferredCriticalIfStale(
            MinecraftClient client, ClientPlayerEntity player
    ) {
        if (deferredCriticalStage == DEFERRED_NONE) {
            return;
        }
        if (deferredCriticalStage == DEFERRED_STOPPING
                && player != null
                && player == deferredCriticalPlayer
                && player == client.player
                && player.age == deferredCriticalAge
                && client.world == deferredCriticalWorld) {

            return;
        }
        if (deferredCriticalStage != DEFERRED_STOPPING) {
            cancelDeferredCriticalAttack();
            return;
        }
        cancelDeferredCriticalAttack();
    }

    private void cancelDeferredCriticalAttack() {
        ClientPlayerEntity player = deferredCriticalPlayer;
        boolean restoreSprint = deferredCriticalSprintApplied;
        if (deferredCriticalStage == DEFERRED_NONE) {
            return;
        }
        clearDeferredCriticalState();
        try {
            if (restoreSprint && player != null) {
                player.setSprinting(true);
            }
        } finally {
            if (restoreSprint) {
                attackInProgress = false;
            }
        }
    }

    private void clearDeferredCriticalState() {
        deferredCriticalPlayer = null;
        deferredCriticalTarget = null;
        deferredCriticalWorld = null;
        deferredCriticalAge = Integer.MIN_VALUE;
        deferredCriticalStage = DEFERRED_NONE;
        deferredCriticalSprintApplied = false;
    }

    public static boolean attackInProgress() {
        return attackInProgress;
    }

    private boolean requiresFallingCritical(MinecraftClient client, ClientPlayerEntity player) {
        if (!onlyCriticals.enabled()) return false;

        if (onlyWithSpace.enabled() && !client.options.jumpKey.isPressed()) return false;
        if (player.getAbilities().flying
                || player.isGliding() || player.isClimbing() || player.hasVehicle()
                || player.hasStatusEffect(StatusEffects.BLINDNESS)
                || NoClip.eaN && player.getVelocity().y < 0.0) return false;
        boolean inWater = player.isTouchingWater() || player.isSubmergedInWater();
        if (moduleEnabled("jesus") && inWater) return false;
        if (!criticalsInWater.enabled() && inWater
                && client.options.jumpKey.isPressed()) return false;
        if (!client.options.jumpKey.isPressed() && inWater) return false;
        if (obstructionCheck.enabled() && !isSkull(player.getMainHandStack())
                && nearbyObsidianColumnIsEmpty(client, player)) {
            return false;
        }
        return true;
    }

    private static boolean isVanillaCriticalDomainExceptSprint(ClientPlayerEntity player) {
        return player.fallDistance > 0.0f
                && !player.isOnGround()
                && !player.isClimbing()
                && !player.isTouchingWater()
                && !player.hasStatusEffect(StatusEffects.BLINDNESS)
                && !player.hasVehicle();
    }

    private static boolean nearbyObsidianColumnIsEmpty(MinecraftClient client, ClientPlayerEntity player) {
        BlockPos origin = player.getBlockPos();
        BlockPos nearest = null;
        double nearestDistance = Double.POSITIVE_INFINITY;
        for (int x = -5; x <= 5; x++) {
            for (int y = -5; y <= 5; y++) {
                for (int z = -5; z <= 5; z++) {
                    BlockPos pos = origin.add(x, y, z);
                    if (!client.world.getBlockState(pos).isOf(Blocks.OBSIDIAN)) continue;
                    double distance = player.squaredDistanceTo(
                            pos.getX(), pos.getY(), pos.getZ());
                    if (distance < nearestDistance) {
                        nearestDistance = distance;
                        nearest = pos;
                    }
                }
            }
        }
        if (nearest == null || nearest.getY() > player.getY()) return false;
        Box column = new Box(nearest.getX(), nearest.getY(), nearest.getZ(),
                nearest.getX() + 1.0, nearest.getY() + 3.0, nearest.getZ() + 1.0);
        return client.world.getOtherEntities(null, column).isEmpty();
    }

    private boolean rotationHits(MinecraftClient client, ClientPlayerEntity player, LivingEntity target) {
        Vec3d start = player.getEyePos();
        Vec3d look = Vec3d.fromPolar(serverPitch, serverYaw);
        Vec3d fullEnd = start.add(look.multiply(attackDistance.value()));

        if (attackBacktrack.enabled() && BackTrackModule.enabledForAura()
                && BackTrackModule.raycastHistory(target, start, fullEnd).isPresent()) {
            return true;
        }

        Vec3d end = fullEnd;
        if (!wallBypass.enabled()) {
            BlockHitResult block = client.world.raycast(new RaycastContext(start, end,
                    RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, player));
            if (block.getType() != HitResult.Type.MISS) end = block.getPos();
        }
        Box targetBox = target.getBoundingBox().expand(target.getTargetingMargin());

        if (Flight.legacyFallFlying(player)) {
            targetBox = targetBox.expand(0.0, 1.0, 0.0);
        }
        return targetBox.raycast(start, end).isPresent();
    }

    private static void breakShieldWithAura(MinecraftClient client, ClientPlayerEntity player, LivingEntity target) {
        if (target instanceof PlayerEntity other) {
            ShieldBreakerModule.breakWithAura(client, player, other);
        }
    }

    private static boolean isLegacyWeapon(ItemStack stack) {
        if (stack.isEmpty()) return false;
        String path = net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).getPath();
        return path.endsWith("_sword") || path.endsWith("_axe")
                || path.endsWith("_pickaxe") || path.endsWith("_shovel");
    }

    private static boolean isSkull(ItemStack stack) {
        String path = net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).getPath();
        return path.endsWith("_head") || path.endsWith("_skull");
    }

    private void renderTargetHud(DrawContext context, float tickProgress) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden) return;
        LegacyTargetHud.render(
                context,
                targetHud.enabled(),
                enabled() ? selectedTarget : null,
                targetHudType.is("Тип 1"),
                AttackAuraModule::clientColor,
                tickProgress);
    }

    private void collectTargetEsp(float tickProgress) {
        LivingEntity target = selectedTarget;
        if (!enabled() || !targetEsp.enabled() || target == null || !target.isAlive()) return;

        Vec3d center = target.getLerpedPos(tickProgress);
        double phase = System.currentTimeMillis() / 200.0;
        double topY = center.y + target.getHeight() * 0.5 + Math.sin(phase);
        double bottomY = topY - Math.cos(phase) * 0.5;
        double radius = 0.6;
        Vec3d previousTop = null;
        Vec3d previousBottom = null;
        for (int i = 0; i <= 45; i++) {
            double angle = Math.toRadians(i * 16.0);
            Vec3d top = new Vec3d(center.x + radius * Math.cos(angle), topY,
                    center.z + radius * Math.sin(angle));
            Vec3d bottom = new Vec3d(top.x, bottomY, top.z);
            int base = clientColor(i * 48);
            VisibilityConfigurable vertical = GizmoDrawing.line(bottom, top, withAlpha(base, 115), 1.0f);
            vertical.ignoreOcclusion();
            if (previousTop != null) {
                VisibilityConfigurable topLine = GizmoDrawing.line(
                        previousTop, top, withAlpha(base, 180), 1.5f);
                VisibilityConfigurable bottomLine = GizmoDrawing.line(
                        previousBottom, bottom, withAlpha(base, 28), 1.0f);
                topLine.ignoreOcclusion();
                bottomLine.ignoreOcclusion();
            }
            previousTop = top;
            previousBottom = bottom;
        }
    }

    private static int clientColor(int offset) {
        Module module = CelestialPortClient.MODULES.find("array_list").orElse(null);
        if (!(module instanceof ArrayListModule array)) return 0xFFC87DFF;

        int divisor = Math.max(1, 10 - (int) array.colorSpeed());
        int phase = (int) ((System.currentTimeMillis() / divisor + (long) offset) % 360L);
        if (phase < 0) phase += 360;
        return switch (array.colorMode()) {
            case "Static" -> 0xFF000000 | array.staticColor() & 0xFFFFFF;
            case "Rainbow" -> 0xFF000000 | Color.HSBtoRGB(
                    phase / 360.0f, 0.7f, 1.0f) & 0xFFFFFF;
            case "Astolfo" -> {
                float hue = phase / 360.0f;
                if (hue < 0.5f) hue = -hue;
                yield 0xFF000000 | Color.HSBtoRGB(hue, 0.7f, 1.0f) & 0xFFFFFF;
            }
            default -> {
                int triangle = (phase >= 180 ? 360 - phase : phase) * 2;
                yield blend(array.fadeFirstColor(), array.fadeSecondColor(),
                        triangle / 360.0f);
            }
        };
    }

    private static int blend(int first, int second, float amount) {
        float value = MathHelper.clamp(amount, 0.0f, 1.0f);

        int r = (int) (((first >>> 16) & 255) * (1 - value) + ((second >>> 16) & 255) * value);
        int g = (int) (((first >>> 8) & 255) * (1 - value) + ((second >>> 8) & 255) * value);
        int b = (int) ((first & 255) * (1 - value) + (second & 255) * value);
        return 0xFF000000 | r << 16 | g << 8 | b;
    }

    private static int withAlpha(int color, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24 | color & 0xFFFFFF;
    }

    private void clearTarget() {
        cancelDeferredCriticalAttack();
        selectedTarget = null;
        previousRotationTarget = null;
    }

    private void resetPreparedRotation() {
        preparedRotationPlayer = null;
        preparedRotationTarget = null;
        preparedRotationWorld = null;
        preparedRotationAge = Integer.MIN_VALUE;
        preparedRotationActive = false;
        preparedAutoExplosionSuppressed = false;
    }

    private void resetMovementContext() {
        movementRotationPlayer = null;
        movementRotationWorld = null;
        movementRotationAge = Integer.MIN_VALUE;
        movementRotationActive = false;
    }

    private void resetFocusedYawContext() {
        focusedYawPlayer = null;
        focusedYawWorld = null;
        focusedYawAge = Integer.MIN_VALUE;
        focusedYawDepth = 0;
    }

    @Override
    protected void onDisable() {
        cancelDeferredCriticalAttack();
        resetPreparedRotation();
        resetMovementContext();
        resetFocusedYawContext();
        selectedTarget = null;
        previousRotationTarget = null;
        attackDelay = 0;
        LegacyTargetHud.resetAnimation();
    }
}
