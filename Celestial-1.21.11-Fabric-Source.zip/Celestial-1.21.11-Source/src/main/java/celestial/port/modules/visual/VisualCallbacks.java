package celestial.port.modules.visual;

import celestial.port.event.SuccessfulAttackCallback;
import celestial.port.core.Module;
import celestial.port.core.ModuleManager;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.util.Identifier;

import java.util.Objects;

public final class VisualCallbacks {
    private static boolean registered;

    private VisualCallbacks() {
    }

    public static synchronized void register(ModuleManager modules) {
        Objects.requireNonNull(modules, "modules");
        if (registered) {
            throw new IllegalStateException("Visual callbacks are already registered");
        }
        registered = true;

        WorldRenderEvents.END_EXTRACTION.register(context -> {
            for (Module module : modules.modules()) {
                if (module.enabled() && module instanceof WorldVisual visual) {
                    visual.collectVisuals(context);
                }
            }
        });

        HudElementRegistry.addLast(Identifier.of("celestial", "visual_effects"), (context, tickCounter) -> {
            if (MinecraftClient.getInstance().options.hudHidden) {
                return;
            }
            for (Module module : modules.modules()) {
                if (module.enabled() && module instanceof HudVisual visual) {
                    visual.renderHud(context, tickCounter);
                }
            }
        });

        SuccessfulAttackCallback.EVENT.register((player, entity) -> {
            MinecraftClient client = MinecraftClient.getInstance();
            if (player == client.player) {
                for (Module module : modules.modules()) {
                    if (module.enabled() && module instanceof Particles particles) {
                        particles.onAttack(entity);
                    }
                }
            }
        });
    }
}
