package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.combat.AttackAuraModule;
import celestial.port.modules.combat.TargetStrafeModule;
import celestial.port.modules.impl.NoClip;
import celestial.port.modules.inventory.InventoryActions;
import celestial.port.modules.legacyutility.BaritoneBridge;
import celestial.port.mixin.accessor.ClientPlayerEntitySprintAccessor;
import celestial.port.mixin.accessor.EntityCollisionInvoker;
import celestial.port.modules.player.Disabler;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.List;
import java.util.Locale;
import java.util.OptionalInt;

public final class Strafe extends Module {
    private static final int ELYTRA_EQUIPPED = -2;
    private static final double DEFAULT_AIR_INCREMENT = 0.0255;
    private static final double COLLISION_AIR_INCREMENT = 0.0269;
    private static final double LEGACY_ELYTRA_Y = -0.4448259643949201;

    private static volatile Strafe instance;

    private static volatile boolean constructedSprintState;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "Режим", "Старый", List.of("Новый", "Старый")
    ));
    private final BooleanSetting elytraBoost = addSetting(new BooleanSetting(
            "elytra_boost", "Буст с элитрой", false
    ).visibleWhen(() -> mode.is("Старый")));
    private final NumberSetting elytraSpeed = addSetting(new NumberSetting(
            "elytra_speed", "Скорость", 1.1, 0.5, 1.5, 0.01
    ).visibleWhen(() -> mode.is("Старый") && elytraBoost.enabled()));
    private final NumberSetting fallSpeed = addSetting(new NumberSetting(
            "fall_speed", "Скорость падения", 0.8, 0.0, 1.0, 0.1
    ).visibleWhen(() -> mode.is("Старый") && elytraBoost.enabled()));
    private final BooleanSetting damageBoost = addSetting(new BooleanSetting(
            "damage_boost", "Буст от урона", false
    ).visibleWhen(() -> mode.is("Старый")));
    private final NumberSetting boostSpeed = addSetting(new NumberSetting(
            "boost_speed", "Скорость буста", 0.7, 0.5, 4.0, 0.1
    ).visibleWhen(() -> mode.is("Старый") && damageBoost.enabled()));
    private final NumberSetting boostDuration = addSetting(new NumberSetting(
            "boost_duration", "Длительность буста", 10.0, 10.0, 25.0, 1.0
    ).visibleWhen(() -> mode.is("Старый") && damageBoost.enabled()));

    private ClientPlayerEntity observedPlayer;

    private double momentum;

    private double lastFriction;
    private boolean pendingSprintFlip;
    private boolean desiredSprintState;
    private int decayAlternation;
    private int itemOverspeedTicks;

    private boolean wasInsideCobweb;
    private boolean correctionKeyRelease;

    private int elytraSource = PlayerInventory.NOT_FOUND;
    private boolean elytraAvailable;
    private boolean elytraPulsePending;
    private float elytraIncrement = (float) DEFAULT_AIR_INCREMENT;
    private long lastElytraPulse;
    private int pendingElytraRestore = PlayerInventory.NOT_FOUND;

    private boolean verifiedDamage;
    private boolean excludeNextDamage;
    private long damageStartedAt;

    public Strafe() {
        super("strafe", "Strafe", "Позволяет стрейфиться", Category.MOVEMENT);
        instance = this;
    }

    public static boolean elytraBoostActive() {
        Strafe module = active();
        return module != null && module.elytraAvailable;
    }

    public static void beginPlayerTick(ClientPlayerEntity player) {
        Disabler.refreshLegacyModuleDispatch(player);
        MinecraftClient client = MinecraftClient.getInstance();
        Strafe dormant = instance;
        if (dormant != null && client.player == player) {
            if (dormant.observedPlayer == player) {

                dormant.restorePendingElytra(client, player);
            } else {

                dormant.pendingElytraRestore = PlayerInventory.NOT_FOUND;
            }
        }
        Strafe module = activeFor(player);
        if (module == null) {
            return;
        }
        module.observe(player);
        module.wasInsideCobweb = MovementSupport.isInsideCobweb(player);

        if (module.correctionKeyRelease) {
            client.options.forwardKey.setPressed(false);
            client.options.backKey.setPressed(false);
            client.options.leftKey.setPressed(false);
            client.options.rightKey.setPressed(false);
            if (player.age % 6 == 0) {
                module.correctionKeyRelease = false;
                module.momentum = 0.0;
            }
        }

        if (module.excludeNextDamage && player.hurtTime > 0) {
            module.excludeNextDamage = false;
        }
        module.updateElytraState(player);
    }

    public static Vec3d adjustMovement(ClientPlayerEntity player, Vec3d movement) {
        Strafe module = activeFor(player);
        if (module == null) {
            return movement;
        }
        module.observe(player);
        MinecraftClient client = MinecraftClient.getInstance();
        if (!module.canStrafe(client, player)) {
            module.momentum = 0.0;
            return movement;
        }
        Vec3d collisionAdjusted = ((EntityCollisionInvoker) player)
                .celestial$invokeAdjustMovementForCollisions(movement);
        boolean predictedOnGround = movement.y < 0.0
                && movement.y != collisionAdjusted.y;
        return module.mode.is("Новый")
                ? module.adjustNew(player, movement)
                : module.adjustOld(client, player, movement, predictedOnGround);
    }

    public static void afterMovement(ClientPlayerEntity player, double movedHorizontal) {
        Strafe module = activeFor(player);
        if (module != null && Double.isFinite(movedHorizontal)) {
            module.momentum = Math.max(0.0, movedHorizontal) * module.lastFriction;
        }
    }

    public static boolean cancelsInputSlowdown(ClientPlayerEntity player) {
        Strafe module = activeFor(player);
        return module != null && module.mode.is("Старый")
                && (module.canStrafe(MinecraftClient.getInstance(), player)
                || module.elytraAvailable);
    }

    public static boolean rewriteSprintState(
            ClientPlayerEntity player, boolean requested, boolean lastSprinting
    ) {
        Strafe module = activeFor(player);
        if (module == null) {
            return requested;
        }

        if (isReallyWorldServer()) {
            return requested;
        }

        boolean rewritten = requested;
        if (module.canStrafe(MinecraftClient.getInstance(), player)
                && !AttackAuraModule.attackInProgress()
                && constructedSprintState != module.desiredSprintState) {
            rewritten = !constructedSprintState;
        }
        if (module.pendingSprintFlip) {
            rewritten = !lastSprinting;
            module.pendingSprintFlip = false;
        }
        return rewritten;
    }

    public static void observeSprintCommand(ClientCommandC2SPacket.Mode mode) {
        if (mode == ClientCommandC2SPacket.Mode.START_SPRINTING) {
            constructedSprintState = true;
        } else if (mode == ClientCommandC2SPacket.Mode.STOP_SPRINTING) {
            constructedSprintState = false;
        }
    }

    public static void onEntityDamage(EntityDamageS2CPacket packet) {
        Strafe module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (module == null || player == null || client.world == null
                || packet.entityId() != player.getId()) {
            return;
        }
        module.observe(player);
        if (hasExcludedDamageEffect(player)) {
            return;
        }

        DamageSource source = packet.createDamageSource(client.world);
        boolean excluded = source.isOf(DamageTypes.FALL)
                || source.isOf(DamageTypes.ENDER_PEARL)
                || source.isOf(DamageTypes.ARROW)
                || source.isIn(DamageTypeTags.IS_EXPLOSION);
        if (module.excludeNextDamage || excluded) {
            module.clearDamage();
            module.excludeNextDamage = false;
            return;
        }
        if (!module.damageBoost.enabled()) {
            return;
        }

        if (!module.verifiedDamage) {
            module.verifiedDamage = true;
            module.damageStartedAt = System.currentTimeMillis();
        }
    }

    public static void onExplosion() {
        Strafe module = active();
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (module == null || !module.damageBoost.enabled()
                || player == null || hasExcludedDamageEffect(player)) {
            return;
        }
        module.clearDamage();
        module.excludeNextDamage = player.hurtTime <= 0;
    }

    public static void onServerCorrection() {
        Strafe module = active();
        if (module == null || moduleEnabled("free_camera")) {
            return;
        }
        module.correctionKeyRelease = true;
        module.momentum = 0.0;
    }

    @Override
    protected void onEnable() {
        observe(MinecraftClient.getInstance().player);

        momentum = 0.15;
    }

    @Override
    protected void onTick() {
        observe(MinecraftClient.getInstance().player);
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        wasInsideCobweb = false;
        elytraAvailable = false;
        elytraSource = PlayerInventory.NOT_FOUND;
    }

    @Override
    protected void onDisable() {
        cleanupLegacyDispatch();
    }

    @Override
    protected void onLegacyDispatchSuspended() {
        cleanupLegacyDispatch();
    }

    private void cleanupLegacyDispatch() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (observedPlayer != null && observedPlayer == client.player) {
            restorePendingElytra(client, observedPlayer);
        }
        if (observedPlayer != null && observedPlayer == client.player) {
            Vec3d velocity = observedPlayer.getVelocity();
            observedPlayer.setVelocity(velocity.x * 0.7, velocity.y, velocity.z * 0.7);
        }

        wasInsideCobweb = false;
        elytraAvailable = false;
        elytraSource = PlayerInventory.NOT_FOUND;
    }

    private Vec3d adjustNew(ClientPlayerEntity player, Vec3d movement) {
        double current = player.getVelocity().horizontalLength();
        double floor = 0.2499 - ((player.age & 1) == 0 ? 0.0001 : 0.0);
        double target = current > floor ? current * 1.0075 : floor;
        boolean projectedCollision = collides(player,
                player.getBoundingBox().offset(0.0, player.getVelocity().y, 0.0));
        boolean landing = player.isOnGround() && player.verticalCollision && !jumpPressed(player);

        if (current < 0.24 && !player.isOnGround()
                && !player.horizontalCollision && !landing) {
            return applyNewVector(player, movement, target);
        }
        if ((player.isOnGround() || projectedCollision)
                && !wasInsideCobweb && !insideFluid(player)) {
            return applyNewVector(player, movement, current);
        }
        return movement;
    }

    private Vec3d applyNewVector(ClientPlayerEntity player, Vec3d movement, double speed) {
        Vec3d direction = normalizedLegacyDirection(player);
        if (!MovementSupport.hasDirection(direction)) {
            momentum = 0.0;
            Vec3d velocity = player.getVelocity();
            player.setVelocity(0.0, velocity.y, 0.0);
            return new Vec3d(0.0, movement.y, 0.0);
        }
        Vec3d velocity = player.getVelocity();
        player.setVelocity(direction.x * speed, velocity.y, direction.z * speed);
        return new Vec3d(direction.x * speed, movement.y, direction.z * speed);
    }

    private Vec3d adjustOld(
            MinecraftClient client, ClientPlayerEntity player,
            Vec3d movement, boolean predictedOnGround
    ) {

        client.options.getFovEffectScale().setValue(0.0);
        if (damageBoost.enabled()) {
            expireDamageWindow();
        }

        boolean onGround = player.isOnGround();
        boolean rising = movement.y > 0.0;

        float friction = 0.91F;
        if (onGround) {
            BlockPos below = BlockPos.ofFloored(
                    player.getX(), player.getBoundingBox().minY - 1.0, player.getZ());
            friction = player.getEntityWorld().getBlockState(below)
                    .getBlock().getSlipperiness() * 0.91F;
        }

        double increment;
        if (onGround) {
            double groundFactor = 0.16277136F / (friction * friction * friction);
            increment = movementSpeedWithoutSprint(player) * groundFactor;
            if (rising) {
                increment += 0.2F;
            }
        } else if (elytraAvailable) {
            increment = elytraIncrement;
        } else if (damageBoost.enabled() && verifiedDamage) {
            increment = boostSpeed.value() / 10.0;
        } else {
            increment = predictedOnGround ? COLLISION_AIR_INCREMENT : DEFAULT_AIR_INCREMENT;
        }

        double speed = momentum + increment;
        boolean itemOverspeed = false;
        if (player.isUsingItem() && !rising) {
            double threshold = increment * 0.5 + 0.005;
            if (movement.y != 0.0 && Math.abs(movement.y) < 0.08) {
                threshold += 0.055;
            }
            if (speed > Math.max(0.043, threshold)) {
                itemOverspeed = true;
                itemOverspeedTicks++;
            } else {
                itemOverspeedTicks = Math.max(itemOverspeedTicks - 1, 0);
            }
        } else {
            itemOverspeedTicks = 0;
        }

        if (player.isUsingItem() && !jumpPressed(player) && onGround) {
            double slowdown = (1.0 - player.getAttributeValue(EntityAttributes.MOVEMENT_SPEED))
                    * 0.9 + 0.02;
            if (player.sidewaysSpeed != 0.0F || backPressed(player)) {
                slowdown *= 0.9;
            }
            speed *= slowdown;
        }

        if (itemOverspeedTicks > 3) {
            speed -= 0.019;
        } else if (!player.horizontalCollision) {
            speed = Math.max(itemOverspeed ? 0.0 : 0.05, speed)
                    - ((decayAlternation++ & 1) == 0 ? 0.001 : 0.002);
        }

        lastFriction = friction;
        if (!predictedOnGround && !onGround) {
            pendingSprintFlip = true;
            desiredSprintState = !((ClientPlayerEntitySprintAccessor) player)
                    .celestial$getLastSprinting();
        }
        if (predictedOnGround && onGround) {
            desiredSprintState = false;
        }

        boolean elytraTrigger = elytraBoost.enabled() && elytraAvailable && !onGround
                && collides(player, player.getBoundingBox().offset(
                0.0, player.getVelocity().y - 0.5, 0.0));
        if (elytraTrigger && !elytraPulsePending) {
            requestElytraPulse(client, player);
        } else if (elytraPulsePending && onGround) {
            elytraPulsePending = false;
        }

        Vec3d direction = normalizedLegacyDirection(player);
        if (!MovementSupport.hasDirection(direction)) {
            return new Vec3d(0.0, movement.y, 0.0);
        }
        return new Vec3d(direction.x * speed, movement.y, direction.z * speed);
    }

    private void updateElytraState(ClientPlayerEntity player) {
        if (!elytraBoost.enabled()) {
            elytraAvailable = false;
            elytraSource = PlayerInventory.NOT_FOUND;
            return;
        }

        elytraAvailable = false;
        elytraSource = findUsableElytra(player);
        if (elytraSource == PlayerInventory.NOT_FOUND) {
            return;
        }

        if (elytraPulsePending) {
            if (collides(player, player.getBoundingBox().offset(
                    0.0, player.getVelocity().y, 0.0))) {
                elytraIncrement = player.getVelocity().y == LEGACY_ELYTRA_Y
                        ? (float) (elytraSpeed.value() - 0.05)
                        : fallSpeed.value().floatValue();
            }
            elytraPulsePending = false;
        } else {
            elytraIncrement = (float) DEFAULT_AIR_INCREMENT;
        }
        elytraAvailable = true;
    }

    private void requestElytraPulse(
            MinecraftClient client, ClientPlayerEntity player
    ) {
        if (elytraSource == PlayerInventory.NOT_FOUND) {
            return;
        }

        long now = System.currentTimeMillis();
        if (!Disabler.vulcanElytraActive() && now - lastElytraPulse > 190L) {
            boolean equipped = elytraSource == ELYTRA_EQUIPPED;
            int source = elytraSource;
            boolean swapped = equipped || beginElytraPulseSwap(client, source);
            if (swapped) {
                try {
                    player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                            player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                    player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                            player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                    lastElytraPulse = now;
                } finally {
                    if (!equipped) {
                        boolean restored = finishElytraPulseSwap(client, source);
                        pendingElytraRestore = restored
                                ? PlayerInventory.NOT_FOUND : source;
                    }
                }
            }
        }

        elytraPulsePending = true;
    }

    private boolean canStrafe(MinecraftClient client, ClientPlayerEntity player) {

        if (NoClip.blocksStrafe(player)) {
            return false;
        }
        if (client.world == null || client.player != player || !player.isAlive()
                || player.isRemoved() || player.isSpectator()
                || BaritoneBridge.isAnyProcessActive()
                || player.isSneaking() || player.isGliding()
                || insideFluid(player)
                || MovementSupport.isInsideCobweb(player)
                || soulSandBelow(player)
                || damageSpeedActive()
                || blockedSpeedMode()
                || moduleEnabled("elytra_flight")
                || moduleEnabled("free_camera")
                || moduleEnabled("flight")
                || TargetStrafeModule.orbiting()
                || LongJump.offGroundSpeed(player) != null && !player.isOnGround()
                || moduleEnabled("spider") && player.horizontalCollision
                || player.getAbilities().flying
                || player.hasStatusEffect(StatusEffects.LEVITATION)) {
            return false;
        }
        return !moduleEnabled("jesus") || !fluidBelow(player, 0.1);
    }

    private void expireDamageWindow() {
        if (verifiedDamage && System.currentTimeMillis() - damageStartedAt
                > Math.round(boostDuration.value() * 50.0)) {
            clearDamage();
        }
    }

    private void clearDamage() {
        verifiedDamage = false;
        damageStartedAt = 0L;
    }

    private void observe(ClientPlayerEntity player) {
        if (player == observedPlayer) {
            return;
        }
        observedPlayer = player;
        wasInsideCobweb = false;
        correctionKeyRelease = false;
        elytraSource = PlayerInventory.NOT_FOUND;
        elytraAvailable = false;
        elytraPulsePending = false;
        pendingElytraRestore = PlayerInventory.NOT_FOUND;
        itemOverspeedTicks = 0;
        pendingSprintFlip = false;
        clearDamage();
        excludeNextDamage = false;
        momentum = 0.0;
        lastFriction = 0.0;
    }

    private static float movementSpeedWithoutSprint(ClientPlayerEntity player) {
        boolean sprinting = player.isSprinting();
        player.setSprinting(false);
        try {
            return (float) player.getAttributeValue(EntityAttributes.MOVEMENT_SPEED) * 1.3F;
        } finally {
            player.setSprinting(sprinting);
        }
    }

    private static int findUsableElytra(ClientPlayerEntity player) {
        if (isElytra(player.getEquippedStack(EquipmentSlot.CHEST))) {
            return ELYTRA_EQUIPPED;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.currentScreen instanceof HandledScreen<?>
                && !(client.currentScreen instanceof InventoryScreen)) {
            return PlayerInventory.NOT_FOUND;
        }

        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (canGlide(inventory.getStack(slot))) {
                return slot;
            }
        }
        if (canGlide(inventory.getStack(PlayerInventory.OFF_HAND_SLOT))) {
            return PlayerInventory.OFF_HAND_SLOT;
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static boolean canGlide(ItemStack stack) {
        return LivingEntity.canGlideWith(stack, EquipmentSlot.CHEST);
    }

    private static boolean isElytra(ItemStack stack) {
        return stack.isOf(Items.ELYTRA);
    }

    private static boolean beginElytraPulseSwap(MinecraftClient client, int sourceIndex) {
        ClientPlayerEntity player = client.player;
        if (!canAccessPlayerInventory(client, true) || player == null) {
            return false;
        }
        ScreenHandler handler = player.playerScreenHandler;
        OptionalInt sourceSlotId = handler.getSlotIndex(player.getInventory(), sourceIndex);
        OptionalInt chestSlotId = handler.getSlotIndex(
                player.getInventory(), InventoryActions.CHEST_INVENTORY_INDEX);
        if (sourceSlotId.isEmpty() || chestSlotId.isEmpty()) {
            return false;
        }
        Slot source = handler.getSlot(sourceSlotId.getAsInt());
        Slot chest = handler.getSlot(chestSlotId.getAsInt());
        ItemStack elytra = source.getStack();
        ItemStack equipped = chest.getStack();
        if (!isElytra(elytra) || !source.canTakeItems(player) || !chest.canInsert(elytra)
                || !equipped.isEmpty()
                && (!chest.canTakeItems(player) || !source.canInsert(equipped))) {
            return false;
        }
        client.interactionManager.clickSlot(
                handler.syncId, source.id, 1, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(
                handler.syncId, chest.id, 1, SlotActionType.PICKUP, player);
        return isElytra(chest.getStack());
    }

    private static boolean finishElytraPulseSwap(MinecraftClient client, int sourceIndex) {
        ClientPlayerEntity player = client.player;
        if (!canAccessPlayerInventory(client, false) || player == null) {
            return false;
        }
        ScreenHandler handler = player.playerScreenHandler;
        OptionalInt sourceSlotId = handler.getSlotIndex(player.getInventory(), sourceIndex);
        OptionalInt chestSlotId = handler.getSlotIndex(
                player.getInventory(), InventoryActions.CHEST_INVENTORY_INDEX);
        if (sourceSlotId.isEmpty() || chestSlotId.isEmpty()) {
            return false;
        }
        Slot source = handler.getSlot(sourceSlotId.getAsInt());
        Slot chest = handler.getSlot(chestSlotId.getAsInt());
        client.interactionManager.clickSlot(
                handler.syncId, chest.id, 1, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(
                handler.syncId, source.id, 1, SlotActionType.PICKUP, player);
        return handler.getCursorStack().isEmpty() && isElytra(source.getStack());
    }

    private static boolean canAccessPlayerInventory(
            MinecraftClient client, boolean requireEmptyCursor
    ) {
        ClientPlayerEntity player = client.player;
        return player != null && player.isAlive()
                && client.interactionManager != null
                && client.getNetworkHandler() != null
                && (!(client.currentScreen instanceof HandledScreen<?>)
                || client.currentScreen instanceof InventoryScreen)
                && player.currentScreenHandler == player.playerScreenHandler
                && (!requireEmptyCursor
                || player.playerScreenHandler.getCursorStack().isEmpty());
    }

    private static boolean swapInventorySlots(
            MinecraftClient client, int sourceIndex, int destinationIndex
    ) {
        ClientPlayerEntity player = client.player;
        if (player == null || !player.isAlive() || client.interactionManager == null
                || client.getNetworkHandler() == null || sourceIndex == destinationIndex
                || client.currentScreen instanceof HandledScreen<?>
                && !(client.currentScreen instanceof InventoryScreen)
                || player.currentScreenHandler != player.playerScreenHandler
                || !player.playerScreenHandler.getCursorStack().isEmpty()) {
            return false;
        }

        ScreenHandler handler = player.playerScreenHandler;
        OptionalInt sourceSlotId = handler.getSlotIndex(player.getInventory(), sourceIndex);
        OptionalInt destinationSlotId = handler.getSlotIndex(player.getInventory(), destinationIndex);
        if (sourceSlotId.isEmpty() || destinationSlotId.isEmpty()) {
            return false;
        }

        Slot source = handler.getSlot(sourceSlotId.getAsInt());
        Slot destination = handler.getSlot(destinationSlotId.getAsInt());
        ItemStack sourceStack = source.getStack();
        ItemStack destinationStack = destination.getStack();
        if ((sourceStack.isEmpty() && destinationStack.isEmpty())
                || (!sourceStack.isEmpty()
                && (!source.canTakeItems(player) || !destination.canInsert(sourceStack)))
                || (!destinationStack.isEmpty()
                && (!destination.canTakeItems(player) || !source.canInsert(destinationStack)))) {
            return false;
        }

        client.interactionManager.clickSlot(
                handler.syncId, source.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(
                handler.syncId, destination.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(
                handler.syncId, source.id, 0, SlotActionType.PICKUP, player);
        return handler.getCursorStack().isEmpty();
    }

    private void restorePendingElytra(
            MinecraftClient client, ClientPlayerEntity player
    ) {
        int source = pendingElytraRestore;
        if (source == PlayerInventory.NOT_FOUND) {
            return;
        }
        if (isElytra(player.getInventory().getStack(source))) {
            pendingElytraRestore = PlayerInventory.NOT_FOUND;
            return;
        }
        if (!isElytra(player.getEquippedStack(EquipmentSlot.CHEST))) {
            ScreenHandler handler = player.playerScreenHandler;
            OptionalInt sourceSlotId = handler.getSlotIndex(player.getInventory(), source);
            if (sourceSlotId.isPresent()
                    && isElytra(handler.getCursorStack())
                    && handler.getSlot(sourceSlotId.getAsInt()).getStack().isEmpty()
                    && canAccessPlayerInventory(client, false)) {
                client.interactionManager.clickSlot(handler.syncId,
                        handler.getSlot(sourceSlotId.getAsInt()).id,
                        1, SlotActionType.PICKUP, player);
                if (handler.getCursorStack().isEmpty()
                        && isElytra(player.getInventory().getStack(source))) {
                    pendingElytraRestore = PlayerInventory.NOT_FOUND;
                }
            }
            return;
        }
        if (finishElytraPulseSwap(client, source)
                && isElytra(player.getInventory().getStack(source))) {
            pendingElytraRestore = PlayerInventory.NOT_FOUND;
        }
    }

    private static Vec3d normalizedLegacyDirection(ClientPlayerEntity player) {
        Vec3d direction = MovementSupport.legacyInputDirection(player);
        double length = direction.horizontalLength();
        if (length <= 1.0E-7) {
            return Vec3d.ZERO;
        }
        return new Vec3d(direction.x / length, 0.0, direction.z / length);
    }

    private static boolean insideFluid(ClientPlayerEntity player) {
        return player.isTouchingWater() || player.isInLava()
                || player.getEntityWorld().containsFluid(player.getBoundingBox());
    }

    private static boolean fluidBelow(ClientPlayerEntity player, double offset) {
        BlockPos below = BlockPos.ofFloored(
                player.getX(), player.getY() - offset, player.getZ());
        return !player.getEntityWorld().getFluidState(below).isEmpty();
    }

    private static boolean soulSandBelow(ClientPlayerEntity player) {
        BlockPos below = BlockPos.ofFloored(
                player.getX(), player.getY() - 0.01, player.getZ());
        return player.getEntityWorld().getBlockState(below).isOf(Blocks.SOUL_SAND);
    }

    private static boolean collides(ClientPlayerEntity player, Box box) {
        return !player.getEntityWorld().isSpaceEmpty(player, box);
    }

    private static boolean jumpPressed(ClientPlayerEntity player) {
        return player.input != null && player.input.playerInput.jump();
    }

    private static boolean backPressed(ClientPlayerEntity player) {
        return player.input != null && player.input.playerInput.backward();
    }

    private static boolean hasExcludedDamageEffect(ClientPlayerEntity player) {
        return player.hasStatusEffect(StatusEffects.POISON)
                || player.hasStatusEffect(StatusEffects.WITHER)
                || player.hasStatusEffect(StatusEffects.INSTANT_DAMAGE);
    }

    private static boolean damageSpeedActive() {
        Module raw = CelestialPortClient.MODULES.find("damage_speed").orElse(null);
        return raw instanceof DamageSpeed module && module.enabled() && module.damageActive();
    }

    private static boolean blockedSpeedMode() {
        Module raw = CelestialPortClient.MODULES.find("speed").orElse(null);
        return raw instanceof Speed speed && speed.enabled()
                && (speed.mode().is("Sunrise Damage") || speed.mode().is("Vulcan"));
    }

    private static boolean isReallyWorldServer() {
        var entry = MinecraftClient.getInstance().getCurrentServerEntry();
        if (entry == null) {
            return false;
        }
        String marker = (entry.name + " " + entry.address).toLowerCase(Locale.ROOT);
        return marker.contains("reallyworld") || marker.contains("really world")
                || marker.contains("playrw");
    }

    private static boolean moduleEnabled(String id) {
        return CelestialPortClient.MODULES.find(id).filter(Module::enabled).isPresent();
    }

    private static Strafe activeFor(ClientPlayerEntity player) {
        Strafe module = active();
        return module != null && MinecraftClient.getInstance().player == player ? module : null;
    }

    private static Strafe active() {
        Strafe module = instance;
        return module != null && module.enabled() && module.legacyDispatchActive() ? module : null;
    }
}
