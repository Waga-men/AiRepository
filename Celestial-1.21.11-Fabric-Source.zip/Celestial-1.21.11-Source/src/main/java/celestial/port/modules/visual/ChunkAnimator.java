package celestial.port.modules.visual;

import celestial.port.core.Category;
import celestial.port.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.chunk.ChunkBuilder;

import java.util.WeakHashMap;

public final class ChunkAnimator extends Module {
    private static final long DURATION_MS = 600L;
    private static volatile ChunkAnimator instance;

    private final WeakHashMap<ChunkBuilder.BuiltChunk, Long> animationStarts = new WeakHashMap<>();

    public ChunkAnimator() {
        super("chunk_animator", "Chunk Animator", "Анимирует появление чанков", Category.RENDER);
        instance = this;
    }

    public static void onBuiltChunk(ChunkBuilder.BuiltChunk chunk) {
        ChunkAnimator module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || client.player == null || client.world == null) {
            return;
        }
        synchronized (module.animationStarts) {
            module.animationStarts.putIfAbsent(chunk, -1L);
        }
    }

    public static float verticalOffset(ChunkBuilder.BuiltChunk chunk) {
        ChunkAnimator module = instance;
        if (module == null || !module.enabled()) {
            return 0.0F;
        }

        long now = System.currentTimeMillis();
        long started;
        synchronized (module.animationStarts) {
            Long stored = module.animationStarts.get(chunk);
            if (stored == null) {
                return 0.0F;
            }
            if (stored == -1L) {
                stored = now;
                module.animationStarts.put(chunk, stored);
            }
            started = stored;
        }

        long elapsed = now - started;
        if (elapsed > DURATION_MS) {
            return 0.0F;
        }

        double progress = Math.max(0.0, (double) elapsed / DURATION_MS);
        double shifted = progress - 1.0;
        double eased = shifted * shifted * shifted + 1.0;
        double originY = chunk.getOrigin().getY();
        return (float) (-originY + originY * eased);
    }

    public static float visibility(ChunkBuilder.BuiltChunk chunk, float vanillaVisibility) {
        ChunkAnimator module = instance;
        if (module == null || !module.enabled()) {
            return vanillaVisibility;
        }
        synchronized (module.animationStarts) {
            return module.animationStarts.containsKey(chunk) ? 1.0F : vanillaVisibility;
        }
    }
}
