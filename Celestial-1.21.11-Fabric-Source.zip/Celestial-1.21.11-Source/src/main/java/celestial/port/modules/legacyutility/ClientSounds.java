package celestial.port.modules.legacyutility;

import celestial.port.client.audio.WavPlayer;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.ModuleFeedback;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public final class ClientSounds extends Module {
    private static final AtomicBoolean INITIALIZED = new AtomicBoolean();
    private static volatile ClientSounds activeInstance;

    private final ModeSetting sound = addSetting(new ModeSetting(
            "mode", "Режим", "Sigma", List.of("Sigma", "Notify", "Intuition")
    ));
    private final NumberSetting volume = addSetting(new NumberSetting(
            "volume", "Громкость", 0.3, 0.1, 1.0, 0.1
    ));

    public ClientSounds() {
        super("client_sounds", "Client Sounds",
                "Воспроизводит звуки при включении/выключении модулей", Category.UTILITY);
        activeInstance = this;
        initialize();
    }

    public static void initialize() {
        if (INITIALIZED.compareAndSet(false, true)) {
            ModuleFeedback.listen(ClientSounds::onModuleStateChanged);
        }
    }

    public ModeSetting sound() {
        return sound;
    }

    public NumberSetting volume() {
        return volume;
    }

    private static void onModuleStateChanged(Module module, boolean enabled) {
        ClientSounds sounds = activeInstance;
        MinecraftClient client = MinecraftClient.getInstance();

        if (sounds == null || !sounds.enabled() || client.player == null
                || module.id().equals("click_gui")) {
            return;
        }
        client.execute(() -> sounds.play(client, enabled));
    }

    private void play(MinecraftClient client, boolean enabled) {
        String family = sound.value().toLowerCase(java.util.Locale.ROOT);
        String state = enabled ? "enable" : "disable";
        WavPlayer.play("/assets/celestial/sounds/clientsounds/"
                + family + "_" + state + ".wav", volume.value().floatValue());
    }
}
