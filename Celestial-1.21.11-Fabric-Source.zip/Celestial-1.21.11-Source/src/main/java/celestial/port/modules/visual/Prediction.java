package celestial.port.modules.visual;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientWorldEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.entity.projectile.PersistentProjectileEntity;
import net.minecraft.entity.projectile.thrown.EggEntity;
import net.minecraft.entity.projectile.thrown.EnderPearlEntity;
import net.minecraft.entity.projectile.thrown.PotionEntity;
import net.minecraft.entity.projectile.thrown.SnowballEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;
import net.minecraft.world.debug.gizmo.GizmoDrawing;
import net.minecraft.world.debug.gizmo.VisibilityConfigurable;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

public final class Prediction extends Module implements WorldVisual {
    private static final String PEARLS = "Эндер пёрлы";
    private static final String ARROWS = "Стрелы";
    private static final String SNOWBALLS = "Снежки";
    private static final String EGGS = "Яйца";
    private static final String POTIONS = "Зелья";
    private static final String FISHING = "Удочки";

    private static final Cache EMPTY_CACHE = new Cache(null, null, List.of());
    private static Prediction instance;
    private static boolean worldListenerRegistered;

    private final ModeSetting colorMode = addSetting(new ModeSetting(
            "mode", "Режим", "Client", List.of("Client", "Static")
    ));
    private final MultiSelectSetting projectiles = addSetting(new MultiSelectSetting(
            "objects", "Выбор объектов", Set.of(PEARLS),
            List.of(PEARLS, ARROWS, SNOWBALLS, EGGS, POTIONS, FISHING)
    ));
    private final ColorSetting color = addSetting(new ColorSetting(
            "color", "Цвет", 0xFFFFFFFF
    ).visibleWhen(() -> colorMode.is("Static")));

    private volatile Cache cache = EMPTY_CACHE;

    public Prediction() {
        super("prediction", "Prediction",
                "Рисует траекторию стрел, эндер-пёрлов, снежков и других снарядов",
                Category.RENDER);
        instance = this;
        synchronized (Prediction.class) {
            if (!worldListenerRegistered) {
                worldListenerRegistered = true;
                ClientWorldEvents.AFTER_CLIENT_WORLD_CHANGE.register((client, world) -> clearCache());
            }
        }
    }

    public interface FishingState {
        boolean celestial$isPredictionFlying();
    }

    public static void captureAtPlayerTick(ClientPlayerEntity player) {
        Prediction prediction = instance;
        if (prediction == null) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (!prediction.enabled()) {
            prediction.cache = EMPTY_CACHE;
            return;
        }
        if (client.player != player) {
            return;
        }

        ClientWorld world = client.world;
        ClientPlayNetworkHandler networkHandler = client.getNetworkHandler();
        if (world == null || networkHandler == null || player.getEntityWorld() != world) {
            prediction.cache = EMPTY_CACHE;
            return;
        }
        prediction.rebuildCache(world, networkHandler);
    }

    @Override
    protected void onEnable() {
        cache = EMPTY_CACHE;
    }

    @Override
    protected void onDisable() {
        cache = EMPTY_CACHE;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        cache = EMPTY_CACHE;
    }

    @Override
    public void collectVisuals(WorldExtractionContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        Cache snapshot = cache;
        if (client.world == null
                || context.world() != client.world
                || snapshot.world() != client.world
                || snapshot.networkHandler() != client.getNetworkHandler()) {
            return;
        }

        boolean staticMode = colorMode.is("Static");
        int staticColor = color.argb();
        for (Segment segment : snapshot.segments()) {
            int lineColor = staticMode ? staticColor : segment.clientColor();
            VisibilityConfigurable line = GizmoDrawing.line(
                    segment.start(), segment.end(), lineColor, 1.5F);
            line.ignoreOcclusion();
        }
    }

    private static void clearCache() {
        Prediction prediction = instance;
        if (prediction != null) {
            prediction.cache = EMPTY_CACHE;
        }
    }

    private void rebuildCache(ClientWorld world, ClientPlayNetworkHandler networkHandler) {
        ArrayList<Segment> next = new ArrayList<>();
        for (Entity entity : world.getEntities()) {
            Profile profile = profile(entity);
            if (profile == null) {
                continue;
            }
            if (entity instanceof PersistentProjectileEntity
                    && entity.getX() == entity.lastX
                    && entity.getY() == entity.lastY
                    && entity.getZ() == entity.lastZ) {
                continue;
            }
            simulate(world, entity, profile, next);
        }
        cache = new Cache(world, networkHandler, List.copyOf(next));
    }

    private Profile profile(Entity entity) {
        if (entity instanceof EnderPearlEntity && projectiles.selected(PEARLS)) {
            return new Profile((double) 0.03F, 0.8F, RaycastContext.ShapeType.OUTLINE);
        }
        if (entity instanceof PersistentProjectileEntity && projectiles.selected(ARROWS)) {
            return new Profile((double) 0.05F, 0.6F, RaycastContext.ShapeType.COLLIDER);
        }
        if (entity instanceof SnowballEntity && projectiles.selected(SNOWBALLS)) {
            return new Profile((double) 0.03F, 0.8F, RaycastContext.ShapeType.OUTLINE);
        }
        if (entity instanceof EggEntity && projectiles.selected(EGGS)) {
            return new Profile((double) 0.03F, 0.8F, RaycastContext.ShapeType.OUTLINE);
        }
        if (entity instanceof PotionEntity && projectiles.selected(POTIONS)) {
            return new Profile((double) 0.05F, 0.8F, RaycastContext.ShapeType.OUTLINE);
        }
        if (entity instanceof FishingBobberEntity
                && projectiles.selected(FISHING)
                && entity instanceof FishingState state
                && state.celestial$isPredictionFlying()) {
            return new Profile((double) 0.05F, 0.8F, RaycastContext.ShapeType.COLLIDER);
        }
        return null;
    }

    private void simulate(ClientWorld world, Entity projectile, Profile profile, List<Segment> output) {
        if (!world.isSpaceEmpty(projectile, projectile.getBoundingBox())) {
            return;
        }

        double x = projectile.getX();
        double y = projectile.getY();
        double z = projectile.getZ();
        Vec3d velocity = projectile.getVelocity();
        double velocityX = velocity.x;
        double velocityY = velocity.y;
        double velocityZ = velocity.z;

        for (int step = 0; step < 360; step++) {
            Vec3d start = new Vec3d(x, y, z);
            float drag = 0.99F;
            x += velocityX;
            y += velocityY;
            z += velocityZ;

            if (world.getBlockState(BlockPos.ofFloored(x, y, z)).isOf(Blocks.WATER)) {
                drag = profile.waterDrag();
            }
            velocityX *= (double) drag;
            velocityY *= (double) drag;
            velocityZ *= (double) drag;
            if (!projectile.hasNoGravity()) {
                velocityY -= profile.gravity();
            }

            Collision collision = collide(world, projectile, start, new Vec3d(x, y, z), profile.shapeType());
            Vec3d end = collision.position();
            x = end.x;
            y = end.y;
            z = end.z;

            int alpha = Math.max(0, 255 - (255 - step * 45));
            output.add(new Segment(start, end,
                    VisualColors.withAlpha(VisualColors.clientColor(step * 10.0F), alpha)));
            if (collision.hit()) {
                break;
            }
        }
    }

    private static Collision collide(
            ClientWorld world,
            Entity projectile,
            Vec3d start,
            Vec3d proposedEnd,
            RaycastContext.ShapeType shapeType
    ) {
        Vec3d end = proposedEnd;
        boolean hit = false;
        double expansion = projectile.getWidth() / 2.0F;

        for (Entity candidate : world.getEntities()) {
            if (candidate == projectile) {
                continue;
            }
            Optional<Vec3d> intercept = candidate.getBoundingBox()
                    .expand(expansion)
                    .raycast(start, end);
            if (intercept.isEmpty()) {
                continue;
            }
            end = intercept.get();
            hit = true;
            break;
        }

        HitResult blockHit = world.raycast(new RaycastContext(
                start, end, shapeType, RaycastContext.FluidHandling.NONE, projectile));
        if (blockHit.getType() != HitResult.Type.MISS) {
            end = blockHit.getPos();
            hit = true;
        }
        return new Collision(end, hit);
    }

    private record Profile(double gravity, float waterDrag, RaycastContext.ShapeType shapeType) {
    }

    private record Collision(Vec3d position, boolean hit) {
    }

    private record Segment(Vec3d start, Vec3d end, int clientColor) {
    }

    private record Cache(
            ClientWorld world,
            ClientPlayNetworkHandler networkHandler,
            List<Segment> segments
    ) {
    }
}
