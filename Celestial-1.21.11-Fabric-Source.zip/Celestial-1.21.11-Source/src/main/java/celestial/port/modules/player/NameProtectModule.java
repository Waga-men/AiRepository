package celestial.port.modules.player;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.TextSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.OrderedText;
import net.minecraft.text.PlainTextContent;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.text.TranslatableTextContent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.UUID;
import java.util.Set;

public final class NameProtectModule extends Module {
    private static final ProtectionPlan INACTIVE_PLAN = new ProtectionPlan(List.of());
    private static volatile NameProtectModule instance;

    private final BooleanSetting streamerMode = addSetting(new BooleanSetting(
            "streamer_mode", "Стример мод", false
    ));
    private final BooleanSetting hideFriends = addSetting(new BooleanSetting(
            "hide_friends", "Скрывать друзей", false
    ).visibleWhen(() -> !streamerMode.enabled()));
    private final TextSetting alias = addSetting(new TextSetting(
            "alias", "Никнейм", "Smertnix"
    ));
    private ProtectionPlan cachedPlan = INACTIVE_PLAN;
    private List<PlayerIdentity> cachedPlayers = List.of();
    private String cachedAlias;
    private String cachedProfileName;
    private UUID cachedLocalPlayerUuid;
    private Object cachedWorld;
    private boolean cachedStreamerMode;
    private boolean cachedHideFriends;
    private Set<String> cachedFriends = Set.of();
    private boolean cacheValid;

    public NameProtectModule() {
        super("name_protect", "Name Protect", "Masks account names in rendered GUI text", Category.PLAYER);
        instance = this;
    }

    public static String configuredAlias() {
        NameProtectModule module = instance;
        return module == null ? "Smertnix" : module.alias.value();
    }

    public static String protect(String input) {
        if (input == null || input.isEmpty()) return input;
        return currentPlan().apply(input);
    }

    public static OrderedText protect(OrderedText input) {
        if (input == null) return null;
        ProtectionPlan plan = currentPlan();
        if (plan.inactive()) return input;

        List<StyledCodePoint> source = new ArrayList<>();
        input.accept((index, style, codePoint) -> {
            source.add(new StyledCodePoint(style, codePoint));
            return true;
        });
        List<StyledCodePoint> protectedText = plan.apply(source);
        if (protectedText == source) return input;

        List<StyledCodePoint> immutableText = List.copyOf(protectedText);
        return visitor -> {
            int index = 0;
            for (StyledCodePoint glyph : immutableText) {
                if (!visitor.accept(index, glyph.style(), glyph.codePoint())) return false;
                index += Character.charCount(glyph.codePoint());
            }
            return true;
        };
    }

    public static Text protect(Text input) {
        if (input == null) return null;
        ProtectionPlan plan = currentPlan();
        return plan.inactive() ? input : protect(input, plan);
    }

    private static Text protect(Text input, ProtectionPlan plan) {
        MutableText output;
        if (input.getContent() instanceof PlainTextContent plain) {
            output = MutableText.of(PlainTextContent.of(plan.apply(plain.string())));
        } else if (input.getContent() instanceof TranslatableTextContent translatable) {
            Object[] arguments = translatable.getArgs().clone();
            for (int index = 0; index < arguments.length; index++) {
                if (arguments[index] instanceof Text text) {
                    arguments[index] = protect(text, plan);
                } else if (arguments[index] instanceof String string) {
                    arguments[index] = plan.apply(string);
                }
            }
            output = MutableText.of(new TranslatableTextContent(
                    translatable.getKey(), translatable.getFallback(), arguments));
        } else {
            output = input.copyContentOnly();
        }
        output.setStyle(input.getStyle());
        for (Text sibling : input.getSiblings()) {
            output.append(protect(sibling, plan));
        }
        return output;
    }

    private static ProtectionPlan currentPlan() {
        NameProtectModule module = instance;
        if (module == null || !module.enabled()) return INACTIVE_PLAN;
        MinecraftClient client = MinecraftClient.getInstance();
        String profileName = client.getGameProfile() == null ? null : client.getGameProfile().name();
        UUID localPlayerUuid = client.player == null ? null : client.player.getUuid();
        String aliasValue = module.alias.value();
        boolean hideOtherPlayers = module.streamerMode.enabled();
        boolean hideFriendNames = !hideOtherPlayers && module.hideFriends.enabled();
        Set<String> friends = hideFriendNames ? FriendManager.names() : Set.of();

        boolean scalarStateMatches = module.cacheValid
                && module.cachedStreamerMode == hideOtherPlayers
                && module.cachedHideFriends == hideFriendNames
                && Objects.equals(module.cachedFriends, friends)
                && Objects.equals(module.cachedAlias, aliasValue)
                && Objects.equals(module.cachedProfileName, profileName)
                && Objects.equals(module.cachedLocalPlayerUuid, localPlayerUuid);
        if (scalarStateMatches
                && (!hideOtherPlayers
                || (module.cachedWorld == client.getNetworkHandler()
                && module.playersMatch(client, localPlayerUuid)))) {
            return module.cachedPlan;
        }

        return module.rebuildPlan(client, profileName, localPlayerUuid, aliasValue,
                hideOtherPlayers, hideFriendNames, friends);
    }

    private ProtectionPlan rebuildPlan(
            MinecraftClient client,
            String profileName,
            UUID localPlayerUuid,
            String aliasValue,
            boolean hideOtherPlayers,
            boolean hideFriendNames,
            Set<String> friends
    ) {
        Map<String, String> replacements = new LinkedHashMap<>();
        addReplacement(replacements, profileName, aliasValue);

        List<PlayerIdentity> playerSnapshot = new ArrayList<>();
        if (hideOtherPlayers && client.getNetworkHandler() != null) {
            for (var entry : client.getNetworkHandler().getPlayerList()) {
                UUID uuid = entry.getProfile().id();
                if (localPlayerUuid != null && uuid.equals(localPlayerUuid)) continue;
                String name = entry.getProfile().name();
                playerSnapshot.add(new PlayerIdentity(uuid, name));
                addReplacement(
                        replacements,
                        name,
                        aliasValue
                );
            }
        }
        ProtectionPlan plan = INACTIVE_PLAN;
        if (!replacements.isEmpty()) {
            List<Replacement> compiled = replacements.entrySet().stream()
                    .map(entry -> new Replacement(
                            entry.getKey().codePoints().toArray(),
                            entry.getValue().codePoints().toArray()))
                    .sorted(Comparator.comparingInt((Replacement replacement) -> replacement.source().length).reversed())
                    .toList();
            plan = new ProtectionPlan(compiled);
        }

        cachedAlias = aliasValue;
        cachedProfileName = profileName;
        cachedLocalPlayerUuid = localPlayerUuid;
        cachedStreamerMode = hideOtherPlayers;
        cachedHideFriends = hideFriendNames;
        cachedFriends = Set.copyOf(friends);
        cachedWorld = hideOtherPlayers ? client.getNetworkHandler() : null;
        cachedPlayers = playerSnapshot.isEmpty() ? List.of() : List.copyOf(playerSnapshot);
        cachedPlan = plan;
        cacheValid = true;
        return plan;
    }

    public static boolean streamerModeActive() {
        NameProtectModule module = instance;
        return module != null && module.enabled() && module.streamerMode.enabled();
    }

    public static String protectedPlayerName(net.minecraft.entity.player.PlayerEntity player,
                                             boolean displayName) {
        NameProtectModule module = instance;
        if (module == null || !module.enabled() || player == null) {
            return null;
        }
        String profileName = player.getGameProfile().name();
        String localName = MinecraftClient.getInstance().getGameProfile().name();
        if (!displayName && Objects.equals(profileName, localName)) {
            return module.alias.value();
        }
        if (displayName && (module.streamerMode.enabled()
                || module.hideFriends.enabled() && FriendManager.isFriend(profileName))) {
            return module.alias.value();
        }
        return null;
    }

    private boolean playersMatch(MinecraftClient client, UUID localPlayerUuid) {
        if (client.getNetworkHandler() == null) return cachedPlayers.isEmpty();

        int snapshotIndex = 0;
        for (var entry : client.getNetworkHandler().getPlayerList()) {
            UUID uuid = entry.getProfile().id();
            if (localPlayerUuid != null && uuid.equals(localPlayerUuid)) continue;
            if (snapshotIndex >= cachedPlayers.size()) return false;

            PlayerIdentity cachedPlayer = cachedPlayers.get(snapshotIndex++);
            if (!cachedPlayer.uuid().equals(uuid)
                    || !Objects.equals(cachedPlayer.name(), entry.getProfile().name())) {
                return false;
            }
        }
        return snapshotIndex == cachedPlayers.size();
    }

    private static void addReplacement(Map<String, String> replacements, String source, String target) {
        if (source == null || source.isEmpty() || target == null || source.equals(target)) return;
        replacements.putIfAbsent(source, target);
    }

    private record StyledCodePoint(Style style, int codePoint) {
    }

    private record Replacement(int[] source, int[] target) {
    }

    private record PlayerIdentity(UUID uuid, String name) {
    }

    private record ProtectionPlan(List<Replacement> replacements) {
        private boolean inactive() {
            return replacements.isEmpty();
        }

        private String apply(String input) {
            if (inactive() || input.isEmpty()) return input;
            int[] source = input.codePoints().toArray();
            StringBuilder output = new StringBuilder(input.length());
            boolean changed = false;
            for (int index = 0; index < source.length; ) {
                Replacement replacement = match(source, index);
                if (replacement == null) {
                    output.appendCodePoint(source[index++]);
                    continue;
                }
                for (int codePoint : replacement.target()) output.appendCodePoint(codePoint);
                index += replacement.source().length;
                changed = true;
            }
            return changed ? output.toString() : input;
        }

        private List<StyledCodePoint> apply(List<StyledCodePoint> source) {
            if (inactive() || source.isEmpty()) return source;
            List<StyledCodePoint> output = new ArrayList<>(source.size());
            boolean changed = false;
            for (int index = 0; index < source.size(); ) {
                Replacement replacement = match(source, index);
                if (replacement == null) {
                    output.add(source.get(index++));
                    continue;
                }

                for (int targetIndex = 0; targetIndex < replacement.target().length; targetIndex++) {
                    int styleIndex = Math.min(targetIndex, replacement.source().length - 1);
                    Style style = source.get(index + styleIndex).style();
                    output.add(new StyledCodePoint(style, replacement.target()[targetIndex]));
                }
                index += replacement.source().length;
                changed = true;
            }
            return changed ? output : source;
        }

        private Replacement match(int[] source, int offset) {
            for (Replacement replacement : replacements) {
                if (offset + replacement.source().length > source.length) continue;
                boolean matches = true;
                for (int index = 0; index < replacement.source().length; index++) {
                    if (source[offset + index] != replacement.source()[index]) {
                        matches = false;
                        break;
                    }
                }
                if (matches) return replacement;
            }
            return null;
        }

        private Replacement match(List<StyledCodePoint> source, int offset) {
            for (Replacement replacement : replacements) {
                if (offset + replacement.source().length > source.size()) continue;
                boolean matches = true;
                for (int index = 0; index < replacement.source().length; index++) {
                    if (source.get(offset + index).codePoint() != replacement.source()[index]) {
                        matches = false;
                        break;
                    }
                }
                if (matches) return replacement;
            }
            return null;
        }
    }
}
