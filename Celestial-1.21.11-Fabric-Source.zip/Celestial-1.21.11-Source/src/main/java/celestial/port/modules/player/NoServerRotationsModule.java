package celestial.port.modules.player;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.EntityPosition;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRotationS2CPacket;
import net.minecraft.network.packet.s2c.play.PositionFlag;

public final class NoServerRotationsModule extends Module {
    public NoServerRotationsModule() {
        super("no_server_rots", "No Server Rots",
                "Убирает ротацию со стороны сервера", Category.PLAYER);
    }

    public static boolean active() {
        return CelestialPortClient.MODULES.find("no_server_rots").map(Module::enabled).orElse(false);
    }

    public static PlayerPositionLookS2CPacket rewrite(PlayerPositionLookS2CPacket packet) {
        var player = MinecraftClient.getInstance().player;
        if (!active() || player == null) {
            return packet;
        }
        var relatives = packet.relatives();
        EntityPosition change = packet.change().withRotation(
                relatives.contains(PositionFlag.Y_ROT) ? 0.0F : player.getYaw(),
                relatives.contains(PositionFlag.X_ROT) ? 0.0F : player.getPitch());
        return new PlayerPositionLookS2CPacket(packet.teleportId(), change, relatives);
    }

    public static PlayerRotationS2CPacket rewrite(PlayerRotationS2CPacket packet) {
        var player = MinecraftClient.getInstance().player;
        if (!active() || player == null) {
            return packet;
        }
        boolean relativeYaw = packet.relativeYaw();
        boolean relativePitch = packet.relativePitch();
        return new PlayerRotationS2CPacket(
                relativeYaw ? 0.0F : player.getYaw(), relativeYaw,
                relativePitch ? 0.0F : player.getPitch(), relativePitch);
    }
}
