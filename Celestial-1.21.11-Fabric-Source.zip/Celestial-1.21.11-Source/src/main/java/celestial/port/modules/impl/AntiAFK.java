package celestial.port.modules.impl;

import celestial.port.core.Category;
import celestial.port.core.Module;
import net.minecraft.client.MinecraftClient;

import java.util.concurrent.ThreadLocalRandom;

public final class AntiAFK extends Module {
    private static final long INTERVAL_MILLIS = 10_000L;

    private long lastMovementMillis = System.currentTimeMillis();

    public AntiAFK() {
        super("anti_afk", "Anti AFK", "Обходит сервера с проверкой на АФК", Category.UTILITY);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.getNetworkHandler() == null) {
            return;
        }

        var movement = client.player.input.getMovementInput();
        boolean moving = movement.x != 0.0F || movement.y != 0.0F;
        long now = System.currentTimeMillis();
        if (moving) {
            lastMovementMillis = now;
            return;
        }
        if (now - lastMovementMillis <= INTERVAL_MILLIS) {
            return;
        }

        char randomLetter = (char) ('a' + ThreadLocalRandom.current().nextInt(26));
        client.getNetworkHandler().sendChatCommand("ho" + randomLetter + "me");
        lastMovementMillis = System.currentTimeMillis();
    }
}
