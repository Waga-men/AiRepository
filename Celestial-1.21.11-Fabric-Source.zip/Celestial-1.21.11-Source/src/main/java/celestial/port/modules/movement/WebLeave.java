package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec3d;

public final class WebLeave extends Module {
    private final NumberSetting motion = addSetting(new NumberSetting(
            "motion", "\u041c\u043e\u0443\u0448\u0435\u043d", 10.0, 1.0, 10.0, 1.0
    ));
    private ClientPlayerEntity sessionPlayer;
    private boolean collidedWithWeb;

    public WebLeave() {
        super("web_leave", "Web Leave",
                "\u0412\u044b\u0441\u043e\u043a\u0438\u0439 \u043f\u0440\u044b\u0436\u043e\u043a \u0432 \u043f\u0430\u0443\u0442\u0438\u043d\u0435", Category.MOVEMENT);
    }

    public static boolean active() {
        Module raw = CelestialPortClient.MODULES.find("web_leave").orElse(null);
        return raw instanceof WebLeave module && module.enabled();
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = MovementSupport.playablePlayer(client);
        if (player != sessionPlayer) {
            sessionPlayer = player;
            collidedWithWeb = false;
        }
        if (player == null) {
            return;
        }

        boolean inWeb = MovementSupport.isInsideCobweb(player);
        Vec3d velocity = player.getVelocity();
        if (inWeb) {
            collidedWithWeb = true;
            player.setVelocity(velocity.x, velocity.y + 2.0, velocity.z);
        } else if (collidedWithWeb) {
            client.options.jumpKey.setPressed(false);
            player.setVelocity(velocity.x, velocity.y + motion.value(), velocity.z);
            collidedWithWeb = false;
        }
    }

    @Override
    protected void onEnable() {
        collidedWithWeb = false;
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        collidedWithWeb = false;
    }

    @Override
    protected void onDisable() {
        sessionPlayer = null;
        collidedWithWeb = false;
    }
}
