package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.inventory.InventoryActions;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;

import java.util.OptionalInt;

public final class ElytraFlight extends Module {
    private final NumberSetting horizontalSpeed = addSetting(new NumberSetting(
            "horizontal_speed", "Скорость по XZ", 1.2, 0.5, 1.9, 0.01
    ));
    private final NumberSetting verticalSpeed = addSetting(new NumberSetting(
            "vertical_speed", "Скорость по Y", 0.1, 0.1, 1.0, 0.01
    ));
    private final NumberSetting fireworkSlot = addSetting(new NumberSetting(
            "firework_slot", "Слот с фейерверком", 9.0, 1.0, 9.0, 1.0
    ));
    private final NumberSetting fireworkDelay = addSetting(new NumberSetting(
            "firework_delay", "Задержка фейерверка", 1.5, 0.5, 1.5, 0.1
    ));
    private final BooleanSetting doNotLand = addSetting(new BooleanSetting(
            "do_not_land", "Не приземляться", true
    ));
    private final BooleanSetting continueFlying = addSetting(new BooleanSetting(
            "continue_flying", "Продолжать лететь", false
    ));
    private final BooleanSetting superBow = addSetting(new BooleanSetting(
            "super_bow", "Супер лук", false
    ));

    private ClientPlayerEntity controlledPlayer;
    private int elytraSource = PlayerInventory.NOT_FOUND;
    private boolean equippedElytra;
    private int fireworkSource = PlayerInventory.NOT_FOUND;
    private boolean movedFirework;
    private ClientPlayNetworkHandler inventorySession;
    private long lastFirework;
    private boolean launched;
    private boolean startFlightSent;
    private int speedRamp;
    private int launchAttempts;
    private boolean forcingPitch;

    public ElytraFlight() {
        super("elytra_flight", "Elytra Flight",
                "Улучшает полет на элитре с фейрверками", Category.MOVEMENT);
    }

    public boolean forcingPitch() {
        return enabled() && forcingPitch;
    }

    public static float movementPacketPitch(ClientPlayerEntity player, float vanillaPitch) {
        ElytraFlight module = active();
        return module != null && module.shouldForceServerPitch(player) ? -90.0F : vanillaPitch;
    }

    public static boolean shouldSuppressFireworkBoost(LivingEntity shooter) {
        ElytraFlight module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        return module != null && shooter == client.player && shooter == module.controlledPlayer;
    }

    public static void retryPendingRestore(ClientPlayerEntity player) {
        ElytraFlight module = registered();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module != null && !module.enabled() && player == client.player && module.hasPendingRestore()) {
            module.restoreInventory(client);
        }
    }

    @Override
    protected void onEnable() {
        MinecraftClient client = MinecraftClient.getInstance();
        resetFlightState();
        if (hasPendingRestore() && !restoreInventory(client)) {
            controlledPlayer = null;
            return;
        }
        controlledPlayer = client.player;
        if (controlledPlayer == null || client.interactionManager == null) {
            return;
        }

        if (!prepareElytra(client, controlledPlayer)) {
            controlledPlayer.sendMessage(net.minecraft.text.Text.literal(
                    "Нету элитр в инвентаре!"), false);
            setEnabled(false);
            return;
        }
        if (!prepareFirework(controlledPlayer)) {
            controlledPlayer.sendMessage(net.minecraft.text.Text.literal(
                    "Нету феерверков в инвентаре!"), false);
            setEnabled(false);
        }
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player != controlledPlayer) {
            if (!restoreInventory(client)) {
                return;
            }
            controlledPlayer = player;
            resetFlightState();
            if (player == null || client.interactionManager == null) return;
            if (!prepareElytra(client, player) || !prepareFirework(player)) {
                setEnabled(false);
                return;
            }
        }
        if (player == null || !player.isAlive()) {
            return;
        }

        if (player.isOnGround()) {
            launched = false;
            startFlightSent = false;
            launchAttempts = 0;
            forcingPitch = false;
            speedRamp = 0;
            if (!player.isSneaking()) {
                client.options.jumpKey.setPressed(false);
                player.jump();
            }
            return;
        }

        if (!canGlide(player.getEquippedStack(EquipmentSlot.CHEST))) {
            forcingPitch = false;
            return;
        }

        if (!player.isGliding() && player.getVelocity().y < 0.0) {
            if (!startFlightSent) {
                player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                        player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                startFlightSent = true;
            }
            if (!player.isTouchingWater() && !player.getAbilities().flying) {
                useFirework(client, player, false);
            }
        }
        if (!player.isGliding()) {
            return;
        }

        forcingPitch = player.getGlidingTicks() < 5;
        useFirework(client, player, true);
        if (!enabled() || !launched) {
            return;
        }
        if (player.getGlidingTicks() < 4) {
            client.options.jumpKey.setPressed(false);
            player.setVelocity(player.getVelocity().x, 1.0, player.getVelocity().z);
        }
        controlFlight(player, client);
    }

    private void controlFlight(ClientPlayerEntity player, MinecraftClient client) {
        Vec3d velocity = player.getVelocity();
        double motionY = velocity.y;
        if (client.options.jumpKey.isPressed()) {
            motionY += verticalSpeed.value();
        } else if (client.options.sneakKey.isPressed()) {
            motionY -= verticalSpeed.value();
        } else if (superBow.enabled() && clearBelow(player, 2.0)) {
            motionY = player.age % 2 == 0 ? 0.42 : -0.42;
        } else {
            motionY = player.age % 2 == 0 ? 0.08 : -0.08;
        }
        motionY *= verticalSpeed.value();

        Vec3d direction = MovementSupport.legacyInputDirection(player);
        double speed = horizontalSpeed.value() - 0.017;
        speed *= Math.min((speedRamp += 9) / 100.0, 1.0);
        if (!moduleEnabled("target_strafe")) {
            player.setVelocity(direction.x * speed, motionY, direction.z * speed);
        } else {
            player.setVelocity(player.getVelocity().x, motionY, player.getVelocity().z);
        }
        if (doNotLand.enabled() && !clearBelow(player, 3.0)) {
            player.setVelocity(player.getVelocity().x, 0.42, player.getVelocity().z);
        }
        player.fallDistance = 0.0F;
    }

    private void useFirework(MinecraftClient client, ClientPlayerEntity player, boolean delayed) {
        long now = System.currentTimeMillis();
        if (delayed && now - lastFirework < Math.round(fireworkDelay.value() * 1_000.0)) {
            return;
        }
        if (delayed && !player.isGliding()) {
            return;
        }
        if (!delayed && launchAttempts > 1) {
            return;
        }
        if (client.interactionManager == null) {
            return;
        }

        if (player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            client.interactionManager.interactItem(player, Hand.OFF_HAND);
            markFireworkUsed(now);
            return;
        }

        int slot = findHotbar(player.getInventory(), Items.FIREWORK_ROCKET);
        if (slot == PlayerInventory.NOT_FOUND) {
            int source = find(player.getInventory(), Items.FIREWORK_ROCKET);
            if (source == PlayerInventory.NOT_FOUND) {
                player.sendMessage(net.minecraft.text.Text.literal(
                        "РќРµС‚Сѓ С„РµРµСЂРІРµСЂРєРѕРІ РІ РёРЅРІРµРЅС‚Р°СЂРµ!"), false);
                setEnabled(false);
                return;
            }
            int destination = fireworkDestination();
            if (source != destination) {
                if (movedFirework || !swapInventorySlots(client, source, destination)) {
                    return;
                }
                if (!player.getInventory().getStack(destination).isOf(Items.FIREWORK_ROCKET)) {
                    return;
                }
                fireworkSource = source;
                movedFirework = true;
                rememberInventorySession(client);
            }
            slot = destination;
        }

        int selected = player.getInventory().getSelectedSlot();
        player.getInventory().setSelectedSlot(slot);
        client.interactionManager.interactItem(player, Hand.MAIN_HAND);
        player.getInventory().setSelectedSlot(selected);
        player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(selected));
        markFireworkUsed(now);
    }

    private void markFireworkUsed(long now) {
        launchAttempts++;
        launched = true;
        lastFirework = now;
    }

    private boolean prepareElytra(MinecraftClient client, ClientPlayerEntity player) {
        if (canGlide(player.getEquippedStack(EquipmentSlot.CHEST))) {
            return true;
        }
        elytraSource = findUsableElytra(player.getInventory());
        if (elytraSource == PlayerInventory.NOT_FOUND) {
            return false;
        }
        equippedElytra = swapInventorySlots(client,
                elytraSource, InventoryActions.CHEST_INVENTORY_INDEX);
        if (equippedElytra) {
            rememberInventorySession(client);
        }
        return equippedElytra && canGlide(player.getEquippedStack(EquipmentSlot.CHEST));
    }

    private boolean prepareFirework(ClientPlayerEntity player) {
        return player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)
                || find(player.getInventory(), Items.FIREWORK_ROCKET) != PlayerInventory.NOT_FOUND;
    }

    private static int find(PlayerInventory inventory, net.minecraft.item.Item item) {
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (inventory.getStack(slot).isOf(item)) return slot;
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int findHotbar(PlayerInventory inventory, net.minecraft.item.Item item) {
        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            if (inventory.getStack(slot).isOf(item)) return slot;
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int findUsableElytra(PlayerInventory inventory) {
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (canGlide(inventory.getStack(slot))) return slot;
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static boolean canGlide(ItemStack stack) {
        return LivingEntity.canGlideWith(stack, EquipmentSlot.CHEST);
    }

    private static boolean swapInventorySlots(MinecraftClient client, int sourceIndex, int destinationIndex) {
        ClientPlayerEntity player = client.player;
        if (player == null || !player.isAlive() || client.interactionManager == null
                || client.getNetworkHandler() == null || sourceIndex == destinationIndex
                || client.currentScreen instanceof HandledScreen<?>
                || player.currentScreenHandler != player.playerScreenHandler
                || !player.currentScreenHandler.getCursorStack().isEmpty()) {
            return false;
        }

        ScreenHandler handler = player.currentScreenHandler;
        OptionalInt sourceSlotId = handler.getSlotIndex(player.getInventory(), sourceIndex);
        OptionalInt destinationSlotId = handler.getSlotIndex(player.getInventory(), destinationIndex);
        if (sourceSlotId.isEmpty() || destinationSlotId.isEmpty()) {
            return false;
        }

        Slot source = handler.getSlot(sourceSlotId.getAsInt());
        Slot destination = handler.getSlot(destinationSlotId.getAsInt());
        ItemStack sourceStack = source.getStack();
        ItemStack destinationStack = destination.getStack();
        if (sourceStack.isEmpty() || !source.canTakeItems(player) || !destination.canInsert(sourceStack)
                || !destinationStack.isEmpty()
                && (!destination.canTakeItems(player) || !source.canInsert(destinationStack))) {
            return false;
        }

        client.interactionManager.clickSlot(handler.syncId, source.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(handler.syncId, destination.id, 0, SlotActionType.PICKUP, player);
        client.interactionManager.clickSlot(handler.syncId, source.id, 0, SlotActionType.PICKUP, player);
        return handler.getCursorStack().isEmpty();
    }

    private static boolean clearBelow(ClientPlayerEntity player, double distance) {
        Box below = player.getBoundingBox().offset(0.0, -distance, 0.0);
        return !player.getEntityWorld().getBlockCollisions(player, below).iterator().hasNext();
    }

    @Override
    protected void onDisable() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (controlledPlayer != null && controlledPlayer == client.player) {
            if (!continueFlying.enabled() && controlledPlayer.isGliding()) {
                controlledPlayer.setVelocity(0.0, 0.0, 0.0);
                controlledPlayer.stopGliding();

                controlledPlayer.networkHandler.sendPacket(new ClientCommandC2SPacket(
                        controlledPlayer, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            }
        }
        restoreInventory(client);
        controlledPlayer = null;
        resetFlightState();
    }

    private boolean restoreInventory(MinecraftClient client) {
        if (!hasPendingRestore()) {
            clearPendingRestore();
            return true;
        }
        ClientPlayNetworkHandler currentSession = client.getNetworkHandler();
        if (currentSession != null && currentSession != inventorySession) {

            clearPendingRestore();
            return true;
        }
        if (client.player == null) {
            return false;
        }
        int destination = fireworkDestination();
        if (movedFirework && fireworkSource != PlayerInventory.NOT_FOUND) {
            if (swapInventorySlots(client, fireworkSource, destination)) {
                movedFirework = false;
                fireworkSource = PlayerInventory.NOT_FOUND;
            }
        }
        if (equippedElytra && elytraSource != PlayerInventory.NOT_FOUND) {
            if (swapInventorySlots(client, elytraSource, InventoryActions.CHEST_INVENTORY_INDEX)) {
                equippedElytra = false;
                elytraSource = PlayerInventory.NOT_FOUND;
            }
        }
        if (!hasPendingRestore()) {
            clearPendingRestore();
            return true;
        }
        return false;
    }

    private boolean hasPendingRestore() {
        return movedFirework || equippedElytra;
    }

    private void rememberInventorySession(MinecraftClient client) {
        if (inventorySession == null) {
            inventorySession = client.getNetworkHandler();
        }
    }

    private void clearPendingRestore() {
        equippedElytra = false;
        movedFirework = false;
        elytraSource = PlayerInventory.NOT_FOUND;
        fireworkSource = PlayerInventory.NOT_FOUND;
        inventorySession = null;
    }

    private boolean shouldForceServerPitch(ClientPlayerEntity player) {
        if (player != controlledPlayer) {
            forcingPitch = false;
            return false;
        }
        boolean earlyGlide = player.getGlidingTicks() < 5;
        forcingPitch = earlyGlide;
        boolean moving = player.forwardSpeed != 0.0F || player.sidewaysSpeed != 0.0F;
        boolean jumping = player.input != null && player.input.playerInput.jump();
        return earlyGlide || !moving && jumping && player.isGliding() && launched;
    }

    private int fireworkDestination() {
        return Math.max(0, Math.min(8, (int) Math.round(fireworkSlot.value()) - 1));
    }

    private void resetFlightState() {
        launched = false;
        startFlightSent = false;
        forcingPitch = false;
        speedRamp = 0;
        launchAttempts = 0;
        lastFirework = 0L;
    }

    private static boolean moduleEnabled(String id) {
        return CelestialPortClient.MODULES.find(id).filter(Module::enabled).isPresent();
    }

    private static ElytraFlight active() {
        ElytraFlight module = registered();
        return module != null && module.enabled() ? module : null;
    }

    private static ElytraFlight registered() {
        Module raw = CelestialPortClient.MODULES.find("elytra_flight").orElse(null);
        return raw instanceof ElytraFlight module ? module : null;
    }
}
