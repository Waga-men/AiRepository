package celestial.port.modules.player;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.PvpContext;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BooleanSetting;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

import java.util.Arrays;
import java.util.List;
import java.util.Locale;

public final class AutoTPAccept extends Module {
    private static final List<String> REQUEST_MARKERS = List.of(
            "has requested teleport",
            "\u043f\u0440\u043e\u0441\u0438\u0442 \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c\u0441\u044f",
            "\u043f\u0440\u043e\u0441\u0438\u0442 \u043a \u0432\u0430\u043c \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u043e\u0432\u0430\u0442\u044c\u0441\u044f"
    );

    private final BooleanSetting onlyFriends = addSetting(new BooleanSetting(
            "only_friends", "\u0422\u043e\u043b\u044c\u043a\u043e \u0434\u0440\u0443\u0437\u044c\u044f", true
    ));

    public AutoTPAccept() {
        super("auto_tp_accept", "Auto TP Accept",
                "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043f\u0440\u0438\u043d\u0438\u043c\u0430\u0435\u0442 \u0437\u0430\u043f\u0440\u043e\u0441 \u043d\u0430 \u0442\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0430\u0446\u0438\u044e", Category.PLAYER);
        ClientReceiveMessageEvents.GAME.register(this::onGameMessage);
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, parameters, receivedAt) ->
                consider(message));
    }

    private void onGameMessage(Text message, boolean overlay) {
        if (!overlay) {
            consider(message);
        }
    }

    private void consider(Text message) {
        if (!enabled()) {
            return;
        }
        String plain = message.getString().toLowerCase(Locale.ROOT);
        if (REQUEST_MARKERS.stream().noneMatch(plain::contains)) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.getNetworkHandler() == null) {
            return;
        }
        if (PvpContext.active()) {
            LegacyCommandFeedback.send(
                    "AutoTPAccept: \u0412\u044b \u043d\u0430\u0445\u043e\u0434\u0438\u0442\u0435\u0441\u044c \u0432 PvP \u0440\u0435\u0436\u0438\u043c\u0435!"
            );
            return;
        }
        if (onlyFriends.enabled() && !mentionsFriend(plain)) {
            return;
        }
        client.getNetworkHandler().sendChatCommand("tpaccept");
    }

    private static boolean mentionsFriend(String message) {
        List<String> words = Arrays.asList(message.split(" "));
        return FriendManager.names().stream()
                .map(name -> name.toLowerCase(Locale.ROOT))
                .anyMatch(words::contains);
    }
}
