package celestial.port.modules.impl;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.enchantment.Enchantments;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ShovelItem;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public final class NoClip extends Module {
    private static volatile NoClip instance;

    public static volatile boolean eaN;

    private final BooleanSetting sunriseBypass = addSetting(new BooleanSetting(
            "sunrise_bypass", "\u041e\u0431\u0445\u043e\u0434 Sunrise", false
    ));
    private final BooleanSetting waitBreaking = addSetting(new BooleanSetting(
            "wait_breaking", "\u0416\u0434\u0430\u0442\u044c \u043b\u043e\u043c\u0430\u043d\u0438\u0435", true
    ).visibleWhen(sunriseBypass::enabled));
    private final NumberSetting delay = addSetting(new NumberSetting(
            "delay", "\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430", 50.0, 0.0, 100.0, 10.0
    ).visibleWhen(sunriseBypass::enabled));
    private final NumberSetting downSpeed = addSetting(new NumberSetting(
            "down_speed", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c \u0432\u043d\u0438\u0437", 0.1, 0.1, 0.2, 0.01
    ).visibleWhen(() -> sunriseBypass.enabled() && !waitBreaking.enabled()));

    private long lastBreakMillis = System.currentTimeMillis();
    private boolean breaking;

    public NoClip() {
        super("no_clip", "No Clip",
                "\u041f\u043e\u0437\u0432\u043e\u043b\u044f\u0435\u0442 \u043f\u0440\u043e\u0445\u043e\u0434\u0438\u0442\u044c \u0441\u043a\u0432\u043e\u0437\u044c \u0441\u0442\u0435\u043d\u044b", Category.PLAYER);
        setDisableOnFlag(false);
        instance = this;
    }

    public static Vec3d adjustCollision(ClientPlayerEntity player, Vec3d requested, Vec3d collided) {
        NoClip module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || client.player != player
                || client.world == null || player.isRemoved()) {
            return collided;
        }
        return module.adjustCollisionInternal(client, player, requested, collided);
    }

    public static boolean blocksStrafe(ClientPlayerEntity player) {
        NoClip module = instance;
        return module != null && module.enabled() && module.sunriseBypass.enabled()
                && player != null && player.age > 55 && eaN;
    }

    public static boolean blocksAutoTool() {
        NoClip module = instance;
        return module != null && module.enabled() && module.sunriseBypass.enabled() && eaN;
    }

    public static void onBlockBroken(ClientPlayerEntity player) {
        NoClip module = instance;
        if (module != null && module.enabled()
                && MinecraftClient.getInstance().player == player
                && !player.getAbilities().creativeMode
                && !player.getMainHandStack().isEmpty()) {
            module.breaking = false;
        }
    }

    private Vec3d adjustCollisionInternal(MinecraftClient client,
                                          ClientPlayerEntity player,
                                          Vec3d requested,
                                          Vec3d collided) {
        boolean startClear = client.world.isSpaceEmpty(
                player, player.getBoundingBox().contract(0.0625));
        boolean destinationClear = startClear && client.world.isSpaceEmpty(
                player, player.getBoundingBox().offset(collided).contract(0.0625));
        if (destinationClear) {
            eaN = false;
            return collided;
        }

        eaN = true;
        boolean sneaking = player.isSneaking();
        boolean jumping = player.input != null && player.input.playerInput.jump();
        boolean hasMovement = player.forwardSpeed != 0.0F || player.sidewaysSpeed != 0.0F;
        boolean mayBreak = hasMovement || !player.isUsingItem() || jumping || sneaking;
        try {
            if (sunriseActive(player) && mayBreak) {
                breakObstruction(client, player, jumping, sneaking);
            }
        } catch (Exception ignored) {

        }

        if (sunriseActive(player) && waitBreaking.enabled() && breaking) {
            return collided;
        }

        boolean horizontalCollision = requested.x != collided.x || requested.z != collided.z;
        double x = horizontalCollision ? requested.x : collided.x;
        double z = horizontalCollision ? requested.z : collided.z;
        double y = collided.y;
        if (requested.y > 0.0 || sneaking) {
            y = requested.y;
            float configuredDownSpeed = downSpeed.value().floatValue();
            if (sunriseActive(player) && !waitBreaking.enabled()
                    && configuredDownSpeed != 0.2F && sneaking) {
                y = -configuredDownSpeed;
            }
        }
        return new Vec3d(x, Math.min(y, 99999.0), z);
    }

    private boolean sunriseActive(ClientPlayerEntity player) {
        return sunriseBypass.enabled() && player.age > 55;
    }

    private void breakObstruction(MinecraftClient client,
                                  ClientPlayerEntity player,
                                  boolean jumping,
                                  boolean sneaking) {
        BlockPos feet = BlockPos.ofFloored(player.getX(), player.getY(), player.getZ());
        BlockPos scanCenter = BlockPos.ofFloored(
                player.getX() + 0.5, player.getY() + 0.5, player.getZ() + 0.5);
        BlockPos target = cheapestNearbyBlock(client, player, scanCenter);
        if (sneaking || player.getPitch() > 80.0F) {
            target = feet.down();
        } else if (jumping || player.getPitch() < -50.0F) {
            target = feet.up();
        }
        if (target == null || client.interactionManager == null) {
            return;
        }

        int delayMillis = delay.value().intValue();
        long now = System.currentTimeMillis();
        if (delayMillis > 0 && now - lastBreakMillis <= delayMillis) {
            return;
        }
        lastBreakMillis = now;

        BlockState state = client.world.getBlockState(target);
        int previousSlot = player.getInventory().getSelectedSlot();
        int toolSlot = bestToolSlot(player, state);
        try {
            select(player, toolSlot);
            if (!state.isAir()) {
                breaking = true;
                if (client.interactionManager.updateBlockBreakingProgress(target, Direction.UP)) {
                    player.swingHand(Hand.MAIN_HAND);
                }
            }
        } finally {
            select(player, previousSlot);
        }
    }

    private BlockPos cheapestNearbyBlock(MinecraftClient client,
                                         ClientPlayerEntity player,
                                         BlockPos center) {
        List<BlockPos> candidates = new ArrayList<>(27);
        for (int x = -1; x <= 1; x++) {
            for (int y = -1; y <= 1; y++) {
                for (int z = -1; z <= 1; z++) {
                    candidates.add(center.add(x, y, z));
                }
            }
        }
        candidates.sort(Comparator.comparingDouble(
                pos -> player.squaredDistanceTo(pos.getX(), pos.getY(), pos.getZ())));

        BlockPos best = null;
        float bestCost = Float.POSITIVE_INFINITY;
        for (BlockPos pos : candidates) {
            BlockState state = client.world.getBlockState(pos);
            if (state.isAir() || state.isOf(Blocks.OBSIDIAN)
                    || state.getCollisionShape(client.world, pos).isEmpty()) {
                continue;
            }
            int toolSlot = bestToolSlot(player, state);
            float cost = breakCost(player, pos, state,
                    player.getInventory().getStack(toolSlot));
            if (cost < bestCost) {
                bestCost = cost;
                best = pos.toImmutable();
            }
        }
        return best;
    }

    private static float breakCost(ClientPlayerEntity player,
                                   BlockPos pos,
                                   BlockState state,
                                   ItemStack stack) {
        float hardness = state.getHardness(player.getEntityWorld(), pos);
        float speed = stack.getMiningSpeedMultiplier(state);
        if (speed > 1.0F) {
            int efficiency = enchantmentLevel(player, Enchantments.EFFICIENCY, stack);
            speed *= efficiency * efficiency + 1.0F;
        }
        float cost = hardness / speed;
        return cost < 0.1F ? 0.1F : cost;
    }

    private static int bestToolSlot(ClientPlayerEntity player, BlockState state) {
        int bestSlot = 0;
        double bestSpeed = Double.NEGATIVE_INFINITY;
        int bestMaterialCost = Integer.MIN_VALUE;
        boolean bestSilkTouch = false;

        BlockState toolState = state.getBlock().getDefaultState();

        for (int slot = 0; slot < PlayerInventory.getHotbarSize(); slot++) {
            ItemStack stack = player.getInventory().getStack(slot);
            if (stack.getItem().getClass() == ShovelItem.class
                    || stack.isDamageable() && stack.getMaxDamage() > 1
                    && stack.getDamage() >= stack.getMaxDamage() - 1) {
                continue;
            }

            double speed = toolSetSpeed(player, toolState, stack);
            boolean silkTouch = enchantmentLevel(player, Enchantments.SILK_TOUCH, stack) > 0;
            int materialCost = materialCost(stack.getItem());
            if (speed > bestSpeed || speed == bestSpeed
                    && materialCost < bestMaterialCost && (silkTouch || !bestSilkTouch)) {
                bestSlot = slot;
                bestSpeed = speed;
                bestMaterialCost = materialCost;
                bestSilkTouch = silkTouch;
            }
        }
        return bestSlot;
    }

    private static double toolSetSpeed(ClientPlayerEntity player,
                                       BlockState state,
                                       ItemStack stack) {
        float hardness = state.getHardness(null, null);
        if (hardness < 0.0F) {
            return -1.0;
        }
        float speed = stack.getMiningSpeedMultiplier(state);
        int efficiency = enchantmentLevel(player, Enchantments.EFFICIENCY, stack);
        if (speed > 1.0F && efficiency > 0 && !stack.isEmpty()) {
            speed += efficiency * efficiency + 1.0F;
        }
        speed /= hardness;
        return (!state.isToolRequired() || stack.isSuitableFor(state))
                ? speed / 30.0F : speed / 100.0F;
    }

    private static int enchantmentLevel(ClientPlayerEntity player,
                                        net.minecraft.registry.RegistryKey<net.minecraft.enchantment.Enchantment> key,
                                        ItemStack stack) {
        var enchantments = player.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        return EnchantmentHelper.getLevel(enchantments.getOrThrow(key), stack);
    }

    private static int materialCost(Item item) {
        String path = Registries.ITEM.getId(item).getPath();

        if (!path.endsWith("_axe") && !path.endsWith("_pickaxe")
                && !path.endsWith("_shovel")) {
            return -1;
        }
        if (path.startsWith("wooden_")) return 0;
        if (path.startsWith("stone_")) return 1;
        if (path.startsWith("copper_")) return 2;
        if (path.startsWith("iron_")) return 3;
        if (path.startsWith("diamond_")) return 4;
        if (path.startsWith("golden_")) return 5;
        if (path.startsWith("netherite_")) return 6;
        return -1;
    }

    private static void select(ClientPlayerEntity player, int slot) {
        if (slot == player.getInventory().getSelectedSlot()) {
            return;
        }
        player.getInventory().setSelectedSlot(slot);
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        eaN = false;
    }

    @Override
    protected void onEnable() {
        eaN = false;
    }

    @Override
    protected void onDisable() {
        eaN = false;
    }
}
