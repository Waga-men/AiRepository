package celestial.port.modules.movement;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageTypes;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.registry.tag.DamageTypeTags;
import net.minecraft.util.math.Vec3d;

public final class LongJump extends Module {
    private static final byte HURT_STATUS = 2;

    private final BooleanSetting onlyOnDamage = addSetting(new BooleanSetting(
            "only_on_damage", "Только при дамаге", true
    ));
    private final BooleanSetting autoJump = addSetting(new BooleanSetting(
            "auto_jump", "Авто прыжок", true
    ));
    private final BooleanSetting autoDisable = addSetting(new BooleanSetting(
            "auto_disable", "Авто выключение", false
    ));
    private final NumberSetting speed = addSetting(new NumberSetting(
            "speed", "Скорость", 0.42, 0.10, 0.42, 0.01
    ));
    private final NumberSetting duration = addSetting(new NumberSetting(
            "duration", "Длительность", 30.0, 10.0, 50.0, 5.0
    ));

    private ClientPlayerEntity observedPlayer;
    private boolean verifiedDamage;
    private boolean excludedDamage;
    private int activeTicks;
    private float acceleration;
    private float offGroundSpeed = Float.NaN;

    public LongJump() {
        super("long_jump", "Long Jump", "Позволяет прыгать на большую длину", Category.MOVEMENT);
    }

    public BooleanSetting onlyOnDamage() {
        return onlyOnDamage;
    }

    public BooleanSetting autoJump() {
        return autoJump;
    }

    public BooleanSetting autoDisable() {
        return autoDisable;
    }

    public NumberSetting speed() {
        return speed;
    }

    public NumberSetting duration() {
        return duration;
    }

    public static void beforeMovementPackets(ClientPlayerEntity player) {
        LongJump module = activeModule();
        if (module != null) {
            module.applyMotion(player);
        }
    }

    public static boolean shouldSpoofSprint() {
        LongJump module = activeModule();
        return module != null && module.verifiedDamage;
    }

    public static Float offGroundSpeed(PlayerEntity player) {
        LongJump module = activeModule();
        if (module == null || player != MinecraftClient.getInstance().player
                || Float.isNaN(module.offGroundSpeed)) {
            return null;
        }
        return module.offGroundSpeed;
    }

    public static void onEntityStatus(EntityStatusS2CPacket packet) {
        LongJump module = activeModule();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || client.world == null || client.player == null
                || packet.getStatus() != HURT_STATUS || packet.getEntity(client.world) != client.player) {
            return;
        }
        module.observe(client.player);
        if (module.hasDamageEffect(client.player)) {
            return;
        }
        if (module.excludedDamage) {
            module.verifiedDamage = false;
            module.excludedDamage = false;
        } else {
            module.verifiedDamage = true;
        }
    }

    public static void onEntityDamage(EntityDamageS2CPacket packet) {
        LongJump module = activeModule();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || client.world == null || client.player == null
                || packet.entityId() != client.player.getId() || module.hasDamageEffect(client.player)) {
            return;
        }

        module.observe(client.player);
        DamageSource source = packet.createDamageSource(client.world);
        boolean excluded = source.isIn(DamageTypeTags.IS_FALL)
                || source.isOf(DamageTypes.ARROW)
                || source.isIn(DamageTypeTags.IS_EXPLOSION)
                || source.isOf(DamageTypes.ENDER_PEARL);
        module.excludedDamage = excluded;
        module.verifiedDamage = !excluded;
    }

    public static void onEntityVelocity(EntityVelocityUpdateS2CPacket packet) {
        LongJump module = activeModule();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || client.player == null
                || packet.getEntityId() != client.player.getId()) {
            return;
        }

        ClientPlayerEntity player = client.player;
        module.observe(player);
        if (module.hasDamageEffect(player)) {
            return;
        }
        if (module.excludedDamage) {
            module.verifiedDamage = false;
            if (player.hurtTime > 0) {
                module.excludedDamage = false;
            }
            return;
        }
        if (player.hurtTime > 0) {
            module.verifiedDamage = true;
        }
    }

    public static void onExplosion() {
        LongJump module = activeModule();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module != null && client.player != null && !module.hasDamageEffect(client.player)) {
            module.observe(client.player);
            module.excludedDamage = true;
            module.verifiedDamage = false;
        }
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        activeTicks = 0;
        acceleration = 0.0f;
        offGroundSpeed = Float.NaN;
        verifiedDamage = false;
        excludedDamage = false;
    }

    @Override
    protected void onEnable() {
        reset(MinecraftClient.getInstance().player);
    }

    @Override
    protected void onTick() {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (player != observedPlayer) {
            reset(player);
        }
    }

    @Override
    protected void onDisable() {
        reset(null);
    }

    private void applyMotion(ClientPlayerEntity player) {
        observe(player);
        if (excludedDamage && player.hurtTime > 0) {
            excludedDamage = false;
            verifiedDamage = false;
        }
        if (!verifiedDamage && onlyOnDamage.enabled()) {
            return;
        }

        activeTicks++;
        if (player.isOnGround()) {
            if (autoJump.enabled()) {
                player.jump();
            }
            acceleration = 0.0f;
            offGroundSpeed = Float.NaN;
        } else {
            acceleration = Math.min(acceleration + 65.0f, 100.0f);
            offGroundSpeed = (float) (speed.value() * acceleration / 100.0);
        }

        setMovementSpeed(player, player.getVelocity().horizontalLength());

        MinecraftClient.getInstance().options.jumpKey.setPressed(false);
        if (activeTicks > (int) Math.round(duration.value())) {
            verifiedDamage = false;
            excludedDamage = false;
            activeTicks = 0;
            acceleration = 0.0f;
            offGroundSpeed = Float.NaN;
            if (autoDisable.enabled()) {
                setEnabled(false);
            }
        }
    }

    private static void setMovementSpeed(ClientPlayerEntity player, double value) {
        Vec3d direction = MovementSupport.legacyInputDirection(player);
        Vec3d velocity = player.getVelocity();
        if (MovementSupport.hasDirection(direction)) {
            player.setVelocity(direction.x * value, velocity.y, direction.z * value);
        } else {
            player.setVelocity(0.0, velocity.y, 0.0);
        }
    }

    private boolean hasDamageEffect(ClientPlayerEntity player) {
        return player.hasStatusEffect(StatusEffects.POISON)
                || player.hasStatusEffect(StatusEffects.WITHER)
                || player.hasStatusEffect(StatusEffects.INSTANT_DAMAGE);
    }

    private void observe(ClientPlayerEntity player) {
        if (observedPlayer != player) {
            reset(player);
        }
    }

    private void reset(ClientPlayerEntity player) {
        observedPlayer = player;
        verifiedDamage = false;
        excludedDamage = false;
        activeTicks = 0;
        acceleration = 0.0f;
        offGroundSpeed = Float.NaN;
    }

    private static LongJump activeModule() {
        Module module = CelestialPortClient.MODULES.find("long_jump").orElse(null);
        return module instanceof LongJump longJump && longJump.enabled() ? longJump : null;
    }
}
