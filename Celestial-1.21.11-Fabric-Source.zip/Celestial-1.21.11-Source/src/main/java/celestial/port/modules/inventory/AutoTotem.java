package celestial.port.modules.inventory;

import celestial.port.client.ui.AutoTotemCounterHud;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.block.BedBlock;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.TntEntity;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.entity.vehicle.TntMinecartEntity;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.biome.BiomeKeys;

import java.util.List;
import java.util.Set;

public final class AutoTotem extends Module {
    private static final String CRYSTALS = "Кристаллы";
    private static final String TNT = "Динамит";
    private static final String OBSIDIAN = "Обсидиан";
    private static final String BED = "Кровать";
    private static final String FALL = "Падение";
    private static final long RETURN_DELAY_NANOS = 400_000_000L;
    private static AutoTotem instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode",
            "Режим",
            "Really World",
            List.of("Really World", "Matrix", "Тестовый")
    ));
    private final MultiSelectSetting triggers = addSetting(new MultiSelectSetting(
            "triggers",
            "Срабатывать на",
            Set.of(CRYSTALS),
            List.of(CRYSTALS, TNT, OBSIDIAN, BED, FALL)
    ));
    private final NumberSetting health = addSetting(new NumberSetting(
            "health",
            "Здоровье",
            5.0,
            1.0,
            20.0,
            0.5
    ));
    private final BooleanSetting returnItem = addSetting(new BooleanSetting(
            "return_item",
            "Вернуть предмет",
            true
    ));
    private final BooleanSetting vulcanBypass = addSetting(new BooleanSetting(
            "vulcan_bypass",
            "Обход Vulcan",
            true
    ).visibleWhen(() -> !mode.is("Really World")));
    private final BooleanSetting doNotChangeHead = addSetting(new BooleanSetting(
            "do_not_change_head",
            "Не менять шар",
            true
    ));
    private final NumberSetting crystalDistance = addSetting(new NumberSetting(
            "crystal_distance",
            "Дистанция до кристалла",
            5.0,
            1.0,
            6.0,
            1.0
    ).visibleWhen(() -> triggers.selected(CRYSTALS)));
    private final NumberSetting tntDistance = addSetting(new NumberSetting(
            "tnt_distance",
            "Дистанция до динамита",
            5.0,
            1.0,
            6.0,
            1.0
    ).visibleWhen(() -> triggers.selected(TNT)));
    private final NumberSetting obsidianDistance = addSetting(new NumberSetting(
            "obsidian_distance",
            "Дистанция до обсидиана",
            5.0,
            2.0,
            6.0,
            1.0
    ).visibleWhen(() -> triggers.selected(OBSIDIAN)));
    private final NumberSetting bedDistance = addSetting(new NumberSetting(
            "bed_distance",
            "Дистанция до кровати",
            5.0,
            1.0,
            6.0,
            1.0
    ).visibleWhen(() -> triggers.selected(BED)));
    private final BooleanSetting goldenHearts = addSetting(new BooleanSetting(
            "golden_hearts",
            "Золотые сердца",
            true
    ));
    private final BooleanSetting totemCounter = addSetting(new BooleanSetting(
            "totem_counter",
            "Счетчик тотемов",
            true
    ));

    private ClientPlayerEntity ownerPlayer;
    private ClientWorld ownerWorld;
    private int returnSlot = PlayerInventory.NOT_FOUND;
    private boolean swapInProgress;
    private boolean cursorTotem;
    private boolean popped;
    private Item originalOffhandItem = Items.AIR;
    private ItemStack originalOffhandStack = ItemStack.EMPTY;
    private int totalTotems;
    private boolean bypassArmed;
    private int bypassTicks;
    private long actionTimer = System.nanoTime();
    private String observedMode;

    public AutoTotem() {
        super(
                "auto_totem",
                "Auto Totem",
                "Автоматически берет тотем в руку",
                Category.COMBAT
        );
        instance = this;
        observedMode = mode.value();
        AutoTotemCounterHud.register(this);
    }

    public static boolean isSwapInProgress() {
        AutoTotem module = instance;
        return module != null && module.enabled() && module.swapInProgress;
    }

    public static void onTotemStatus(byte status, net.minecraft.entity.Entity entity) {
        AutoTotem module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module != null
                && module.enabled()
                && status == 35
                && client.player != null
                && entity == client.player) {
            module.popped = true;
        }
    }

    public static void onCrystalSpawn(double x, double y, double z) {
        AutoTotem module = instance;
        if (module == null || !module.enabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (!client.isOnThread()) {
            client.execute(() -> onCrystalSpawn(x, y, z));
            return;
        }
        module.handleCrystalSpawn(client, x, y, z);
    }

    public boolean counterEnabled() {
        return totemCounter.enabled();
    }

    public int totemCount() {
        MinecraftClient client = MinecraftClient.getInstance();
        return totalTotems + (client.player != null
                && client.player.currentScreenHandler.getCursorStack().isOf(Items.TOTEM_OF_UNDYING) ? 1 : 0);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!validSession(client)) {
            resetState();
            ownerPlayer = client.player;
            ownerWorld = client.world;
        }
        if (!mode.value().equals(observedMode)) {
            observedMode = mode.value();
            resetState();
        }
        advanceBypass(client);

        if (client.player == null || client.world == null || !client.player.isAlive()) {
            totalTotems = 0;
            return;
        }
        totalTotems = countTotems(client.player, true);
        if (!OffhandTransactions.canUsePlayerHandler(client, false)) {
            return;
        }

        boolean protect = shouldProtect(client);
        if (mode.is("Matrix")) {
            if (protect) {
                deployMatrix(client, false);
            } else {
                restoreMatrix(client);
            }
            return;
        }
        if (mode.is("Really World")) {
            if (protect && containsInventoryTotem(client.player)) {
                if (hasTotemEquipped(client.player)) {
                    return;
                }
                deployReallyWorld(client);
                popped = false;
                return;
            }
            restoreReallyWorld(client);
            return;
        }

        if (protect) {
            if (hasTotemEquipped(client.player)) {
                return;
            }
            deployTest(client, false);
        } else if (returnItem.enabled() && swapInProgress
                && System.nanoTime() - actionTimer >= RETURN_DELAY_NANOS
                && restoreTest(client)) {
            resetState();
            actionTimer = System.nanoTime();
        }
    }

    private void handleCrystalSpawn(MinecraftClient client, double x, double y, double z) {
        if (client.player == null
                || !triggers.selected(CRYSTALS)
                || client.player.squaredDistanceTo(x, y, z) > crystalDistance.value() * crystalDistance.value()
                || suppressEnvironmentalThreats(client.player)) {
            return;
        }
        totalTotems = countTotems(client.player, true);
        if (mode.is("Really World")) {
            deployReallyWorld(client);
            popped = false;
        } else if (mode.is("Matrix")) {
            deployMatrix(client, true);
        } else {
            deployTest(client, true);
        }
    }

    private boolean shouldProtect(MinecraftClient client) {
        if (totalTotems <= 0) {
            return false;
        }
        ClientPlayerEntity player = client.player;
        float absorption = goldenHearts.enabled() && player.hasStatusEffect(StatusEffects.ABSORPTION)
                ? player.getAbsorptionAmount() : 0.0F;
        if (player.getHealth() + absorption <= health.value()) {
            return true;
        }
        if (suppressEnvironmentalThreats(player)) {
            return false;
        }
        if (nearExplosiveEntity(client)) {
            return true;
        }
        if (triggers.selected(OBSIDIAN) && unsafeObsidianNearby(client)) {
            return true;
        }
        if (triggers.selected(FALL) && dangerousFall(player)) {
            return true;
        }
        return triggers.selected(BED) && dangerousBedNearby(client);
    }

    private boolean suppressEnvironmentalThreats(ClientPlayerEntity player) {
        if (triggers.selected(FALL) && player.fallDistance > 5.0F) {
            return false;
        }
        return doNotChangeHead.enabled() && isSkull(player.getOffHandStack());
    }

    private boolean nearExplosiveEntity(MinecraftClient client) {
        if (triggers.selected(CRYSTALS)) {
            double range = crystalDistance.value();
            if (!client.world.getEntitiesByClass(
                    EndCrystalEntity.class,
                    client.player.getBoundingBox().expand(range),
                    entity -> entity.distanceTo(client.player) < range
            ).isEmpty()) {
                return true;
            }
        }
        if (!triggers.selected(TNT)) {
            return false;
        }
        double range = tntDistance.value();
        Box box = client.player.getBoundingBox().expand(range);
        return !client.world.getEntitiesByClass(
                TntEntity.class,
                box,
                entity -> entity.distanceTo(client.player) < range
        ).isEmpty() || !client.world.getEntitiesByClass(
                TntMinecartEntity.class,
                box,
                entity -> entity.distanceTo(client.player) < range
        ).isEmpty();
    }

    private boolean unsafeObsidianNearby(MinecraftClient client) {
        int radius = obsidianDistance.value().intValue();
        BlockPos center = client.player.getBlockPos();
        BlockPos nearest = null;
        double nearestDistance = Double.MAX_VALUE;
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    BlockPos pos = center.add(x, y, z);
                    if (!client.world.getBlockState(pos).isOf(Blocks.OBSIDIAN)) {
                        continue;
                    }
                    double distance = client.player.squaredDistanceTo(pos.getX(), pos.getY(), pos.getZ());
                    if (distance < nearestDistance) {
                        nearest = pos;
                        nearestDistance = distance;
                    }
                }
            }
        }
        if (nearest == null || nearest.getY() > client.player.getY()) {
            return false;
        }
        Box column = new Box(
                nearest.getX(), nearest.getY(), nearest.getZ(),
                nearest.getX() + 1.0, nearest.getY() + 3.0, nearest.getZ() + 1.0
        );
        return client.world.getOtherEntities(null, column).isEmpty();
    }

    private boolean dangerousBedNearby(MinecraftClient client) {
        if (!client.world.getBiome(client.player.getBlockPos()).matchesKey(BiomeKeys.THE_END)) {
            return false;
        }
        int radius = bedDistance.value().intValue();
        BlockPos center = client.player.getBlockPos();
        double rangeSq = bedDistance.value() * bedDistance.value();
        for (int x = -radius; x <= radius; x++) {
            for (int y = -radius; y <= radius; y++) {
                for (int z = -radius; z <= radius; z++) {
                    BlockPos pos = center.add(x, y, z);
                    if (client.world.getBlockState(pos).getBlock() instanceof BedBlock
                            && client.player.squaredDistanceTo(pos.getX(), pos.getY(), pos.getZ()) < rangeSq) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean dangerousFall(ClientPlayerEntity player) {
        if (player.getMainHandStack().isOf(Items.FIREWORK_ROCKET)
                || player.getOffHandStack().isOf(Items.FIREWORK_ROCKET)) {
            return false;
        }
        return player.fallDistance > 10.0F;
    }

    private void deployMatrix(MinecraftClient client, boolean immediate) {
        int source = findMainTotem(client.player, false);
        if (source != PlayerInventory.NOT_FOUND) {
            if (!client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
                if (!immediate && !passesVulcanBypass(client)) {
                    return;
                }
                if (returnSlot == PlayerInventory.NOT_FOUND) {
                    returnSlot = source;
                }
                if (!OffhandTransactions.pickupSwapWithOffhand(client, source, 1)) {
                    return;
                }
                swapInProgress = true;
                clearBypass();
            }
            actionTimer = System.nanoTime();
            return;
        }

        if (client.player.currentScreenHandler.getCursorStack().isOf(Items.TOTEM_OF_UNDYING)) {
            cursorTotem = true;
            if (OffhandTransactions.pickupOffhand(client, 0)) {
                swapInProgress = true;
                actionTimer = System.nanoTime();
            }
            return;
        }
        restoreMatrix(client);
    }

    private boolean restoreMatrix(MinecraftClient client) {
        if (!returnItem.enabled()
                || !swapInProgress
                || (System.nanoTime() - actionTimer < RETURN_DELAY_NANOS
                && findMainTotem(client.player, false) != PlayerInventory.NOT_FOUND
                && !client.player.getOffHandStack().isEmpty())) {
            return false;
        }

        if (cursorTotem) {
            if (!client.player.currentScreenHandler.getCursorStack().isEmpty()) {
                OffhandTransactions.pickupOffhand(client, 0);
            }
            cursorTotem = false;
            if (returnSlot == PlayerInventory.NOT_FOUND) {
                swapInProgress = false;
                return true;
            }
        }
        if (returnSlot == PlayerInventory.NOT_FOUND || !passesVulcanBypass(client)) {
            return false;
        }

        if (!OffhandTransactions.pickup(client, returnSlot, 0)) {
            return false;
        }
        if (!client.player.getOffHandStack().isEmpty()) {
            OffhandTransactions.pickupOffhand(client, 0);
            OffhandTransactions.pickup(client, returnSlot, 0);
        } else {
            OffhandTransactions.pickupOffhand(client, 0);
        }
        boolean complete = client.player.currentScreenHandler.getCursorStack().isEmpty();
        if (complete) {
            returnSlot = PlayerInventory.NOT_FOUND;
            swapInProgress = false;
            clearBypass();
        }
        return complete;
    }

    private void deployReallyWorld(MinecraftClient client) {
        if (returnSlot != PlayerInventory.NOT_FOUND && !popped) {
            return;
        }
        int source = findMainTotem(client.player, false);
        if (source == PlayerInventory.NOT_FOUND) {
            return;
        }
        if (OffhandTransactions.silentSwapInventorySlotWithOffhand(client, source)) {
            returnSlot = source;
            swapInProgress = true;
        }
    }

    private void restoreReallyWorld(MinecraftClient client) {
        if (!returnItem.enabled() || returnSlot == PlayerInventory.NOT_FOUND) {
            return;
        }
        if (OffhandTransactions.silentSwapInventorySlotWithOffhand(client, returnSlot)) {
            returnSlot = PlayerInventory.NOT_FOUND;
            swapInProgress = false;
        }
    }

    private void deployTest(MinecraftClient client, boolean immediate) {
        actionTimer = System.nanoTime();
        if (client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) {
            return;
        }
        if (!immediate && !passesVulcanBypass(client)) {
            return;
        }

        int source = findPreferredTotem(client.player);
        if (source == PlayerInventory.NOT_FOUND) {
            return;
        }
        if (returnSlot == PlayerInventory.NOT_FOUND) {
            returnSlot = source;
            originalOffhandStack = client.player.getOffHandStack().copy();
            originalOffhandItem = originalOffhandStack.isEmpty() ? Items.AIR : originalOffhandStack.getItem();
        }
        if (OffhandTransactions.pickupSwapWithOffhand(client, source, 1)) {
            swapInProgress = true;
            popped = false;
            clearBypass();
        }
    }

    private boolean restoreTest(MinecraftClient client) {
        if (!client.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)
                || returnSlot == PlayerInventory.NOT_FOUND
                || originalOffhandItem == Items.AIR) {
            return true;
        }

        int originalSlot = findExactStack(client.player.getInventory(), originalOffhandStack);
        if (originalSlot == PlayerInventory.NOT_FOUND || !passesVulcanBypass(client)) {
            return false;
        }
        if (!client.player.currentScreenHandler.getCursorStack().isEmpty()) {
            OffhandTransactions.pickupOffhand(client, 0);
            OffhandTransactions.pickup(client, returnSlot, 0);
            return false;
        }

        ItemStack returnStack = client.player.getInventory().getStack(returnSlot);
        boolean returnSlotChanged = !returnStack.isEmpty()
                && !ItemStack.areItemsAndComponentsEqual(returnStack, originalOffhandStack);
        if (!OffhandTransactions.pickup(client, originalSlot, 0)
                || !OffhandTransactions.pickupOffhand(client, 0)) {
            return false;
        }
        int destination = returnSlotChanged ? firstEmptyMain(client.player.getInventory()) : returnSlot;
        if (destination != PlayerInventory.NOT_FOUND) {
            OffhandTransactions.pickup(client, destination, 0);
        }
        boolean complete = client.player.currentScreenHandler.getCursorStack().isEmpty();
        if (complete) {
            clearBypass();
        }
        return complete;
    }

    private boolean passesVulcanBypass(MinecraftClient client) {
        if (!vulcanBypass.enabled() || mode.is("Really World")) {
            return true;
        }
        if (!bypassArmed) {
            bypassArmed = true;
            bypassTicks = 0;
        }
        return bypassTicks >= 3;
    }

    private void advanceBypass(MinecraftClient client) {
        if (!bypassArmed || client.player == null) {
            return;
        }
        bypassTicks++;
        if (!client.player.isGliding()
                && !client.player.isTouchingWater()
                && !client.player.hasVehicle()
                && !client.player.getAbilities().flying) {
            var velocity = client.player.getVelocity();
            client.player.setVelocity(velocity.x * 0.7, velocity.y, velocity.z * 0.7);
        }
        if (bypassTicks > 5) {
            clearBypass();
        }
    }

    private void clearBypass() {
        bypassArmed = false;
        bypassTicks = 0;
    }

    private static int countTotems(ClientPlayerEntity player, boolean includeEnchanted) {
        int count = 0;
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < inventory.size(); slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (stack.isOf(Items.TOTEM_OF_UNDYING) && (includeEnchanted || !stack.hasEnchantments())) {
                count++;
            }
        }
        return count;
    }

    private static int findMainTotem(ClientPlayerEntity player, boolean unenchantedOnly) {
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            ItemStack stack = inventory.getStack(slot);
            if (stack.isOf(Items.TOTEM_OF_UNDYING) && (!unenchantedOnly || !stack.hasEnchantments())) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int findPreferredTotem(ClientPlayerEntity player) {
        int unenchanted = findMainTotem(player, true);
        return unenchanted != PlayerInventory.NOT_FOUND ? unenchanted : findMainTotem(player, false);
    }

    private static int findExactStack(PlayerInventory inventory, ItemStack wanted) {
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            ItemStack candidate = inventory.getStack(slot);
            if (candidate.isOf(wanted.getItem()) && ItemStack.areItemsAndComponentsEqual(candidate, wanted)) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int firstEmptyMain(PlayerInventory inventory) {
        for (int slot = 9; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (inventory.getStack(slot).isEmpty()) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static boolean containsInventoryTotem(ClientPlayerEntity player) {
        PlayerInventory inventory = player.getInventory();
        for (int slot = 0; slot <= PlayerInventory.OFF_HAND_SLOT; slot++) {
            if (inventory.getStack(slot).isOf(Items.TOTEM_OF_UNDYING)) {
                return true;
            }
        }
        return false;
    }

    private static boolean hasTotemEquipped(ClientPlayerEntity player) {
        for (EquipmentSlot slot : EquipmentSlot.values()) {
            if (player.getEquippedStack(slot).isOf(Items.TOTEM_OF_UNDYING)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isSkull(ItemStack stack) {
        return stack.getItem() instanceof BlockItem blockItem
                && blockItem.getBlock() instanceof AbstractSkullBlock;
    }

    private boolean validSession(MinecraftClient client) {
        return ownerPlayer == client.player && ownerWorld == client.world;
    }

    private void resetState() {
        returnSlot = PlayerInventory.NOT_FOUND;
        swapInProgress = false;
        cursorTotem = false;
        popped = false;
        originalOffhandItem = Items.AIR;
        originalOffhandStack = ItemStack.EMPTY;
        clearBypass();
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        returnSlot = PlayerInventory.NOT_FOUND;
        clearBypass();
        swapInProgress = false;
        cursorTotem = false;
        originalOffhandItem = Items.AIR;
        originalOffhandStack = ItemStack.EMPTY;
    }

    @Override
    protected void onDisable() {
        resetState();
        totalTotems = 0;
        ownerPlayer = null;
        ownerWorld = null;
    }
}
