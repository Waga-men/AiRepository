package celestial.port.modules.legacyutility;

import celestial.port.CelestialPortClient;
import celestial.port.client.ui.ClientFeedback;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.modules.render.ClickGuiModule;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.network.packet.s2c.play.BossBarS2CPacket;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

public final class AutoWay extends Module {
    private static final String AIR_DROP = "Аир дроп";
    private static final String TALISMAN = "Талисман";
    private static final String SCROOGE = "Скрудж";
    private static final StyleSpriteSource MONTSERRAT = new StyleSpriteSource.Font(
            Identifier.of("celestial", "montserrat"));
    private static AutoWay instance;

    private final MultiSelectSetting events = addSetting(new MultiSelectSetting(
            "events", "Выбор событий",
            List.of(AIR_DROP, TALISMAN, SCROOGE),
            List.of(AIR_DROP, TALISMAN, SCROOGE)
    ));
    private final BooleanSetting notification = addSetting(new BooleanSetting(
            "notification", "Уведомление", false
    ));

    private UUID bossBarId;
    private Waypoint waypoint;
    private Waypoint manualWaypoint;
    private ClientWorld observedWorld;

    public AutoWay() {
        super("auto_way", "Auto Way",
                "Автоматически рисует путь до аир-дропа/талисмана", Category.UTILITY);
        instance = this;
        HudElementRegistry.addLast(Identifier.of("celestial", "auto_way"),
                (context, tickCounter) -> {
                    if (hasRenderableWaypoint()
                            && !MinecraftClient.getInstance().options.hudHidden) {
                        render(context, tickCounter);
                    }
                });
    }

    public MultiSelectSetting events() {
        return events;
    }

    public BooleanSetting notificationEnabled() {
        return notification;
    }

    public synchronized Optional<Waypoint> waypoint() {
        return Optional.ofNullable(waypoint);
    }

    public synchronized boolean setWaypoint(String label, double x, double z) {
        if (!enabled() || !Double.isFinite(x) || !Double.isFinite(z)) return false;
        String resolvedLabel = label == null || label.isBlank() ? AIR_DROP : label.strip();
        waypoint = new Waypoint(resolvedLabel, (int) x,
                EventParser.yForLabel(resolvedLabel), (int) z);
        return true;
    }

    public synchronized void clearWaypoint() {
        reset();
    }

    public synchronized double distanceToWaypoint() {
        MinecraftClient client = MinecraftClient.getInstance();
        return waypoint == null || client.player == null ? Double.NaN
                : Math.hypot(waypoint.x - client.player.getX(), waypoint.z - client.player.getZ());
    }

    public synchronized float relativeBearing() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (waypoint == null || client.player == null) return Float.NaN;
        return arrowAngle(client, waypoint);
    }

    public static void setManualWaypoint(long x, long z) {
        AutoWay module = instance;
        if (module != null) {
            synchronized (module) {
                module.manualWaypoint = new Waypoint("", x, 0, z);
            }
        }
    }

    public static void stopManualWaypoint() {
        AutoWay module = instance;
        if (module != null) {
            synchronized (module) {
                module.manualWaypoint = null;
            }
        }
    }

    private synchronized boolean hasRenderableWaypoint() {
        return enabled() && waypoint != null || manualWaypoint != null;
    }

    public static void onBossBar(BossBarS2CPacket packet) {
        AutoWay module = instance;
        if (module == null || !module.enabled()) return;
        packet.accept(new BossBarS2CPacket.Consumer() {
            @Override
            public void add(UUID uuid, Text name, float percent, BossBar.Color color,
                            BossBar.Style style, boolean darkenSky,
                            boolean dragonMusic, boolean thickenFog) {
                module.onAdded(uuid, name);
            }

            @Override
            public void remove(UUID uuid) {
                module.onRemoved(uuid);
            }
        });
    }

    private synchronized void onAdded(UUID uuid, Text title) {
        String plain = title.getString().toLowerCase(Locale.ROOT).trim();
        if (plain.contains("pvp")) return;
        EventParser parser = EventParser.forTitle(plain);
        if (parser == null || !events.selected(parser.label)) return;
        try {
            Point point = parser.parse(plain);
            bossBarId = uuid;
            waypoint = new Waypoint(parser.label, point.x, parser.y, point.z);
            if (notification.enabled()) {
                MinecraftClient client = MinecraftClient.getInstance();
                client.execute(() -> {
                    if (!client.isWindowFocused()) {
                        ClientFeedback.info("AutoWay", "Заспавнился " + parser.label + "!", 5);
                    }
                });
            }
        } catch (RuntimeException exception) {
            CelestialPortClient.LOGGER.warn("Unable to parse legacy AutoWay boss bar: {}", plain, exception);
            reset();
        }
    }

    private synchronized void onRemoved(UUID uuid) {
        if (uuid.equals(bossBarId)) reset();
    }

    @Override
    protected synchronized void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != observedWorld) {
            if (observedWorld != null) reset();
            observedWorld = client.world;
        }
    }

    private synchronized void render(DrawContext context, RenderTickCounter tickCounter) {
        MinecraftClient client = MinecraftClient.getInstance();

        boolean eventWaypoint = enabled() && waypoint != null;
        Waypoint target = eventWaypoint ? waypoint : manualWaypoint;
        if (target == null || client.player == null) return;

        float tickProgress = tickCounter.getTickProgress(false);
        double playerX = client.player.lastX
                + (client.player.getX() - client.player.lastX) * tickProgress;
        double playerZ = client.player.lastZ
                + (client.player.getZ() - client.player.lastZ) * tickProgress;
        float angle = arrowAngle(client, target, playerX, playerZ);
        float radians = (float) Math.toRadians(angle);
        double arrowX = 25.0 * Math.cos(radians) + context.getScaledWindowWidth() / 2.0 + 0.5;
        double arrowY = 25.0 * Math.sin(radians) + context.getScaledWindowHeight() / 2.0
                + (eventWaypoint ? -17.0 : -7.0);
        int color = themeColor();

        context.getMatrices().pushMatrix();
        context.getMatrices().translate((float) arrowX, (float) arrowY);
        String distance = (int) Math.sqrt(
                Math.pow(client.player.getX() - target.x, 2.0)
                        + Math.pow(client.player.getZ() - target.z, 2.0)) + "m";
        TextRenderer renderer = client.textRenderer;
        drawCenteredAtLegacyOffset(context, renderer, distance, 13, 0xFFEBEBEB);
        drawCenteredAtLegacyOffset(context, renderer, target.label, 20, 0xFFEBEBEB);

        context.getMatrices().rotate((float) Math.toRadians(angle + 270.0f));
        for (int line = -2; line <= 9; line++) {
            int halfWidth = Math.max(0, Math.round((9 - line) * 0.52f));
            for (int pixel = -halfWidth; pixel <= halfWidth; pixel++) {
                float edge = halfWidth == 0 ? 0.0f : Math.abs(pixel) / (float) halfWidth;
                int pixelColor = darken(color, 1.0f - edge * 0.6f);
                context.fill(pixel, line, pixel + 1, line + 1, pixelColor);
            }
        }
        context.getMatrices().popMatrix();
    }

    private static float arrowAngle(MinecraftClient client, Waypoint target) {
        return arrowAngle(client, target, client.player.getX(), client.player.getZ());
    }

    private static float arrowAngle(
            MinecraftClient client, Waypoint target, double playerX, double playerZ
    ) {
        long dx = (long) (target.x - playerX);
        long dz = (long) (target.z - playerZ);
        float yaw = (float) Math.toRadians(client.player.getYaw());
        double cosine = Math.cos(yaw);
        double sine = Math.sin(yaw);
        double localX = -(dz * cosine - dx * sine);
        double localY = -(dx * cosine + dz * sine);
        return (float) Math.toDegrees(Math.atan2(localX, localY));
    }

    private static void drawCenteredAtLegacyOffset(
            DrawContext context, TextRenderer renderer, String string, int y, int color
    ) {
        Text text = Text.literal(string).styled(style -> style.withFont(MONTSERRAT));
        int width = renderer.getWidth(text);
        int center = width / 4 - 6;
        context.drawText(renderer, text, center - width / 2, y, color, false);
    }

    private static int themeColor() {
        return CelestialPortClient.MODULES.find("click_gui")
                .filter(ClickGuiModule.class::isInstance)
                .map(ClickGuiModule.class::cast)
                .map(ClickGuiModule::primaryColor)
                .orElse(0xFFBF68FF);
    }

    private static int darken(int argb, float amount) {
        int red = Math.round(((argb >>> 16) & 0xFF) * amount);
        int green = Math.round(((argb >>> 8) & 0xFF) * amount);
        int blue = Math.round((argb & 0xFF) * amount);
        return 0xFF000000 | red << 16 | green << 8 | blue;
    }

    private void reset() {
        bossBarId = null;
        waypoint = null;
    }

    @Override
    protected synchronized void onLoadedEnabledStateApplied() {
        reset();
    }

    @Override
    protected synchronized void onDisable() {
        observedWorld = null;
        reset();
    }

    private enum EventParser {
        AIR_DROP_PARSER(AIR_DROP, 64, "аирдроп") {
            @Override
            Point parse(String text) {
                int x = Integer.parseInt(text.substring(text.indexOf("x:") + 2,
                        text.indexOf("z:")).trim());
                int z = Integer.parseInt(text.substring(text.indexOf("z:") + 2).trim());
                return new Point(x, z);
            }
        },
        TALISMAN_PARSER(TALISMAN, 72, "талисман") {
            @Override
            Point parse(String text) {
                String[] words = text.split(" ");
                return new Point(Integer.parseInt(words[1]), Integer.parseInt(words[2]));
            }
        },
        SCROOGE_PARSER(SCROOGE, 56, "скрудж") {
            @Override
            Point parse(String text) {
                String[] words = text.split("\\s+");
                return new Point(Integer.parseInt(words[words.length - 2]),
                        Integer.parseInt(words[words.length - 1]));
            }
        };

        private final String label;
        private final int y;
        private final String marker;

        EventParser(String label, int y, String marker) {
            this.label = label;
            this.y = y;
            this.marker = marker;
        }

        abstract Point parse(String text);

        static EventParser forTitle(String title) {
            for (EventParser parser : values()) {
                if (title.contains(parser.marker)) return parser;
            }
            return null;
        }

        static int yForLabel(String label) {
            for (EventParser parser : values()) {
                if (parser.label.equals(label)) return parser.y;
            }
            return 0;
        }
    }

    private record Point(int x, int z) {
    }

    public record Waypoint(String label, long x, int y, long z) {
    }
}
