package celestial.port.modules.visual;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldExtractionContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderSetup;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.shape.VoxelShape;
import org.joml.Matrix4fc;

import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Set;
import java.util.UUID;

public final class JumpCircles extends Module implements WorldVisual {
    private static final String SELF = "\u0421\u0435\u0431\u044f";
    private static final String OTHER_PLAYERS = "\u0414\u0440\u0443\u0433\u0438\u0435 \u0438\u0433\u0440\u043e\u043a\u0438";
    private static final int MAX_CIRCLES = 20;
    private static final int SEGMENT_STEP = 8;
    private static final int SEGMENTS = 360 / SEGMENT_STEP;
    private static final int QUADS_PER_SEGMENT = 3;
    private static final int VERTICES_PER_QUAD = 4;
    private static final int MAX_VERTICES = MAX_CIRCLES * SEGMENTS
            * QUADS_PER_SEGMENT * VERTICES_PER_QUAD;
    private static final RenderLayer LEGACY_GLOW_LAYER = createLegacyGlowLayer();
    private static final RenderFrame EMPTY_FRAME = new RenderFrame(List.of());

    private static JumpCircles instance;

    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "\u0420\u0435\u0436\u0438\u043c", "Client", List.of("Client", "Static")
    ));
    private final MultiSelectSetting targets = addSetting(new MultiSelectSetting(
            "targets", "\u0412\u044b\u0431\u043e\u0440 \u0446\u0435\u043b\u0435\u0439", Set.of(SELF), List.of(SELF, OTHER_PLAYERS)
    ));
    private final ColorSetting color = addSetting(new ColorSetting(
            "color", "\u0426\u0432\u0435\u0442", 0xFFFFFFFF
    ).visibleWhen(() -> mode.is("Static")));
    private final NumberSetting radius = addSetting(new NumberSetting(
            "radius", "\u0420\u0430\u0434\u0438\u0443\u0441", 1.0, 1.0, 3.0, 0.1
    ));
    private final NumberSetting glowRadius = addSetting(new NumberSetting(
            "glow_radius", "\u0420\u0430\u0434\u0438\u0443\u0441 \u0441\u0432\u0435\u0447\u0435\u043d\u0438\u044f", 3.0, 1.0, 3.0, 0.5
    ));
    private final NumberSetting speed = addSetting(new NumberSetting(
            "speed", "\u0421\u043a\u043e\u0440\u043e\u0441\u0442\u044c", 0.1, 0.1, 0.3, 0.01
    ));

    private final Deque<Circle> circles = new ArrayDeque<>();
    private ClientWorld trackedWorld;
    private long previousFrameTime;
    private volatile RenderFrame renderFrame = EMPTY_FRAME;

    public JumpCircles() {
        super("jump_circles", "Jump Circles",
                "\u0414\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u0442 \u0430\u043d\u0438\u043c\u0430\u0446\u0438\u044e \u043f\u0440\u044b\u0436\u043a\u0430 \u043f\u043e\u0434 \u0432\u0430\u043c\u0438", Category.RENDER);
        instance = this;

        ClientTickEvents.START_WORLD_TICK.register(this::onStartWorldTick);
        WorldRenderEvents.END_MAIN.register(this::drawFrame);
    }

    public MultiSelectSetting targets() {
        return targets;
    }

    public ModeSetting mode() {
        return mode;
    }

    public ColorSetting color() {
        return color;
    }

    public NumberSetting radius() {
        return radius;
    }

    public NumberSetting glowRadius() {
        return glowRadius;
    }

    public NumberSetting speed() {
        return speed;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientWorld world = client.world;
        if (world == null || client.player == null) {
            clearWorldState();
            return;
        }
        if (world != trackedWorld) {
            clearWorldState();
            trackedWorld = world;
        }
    }

    private void onStartWorldTick(ClientWorld world) {
        if (!enabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != world || client.player == null) {
            return;
        }
        if (world != trackedWorld) {
            clearWorldState();
            trackedWorld = world;
        }

        circles.removeIf(circle -> (double) circle.progress
                > (double) radius.value().floatValue() - 0.05);
    }

    public static void onLocalJump(LivingEntity entity) {
        JumpCircles module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !(entity instanceof ClientPlayerEntity player)
                || player != client.player || client.world == null
                || player.getEntityWorld() != client.world
                || !module.targets.selected(SELF)) {
            return;
        }
        module.trackWorld(client.world);
        module.addCircle((float) player.getX(),
                legacyLocalCircleY(player, player.getX(), player.getY(), player.getZ()),
                (float) player.getZ());
    }

    public static boolean shouldTrackRemote(AbstractClientPlayerEntity player) {
        JumpCircles module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        return module != null && module.targets.selected(OTHER_PLAYERS)
                && client.player != null && player != client.player;
    }

    public static void onRemoteFirstAirTick(AbstractClientPlayerEntity player) {
        JumpCircles module = active();
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity local = client.player;
        if (module == null || !module.targets.selected(OTHER_PLAYERS)
                || local == null || client.world == null || player == local
                || player.getEntityWorld() != client.world || !player.isAlive()
                || legacyBot(player) || local.distanceTo(player) > 16.0F) {
            return;
        }
        module.trackWorld(client.world);
        module.addCircle((float) player.getX(), (float) player.getY() - 0.13F,
                (float) player.getZ());
    }

    private static JumpCircles active() {
        JumpCircles module = instance;
        return module != null && module.enabled() ? module : null;
    }

    private void trackWorld(ClientWorld world) {
        if (world != trackedWorld) {
            clearWorldState();
            trackedWorld = world;
        }
    }

    private static float legacyLocalCircleY(AbstractClientPlayerEntity player,
                                            double x, double y, double z) {
        float baseY = (float) y;
        BlockPos pos = BlockPos.ofFloored(x, y, z);
        var state = player.getEntityWorld().getBlockState(pos);
        double blockMaxY;
        if (state.isAir()) {
            blockMaxY = 1.0;
        } else {
            VoxelShape shape = state.getOutlineShape(player.getEntityWorld(), pos);
            blockMaxY = shape.isEmpty() ? 0.0 : shape.getMax(Direction.Axis.Y);
        }
        return (float) Math.min((double) baseY + blockMaxY + 0.05,
                (double) baseY + 0.15);
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        circles.clear();
    }

    @Override
    protected void onDisable() {

        circles.clear();
        previousFrameTime = 0L;
        renderFrame = EMPTY_FRAME;
    }

    @Override
    public void collectVisuals(WorldExtractionContext context) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null || context.world() != client.world) {
            renderFrame = EMPTY_FRAME;
            previousFrameTime = 0L;
            return;
        }

        long now = Util.getMeasuringTimeMs();
        int frameDelta = previousFrameTime == 0L
                ? Math.max(0, (int) (context.tickCounter().getFixedDeltaTicks() * 50.0F))
                : Math.max(0, (int) (now - previousFrameTime));
        previousFrameTime = now;

        if (circles.isEmpty()) {
            renderFrame = EMPTY_FRAME;
            return;
        }

        float targetRadius = radius.value().floatValue();
        float interpolationStep = speed.value().floatValue() / 250.0F;
        float interpolation = (float) ((double) frameDelta * (double) interpolationStep);
        float glowPercent = glowRadius.value().floatValue() * 20.0F;
        boolean staticMode = mode.is("Static");
        int staticColor = color.argb();
        int baseAlpha = staticMode ? staticColor >>> 24 & 255 : 255;

        List<CircleVertex> vertices = new ArrayList<>(Math.min(MAX_VERTICES,
                circles.size() * SEGMENTS * QUADS_PER_SEGMENT * VERTICES_PER_QUAD));
        for (Circle circle : circles) {
            circle.progress = (float) easeOutInterpolate(
                    circle.progress, targetRadius, interpolation);

            float fade = circle.progress > circle.progress / 6.0F
                    ? circle.progress / 6.0F : 0.0F;
            float alphaValue = baseAlpha - fade * 2000.0F / targetRadius;
            int alpha = (int) Math.max(0.0F, alphaValue);
            appendLegacyCircle(vertices, circle, glowPercent, alpha,
                    staticMode, staticColor);
        }
        renderFrame = new RenderFrame(List.copyOf(vertices));
    }

    private static void appendLegacyCircle(List<CircleVertex> vertices, Circle circle,
                                           float glowPercent, int alpha,
                                           boolean staticMode, int staticColor) {
        float currentRadius = circle.progress;
        float radiansPerDegree = (float) Math.PI / 180.0F;
        int previousColor = staticMode ? staticColor : VisualColors.clientColor(0.0F);
        for (float angle = 0.0F; angle < 360.0F; angle += SEGMENT_STEP) {
            double previousSin = Math.sin((angle - SEGMENT_STEP) * radiansPerDegree);
            double previousCos = Math.cos((angle - SEGMENT_STEP) * radiansPerDegree);
            double currentSin = Math.sin(angle * radiansPerDegree);
            double currentCos = Math.cos(angle * radiansPerDegree);
            int currentColor = staticMode ? staticColor : VisualColors.clientColor(angle);

            double bandRadius = currentRadius
                    - currentRadius / 100.0F * glowPercent;
            appendBand(vertices, circle, currentRadius, bandRadius,
                    previousSin, previousCos, currentSin, currentCos,
                    previousColor, currentColor, alpha);

            bandRadius = currentRadius
                    + currentRadius / 100.0F * glowPercent;
            appendBand(vertices, circle, currentRadius, bandRadius,
                    previousSin, previousCos, currentSin, currentCos,
                    previousColor, currentColor, alpha);

            bandRadius = currentRadius + (currentRadius - bandRadius) / 8.0;
            appendBand(vertices, circle, currentRadius, bandRadius,
                    previousSin, previousCos, currentSin, currentCos,
                    previousColor, currentColor, alpha);
            previousColor = currentColor;
        }
    }

    private static void appendBand(List<CircleVertex> vertices, Circle circle,
                                   float mainRadius, double transparentRadius,
                                   double previousSin, double previousCos,
                                   double currentSin, double currentCos,
                                   int previousColor, int currentColor, int alpha) {
        addVertex(vertices, circle,
                previousSin * transparentRadius, previousCos * transparentRadius,
                VisualColors.withAlpha(previousColor, 0));
        addVertex(vertices, circle,
                previousSin * mainRadius, previousCos * mainRadius,
                VisualColors.withAlpha(previousColor, alpha));
        addVertex(vertices, circle,
                currentSin * mainRadius, currentCos * mainRadius,
                VisualColors.withAlpha(currentColor, alpha));
        addVertex(vertices, circle,
                currentSin * transparentRadius, currentCos * transparentRadius,
                VisualColors.withAlpha(currentColor, 0));
    }

    private static void addVertex(List<CircleVertex> vertices, Circle circle,
                                  double xOffset, double zOffset, int color) {

        vertices.add(new CircleVertex(
                (float) (circle.x + xOffset), circle.y,
                (float) (circle.z + zOffset), color));
    }

    private void drawFrame(WorldRenderContext context) {
        if (!enabled()) {
            return;
        }
        RenderFrame frame = renderFrame;
        MatrixStack matrices = context.matrices();
        if (matrices == null || frame.vertices.isEmpty()) {
            return;
        }

        Matrix4fc matrix = matrices.peek().getPositionMatrix();
        var camera = context.worldState().cameraRenderState.pos;
        VertexConsumer consumer = context.consumers().getBuffer(LEGACY_GLOW_LAYER);
        for (CircleVertex vertex : frame.vertices) {
            consumer.vertex(matrix,
                            (float) (vertex.x - camera.x),
                            (float) (vertex.y - camera.y),
                            (float) (vertex.z - camera.z))
                    .color(vertex.color);
        }
    }

    private static double easeOutInterpolate(double start, double end, double fraction) {
        double eased = fraction > 0.8
                ? -2.7777777777777777 * fraction * fraction
                    + 5.555555555555555 * fraction - 1.7777777777777777
                : 1.1111111111111112 * fraction;
        eased = eased < 0.0 ? 0.0 : Math.min(eased, 1.0);
        return start + (end - start) * eased;
    }

    private static boolean legacyBot(PlayerEntity player) {
        UUID offline = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + player.getGameProfile().name())
                        .getBytes(StandardCharsets.UTF_8)
        );
        return !player.getUuid().equals(offline);
    }

    private void addCircle(float x, float y, float z) {
        if (circles.size() >= MAX_CIRCLES) {
            circles.removeFirst();
        }
        circles.addLast(new Circle(x, y, z));
    }

    private void clearWorldState() {
        circles.clear();
        trackedWorld = null;
        previousFrameTime = 0L;
        renderFrame = EMPTY_FRAME;
    }

    private static RenderLayer createLegacyGlowLayer() {
        RenderPipeline pipeline = RenderPipelines.register(RenderPipeline.builder()
                .withLocation(Identifier.of("celestial", "pipeline/jump_circles"))
                .withVertexShader("core/position_color")
                .withFragmentShader("core/position_color")
                .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
                .withUniform("Projection", UniformType.UNIFORM_BUFFER)
                .withBlend(BlendFunction.LIGHTNING)
                .withCull(false)
                .withDepthWrite(false)
                .withVertexFormat(VertexFormats.POSITION_COLOR,
                        VertexFormat.DrawMode.QUADS)
                .build());
        RenderSetup setup = RenderSetup.builder(pipeline)
                .translucent()
                .expectedBufferSize(MAX_VERTICES * 16)
                .build();
        return RenderLayer.of("celestial_jump_circles", setup);
    }

    private static final class Circle {
        private final float x;
        private final float y;
        private final float z;
        private float progress;

        private Circle(float x, float y, float z) {
            this.x = x;
            this.y = y;
            this.z = z;
        }
    }

    private record CircleVertex(float x, float y, float z, int color) {
    }

    private record RenderFrame(List<CircleVertex> vertices) {
    }
}
