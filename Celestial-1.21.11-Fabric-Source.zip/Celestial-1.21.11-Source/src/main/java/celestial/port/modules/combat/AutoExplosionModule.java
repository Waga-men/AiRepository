package celestial.port.modules.combat;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.mixin.accessor.RenderTickCounterDynamicAccessor;
import net.minecraft.block.Blocks;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.decoration.EndCrystalEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.s2c.play.EntitiesDestroyS2CPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import java.util.List;
import java.util.Locale;

public final class AutoExplosionModule extends Module {
    private static final float VANILLA_TICK_MILLIS = 50.0F;

    private static AutoExplosionModule instance;

    private static boolean ownsAuraRotation;

    private final BooleanSetting protectSelf = addSetting(new BooleanSetting(
            "protect_self", "\u041d\u0435 \u0432\u0437\u0440\u044b\u0432\u0430\u0442\u044c \u0441\u0435\u0431\u044f", false
    ));

    private ClientWorld sessionWorld;
    private BlockPos armedPos;
    private EndCrystalEntity attackedCrystal;
    private int attackDelay;
    private boolean placePending;
    private boolean rotatePending;

    private boolean movementRotationActive;
    private float movementYaw;
    private float movementPitch;
    private int renderRotationAge = Integer.MIN_VALUE;

    public AutoExplosionModule() {
        super("auto_explosion", "Auto Explosion",
                "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0441\u0442\u0430\u0432\u0438\u0442 \u0438 \u0432\u0437\u0440\u044b\u0432\u0430\u0435\u0442 \u043a\u0440\u0438\u0441\u0442\u0430\u043b\u043b \u043f\u043e\u0441\u043b\u0435 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043a\u0438 \u043e\u0431\u0441\u0438\u0434\u0438\u0430\u043d\u0430", Category.COMBAT);
        instance = this;
    }

    public static BlockPos captureObsidianPlacement(
            ClientPlayerEntity player, Hand hand, BlockHitResult hit
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (player == null || player != client.player || client.world == null) {
            return null;
        }
        ItemStack stack = player.getStackInHand(hand);
        if (!stack.isOf(Blocks.OBSIDIAN.asItem())) {
            return null;
        }
        ItemPlacementContext placement = new ItemPlacementContext(player, hand, stack, hit);
        BlockPos pos = placement.getBlockPos();
        return client.world.getBlockState(pos).isOf(Blocks.OBSIDIAN)
                ? null : pos.toImmutable();
    }

    public static void finishObsidianPlacement(
            ClientPlayerEntity player, BlockPos candidate, ActionResult result
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (candidate == null || result == null || !result.isAccepted()
                || player != client.player || client.world == null
                || !client.world.getBlockState(candidate).isOf(Blocks.OBSIDIAN)) {
            return;
        }

        ownsAuraRotation = true;
        AutoExplosionModule module = instance;
        if (module != null && module.enabled()) {
            module.arm(client.world, player, candidate);
        }
    }

    private void arm(ClientWorld world, ClientPlayerEntity player, BlockPos pos) {
        if (sessionWorld != world) {
            reset(world);
        }
        BlockPos above = pos.up();
        boolean blockedAbove = !world.getBlockState(above).isAir()
                && !world.getBlockState(above).isReplaceable();
        Box crystalColumn = crystalColumn(pos);
        if (findCrystal(player.getInventory(), player.getOffHandStack(), false)
                != PlayerInventory.NOT_FOUND
                && world.getOtherEntities(null, crystalColumn).isEmpty()
                && !blockedAbove) {
            armedPos = pos.toImmutable();
            placePending = true;
            rotatePending = true;
        }
    }

    public static void beforeMovementPackets(ClientPlayerEntity player) {
        AutoExplosionModule module = instance;
        if (module == null || !module.enabled() || module.armedPos == null
                || !module.rotatePending || player != MinecraftClient.getInstance().player
                || player.networkHandler == null) {
            return;
        }

        Direction side = module.interactionSide(player, module.armedPos);
        Vec3d faceCenter = Vec3d.ofCenter(module.armedPos)
                .subtract(Vec3d.of(side.getVector()).multiply(0.5));
        float[] rotation = rotationTo(player, faceCenter);
        module.movementYaw = rotation[0];
        module.movementPitch = rotation[1];
        module.movementRotationActive = true;
        module.rotatePending = false;
        module.renderRotationAge = player.age;
        ownsAuraRotation = true;

        player.networkHandler.sendPacket(new PlayerMoveC2SPacket.LookAndOnGround(
                module.movementYaw, module.movementPitch,
                player.isOnGround(), player.horizontalCollision));

        player.setHeadYaw(module.movementYaw);
        player.bodyYaw = module.movementYaw;
        player.renderYaw = module.movementYaw;
        player.renderPitch = module.movementPitch;
    }

    public static void afterMovementPackets() {
        AutoExplosionModule module = instance;
        if (module != null) {
            module.movementRotationActive = false;
        }
    }

    public static Packet<?> rewriteMovementPacket(Packet<?> packet) {
        AutoExplosionModule module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || !module.movementRotationActive
                || client.player == null || !(packet instanceof PlayerMoveC2SPacket movement)) {
            return packet;
        }
        ClientPlayerEntity player = client.player;
        if (movement.changesPosition()) {
            return new PlayerMoveC2SPacket.Full(
                    movement.getX(player.getX()), movement.getY(player.getY()),
                    movement.getZ(player.getZ()), module.movementYaw, module.movementPitch,
                    movement.isOnGround(), movement.horizontalCollision());
        }
        return new PlayerMoveC2SPacket.LookAndOnGround(
                module.movementYaw, module.movementPitch,
                movement.isOnGround(), movement.horizontalCollision());
    }

    public static boolean consumeAuraRotationSuppression(ClientPlayerEntity player) {
        boolean suppressed = ownsAuraRotation;
        if (suppressed && player != null && player.age % 10 == 0) {
            ownsAuraRotation = false;
        }
        return suppressed;
    }

    public static boolean ownsRenderRotation(ClientPlayerEntity player) {
        AutoExplosionModule module = instance;
        return module != null && module.enabled() && player != null
                && module.renderRotationAge == player.age;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.interactionManager == null) {
            reset(null);
            return;
        }
        if (sessionWorld != client.world) {
            reset(client.world);
        }
        if (armedPos == null || rotatePending) {
            return;
        }

        if (placePending) {
            placeCrystal(client, armedPos);
            placePending = false;
        }
        if (attackDelay > 0) {
            attackDelay = Math.max(0, (int) (attackDelay - 1.0F / timerMultiplier(client)));
            return;
        }

        List<EndCrystalEntity> crystals = client.world.getEntitiesByClass(
                EndCrystalEntity.class, crystalColumn(armedPos), EndCrystalEntity::isAlive);
        for (EndCrystalEntity crystal : crystals) {
            if (!canBreak(player, crystal)) {
                continue;
            }
            client.interactionManager.attackEntity(player, crystal);
            player.swingHand(Hand.MAIN_HAND);
            attackedCrystal = crystal;
        }
    }

    private void placeCrystal(MinecraftClient client, BlockPos base) {
        ClientPlayerEntity player = client.player;
        PlayerInventory inventory = player.getInventory();
        int selected = inventory.getSelectedSlot();
        boolean offhand = player.getOffHandStack().isOf(Items.END_CRYSTAL);
        int sourceSlot = findCrystal(inventory, player.getOffHandStack(), true);
        if (sourceSlot == PlayerInventory.NOT_FOUND) {

            return;
        }

        Hand hand = offhand ? Hand.OFF_HAND : Hand.MAIN_HAND;
        boolean inventorySwap = !offhand && sourceSlot >= PlayerInventory.getHotbarSize();
        if (!offhand) {
            if (inventorySwap) {
                clickSwap(client, player, sourceSlot, selected);
            } else {
                inventory.setSelectedSlot(sourceSlot);
            }
        }

        ActionResult result;
        try {
            Direction side = interactionSide(player, base);
            Vec3d hitPos = client.crosshairTarget != null
                    ? client.crosshairTarget.getPos()
                    : Vec3d.ofCenter(base)
                            .subtract(Vec3d.of(side.getVector()).multiply(0.5));
            result = client.interactionManager.interactBlock(player, hand,
                    new BlockHitResult(hitPos, side, base, false));
        } finally {
            if (inventorySwap) {
                clickSwap(client, player, sourceSlot, selected);
            } else if (!offhand) {
                inventory.setSelectedSlot(selected);
            }
        }

        if (result.isAccepted() && isStormServer(client)) {
            int baseDelay = offhand ? 3 : 11;
            attackDelay = (int) (baseDelay * timerMultiplier(client));
        }
    }

    private boolean canBreak(ClientPlayerEntity player, EndCrystalEntity crystal) {
        double vertical = player.getY() - crystal.getY();
        double dx = player.getX() - crystal.getX();
        double dz = player.getZ() - crystal.getZ();
        double horizontal = Math.sqrt(dx * dx + dz * dz);
        int maximum = vertical < -4.0
                ? 4 : horizontal > 2.8 && vertical < -3.0 ? 4 : 5;
        boolean safe = vertical < 0.0 && player.isOnGround()
                || !protectSelf.enabled()
                || isSkull(player.getOffHandStack())
                || player.isCreative();
        return player.distanceTo(crystal) <= maximum && player.canSee(crystal) && safe;
    }

    public static void onEntitiesDestroy(EntitiesDestroyS2CPacket packet) {
        AutoExplosionModule module = instance;
        if (module == null || !module.enabled() || module.attackedCrystal == null
                || !packet.getEntityIds().contains(module.attackedCrystal.getId())) {
            return;
        }
        module.armedPos = null;
        ownsAuraRotation = false;
    }

    private Direction interactionSide(ClientPlayerEntity player, BlockPos base) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (base.getY() == player.getEntityWorld().getTopYInclusive()) {
            return Direction.DOWN;
        }
        if (client.crosshairTarget instanceof BlockHitResult hit) {
            return hit.getSide();
        }
        Vec3d end = new Vec3d(base.getX() + 0.5, base.getY() - 0.5, base.getZ() + 0.5);
        BlockHitResult result = player.getEntityWorld().raycast(new RaycastContext(
                player.getEyePos(), end, RaycastContext.ShapeType.COLLIDER,
                RaycastContext.FluidHandling.NONE, player));
        return result.getType() == HitResult.Type.MISS ? Direction.UP : result.getSide();
    }

    private static Box crystalColumn(BlockPos base) {
        return new Box(base.getX(), base.getY(), base.getZ(),
                base.getX() + 1.0, base.getY() + 2.0, base.getZ() + 1.0);
    }

    private static int findCrystal(PlayerInventory inventory, ItemStack offhand, boolean hotbarFirst) {
        if (offhand.isOf(Items.END_CRYSTAL)) {
            return 0;
        }
        int end = Math.min(hotbarFirst ? PlayerInventory.getHotbarSize() : 36, inventory.size());
        for (int slot = 0; slot < end; slot++) {
            if (inventory.getStack(slot).isOf(Items.END_CRYSTAL)) {
                return slot;
            }
        }
        if (hotbarFirst) {
            for (int slot = PlayerInventory.getHotbarSize(); slot < Math.min(36, inventory.size()); slot++) {
                if (inventory.getStack(slot).isOf(Items.END_CRYSTAL)) {
                    return slot;
                }
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static void clickSwap(
            MinecraftClient client, ClientPlayerEntity player, int inventorySlot, int hotbarSlot
    ) {
        int handlerSlot = inventorySlot < PlayerInventory.getHotbarSize()
                ? 36 + inventorySlot : inventorySlot;
        client.interactionManager.clickSlot(
                player.playerScreenHandler.syncId, handlerSlot, hotbarSlot,
                SlotActionType.SWAP, player);
    }

    private static float[] rotationTo(ClientPlayerEntity player, Vec3d target) {
        Vec3d delta = target.subtract(player.getEyePos());
        double horizontal = Math.sqrt(delta.x * delta.x + delta.z * delta.z);
        float yaw = (float) (Math.toDegrees(Math.atan2(delta.z, delta.x)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(delta.y, horizontal));
        yaw = player.getYaw() + MathHelper.wrapDegrees(yaw - player.getYaw());
        pitch = player.getPitch() + MathHelper.wrapDegrees(pitch - player.getPitch());
        return new float[]{yaw, MathHelper.clamp(pitch, -90.0F, 90.0F)};
    }

    private static boolean isSkull(ItemStack stack) {
        if (stack.isEmpty()) {
            return false;
        }
        String path = net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).getPath();
        return path.endsWith("_head") || path.endsWith("_skull");
    }

    private static float timerMultiplier(MinecraftClient client) {
        if (client.getRenderTickCounter() instanceof RenderTickCounter.Dynamic
                && client.getRenderTickCounter() instanceof RenderTickCounterDynamicAccessor accessor) {
            return Math.max(0.05F, VANILLA_TICK_MILLIS / accessor.celestial$getTickTime());
        }
        return 1.0F;
    }

    private static boolean isStormServer(MinecraftClient client) {
        if (client.getCurrentServerEntry() == null) {
            return false;
        }
        return client.getCurrentServerEntry().address.toLowerCase(Locale.ROOT).contains("storm");
    }

    private void reset(ClientWorld world) {
        sessionWorld = world;
        armedPos = null;
        attackedCrystal = null;
        attackDelay = 0;
        placePending = false;
        rotatePending = false;
        movementRotationActive = false;
        renderRotationAge = Integer.MIN_VALUE;
        ownsAuraRotation = false;
    }

    @Override
    protected void onDisable() {
        reset(null);
    }
}
