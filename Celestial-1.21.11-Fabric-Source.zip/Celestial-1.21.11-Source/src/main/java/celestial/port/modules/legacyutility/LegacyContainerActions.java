package celestial.port.modules.legacyutility;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.LoreComponent;
import net.minecraft.item.ItemStack;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;

import java.util.Locale;

final class LegacyContainerActions {
    private LegacyContainerActions() {
    }

    static HandledScreen<?> currentHandledScreen(MinecraftClient client) {
        return client.currentScreen instanceof HandledScreen<?> handled ? handled : null;
    }

    static boolean titleContains(Screen screen, String configuredMarker) {
        String marker = configuredMarker.strip();
        return !marker.isEmpty()
                && screen.getTitle().getString().toLowerCase(Locale.ROOT)
                .contains(marker.toLowerCase(Locale.ROOT));
    }

    static boolean isContainerSlot(MinecraftClient client, Slot slot) {
        return client.player != null && slot.inventory != client.player.getInventory();
    }

    static boolean click(MinecraftClient client, ScreenHandler handler, Slot slot, SlotActionType action) {
        return click(client, handler, slot, 0, action);
    }

    static boolean click(
            MinecraftClient client, ScreenHandler handler, Slot slot, int button, SlotActionType action
    ) {
        if (client.player == null
                || client.interactionManager == null
                || slot == null
                || !slot.isEnabled()
                || !slot.canTakeItems(client.player)) {
            return false;
        }
        client.interactionManager.clickSlot(handler.syncId, slot.id, button, action, client.player);
        return true;
    }

    static String searchableText(ItemStack stack) {
        StringBuilder result = new StringBuilder(stack.getName().getString());
        LoreComponent lore = stack.get(DataComponentTypes.LORE);
        if (lore != null) {
            lore.lines().forEach(line -> result.append('\n').append(line.getString()));
        }
        return result.toString();
    }

    static Slot findHoveredSlot(HandledScreen<?> screen, double mouseX, double mouseY) {
        ScreenHandler handler = screen.getScreenHandler();
        int maximumX = handler.slots.stream().mapToInt(slot -> slot.x).max().orElse(162);
        int maximumY = handler.slots.stream().mapToInt(slot -> slot.y).max().orElse(140);
        int backgroundWidth = Math.max(176, maximumX + 14);
        int backgroundHeight = Math.max(166, maximumY + 26);
        int originX = (screen.width - backgroundWidth) / 2;
        int originY = (screen.height - backgroundHeight) / 2;
        for (Slot slot : handler.slots) {
            double left = originX + slot.x;
            double top = originY + slot.y;
            if (slot.isEnabled()
                    && mouseX >= left && mouseX < left + 16.0
                    && mouseY >= top && mouseY < top + 16.0) {
                return slot;
            }
        }
        return null;
    }
}
