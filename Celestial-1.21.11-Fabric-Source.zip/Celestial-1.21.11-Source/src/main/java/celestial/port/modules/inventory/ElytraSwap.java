package celestial.port.modules.inventory;

import celestial.port.CelestialPortClient;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BindSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.ScreenHandler;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.lwjgl.glfw.GLFW;

import java.util.OptionalInt;

public final class ElytraSwap extends Module {
    private static volatile ElytraSwap instance;
    private static boolean keepElytraEquipped;
    private final BindSetting activationKey = addSetting(new BindSetting(
            "activation_key", "Клавиша", GLFW.GLFW_KEY_H
    ));
    private final KeyPressLatch keyLatch = new KeyPressLatch();
    private int previousHotbarSlot;
    private int returnArmorInventorySlot = PlayerInventory.NOT_FOUND;
    private boolean returnArmorOnCursor;
    private boolean hotbarSlotSaved;
    private boolean swapping;
    private ClientPlayerEntity statePlayer;
    private ClientWorld stateWorld;
    private ClientPlayNetworkHandler stateNetworkHandler;

    public ElytraSwap() {
        super("elytra_swap", "Elytra Swap",
                "Автоматически надевает элитру с фейерверками нажатием на кнопку",
                Category.UTILITY);
        instance = this;
    }

    public BindSetting activationKey() {
        return activationKey;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        refreshSessionState(client);
        if (!keyLatch.poll(client, activationKey)) {
            return;
        }

        if (ordinaryFlightEnabled() || swapping || !canUsePlayerHandler(client)) {
            return;
        }

        ItemStack chest = client.player.getEquippedStack(EquipmentSlot.CHEST);
        PlayerInventory inventory = client.player.getInventory();
        boolean chestWasArmor = isChestArmor(chest);
        if (chest.isEmpty() || chestWasArmor) {
            keepElytraEquipped = false;
            returnArmorInventorySlot = PlayerInventory.NOT_FOUND;
            returnArmorOnCursor = false;
            hotbarSlotSaved = false;
            swapping = true;
            try {
                ScreenHandler handler = client.player.playerScreenHandler;
                boolean equipped;
                if (handler.getCursorStack().isOf(Items.ELYTRA)) {
                    equipped = swapCursorWithChest(client, handler);
                    returnArmorOnCursor = equipped && chestWasArmor;
                } else {
                    int elytra = first(inventory, Items.ELYTRA);
                    equipped = elytra != PlayerInventory.NOT_FOUND
                            && swapPlayerInventorySlots(client, handler, elytra,
                            InventoryActions.CHEST_INVENTORY_INDEX);
                    returnArmorInventorySlot = equipped && chestWasArmor
                            && isChestArmor(inventory.getStack(elytra))
                            ? elytra : PlayerInventory.NOT_FOUND;
                }
                if (!equipped || !client.player.getEquippedStack(EquipmentSlot.CHEST)
                        .isOf(Items.ELYTRA)) {
                    returnArmorInventorySlot = PlayerInventory.NOT_FOUND;
                    returnArmorOnCursor = false;
                    return;
                }

                keepElytraEquipped = true;
                hotbarSlotSaved = false;
                int firework = firstHotbar(inventory, Items.FIREWORK_ROCKET);
                if (firework != PlayerInventory.NOT_FOUND) {
                    previousHotbarSlot = inventory.getSelectedSlot();
                    hotbarSlotSaved = true;
                    inventory.setSelectedSlot(firework);
                }
            } finally {
                swapping = false;
            }
            return;
        }

        if (chest.isOf(Items.ELYTRA)) {

            keepElytraEquipped = false;
            swapping = true;
            try {
                ScreenHandler handler = client.player.playerScreenHandler;
                ItemStack cursor = handler.getCursorStack();
                if (returnArmorOnCursor && isChestArmor(cursor)) {
                    swapCursorWithChest(client, handler);
                } else {
                    int chestplate = validReturnArmorSlot(inventory)
                            ? returnArmorInventorySlot : firstChestArmor(inventory);
                    if (chestplate != PlayerInventory.NOT_FOUND) {
                        swapPlayerInventorySlots(client, handler, chestplate,
                                InventoryActions.CHEST_INVENTORY_INDEX);
                    }
                }
                returnArmorInventorySlot = PlayerInventory.NOT_FOUND;
                returnArmorOnCursor = false;
                if (hotbarSlotSaved
                        && previousHotbarSlot >= 0
                        && previousHotbarSlot < PlayerInventory.getHotbarSize()) {
                    inventory.setSelectedSlot(previousHotbarSlot);
                }
                hotbarSlotSaved = false;
            } finally {
                swapping = false;
            }
        }
    }

    private static boolean canUsePlayerHandler(MinecraftClient client) {
        return client.player != null
                && client.player.isAlive()
                && client.interactionManager != null
                && client.getNetworkHandler() != null
                && (client.currentScreen == null
                    || !client.interactionManager.getCurrentGameMode().isCreative())
                && client.player.currentScreenHandler == client.player.playerScreenHandler;
    }

    private static boolean swapCursorWithChest(
            MinecraftClient client, ScreenHandler handler
    ) {
        OptionalInt chestSlot = handler.getSlotIndex(
                client.player.getInventory(), InventoryActions.CHEST_INVENTORY_INDEX);
        if (chestSlot.isEmpty()) {
            return false;
        }
        Slot destination = handler.getSlot(chestSlot.getAsInt());
        ItemStack cursorBefore = handler.getCursorStack().copy();
        ItemStack chestBefore = destination.getStack().copy();
        if (cursorBefore.isEmpty() || !destination.canInsert(cursorBefore)
                || (!chestBefore.isEmpty() && !destination.canTakeItems(client.player))) {
            return false;
        }
        client.interactionManager.clickSlot(
                handler.syncId, destination.id, 0, SlotActionType.PICKUP, client.player);
        return ItemStack.areEqual(cursorBefore, destination.getStack())
                && ItemStack.areEqual(chestBefore, handler.getCursorStack());
    }

    private static boolean swapPlayerInventorySlots(
            MinecraftClient client, ScreenHandler handler,
            int sourceInventoryIndex, int destinationInventoryIndex
    ) {
        OptionalInt sourceSlotId = handler.getSlotIndex(
                client.player.getInventory(), sourceInventoryIndex);
        OptionalInt destinationSlotId = handler.getSlotIndex(
                client.player.getInventory(), destinationInventoryIndex);
        if (sourceSlotId.isEmpty() || destinationSlotId.isEmpty()) {
            return false;
        }

        Slot source = handler.getSlot(sourceSlotId.getAsInt());
        Slot destination = handler.getSlot(destinationSlotId.getAsInt());
        ItemStack sourceBefore = source.getStack().copy();
        ItemStack destinationBefore = destination.getStack().copy();
        ItemStack cursorBefore = handler.getCursorStack().copy();
        if (sourceBefore.isEmpty() || !source.canTakeItems(client.player)
                || !destination.canInsert(sourceBefore)
                || (!destinationBefore.isEmpty()
                && (!destination.canTakeItems(client.player)
                || !source.canInsert(destinationBefore)))
                || (!cursorBefore.isEmpty() && !source.canInsert(cursorBefore))) {
            return false;
        }

        client.interactionManager.clickSlot(
                handler.syncId, source.id, 0, SlotActionType.PICKUP, client.player);
        client.interactionManager.clickSlot(
                handler.syncId, destination.id, 0, SlotActionType.PICKUP, client.player);
        client.interactionManager.clickSlot(
                handler.syncId, source.id, 0, SlotActionType.PICKUP, client.player);
        return ItemStack.areEqual(cursorBefore, handler.getCursorStack())
                && ItemStack.areEqual(sourceBefore, destination.getStack())
                && ItemStack.areEqual(destinationBefore, source.getStack());
    }

    private static boolean ordinaryFlightEnabled() {
        return CelestialPortClient.MODULES.find("flight").filter(Module::enabled).isPresent();
    }

    private static int first(PlayerInventory inventory, net.minecraft.item.Item item) {
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (inventory.getStack(slot).isOf(item)) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static int firstHotbar(PlayerInventory inventory, net.minecraft.item.Item item) {

        for (int slot = 1; slot < PlayerInventory.getHotbarSize(); slot++) {
            if (inventory.getStack(slot).isOf(item)) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private boolean validReturnArmorSlot(PlayerInventory inventory) {
        return returnArmorInventorySlot >= 0
                && returnArmorInventorySlot < PlayerInventory.MAIN_SIZE
                && isChestArmor(inventory.getStack(returnArmorInventorySlot));
    }

    private static int firstChestArmor(PlayerInventory inventory) {
        for (int slot = 0; slot < PlayerInventory.MAIN_SIZE; slot++) {
            if (isChestArmor(inventory.getStack(slot))) {
                return slot;
            }
        }
        return PlayerInventory.NOT_FOUND;
    }

    private static boolean isChestArmor(ItemStack stack) {
        return !stack.isEmpty() && !stack.isOf(Items.ELYTRA)
                && InventoryActions.equips(stack, EquipmentSlot.CHEST);
    }

    private void refreshSessionState(MinecraftClient client) {
        if (statePlayer == client.player && stateWorld == client.world
                && stateNetworkHandler == client.getNetworkHandler()) {
            return;
        }
        clearSwapState();
        statePlayer = client.player;
        stateWorld = client.world;
        stateNetworkHandler = client.getNetworkHandler();
    }

    public static boolean keepingElytra() {
        ElytraSwap module = instance;
        return module != null && module.enabled() && keepElytraEquipped;
    }

    @Override
    protected void onEnable() {
        resetRuntimeState();
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        resetRuntimeState();
    }

    @Override
    protected void onDisable() {
        resetRuntimeState();
    }

    private void resetRuntimeState() {
        keyLatch.reset();
        clearSwapState();
        statePlayer = null;
        stateWorld = null;
        stateNetworkHandler = null;
    }

    private void clearSwapState() {
        swapping = false;
        keepElytraEquipped = false;
        returnArmorInventorySlot = PlayerInventory.NOT_FOUND;
        returnArmorOnCursor = false;
        hotbarSlotSaved = false;
    }
}
