package celestial.port.modules.player;

import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.setting.BindSetting;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

import org.lwjgl.glfw.GLFW;

public final class ClickTP extends Module {
    private static final double PLAYER_RAY_DISTANCE = 120.0;
    private static final double BLOCK_RAY_DISTANCE = 500.0;

    private final BindSetting activationKey = addSetting(new BindSetting(
            "key", "\u041a\u043b\u0430\u0432\u0438\u0448\u0430",
            BindSetting.forMouseButton(GLFW.GLFW_MOUSE_BUTTON_LEFT)
    ));
    private final KeyInputLatch keyLatch = new KeyInputLatch();
    private PlayerEntity aimedPlayer;

    public ClickTP() {
        super("click_tp", "ClickTP",
                "\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442\u0438\u0440\u0443\u0435\u0442 \u0432\u0430\u0441 \u0442\u0443\u0434\u0430, \u043a\u0443\u0434\u0430 \u0432\u044b \u043a\u043b\u0438\u043a\u043d\u0438\u0442\u0435", Category.PLAYER);
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null || client.currentScreen != null) {
            aimedPlayer = null;
            keyLatch.reset();
            return;
        }

        aimedPlayer = raycastPlayer(client);

        if (!keyLatch.poll(client, activationKey, client.options.attackKey)) {
            return;
        }

        BlockPos destination;
        boolean playerTarget;
        if (aimedPlayer != null) {
            destination = aimedPlayer.getBlockPos();
            playerTarget = true;
        } else {
            Vec3d eye = client.player.getEyePos();
            Vec3d end = eye.add(client.player.getRotationVec(1.0F).multiply(BLOCK_RAY_DISTANCE));
            BlockHitResult block = client.world.raycast(new RaycastContext(
                    eye, end, RaycastContext.ShapeType.OUTLINE,
                    RaycastContext.FluidHandling.NONE, client.player
            ));
            if (block.getType() != HitResult.Type.BLOCK) {
                return;
            }
            destination = block.getBlockPos();
            playerTarget = false;
        }

        double x = destination.getX();
        double y = destination.getY() + (playerTarget ? 0.5 : 1.0);
        double z = destination.getZ();
        if (isReallyWorld(client)) {
            boolean horizontalCollision = client.player.horizontalCollision;
            client.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    x, y, z, false, horizontalCollision
            ));
            client.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                    x, y, z, true, horizontalCollision
            ));
            for (int i = 0; i < 41; i++) {
                client.player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                        x, y + 2.0E7, z, true, horizontalCollision
                ));
            }
        } else {
            client.player.setPosition(x, y, z);
        }

        setEnabled(false);
    }

    public PlayerEntity aimedPlayer() {
        return aimedPlayer;
    }

    private static PlayerEntity raycastPlayer(MinecraftClient client) {
        Vec3d start = client.player.getEyePos();
        Vec3d end = start.add(client.player.getRotationVec(1.0F).multiply(PLAYER_RAY_DISTANCE));
        EntityHitResult hit = ProjectileUtil.raycast(
                client.player,
                start,
                end,
                client.player.getBoundingBox().stretch(end.subtract(start)).expand(1.0),
                entity -> entity instanceof PlayerEntity && entity != client.player && !entity.isSpectator(),
                PLAYER_RAY_DISTANCE * PLAYER_RAY_DISTANCE
        );
        return hit != null && hit.getEntity() instanceof PlayerEntity player ? player : null;
    }

    private static boolean isReallyWorld(MinecraftClient client) {
        return LegacyTeleportCoordinator.isReallyWorld(client);
    }

    @Override
    protected void onLoadedEnabledStateApplied() {
        aimedPlayer = null;
    }

    @Override
    protected void onDisable() {
        aimedPlayer = null;
        keyLatch.reset();
    }
}
