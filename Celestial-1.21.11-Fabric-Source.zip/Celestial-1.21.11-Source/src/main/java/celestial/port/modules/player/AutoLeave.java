package celestial.port.modules.player;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.PvpContext;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.legacyutility.BaritoneBridge;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.network.ClientConnection;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;

public final class AutoLeave extends Module {
    private static volatile AutoLeave instance;

    private static final String LOW_HEALTH = "\u041c\u0430\u043b\u043e \u0437\u0434\u043e\u0440\u043e\u0432\u044c\u044f";
    private static final String PLAYER_NEAR = "\u0420\u044f\u0434\u043e\u043c \u0438\u0433\u0440\u043e\u043a";
    private static final String STAFF_NEAR = "\u0420\u044f\u0434\u043e\u043c \u0441\u0442\u0430\u0444\u0444";
    private static final String STAFF_SPEC = "\u0421\u0442\u0430\u0444\u0444 \u0432 \u0441\u043f\u0435\u043a\u0435";
    private static final String DISCONNECT = "\u041e\u0442\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435";
    private static final String SPAWN = "\u0422\u0435\u043b\u0435\u043f\u043e\u0440\u0442 \u043d\u0430 \u0441\u043f\u0430\u0432\u043d";
    private static final Set<String> LEGACY_RANK_PREFIXES = Set.of(
            "\u0430\u0434\u043c\u0438\u043d", "admin", "ml.admin", "moder", "st.moder", "s.moder",
            "gl.moder", "j.moder", "\u043c\u043e\u0434\u0435\u0440\u0430\u0442\u043e\u0440", "\u043c\u043e\u0434\u0435\u0440",
            "st.helper", "\u0445\u0435\u043b\u043f\u0435\u0440", "helper", "yt"
    );
    private static final Pattern LEGACY_FORMATTING = Pattern.compile(
            "(?i)\\u00A7[0-9A-FK-OR]");

    private final MultiSelectSetting triggers = addSetting(new MultiSelectSetting(
            "triggers", "\u0421\u0440\u0430\u0431\u0430\u0442\u044b\u0432\u0430\u0442\u044c \u0435\u0441\u043b\u0438",
            Set.of(LOW_HEALTH), List.of(LOW_HEALTH, PLAYER_NEAR, STAFF_NEAR, STAFF_SPEC)
    ));
    private final ModeSetting mode = addSetting(new ModeSetting(
            "mode", "\u0420\u0435\u0436\u0438\u043c", DISCONNECT, List.of(DISCONNECT, SPAWN)
    ));
    private final NumberSetting health = addSetting(new NumberSetting(
            "health", "\u0417\u0434\u043e\u0440\u043e\u0432\u044c\u0435", 15.0, 5.0, 19.0, 1.0
    ).visibleWhen(() -> triggers.selected(LOW_HEALTH)));
    private final NumberSetting playerDistance = addSetting(new NumberSetting(
            "player_distance", "\u0414\u0438\u0441\u0442\u0430\u043d\u0446\u0438\u044f \u0434\u043e \u0438\u0433\u0440\u043e\u043a\u0430", 24.0, 12.0, 128.0, 4.0
    ).visibleWhen(() -> triggers.selected(PLAYER_NEAR)));
    private final BooleanSetting autoDisable = addSetting(new BooleanSetting(
            "auto_disable", "\u0410\u0432\u0442\u043e \u0432\u044b\u043a\u043b\u044e\u0447\u0435\u043d\u0438\u0435", true
    ));

    private final Map<String, StaffState> knownStaff = new LinkedHashMap<>();
    private final Map<String, Long> pendingStaff = new LinkedHashMap<>();
    private Object trackedNetworkHandler;

    public AutoLeave() {
        super("auto_leave", "Auto Leave",
                "\u0418\u0437\u0431\u0435\u0433\u0430\u0435\u0442 \u043a\u043e\u043d\u0442\u0430\u043a\u0442\u0430 \u0441 \u0438\u0433\u0440\u043e\u043a\u0430\u043c\u0438", Category.PLAYER);
        instance = this;
    }

    @Override
    protected void onTick() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null || client.isInSingleplayer() || PvpContext.active()) {
            return;
        }

        if (triggers.selected(LOW_HEALTH) && player.getHealth() <= health.value().floatValue()) {
            avoidDeath(client);
            disableAfterAction(true);

        }

        if (triggers.selected(STAFF_SPEC) || triggers.selected(STAFF_NEAR)) {
            for (StaffState staff : new ArrayList<>(knownStaff.values())) {
                if (triggers.selected(STAFF_SPEC) && staff.missingFromTab) {
                    avoidStaff(client, "staff spec!",
                            "Auto Leave: Successfully avoided staff " + staff.name + " spec!");
                }
                if (triggers.selected(STAFF_NEAR) && staff.seenNearby) {
                    avoidStaff(client, "staff near!",
                            "Auto Leave: Successfully avoided staff " + staff.name + " near!");
                }
            }
        }

        if (triggers.selected(PLAYER_NEAR)) {
            for (AbstractClientPlayerEntity other : client.world.getPlayers()) {
                if (!isAvoidablePlayer(player, other)
                        || player.distanceTo(other) > playerDistance.value().floatValue()) {
                    continue;
                }
                avoidPlayer(client, other);
                break;
            }
        }

    }

    public static void tickSharedStaffTracker(MinecraftClient client, boolean advanceStatus) {
        AutoLeave module = instance;
        if (module != null) {
            if (advanceStatus) {
                module.advanceStaffStatuses(client);
            } else {
                module.updateStaffTracker(client);
            }
        }
    }

    public static void clearSharedStaffTracker() {
        AutoLeave module = instance;
        if (module != null) {
            module.knownStaff.clear();
            module.pendingStaff.clear();
            module.trackedNetworkHandler = null;
        }
    }

    private void avoidDeath(MinecraftClient client) {
        if (mode.is(DISCONNECT)) {
            disconnect(client, "Auto Leave: Successfully avoided death!");
        } else if (mode.is(SPAWN)) {
            sendSpawn(client);
            chat(client, "Auto Leave: Successfully avoided death!");
        }
    }

    private void avoidStaff(MinecraftClient client, String disconnectReason, String spawnReason) {
        if (mode.is(DISCONNECT)) {
            disconnect(client, "Auto Leave: Successfully avoided " + disconnectReason);

            disableAfterAction(false);
        } else if (mode.is(SPAWN)) {
            sendSpawn(client);
            chat(client, spawnReason);

            disableAfterAction(true);
        }
    }

    private void avoidPlayer(MinecraftClient client, AbstractClientPlayerEntity other) {
        int distance = (int) client.player.distanceTo(other);
        String reason = "Auto Leave: Successfully avoided "
                + other.getDisplayName().getString() + " (" + distance + "m)";
        if (mode.is(DISCONNECT)) {
            disconnect(client, reason);

            disableAfterAction(true);
        } else if (mode.is(SPAWN)) {

            disableAfterAction(false);
            sendSpawn(client);
            chat(client, reason);
        }
    }

    private void disableAfterAction(boolean honorAutoDisable) {
        if (honorAutoDisable && !autoDisable.enabled()) {
            return;
        }
        BaritoneBridge.cancelPathing();
        if (enabled()) {
            disableFromServerCorrection();
        }
    }

    private static void disconnect(MinecraftClient client, String reason) {
        if (client.getNetworkHandler() == null) {
            return;
        }
        ClientConnection connection = client.getNetworkHandler().getConnection();
        if (connection != null && connection.isOpen()) {
            connection.disconnect(Text.literal(reason));
        }
    }

    private static void sendSpawn(MinecraftClient client) {
        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().sendChatCommand("spawn");
        }
    }

    private static void chat(MinecraftClient client, String message) {
        if (client.player != null) {
            client.player.sendMessage(Text.literal(message), false);
        }
    }

    private void updateStaffTracker(MinecraftClient client) {
        if (client.getNetworkHandler() == null) {
            return;
        }

        if (trackedNetworkHandler != client.getNetworkHandler()) {
            knownStaff.clear();
            pendingStaff.clear();
            trackedNetworkHandler = client.getNetworkHandler();
        }

        knownStaff.values().removeIf(staff -> staff.missingFromTab
                && client.world.getScoreboard().getScoreHolderTeam(staff.profileName) == null);

        Set<String> rankTeamMembers = new java.util.HashSet<>();
        String localName = client.player.getGameProfile().name();
        long now = System.currentTimeMillis();

        for (Team team : client.world.getScoreboard().getTeams()) {
            for (String profileName : team.getPlayerList()) {
                if (profileName.equals(localName)) {
                    knownStaff.remove(profileName);
                    continue;
                }
                String formatted = Team.decorateName(team, Text.literal(profileName)).getString();
                StaffState state = knownStaff.get(profileName);
                if (isLegacyAutoLeaveStaff(team, formatted)) {
                    rankTeamMembers.add(profileName);
                    if (state == null) {
                        long firstSeen = pendingStaff.computeIfAbsent(profileName, ignored -> now);
                        if (now - firstSeen >= 250L) {
                            state = new StaffState(profileName, formatted);
                            knownStaff.put(profileName, state);
                            pendingStaff.remove(profileName);
                        }
                    }
                }
            }
        }
        pendingStaff.keySet().removeIf(profileName -> !rankTeamMembers.contains(profileName));
    }

    private void advanceStaffStatuses(MinecraftClient client) {
        if (client.player == null || client.world == null || client.getNetworkHandler() == null
                || trackedNetworkHandler != client.getNetworkHandler()) {
            return;
        }
        Set<String> present = new java.util.HashSet<>();
        String localName = client.player.getGameProfile().name();
        for (PlayerListEntry entry : client.getNetworkHandler().getListedPlayerListEntries()) {
            String profileName = entry.getProfile().name();
            if (profileName.equals(localName)) {
                continue;
            }
            present.add(profileName);
        }
        for (Map.Entry<String, StaffState> entry : knownStaff.entrySet()) {
            StaffState state = entry.getValue();

            if (isEntityPresent(client, entry.getKey(), null)) {
                state.seenNearby = true;
                state.missingFromTab = false;
            } else {
                state.missingFromTab = !present.contains(entry.getKey());
            }
        }
    }

    private static boolean isLegacyAutoLeaveStaff(Team team, String formatted) {

        if (team.getPrefix().getString().isEmpty()) {
            return false;
        }
        String normalized = LEGACY_FORMATTING.matcher(formatted)
                .replaceAll("").toLowerCase(Locale.ROOT);
        return LEGACY_RANK_PREFIXES.stream().anyMatch(normalized::startsWith)
                && (formatted.contains("MODER") || formatted.contains("ADMIN"));
    }

    private static boolean isEntityPresent(MinecraftClient client,
                                           String profileName,
                                           UUID uuid) {
        for (AbstractClientPlayerEntity player : client.world.getPlayers()) {
            if (uuid != null && player.getUuid().equals(uuid)
                    || player.getGameProfile().name().equals(profileName)) {
                return true;
            }
        }
        return false;
    }

    private static boolean isAvoidablePlayer(ClientPlayerEntity local,
                                             AbstractClientPlayerEntity other) {
        return other != null
                && other != local
                && !other.getName().getString().equals(local.getName().getString())
                && !FriendManager.isFriend(other)
                && !legacyOfflineProfileFlag(other);
    }

    private static boolean legacyOfflineProfileFlag(AbstractClientPlayerEntity player) {
        UUID offlineUuid = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + player.getGameProfile().name()).getBytes(StandardCharsets.UTF_8)
        );
        return !player.getUuid().equals(offlineUuid);
    }

    private static final class StaffState {
        private final String profileName;
        private final String name;
        private boolean seenNearby;
        private boolean missingFromTab;

        private StaffState(String profileName, String name) {
            this.profileName = profileName;
            this.name = name;

            this.missingFromTab = true;
        }
    }
}
