package celestial.port.modules.impl;

import celestial.port.core.Category;
import celestial.port.core.Module;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import org.lwjgl.glfw.GLFW;

public final class AutoEat extends Module {
    private static volatile AutoEat instance;

    private PendingAction pendingAction = PendingAction.NONE;
    private ClientPlayerEntity pendingPlayer;

    public AutoEat() {
        super("auto_eat", "Auto Eat",
                "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u0435\u0441\u0442 \u0435\u0434\u0443", Category.PLAYER);
        instance = this;
    }

    @Override
    protected void onEnable() {
        clearPending();
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null) {
            client.player.sendMessage(legacyChat(
                    "\u0414\u043b\u044f \u044d\u0442\u043e\u0433\u043e \u043c\u043e\u0434\u0443\u043b\u044f \u043d\u0443\u0436\u043d\u0430 \u0435\u0434\u0430 \u0432 \u043b\u0435\u0432\u043e\u0439 \u0440\u0443\u043a\u0435!"), false);
        }
    }

    public static void captureBeforeVanillaPlayerTick(ClientPlayerEntity player) {
        AutoEat module = instance;
        if (module == null || !module.enabled()) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (player == null || player != client.player) {
            module.clearPending();
            return;
        }

        module.pendingPlayer = player;
        if (player.getHungerManager().getFoodLevel() < 20 && !player.isCreative()) {

            module.pendingAction = isEdible(player.getOffHandStack())
                    ? PendingAction.PRESS : PendingAction.NOOP;
            return;
        }
        boolean physicalRightMouse = GLFW.glfwGetMouseButton(
                client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;
        module.pendingAction = physicalRightMouse
                ? PendingAction.RESTORE_PRESSED : PendingAction.RESTORE_RELEASED;
    }

    @Override
    protected void onTick() {
        PendingAction action = pendingAction;
        ClientPlayerEntity player = pendingPlayer;
        clearPending();
        MinecraftClient client = MinecraftClient.getInstance();
        if (player == null || player != client.player) {
            return;
        }
        switch (action) {
            case PRESS -> client.options.useKey.setPressed(true);
            case RESTORE_PRESSED -> client.options.useKey.setPressed(true);
            case RESTORE_RELEASED -> client.options.useKey.setPressed(false);
            case NONE, NOOP -> {

            }
        }
    }

    private static boolean isEdible(ItemStack stack) {
        return !stack.isEmpty()
                && stack.getItem().getComponents().contains(DataComponentTypes.FOOD)
                && stack.getItem().getComponents().contains(DataComponentTypes.CONSUMABLE);
    }

    private void clearPending() {
        pendingAction = PendingAction.NONE;
        pendingPlayer = null;
    }

    @Override
    protected void onDisable() {

        clearPending();
    }

    private static Text legacyChat(String message) {
        return Text.empty()
                .append(Text.literal("(").formatted(Formatting.GRAY))
                .append(Text.literal("Celestial").formatted(Formatting.LIGHT_PURPLE))
                .append(Text.literal(") ").formatted(Formatting.GRAY))
                .append(Text.literal("\u00bb ").formatted(Formatting.DARK_GRAY))
                .append(Text.literal(message).formatted(Formatting.WHITE, Formatting.BOLD));
    }

    private enum PendingAction {
        NONE,
        NOOP,
        PRESS,
        RESTORE_PRESSED,
        RESTORE_RELEASED
    }
}
