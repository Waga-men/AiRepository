package celestial.port.modules.combat;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.modules.player.NoInteract;
import celestial.port.modules.visual.VisualColors;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.render.DrawStyle;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderLayers;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.util.Identifier;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.debug.gizmo.GizmoDrawing;

import java.nio.charset.StandardCharsets;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

public final class BackTrackModule extends Module {
    public static final String CHAMS = "Чамсы";
    public static final String HITBOXES = "Хитбоксы";
    public static final String NO_VISUAL = "Без визуала";

    private static final Identifier WHITE_TEXTURE =
            Identifier.of("celestial", "dynamic/backtrack_white");
    private static BackTrackModule instance;
    private static boolean whiteTextureRegistered;

    private final NumberSetting shift;
    private final ModeSetting visual;
    private final ModeSetting colorMode;
    private final ColorSetting color;
    private final BooleanSetting glow;
    private final Map<UUID, Track> tracks = new LinkedHashMap<>();
    private ClientWorld trackedWorld;

    public BackTrackModule() {
        super("back_track", "Back Track",
                "Замедляет хитбокс игрока на некоторое количество тиков", Category.COMBAT);

        shift = addSetting(new NumberSetting("shift", "Сдвиг", 3.0, 1.0, 7.0, 0.5));
        visual = addSetting(new ModeSetting("visual", "Выбор визуала", CHAMS,
                List.of(CHAMS, HITBOXES, NO_VISUAL)));
        colorMode = addSetting(new ModeSetting("color_mode", "Выбор цвета", "Client",
                List.of("Client", "Static")).visibleWhen(() -> !visual.is(NO_VISUAL)));
        color = addSetting(new ColorSetting("color", "Цвет", 0xFFFFFFFF)
                .visibleWhen(() -> !visual.is(NO_VISUAL) && colorMode.is("Static")));
        glow = addSetting(new BooleanSetting("glow", "Свечение", true)
                .visibleWhen(() -> visual.is(CHAMS)));
        instance = this;

        WorldRenderEvents.END_EXTRACTION.register(context -> collectHitboxes());
    }

    public static boolean enabledForAura() {
        BackTrackModule module = instance;
        return module != null && module.enabled();
    }

    public static void sampleBeforeTick(PlayerEntity player) {
        BackTrackModule module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || client.world == null || client.player == null
                || player.getEntityWorld() != client.world) {
            return;
        }

        module.synchronizeWorld(client.world);
        if (player == client.player || !player.isAlive() || player.isRemoved()
                || FriendManager.isFriend(player) || legacyBot(player)) {
            module.tracks.remove(player.getUuid());
            return;
        }

        Track track = module.tracks.computeIfAbsent(player.getUuid(), ignored -> new Track(player));
        track.entity = player;
        track.sample(player);
    }

    public static Optional<Vec3d> raycastHistory(LivingEntity target, Vec3d start, Vec3d end) {
        BackTrackModule module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || client.world == null) {
            return Optional.empty();
        }
        module.synchronizeWorld(client.world);
        Track track = module.tracks.get(target.getUuid());
        if (track == null || !track.visualActive()) {
            return Optional.empty();
        }
        return module.raycast(track, start, end).map(HistoricalHit::position);
    }

    public static void updateCrosshairTarget(float tickProgress) {
        BackTrackModule module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        Entity camera = client.getCameraEntity();
        if (module == null || !module.enabled() || player == null
                || client.world == null || camera == null) {
            return;
        }
        module.synchronizeWorld(client.world);

        double blockRange = ReachModule.legacyBlockScanRange(player);
        double entityRange = ReachModule.legacyEntityCutoff(player);
        double rayRange = ReachModule.legacyEntityScanRange(player);
        Vec3d start = camera.getCameraPosVec(tickProgress);
        Vec3d direction = camera.getRotationVec(1.0F);
        Vec3d end = start.add(direction.multiply(rayRange));
        Box searchBox = camera.getBoundingBox().stretch(direction.multiply(rayRange)).expand(1.0);
        List<Entity> candidates = client.world.getOtherEntities(
                camera, searchBox, EntityPredicates.CAN_HIT
                        .and(entity -> !NoInteract.skipsCrosshairEntity(entity)));

        boolean hasHistoricalIntersection = false;
        for (Entity candidate : candidates) {
            if (!(candidate instanceof PlayerEntity other) || other == player) {
                continue;
            }
            Track track = module.tracks.get(other.getUuid());
            if (track != null && module.raycast(track, start, end).isPresent()) {
                hasHistoricalIntersection = true;
                break;
            }
        }
        if (!hasHistoricalIntersection) {
            return;
        }

        HitResult blockHit = camera.raycast(blockRange, tickProgress, false);
        double blockDistance = blockHit.getType() == HitResult.Type.MISS
                ? Double.POSITIVE_INFINITY
                : start.distanceTo(blockHit.getPos());
        double selectedDistance = blockHit.getType() == HitResult.Type.MISS
                ? rayRange
                : blockDistance;
        Entity selectedEntity = null;
        Vec3d selectedPosition = null;

        for (Entity candidate : candidates) {
            Box currentBox = candidate.getBoundingBox().expand(candidate.getTargetingMargin());
            Optional<Vec3d> currentIntersection = currentBox.raycast(start, end);

            if (candidate instanceof PlayerEntity other && other != player) {
                Track track = module.tracks.get(other.getUuid());
                if (track != null) {
                    Optional<HistoricalHit> historical = module.raycast(track, start, end);
                    if (historical.isPresent()) {
                        selectedEntity = candidate;
                        selectedPosition = historical.get().position;
                        selectedDistance = 0.0;
                    }
                }
            }

            if (currentBox.contains(start)) {
                if (selectedDistance >= 0.0) {
                    selectedEntity = candidate;
                    selectedPosition = currentIntersection.orElse(start);
                    selectedDistance = 0.0;
                }
                continue;
            }

            if (currentIntersection.isEmpty()) {
                continue;
            }
            Vec3d hitPosition = currentIntersection.get();
            double distance = start.distanceTo(hitPosition);
            if (distance >= selectedDistance && selectedDistance != 0.0) {
                continue;
            }

            if (candidate.getRootVehicle() == camera.getRootVehicle()) {
                if (selectedDistance == 0.0) {
                    selectedEntity = candidate;
                    selectedPosition = hitPosition;
                }
                continue;
            }
            selectedEntity = candidate;
            selectedPosition = hitPosition;
            selectedDistance = distance;
        }

        boolean limitedReach = !player.isCreative() && rayRange > entityRange;
        if (selectedEntity != null && selectedPosition != null
                && limitedReach && start.distanceTo(selectedPosition) > entityRange) {
            Direction side = Direction.getFacing(
                    selectedPosition.x - start.x,
                    selectedPosition.y - start.y,
                    selectedPosition.z - start.z);
            client.targetedEntity = null;
            client.crosshairTarget = BlockHitResult.createMissed(
                    selectedPosition, side, BlockPos.ofFloored(selectedPosition));
            return;
        }

        if (selectedEntity != null && selectedPosition != null
                && selectedDistance < blockDistance) {
            client.targetedEntity = selectedEntity;
            client.crosshairTarget = new EntityHitResult(selectedEntity, selectedPosition);
        } else {
            client.targetedEntity = null;
            client.crosshairTarget = blockHit;
        }
    }

    public static ChamsGhost chamsGhost(PlayerEntityRenderState state) {
        BackTrackModule module = instance;
        MinecraftClient client = MinecraftClient.getInstance();
        if (module == null || !module.enabled() || !module.visual.is(CHAMS)
                || client.world == null || client.player == null) {
            return null;
        }
        module.synchronizeWorld(client.world);
        Entity rendered = client.world.getEntityById(state.id);
        if (!(rendered instanceof PlayerEntity player) || player == client.player) {
            return null;
        }
        Track track = module.tracks.get(player.getUuid());
        if (track == null || !track.visualActive()) {
            return null;
        }

        Snapshot snapshot = track.snapshot;
        float tickProgress = state.age - MathHelper.floor(state.age);
        Vec3d position = snapshot.previousPosition.lerp(snapshot.position, tickProgress);
        int baseColor = module.selectedColor();
        int alpha = (baseColor >>> 24) / 2;
        return new ChamsGhost(position, snapshot.yaw, snapshot.pitch,
                withAlpha(baseColor, alpha), module.glow.enabled());
    }

    public static RenderLayer chamsLayer(boolean additiveGlow) {
        if (additiveGlow) {
            return RenderLayers.lightning();
        }
        ensureWhiteTexture();
        return RenderLayers.entityTranslucent(WHITE_TEXTURE, false);
    }

    private Optional<HistoricalHit> raycast(Track track, Vec3d start, Vec3d end) {
        Optional<Box> box = historicalBox(track);
        if (box.isEmpty()) {
            return Optional.empty();
        }
        Optional<Vec3d> intersection = box.get().raycast(start, end);
        if (intersection.isEmpty()) {
            return Optional.empty();
        }
        Vec3d position = intersection.get();
        return Optional.of(new HistoricalHit(track.entity, position,
                start.squaredDistanceTo(position)));
    }

    private Optional<Box> historicalBox(Track track) {
        if (track.snapshot == null || !valid(track.entity)) {
            return Optional.empty();
        }
        Vec3d movement = track.entity.getEntityPos()
                .subtract(track.snapshot.position)
                .multiply(shift.value());
        return Optional.of(track.entity.getBoundingBox().offset(movement));
    }

    private void collectHitboxes() {
        if (!enabled() || !visual.is(HITBOXES)) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null) {
            clear();
            return;
        }
        synchronizeWorld(client.world);
        int selected = selectedColor();

        int argb = withAlpha(selected, Math.max(26, selected >>> 24));
        for (Track track : tracks.values()) {
            if (!track.visualActive()) {
                continue;
            }
            Optional<Box> box = historicalBox(track);
            if (box.isEmpty()) {
                continue;
            }
            GizmoDrawing.box(box.get(), DrawStyle.stroked(argb, 1.0F));
        }
    }

    private int selectedColor() {
        return colorMode.is("Static") ? color.argb() : VisualColors.clientColor(270.0F);
    }

    private void synchronizeWorld(ClientWorld world) {
        if (trackedWorld != world) {
            tracks.clear();
            trackedWorld = world;
        }
        tracks.entrySet().removeIf(entry -> {
            PlayerEntity player = entry.getValue().entity;
            return !valid(player) || world.getEntityById(player.getId()) != player;
        });
    }

    private static boolean valid(PlayerEntity player) {
        MinecraftClient client = MinecraftClient.getInstance();
        return player != null && player.isAlive() && !player.isRemoved()
                && client.world != null && player.getEntityWorld() == client.world;
    }

    private static boolean legacyBot(PlayerEntity player) {
        UUID offline = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + player.getGameProfile().name())
                        .getBytes(StandardCharsets.UTF_8));
        return !player.getUuid().equals(offline);
    }

    private static int withAlpha(int argb, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24 | argb & 0xFFFFFF;
    }

    private static void ensureWhiteTexture() {
        if (whiteTextureRegistered) {
            return;
        }
        NativeImageBackedTexture texture = new NativeImageBackedTexture(
                "Celestial BackTrack white", 1, 1, false);
        NativeImage image = texture.getImage();
        if (image != null) {
            image.setColorArgb(0, 0, 0xFFFFFFFF);
            texture.upload();
        }
        MinecraftClient.getInstance().getTextureManager().registerTexture(WHITE_TEXTURE, texture);
        whiteTextureRegistered = true;
    }

    private void clear() {
        tracks.clear();
        trackedWorld = null;
    }

    public record ChamsGhost(Vec3d position, float yaw, float pitch, int argb, boolean glow) {
    }

    private static final class Track {
        private PlayerEntity entity;
        private Snapshot snapshot;
        private Vec3d lastObservedPosition;
        private int stationaryTicks;

        private Track(PlayerEntity entity) {
            this.entity = entity;
        }

        private void sample(PlayerEntity player) {
            Vec3d current = player.getEntityPos();
            Vec3d previous = lastObservedPosition == null ? current : lastObservedPosition;
            Snapshot next = new Snapshot(previous, current, player.getYaw(), player.getPitch());
            if (snapshot != null && snapshot.position.equals(current)) {
                stationaryTicks++;
            } else {
                stationaryTicks = 0;
                snapshot = next;
            }

            lastObservedPosition = current;
        }

        private boolean visualActive() {
            return snapshot != null && stationaryTicks <= 0 && valid(entity);
        }
    }

    private record Snapshot(Vec3d previousPosition, Vec3d position, float yaw, float pitch) {
    }

    private record HistoricalHit(PlayerEntity entity, Vec3d position, double distanceSquared) {
    }
}
