package celestial.port.core.config;

import celestial.port.core.Module;
import celestial.port.core.ModuleManager;
import celestial.port.core.friend.FriendManager;
import celestial.port.core.setting.ActionSetting;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.core.setting.Setting;
import celestial.port.core.setting.TextSetting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashSet;
import java.util.Objects;
import java.util.Set;

public final class ConfigManager {
    public enum Scope {
        ACTIVE,
        MODULES_ONLY
    }

    private static final int SCHEMA_VERSION = 1;
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create();

    private final ModuleManager modules;
    private final Path configFile;
    private final Scope scope;

    public ConfigManager(ModuleManager modules) {
        this(modules, FabricLoader.getInstance().getConfigDir()
                .resolve("celestial")
                .resolve("modules.json"), Scope.ACTIVE);
    }

    public ConfigManager(ModuleManager modules, Path configFile) {
        this(modules, configFile, Scope.ACTIVE);
    }

    public ConfigManager(ModuleManager modules, Path configFile, Scope scope) {
        this.modules = Objects.requireNonNull(modules, "modules");
        this.configFile = Objects.requireNonNull(configFile, "configFile").toAbsolutePath().normalize();
        this.scope = Objects.requireNonNull(scope, "scope");
    }

    public Path configFile() {
        return configFile;
    }

    public synchronized void save() throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("schemaVersion", SCHEMA_VERSION);

        JsonObject moduleStates = new JsonObject();
        for (Module module : modules.modules()) {
            JsonObject state = new JsonObject();
            state.addProperty("enabled", module.enabled());
            state.addProperty("key", module.key());
            if (module.supportsDisableOnFlag()) {
                state.addProperty("flag", module.disableOnFlag());
            }
            if (module.supportsOnlyWithDisabler()) {
                state.addProperty("disabler", module.onlyWithDisabler());
            }

            JsonObject settingStates = new JsonObject();
            for (Setting<?> setting : module.settings()) {
                if (setting instanceof ActionSetting) {
                    continue;
                }
                settingStates.add(setting.id(), encode(setting));
            }
            state.add("settings", settingStates);
            moduleStates.add(module.id(), state);
        }
        root.add("modules", moduleStates);

        if (scope == Scope.ACTIVE) {
            JsonArray friends = new JsonArray();
            FriendManager.names().forEach(friends::add);
            root.add("friends", friends);
        }

        Path parent = configFile.getParent();
        if (parent != null) {
            Files.createDirectories(parent);
        }
        Path temporary = configFile.resolveSibling(configFile.getFileName() + ".tmp");
        try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
            GSON.toJson(root, writer);
        }
        try {
            Files.move(temporary, configFile, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException ignored) {
            Files.move(temporary, configFile, StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public synchronized boolean load() throws IOException {
        if (!Files.isRegularFile(configFile)) {
            return false;
        }

        JsonObject root;
        try (Reader reader = Files.newBufferedReader(configFile, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (!parsed.isJsonObject()) {
                throw new JsonParseException("Config root must be a JSON object");
            }
            root = parsed.getAsJsonObject();
        } catch (JsonParseException exception) {
            throw new IOException("Invalid Celestial config: " + configFile, exception);
        }

        return load(root);
    }

    public synchronized boolean load(JsonObject root) {
        Objects.requireNonNull(root, "root");

        JsonObject states = object(root, "modules");
        JsonElement friends = root.get("friends");
        if (scope == Scope.ACTIVE && friends != null && friends.isJsonArray()) {
            FriendManager.clear();
            for (JsonElement friend : friends.getAsJsonArray()) {
                if (friend.isJsonPrimitive()) {
                    FriendManager.add(friend.getAsString());
                }
            }
        }

        if (states == null) return true;

        for (Module module : modules.modules()) {
            JsonObject state = object(states, module.id());
            if (state == null) {
                continue;
            }

            Boolean enabled = bool(state, "enabled");
            if (enabled != null) {
                module.applyLoadedEnabled(enabled);
            }

            Integer key = integer(state, "key");
            if (key != null && BindSetting.isValid(key)) {

                int loadedKey = module.id().equals("click_gui")
                        && key == BindSetting.UNBOUND
                        ? GLFW.GLFW_KEY_RIGHT_SHIFT
                        : key;
                module.setKey(loadedKey);
            }

            Boolean flag = bool(state, "flag");
            if (flag != null) {
                module.setDisableOnFlag(flag);
            }
            Boolean disabler = bool(state, "disabler");
            if (disabler != null) {
                module.setOnlyWithDisabler(disabler);
            }

            JsonObject settingStates = object(state, "settings");
            if (settingStates != null) {
                for (Setting<?> setting : module.settings()) {
                    JsonElement value = settingStates.get(setting.id());
                    if (value == null || value.isJsonNull()) {
                        continue;
                    }
                    try {
                        decode(setting, value);
                    } catch (RuntimeException ignored) {

                    }
                }
            }

        }
        return true;
    }

    private static JsonElement encode(Setting<?> setting) {
        if (setting instanceof MultiSelectSetting multiSelect) {
            JsonArray values = new JsonArray();
            multiSelect.value().forEach(values::add);
            return values;
        }
        if (setting instanceof BooleanSetting booleanSetting) {
            return GSON.toJsonTree(booleanSetting.value());
        }
        if (setting instanceof NumberSetting numberSetting) {
            return GSON.toJsonTree(numberSetting.value());
        }
        if (setting instanceof ModeSetting modeSetting) {
            return GSON.toJsonTree(modeSetting.value());
        }
        if (setting instanceof ColorSetting colorSetting) {
            return GSON.toJsonTree(colorSetting.value());
        }
        if (setting instanceof TextSetting textSetting) {
            return GSON.toJsonTree(textSetting.value());
        }
        if (setting instanceof BindSetting bindSetting) {
            return GSON.toJsonTree(bindSetting.value());
        }
        throw new IllegalArgumentException("Unsupported setting type: " + setting.getClass().getName());
    }

    private static void decode(Setting<?> setting, JsonElement value) {
        if (setting instanceof BooleanSetting booleanSetting) {
            booleanSetting.setEnabled(value.getAsBoolean());
        } else if (setting instanceof NumberSetting numberSetting) {
            numberSetting.set(value.getAsDouble());
        } else if (setting instanceof ModeSetting modeSetting) {
            modeSetting.select(value.getAsString());
        } else if (setting instanceof MultiSelectSetting multiSelect) {
            if (!value.isJsonArray()) {
                throw new IllegalArgumentException("Multi-select value must be an array");
            }
            Set<String> selected = new LinkedHashSet<>();
            value.getAsJsonArray().forEach(element -> selected.add(element.getAsString()));
            multiSelect.setSelected(selected);
        } else if (setting instanceof ColorSetting colorSetting) {
            colorSetting.setArgb(value.getAsInt());
        } else if (setting instanceof TextSetting textSetting) {
            textSetting.set(value.getAsString());
        } else if (setting instanceof BindSetting bindSetting) {
            bindSetting.setKey(value.getAsInt());
        } else {
            throw new IllegalArgumentException("Unsupported setting type: " + setting.getClass().getName());
        }
    }

    private static JsonObject object(JsonObject parent, String key) {
        JsonElement value = parent.get(key);
        return value != null && value.isJsonObject() ? value.getAsJsonObject() : null;
    }

    private static Integer integer(JsonObject parent, String key) {
        JsonElement value = parent.get(key);
        try {
            return value != null && value.isJsonPrimitive() ? value.getAsInt() : null;
        } catch (NumberFormatException | UnsupportedOperationException exception) {
            return null;
        }
    }

    private static Boolean bool(JsonObject parent, String key) {
        JsonElement value = parent.get(key);
        try {
            return value != null && value.isJsonPrimitive() ? value.getAsBoolean() : null;
        } catch (UnsupportedOperationException exception) {
            return null;
        }
    }
}
