package celestial.port.core.friend;

import net.minecraft.entity.player.PlayerEntity;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public final class FriendManager {
    private static final Set<String> FRIENDS = ConcurrentHashMap.newKeySet();

    private FriendManager() {
    }

    public static Set<String> names() {
        return Collections.unmodifiableSet(new HashSet<>(FRIENDS));
    }

    public static boolean isFriend(String name) {
        return name != null && FRIENDS.contains(name);
    }

    public static boolean isFriend(PlayerEntity player) {
        return player != null && isFriend(player.getName().getString());
    }

    public static boolean toggle(String name) {
        if (name == null) {
            return false;
        }

        if (FRIENDS.add(name)) {
            return true;
        }
        remove(name);
        return false;
    }

    public static boolean toggle(PlayerEntity player) {
        return player != null && toggle(player.getName().getString());
    }

    public static boolean add(String name) {
        return name != null && FRIENDS.add(name);
    }

    public static boolean remove(String name) {
        if (name == null) {
            return false;
        }
        boolean removed = false;
        for (String stored : FRIENDS) {
            if (stored.equalsIgnoreCase(name)) {
                removed |= FRIENDS.remove(stored);
            }
        }
        return removed;
    }

    public static void clear() {
        FRIENDS.clear();
    }
}
