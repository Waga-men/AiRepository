package celestial.port.core.staff;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class ManualStaffRegistry {
    private static final Set<String> NAMES = new HashSet<>();
    private static final Path FILE = FabricLoader.getInstance().getGameDir()
            .resolve("Celestial").resolve("staff.celka").toAbsolutePath().normalize();
    private static boolean initialized;

    private ManualStaffRegistry() {
    }

    public static synchronized void initialize() {
        if (initialized) {
            return;
        }
        initialized = true;
        load();
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> save());
    }

    public static synchronized boolean add(String name) {
        return NAMES.add(name);
    }

    public static synchronized boolean remove(String name) {
        return NAMES.remove(name);
    }

    public static synchronized boolean isEmpty() {
        return NAMES.isEmpty();
    }

    public static synchronized List<String> names() {
        return List.copyOf(NAMES);
    }

    public static synchronized void clear() {
        NAMES.clear();
    }

    public static synchronized boolean matchesFormattedName(String formattedName) {
        for (String name : NAMES) {
            if (formattedName.contains(name)) {
                return true;
            }
        }
        return false;
    }

    public static Path file() {
        return FILE;
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (BufferedWriter writer = Files.newBufferedWriter(FILE, Charset.defaultCharset(),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                for (String name : NAMES) {
                    writer.write(name.replace(" ", ""));
                    writer.write("\r\n");
                }
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    private static void load() {
        try {
            Files.createDirectories(FILE.getParent());
            if (!Files.exists(FILE)) {
                Files.createFile(FILE);
                return;
            }
            try (BufferedReader reader = Files.newBufferedReader(FILE, Charset.defaultCharset())) {
                String line;
                while ((line = reader.readLine()) != null) {
                    String trimmed = line.trim();
                    NAMES.add(trimmed.split(":")[0]);
                }
            }
        } catch (Exception exception) {

            exception.printStackTrace();
        }
    }
}
