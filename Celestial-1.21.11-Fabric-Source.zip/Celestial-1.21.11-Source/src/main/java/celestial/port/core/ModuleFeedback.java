package celestial.port.core;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.BiConsumer;

public final class ModuleFeedback {
    private static final List<BiConsumer<Module, Boolean>> LISTENERS = new CopyOnWriteArrayList<>();

    private ModuleFeedback() {
    }

    public static void listen(BiConsumer<Module, Boolean> listener) {
        LISTENERS.add(listener);
    }

    static void publish(Module module, boolean enabled) {
        for (BiConsumer<Module, Boolean> listener : LISTENERS) {
            try {
                listener.accept(module, enabled);
            } catch (RuntimeException ignored) {

            }
        }
    }
}
