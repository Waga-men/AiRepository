package celestial.port.core.setting;

import celestial.port.core.LegacyString;

import java.util.List;
import java.util.Locale;

public final class ModeSetting extends Setting<String> {
    private final List<String> options;

    public ModeSetting(String id, String displayName, String defaultValue, List<String> options) {
        super(id, displayName, validateDefault(defaultValue, options));
        this.options = normalizeOptions(options);
    }

    private static String validateDefault(String defaultValue, List<String> options) {
        List<String> normalized = normalizeOptions(options);
        return canonicalOption(defaultValue, normalized);
    }

    private static List<String> normalizeOptions(List<String> options) {
        if (options == null || options.isEmpty()) {
            throw new IllegalArgumentException("Mode setting requires at least one option");
        }
        List<String> normalized = options.stream()
                .map(option -> requireText(option, "option"))
                .toList();
        if (normalized.stream().map(option -> option.toLowerCase(Locale.ROOT)).distinct().count() != normalized.size()) {
            throw new IllegalArgumentException("Mode setting options must be unique");
        }
        return normalized;
    }

    private static String canonicalOption(String value, List<String> options) {
        String candidate = requireText(value, "value");
        return options.stream()
                .filter(option -> option.equalsIgnoreCase(candidate))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown mode: " + value));
    }

    @Override
    protected String normalize(String value) {
        return canonicalOption(value, options);
    }

    public List<String> options() {
        return options;
    }

    public boolean is(String option) {
        return value().equalsIgnoreCase(LegacyString.repair(option));
    }

    public void select(String option) {
        setValue(option);
    }
}
