package celestial.port.core;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.Setting;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public abstract class Module {
    private static final Set<String> LEGACY_FLAG_MODULES = Set.of(
            "water_speed", "spider", "timer", "jesus", "flight",
            "damage_speed", "no_clip", "long_jump", "speed"
    );
    private static final Set<String> LEGACY_DISABLER_MODULES = Set.of(
            "strafe", "anti_levitation", "speed"
    );

    private final String id;
    private final String displayName;
    private final String description;
    private final Category category;
    private final List<Setting<?>> settings = new ArrayList<>();
    private final Map<String, Setting<?>> settingsById = new LinkedHashMap<>();

    private boolean enabled;
    private int key = BindSetting.UNBOUND;
    private boolean disableOnFlag = true;
    private boolean onlyWithDisabler;

    private boolean legacyDispatchActive = true;

    protected Module(String id, String displayName, String description, Category category) {
        this.id = Setting.normalizeId(id);
        this.displayName = requireText(displayName, "displayName");
        this.description = LegacyString.repair(
                Objects.requireNonNull(description, "description").strip());
        this.category = Objects.requireNonNull(category, "category");
    }

    public final String id() {
        return id;
    }

    public final String displayName() {
        return displayName;
    }

    public final String description() {
        return description;
    }

    public final Category category() {
        return category;
    }

    public final boolean enabled() {
        return enabled;
    }

    public final int key() {
        return key;
    }

    public final boolean supportsDisableOnFlag() {
        return LEGACY_FLAG_MODULES.contains(id);
    }

    public final boolean disableOnFlag() {
        return disableOnFlag;
    }

    public final void setDisableOnFlag(boolean disableOnFlag) {
        if (supportsDisableOnFlag()) this.disableOnFlag = disableOnFlag;
    }

    public final boolean supportsOnlyWithDisabler() {
        return LEGACY_DISABLER_MODULES.contains(id);
    }

    public final boolean onlyWithDisabler() {
        return onlyWithDisabler;
    }

    public final void setOnlyWithDisabler(boolean onlyWithDisabler) {
        if (supportsOnlyWithDisabler()) this.onlyWithDisabler = onlyWithDisabler;
    }

    public final boolean legacyDispatchActive() {
        return !supportsOnlyWithDisabler() || legacyDispatchActive;
    }

    public final void refreshLegacyDisablerDispatch(boolean disablerReady) {
        if (!supportsOnlyWithDisabler()) {
            return;
        }
        boolean next = !onlyWithDisabler || disablerReady;
        if (next == legacyDispatchActive) {
            return;
        }
        legacyDispatchActive = next;
        if (!next && enabled) {
            onLegacyDispatchSuspended();
        }
    }

    public final void setKey(int key) {
        if (!BindSetting.isValid(key)) {
            throw new IllegalArgumentException("Unsupported key or mouse binding: " + key);
        }
        this.key = key;
    }

    public final void setEnabled(boolean enabled) {
        if (this.enabled == enabled) {
            return;
        }

        boolean dispatchCallbacks = legacyDispatchActive();
        if (enabled) {
            this.enabled = true;
            if (!dispatchCallbacks) {
                try {
                    LegacyCommandFeedback.send(legacyInternalName()
                            + ": Включите Disabler!");
                } catch (RuntimeException ignored) {

                }
                ModuleFeedback.publish(this, true);
                return;
            }
            try {
                onEnable();
            } catch (RuntimeException | Error exception) {
                this.enabled = false;
                try {
                    onDisable();
                } catch (RuntimeException | Error cleanupFailure) {
                    exception.addSuppressed(cleanupFailure);
                }
                ModuleFeedback.publish(this, false);
                throw exception;
            }
        } else {
            this.enabled = false;
            if (!dispatchCallbacks) {
                ModuleFeedback.publish(this, false);
                return;
            }
            try {
                onDisable();
            } finally {
                ModuleFeedback.publish(this, false);
            }
            return;
        }
        ModuleFeedback.publish(this, this.enabled);
    }

    public final void applyLoadedEnabled(boolean enabled) {
        this.enabled = enabled;
        if (this.enabled && legacyDispatchActive()) {
            try {
                onLoadedEnabledStateApplied();
            } catch (RuntimeException exception) {

                exception.printStackTrace();
            }
        }
    }

    public final void toggle() {
        setEnabled(!enabled);
    }

    public final boolean disableFromServerCorrection() {
        if (!enabled) {
            return false;
        }
        enabled = false;
        onDisable();
        return true;
    }

    public final List<Setting<?>> settings() {
        return Collections.unmodifiableList(settings);
    }

    public final Optional<Setting<?>> setting(String id) {
        return Optional.ofNullable(settingsById.get(Setting.normalizeId(id)));
    }

    protected final <S extends Setting<?>> S addSetting(S setting) {
        Objects.requireNonNull(setting, "setting");
        if (settingsById.putIfAbsent(setting.id(), setting) != null) {
            throw new IllegalArgumentException("Duplicate setting id '" + setting.id() + "' in module '" + id + "'");
        }
        settings.add(setting);
        return setting;
    }

    final void tick() {
        if (enabled && legacyDispatchActive()) {
            onTick();
        }
    }

    protected void onEnable() {
    }

    protected void onDisable() {
    }

    protected void onLegacyDispatchSuspended() {
    }

    protected void onLoadedEnabledStateApplied() {
    }

    protected void onTick() {
    }

    private static String requireText(String value, String name) {
        Objects.requireNonNull(value, name);
        String stripped = value.strip();
        if (stripped.isEmpty()) {
            throw new IllegalArgumentException(name + " must not be blank");
        }
        return LegacyString.repair(stripped);
    }

    private String legacyInternalName() {
        return id.equals("anti_levitation") ? "AntiLevitation" : displayName;
    }
}
