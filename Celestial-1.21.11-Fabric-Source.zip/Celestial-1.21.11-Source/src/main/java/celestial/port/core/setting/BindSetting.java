package celestial.port.core.setting;

import org.lwjgl.glfw.GLFW;

public final class BindSetting extends Setting<Integer> {
    public static final int UNBOUND = -1;
    public static final int MOUSE_BIND_BASE = -100;
    private static final int LAST_MOUSE_BIND = MOUSE_BIND_BASE + 7;

    public BindSetting(String id, String displayName, int defaultKey) {
        super(id, displayName, validate(defaultKey));
    }

    private static int validate(int value) {
        if (!isValid(value)) {
            throw new IllegalArgumentException(
                    "Binding must be -1, a GLFW key, or a legacy mouse code");
        }
        return value;
    }

    public static boolean isValid(int value) {
        return value == UNBOUND || value >= 0
                || value >= MOUSE_BIND_BASE && value <= LAST_MOUSE_BIND;
    }

    public static boolean isMouseButton(int value) {
        return value >= MOUSE_BIND_BASE && value <= LAST_MOUSE_BIND;
    }

    public static int forMouseButton(int button) {
        if (button < 0 || button > 7) {
            throw new IllegalArgumentException("Mouse button must be between 0 and 7");
        }
        return MOUSE_BIND_BASE + button;
    }

    public static int mouseButton(int value) {
        if (!isMouseButton(value)) {
            throw new IllegalArgumentException("Not a mouse binding: " + value);
        }
        return value - MOUSE_BIND_BASE;
    }

    public static boolean isPressed(long window, int value) {
        if (isMouseButton(value)) {
            return GLFW.glfwGetMouseButton(window, mouseButton(value)) == GLFW.GLFW_PRESS;
        }
        return value >= 0 && GLFW.glfwGetKey(window, value) == GLFW.GLFW_PRESS;
    }

    @Override
    protected Integer normalize(Integer value) {
        return validate(value);
    }

    public int key() {
        return value();
    }

    public void setKey(int key) {
        setValue(key);
    }

    public boolean isBound() {
        return key() != UNBOUND;
    }
}
