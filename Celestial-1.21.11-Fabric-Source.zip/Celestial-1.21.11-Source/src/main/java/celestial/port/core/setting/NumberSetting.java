package celestial.port.core.setting;

public final class NumberSetting extends Setting<Double> {
    private final double minimum;
    private final double maximum;
    private final double step;

    public NumberSetting(String id, String displayName, double defaultValue, double minimum, double maximum) {
        this(id, displayName, defaultValue, minimum, maximum, 0.0);
    }

    public NumberSetting(String id, String displayName, double defaultValue,
                         double minimum, double maximum, double step) {
        super(id, displayName, validateDefault(defaultValue, minimum, maximum, step));
        this.minimum = minimum;
        this.maximum = maximum;
        this.step = step;
    }

    private static double validateDefault(double value, double minimum, double maximum, double step) {
        if (!Double.isFinite(minimum) || !Double.isFinite(maximum) || minimum > maximum) {
            throw new IllegalArgumentException("Number setting bounds must be finite and minimum <= maximum");
        }
        if (!Double.isFinite(step) || step < 0.0) {
            throw new IllegalArgumentException("Number setting step must be finite and non-negative");
        }
        if (!Double.isFinite(value)) {
            throw new IllegalArgumentException("Default value must be finite");
        }
        return snap(value, minimum, maximum, step);
    }

    @Override
    protected Double normalize(Double value) {
        if (!Double.isFinite(value)) {
            throw new IllegalArgumentException("Number setting value must be finite");
        }
        return snap(value, minimum, maximum, step);
    }

    private static double snap(double value, double minimum, double maximum, double step) {
        double clamped = Math.max(minimum, Math.min(maximum, value));
        if (step == 0.0) {
            return clamped;
        }
        double snapped = minimum + Math.round((clamped - minimum) / step) * step;
        return Math.max(minimum, Math.min(maximum, snapped));
    }

    public double minimum() {
        return minimum;
    }

    public double maximum() {
        return maximum;
    }

    public double step() {
        return step;
    }

    public void set(double value) {
        setValue(value);
    }
}
