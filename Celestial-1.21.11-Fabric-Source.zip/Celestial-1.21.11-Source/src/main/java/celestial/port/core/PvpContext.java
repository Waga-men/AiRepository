package celestial.port.core;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.boss.BossBar;
import net.minecraft.network.packet.s2c.play.BossBarS2CPacket;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;

public final class PvpContext {
    private static final Map<UUID, Boolean> BARS = new HashMap<>();
    private static ClientWorld sessionWorld;

    private PvpContext() {
    }

    public static synchronized void onBossBar(BossBarS2CPacket packet) {
        synchronizeSession();
        packet.accept(new BossBarS2CPacket.Consumer() {
            @Override
            public void add(UUID uuid, Text name, float percent, BossBar.Color color,
                            BossBar.Style style, boolean darkenSky,
                            boolean dragonMusic, boolean thickenFog) {
                BARS.put(uuid, isPvpName(name));
            }

            @Override
            public void updateName(UUID uuid, Text name) {
                BARS.put(uuid, isPvpName(name));
            }

            @Override
            public void remove(UUID uuid) {
                BARS.remove(uuid);
            }
        });
    }

    public static synchronized boolean active() {
        synchronizeSession();
        return BARS.containsValue(Boolean.TRUE);
    }

    private static void synchronizeSession() {
        ClientWorld current = MinecraftClient.getInstance().world;
        if (current != sessionWorld) {
            sessionWorld = current;
            BARS.clear();
        }
    }

    private static boolean isPvpName(Text name) {
        return name.getString().toLowerCase(Locale.ROOT).contains("pvp");
    }
}
