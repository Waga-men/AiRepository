package celestial.port.core.setting;

public final class TextSetting extends Setting<String> {
    private final int maximumLength;

    public TextSetting(String id, String displayName, String defaultValue) {
        this(id, displayName, defaultValue, 256);
    }

    public TextSetting(String id, String displayName, String defaultValue, int maximumLength) {
        super(id, displayName, validate(defaultValue, maximumLength));
        this.maximumLength = maximumLength;
    }

    private static String validate(String value, int maximumLength) {
        if (maximumLength < 1) {
            throw new IllegalArgumentException("maximumLength must be positive");
        }
        if (value == null) {
            throw new NullPointerException("value");
        }
        return value.length() <= maximumLength ? value : value.substring(0, maximumLength);
    }

    @Override
    protected String normalize(String value) {
        return value.length() <= maximumLength ? value : value.substring(0, maximumLength);
    }

    public int maximumLength() {
        return maximumLength;
    }

    public void set(String text) {
        setValue(text);
    }
}
