package celestial.port.core.macro;

import org.lwjgl.glfw.GLFW;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public final class LegacyMacroKeyCodec {
    private static final Map<Integer, Key> BY_LEGACY = new HashMap<>();
    private static final Map<String, Integer> BY_NAME = new HashMap<>();
    private static final Map<Integer, Integer> BY_GLFW = new HashMap<>();

    static {
        key(0, GLFW.GLFW_KEY_UNKNOWN, "NONE");
        key(1, GLFW.GLFW_KEY_ESCAPE, "ESCAPE");
        key(2, GLFW.GLFW_KEY_1, "1"); key(3, GLFW.GLFW_KEY_2, "2");
        key(4, GLFW.GLFW_KEY_3, "3"); key(5, GLFW.GLFW_KEY_4, "4");
        key(6, GLFW.GLFW_KEY_5, "5"); key(7, GLFW.GLFW_KEY_6, "6");
        key(8, GLFW.GLFW_KEY_7, "7"); key(9, GLFW.GLFW_KEY_8, "8");
        key(10, GLFW.GLFW_KEY_9, "9"); key(11, GLFW.GLFW_KEY_0, "0");
        key(12, GLFW.GLFW_KEY_MINUS, "MINUS"); key(13, GLFW.GLFW_KEY_EQUAL, "EQUALS");
        key(14, GLFW.GLFW_KEY_BACKSPACE, "BACK"); key(15, GLFW.GLFW_KEY_TAB, "TAB");
        letters(16, "QWERTYUIOP", new int[]{GLFW.GLFW_KEY_Q, GLFW.GLFW_KEY_W,
                GLFW.GLFW_KEY_E, GLFW.GLFW_KEY_R, GLFW.GLFW_KEY_T, GLFW.GLFW_KEY_Y,
                GLFW.GLFW_KEY_U, GLFW.GLFW_KEY_I, GLFW.GLFW_KEY_O, GLFW.GLFW_KEY_P});
        key(26, GLFW.GLFW_KEY_LEFT_BRACKET, "LBRACKET");
        key(27, GLFW.GLFW_KEY_RIGHT_BRACKET, "RBRACKET");
        key(28, GLFW.GLFW_KEY_ENTER, "RETURN"); key(29, GLFW.GLFW_KEY_LEFT_CONTROL, "LCONTROL");
        letters(30, "ASDFGHJKL", new int[]{GLFW.GLFW_KEY_A, GLFW.GLFW_KEY_S,
                GLFW.GLFW_KEY_D, GLFW.GLFW_KEY_F, GLFW.GLFW_KEY_G, GLFW.GLFW_KEY_H,
                GLFW.GLFW_KEY_J, GLFW.GLFW_KEY_K, GLFW.GLFW_KEY_L});
        key(39, GLFW.GLFW_KEY_SEMICOLON, "SEMICOLON");
        key(40, GLFW.GLFW_KEY_APOSTROPHE, "APOSTROPHE");
        key(41, GLFW.GLFW_KEY_GRAVE_ACCENT, "GRAVE");
        key(42, GLFW.GLFW_KEY_LEFT_SHIFT, "LSHIFT");
        key(43, GLFW.GLFW_KEY_BACKSLASH, "BACKSLASH");
        letters(44, "ZXCVBNM", new int[]{GLFW.GLFW_KEY_Z, GLFW.GLFW_KEY_X,
                GLFW.GLFW_KEY_C, GLFW.GLFW_KEY_V, GLFW.GLFW_KEY_B, GLFW.GLFW_KEY_N,
                GLFW.GLFW_KEY_M});
        key(51, GLFW.GLFW_KEY_COMMA, "COMMA"); key(52, GLFW.GLFW_KEY_PERIOD, "PERIOD");
        key(53, GLFW.GLFW_KEY_SLASH, "SLASH"); key(54, GLFW.GLFW_KEY_RIGHT_SHIFT, "RSHIFT");
        key(55, GLFW.GLFW_KEY_KP_MULTIPLY, "MULTIPLY");
        key(56, GLFW.GLFW_KEY_LEFT_ALT, "LMENU"); key(57, GLFW.GLFW_KEY_SPACE, "SPACE");
        key(58, GLFW.GLFW_KEY_CAPS_LOCK, "CAPITAL");
        for (int i = 0; i < 10; i++) key(59 + i, GLFW.GLFW_KEY_F1 + i, "F" + (i + 1));
        key(69, GLFW.GLFW_KEY_NUM_LOCK, "NUMLOCK"); key(70, GLFW.GLFW_KEY_SCROLL_LOCK, "SCROLL");
        keypad(71, 7); keypad(72, 8); keypad(73, 9);
        key(74, GLFW.GLFW_KEY_KP_SUBTRACT, "SUBTRACT");
        keypad(75, 4); keypad(76, 5); keypad(77, 6);
        key(78, GLFW.GLFW_KEY_KP_ADD, "ADD");
        keypad(79, 1); keypad(80, 2); keypad(81, 3); keypad(82, 0);
        key(83, GLFW.GLFW_KEY_KP_DECIMAL, "DECIMAL");
        key(87, GLFW.GLFW_KEY_F11, "F11"); key(88, GLFW.GLFW_KEY_F12, "F12");
        key(100, GLFW.GLFW_KEY_F13, "F13"); key(101, GLFW.GLFW_KEY_F14, "F14");
        key(102, GLFW.GLFW_KEY_F15, "F15");
        key(103, GLFW.GLFW_KEY_F16, "F16"); key(104, GLFW.GLFW_KEY_F17, "F17");
        key(105, GLFW.GLFW_KEY_F18, "F18");
        key(112, GLFW.GLFW_KEY_UNKNOWN, "KANA");
        key(113, GLFW.GLFW_KEY_F19, "F19");
        key(121, GLFW.GLFW_KEY_UNKNOWN, "CONVERT");
        key(123, GLFW.GLFW_KEY_UNKNOWN, "NOCONVERT");
        key(125, GLFW.GLFW_KEY_UNKNOWN, "YEN");
        key(141, GLFW.GLFW_KEY_KP_EQUAL, "NUMPADEQUALS");
        key(144, GLFW.GLFW_KEY_UNKNOWN, "CIRCUMFLEX");
        key(145, GLFW.GLFW_KEY_UNKNOWN, "AT");
        key(146, GLFW.GLFW_KEY_UNKNOWN, "COLON");
        key(147, GLFW.GLFW_KEY_UNKNOWN, "UNDERLINE");
        key(148, GLFW.GLFW_KEY_UNKNOWN, "KANJI");
        key(149, GLFW.GLFW_KEY_UNKNOWN, "STOP");
        key(150, GLFW.GLFW_KEY_UNKNOWN, "AX");
        key(151, GLFW.GLFW_KEY_UNKNOWN, "UNLABELED");
        key(156, GLFW.GLFW_KEY_KP_ENTER, "NUMPADENTER");
        key(157, GLFW.GLFW_KEY_RIGHT_CONTROL, "RCONTROL");
        key(167, GLFW.GLFW_KEY_UNKNOWN, "SECTION");
        key(179, GLFW.GLFW_KEY_UNKNOWN, "NUMPADCOMMA");
        key(181, GLFW.GLFW_KEY_KP_DIVIDE, "DIVIDE");
        key(183, GLFW.GLFW_KEY_PRINT_SCREEN, "SYSRQ");
        key(184, GLFW.GLFW_KEY_RIGHT_ALT, "RMENU");
        key(196, GLFW.GLFW_KEY_UNKNOWN, "FUNCTION");
        key(197, GLFW.GLFW_KEY_PAUSE, "PAUSE");
        key(199, GLFW.GLFW_KEY_HOME, "HOME"); key(200, GLFW.GLFW_KEY_UP, "UP");
        key(201, GLFW.GLFW_KEY_PAGE_UP, "PRIOR"); key(203, GLFW.GLFW_KEY_LEFT, "LEFT");
        key(205, GLFW.GLFW_KEY_RIGHT, "RIGHT"); key(207, GLFW.GLFW_KEY_END, "END");
        key(208, GLFW.GLFW_KEY_DOWN, "DOWN"); key(209, GLFW.GLFW_KEY_PAGE_DOWN, "NEXT");
        key(210, GLFW.GLFW_KEY_INSERT, "INSERT"); key(211, GLFW.GLFW_KEY_DELETE, "DELETE");
        key(218, GLFW.GLFW_KEY_UNKNOWN, "CLEAR");
        key(219, GLFW.GLFW_KEY_LEFT_SUPER, "LMETA", "LWIN");
        key(220, GLFW.GLFW_KEY_RIGHT_SUPER, "RMETA", "RWIN");
        key(221, GLFW.GLFW_KEY_MENU, "APPS");
        key(222, GLFW.GLFW_KEY_UNKNOWN, "POWER");
        key(223, GLFW.GLFW_KEY_UNKNOWN, "SLEEP");
    }

    private LegacyMacroKeyCodec() {
    }

    public static int fromLegacy(String name) {
        if (name == null) return 0;
        return BY_NAME.getOrDefault(name.toUpperCase(Locale.ROOT), 0);
    }

    public static String name(int legacyCode) {
        if (legacyCode < 0) {
            return switch (legacyCode) {
                case -100 -> "LEFT";
                case -99 -> "RIGHT";
                case -98 -> "MIDDLE";
                default -> "MOUSE" + (legacyCode + 101);
            };
        }
        Key key = BY_LEGACY.get(legacyCode);
        if (key != null) return key.name;
        return legacyCode >= 256
                ? Character.toString((char) (legacyCode - 256)).toUpperCase(Locale.ROOT)
                : "NONE";
    }

    public static int toGlfw(int legacyCode) {
        Key key = BY_LEGACY.get(legacyCode);
        return key == null ? GLFW.GLFW_KEY_UNKNOWN : key.glfw;
    }

    public static int fromGlfw(int glfwCode) {
        if (glfwCode == GLFW.GLFW_KEY_UNKNOWN) return 0;
        return BY_GLFW.getOrDefault(glfwCode, 0);
    }

    public static boolean isMouse(int legacyCode) {
        int button = legacyCode + 100;
        return legacyCode < 0 && button >= 0 && button <= GLFW.GLFW_MOUSE_BUTTON_LAST;
    }

    public static int mouseButton(int legacyCode) {
        return isMouse(legacyCode) ? legacyCode + 100 : -1;
    }

    private static void letters(int firstLegacy, String names, int[] glfw) {
        for (int i = 0; i < names.length(); i++) {
            key(firstLegacy + i, glfw[i], Character.toString(names.charAt(i)));
        }
    }

    private static void keypad(int legacy, int digit) {
        key(legacy, GLFW.GLFW_KEY_KP_0 + digit, "NUMPAD" + digit);
    }

    private static void key(int legacy, int glfw, String name, String... aliases) {
        Key value = new Key(glfw, name);
        BY_LEGACY.put(legacy, value);
        BY_NAME.put(name, legacy);
        if (glfw != GLFW.GLFW_KEY_UNKNOWN) BY_GLFW.putIfAbsent(glfw, legacy);
        for (String alias : aliases) BY_NAME.put(alias, legacy);
    }

    private record Key(int glfw, String name) {
    }
}
