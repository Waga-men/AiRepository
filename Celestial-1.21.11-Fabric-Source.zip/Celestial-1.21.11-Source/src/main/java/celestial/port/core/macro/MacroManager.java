package celestial.port.core.macro;

import celestial.port.CelestialPortClient;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.lwjgl.glfw.GLFW;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.IntPredicate;

public final class MacroManager {
    private static final List<Entry> ENTRIES = new ArrayList<>();
    private static final Path FILE = FabricLoader.getInstance().getGameDir()
            .resolve("Celestial").resolve("macro.celka").toAbsolutePath().normalize();
    private static boolean initialized;

    private MacroManager() {
    }

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        ENTRIES.addAll(load());
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> save());
    }

    public static synchronized List<Entry> entries() {
        return List.copyOf(ENTRIES);
    }

    public static synchronized void add(int legacyKey, String text) {
        ENTRIES.add(new Entry(legacyKey, Objects.requireNonNull(text, "text")));
        save();
    }

    public static synchronized int removeAll(int legacyKey) {
        int before = ENTRIES.size();
        ENTRIES.removeIf(entry -> entry.legacyKey == legacyKey);
        int removed = before - ENTRIES.size();
        save();
        return removed;
    }

    public static synchronized void clear() {
        ENTRIES.clear();
        save();
    }

    public static synchronized Path file() {
        return FILE;
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (BufferedWriter writer = Files.newBufferedWriter(FILE, Charset.defaultCharset(),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                for (Entry entry : ENTRIES) {
                    writer.write(Integer.toString(entry.legacyKey));
                    writer.write(':');
                    writer.write(entry.text);
                    writer.write("\r\n");
                }
            }
        } catch (IOException exception) {
            CelestialPortClient.LOGGER.error("Unable to save legacy macro file {}", FILE, exception);
        }
    }

    public static void onKeyboardPress(MinecraftClient client, long window, int glfwKey) {
        if (client.currentScreen != null || glfwKey == GLFW.GLFW_KEY_UNKNOWN) return;
        dispatch(client, window, legacyKey -> LegacyMacroKeyCodec.toGlfw(legacyKey) == glfwKey);
    }

    public static void onMousePress(MinecraftClient client, long window, int button) {
        int legacyKey = -100 + button;
        dispatch(client, window, candidate -> candidate == legacyKey);
    }

    private static void dispatch(MinecraftClient client, long window, IntPredicate matches) {
        if (client.player == null
                || GLFW.glfwGetKey(window, GLFW.GLFW_KEY_F3) == GLFW.GLFW_PRESS
                || client.player.getHealth() <= 0.0F
                || client.player.networkHandler == null) {
            return;
        }

        ClientPlayNetworkHandler networkHandler = client.player.networkHandler;
        List<Entry> snapshot;
        synchronized (MacroManager.class) {
            snapshot = List.copyOf(ENTRIES);
        }
        for (Entry entry : snapshot) {
            if (matches.test(entry.legacyKey)) {
                networkHandler.sendChatMessage(entry.text);
            }
        }
    }

    private static List<Entry> load() {
        List<Entry> loaded = new ArrayList<>();
        try {
            Files.createDirectories(FILE.getParent());
            if (!Files.exists(FILE)) {
                Files.createFile(FILE);
                return loaded;
            }
            try (BufferedReader reader = Files.newBufferedReader(FILE, Charset.defaultCharset())) {
                String line;
                while ((line = reader.readLine()) != null) {

                    String[] fields = line.trim().split(":");
                    loaded.add(new Entry(Integer.parseInt(fields[0]), fields[1]));
                }
            }
        } catch (Exception exception) {

            CelestialPortClient.LOGGER.error("Unable to load legacy macro file {}", FILE, exception);
        }
        return loaded;
    }

    public record Entry(int legacyKey, String text) {
        public Entry {
            Objects.requireNonNull(text, "text");
        }
    }
}
