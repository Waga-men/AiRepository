package celestial.port.core;

import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.Setting;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public final class ModuleManager {
    private static final Logger LOGGER = LoggerFactory.getLogger("celestial/modules");
    private final Map<String, Module> modulesById = new LinkedHashMap<>();

    public <M extends Module> M register(M module) {
        Objects.requireNonNull(module, "module");
        if (modulesById.putIfAbsent(module.id(), module) != null) {
            throw new IllegalArgumentException("Duplicate module id: " + module.id());
        }
        return module;
    }

    public void registerAll(Collection<? extends Module> modules) {
        Objects.requireNonNull(modules, "modules").forEach(this::register);
    }

    public List<Module> modules() {
        return List.copyOf(modulesById.values());
    }

    public Optional<Module> find(String id) {
        return Optional.ofNullable(modulesById.get(Setting.normalizeId(id)));
    }

    public Module require(String id) {
        return find(id).orElseThrow(() -> new IllegalArgumentException("Unknown module: " + id));
    }

    public List<Module> byCategory(Category category) {
        Objects.requireNonNull(category, "category");
        return modulesById.values().stream()
                .filter(module -> module.category() == category)
                .toList();
    }

    public boolean toggle(String id) {
        Optional<Module> module = find(id);
        module.ifPresent(Module::toggle);
        return module.isPresent();
    }

    public int toggleByKey(int key) {
        if (!BindSetting.isValid(key) || key == BindSetting.UNBOUND) {
            return 0;
        }
        int toggled = 0;
        for (Module module : modulesById.values()) {
            if (module.key() == key && module.key() != BindSetting.UNBOUND) {
                module.toggle();
                toggled++;
            }
        }
        return toggled;
    }

    public void tick() {
        for (Module module : List.copyOf(modulesById.values())) {
            try {
                module.tick();
            } catch (RuntimeException exception) {
                LOGGER.error("Disabling module '{}' after an uncaught tick error", module.id(), exception);
                try {
                    module.setEnabled(false);
                } catch (RuntimeException disableFailure) {
                    exception.addSuppressed(disableFailure);
                }
            }
        }
    }

    public void disableAll() {
        for (Module module : List.copyOf(modulesById.values())) {
            if (!module.enabled()) {
                continue;
            }
            try {
                module.setEnabled(false);
            } catch (RuntimeException exception) {
                LOGGER.error("Module '{}' failed during shutdown cleanup", module.id(), exception);
            }
        }
    }
}
