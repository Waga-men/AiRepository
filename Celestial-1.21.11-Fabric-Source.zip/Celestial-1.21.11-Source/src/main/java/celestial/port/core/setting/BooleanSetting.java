package celestial.port.core.setting;

public final class BooleanSetting extends Setting<Boolean> {
    public BooleanSetting(String id, String displayName, boolean defaultValue) {
        super(id, displayName, defaultValue);
    }

    @Override
    protected Boolean normalize(Boolean value) {
        return value;
    }

    public boolean enabled() {
        return value();
    }

    public void setEnabled(boolean enabled) {
        setValue(enabled);
    }

    public void toggle() {
        setValue(!value());
    }
}
