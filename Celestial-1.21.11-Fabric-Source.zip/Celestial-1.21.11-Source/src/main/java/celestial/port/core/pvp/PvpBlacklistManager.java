package celestial.port.core.pvp;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyCommandFeedback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.item.Items;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class PvpBlacklistManager {
    private static final Set<String> NAMES = new LinkedHashSet<>();
    private static final Path FILE = FabricLoader.getInstance().getGameDir()
            .resolve("Celestial").resolve("pvpbl.celka").toAbsolutePath().normalize();
    private static boolean initialized;

    private PvpBlacklistManager() {
    }

    public static synchronized void initialize() {
        if (initialized) {
            return;
        }
        initialized = true;
        load();
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> save());
    }

    public static synchronized List<String> names() {
        initialize();
        return List.copyOf(NAMES);
    }

    public static synchronized boolean add(String name) {
        initialize();
        boolean changed = NAMES.add(name);
        if (changed) {
            save();
        }
        return changed;
    }

    public static synchronized boolean removeIgnoreCase(String name) {
        initialize();
        boolean changed = NAMES.removeIf(entry -> entry.equalsIgnoreCase(name));
        if (changed) {
            save();
        }
        return changed;
    }

    public static synchronized boolean clear() {
        initialize();
        if (NAMES.isEmpty()) {
            return false;
        }
        NAMES.clear();
        save();
        return true;
    }

    public static void onHandledScreenTick(HandledScreen<?> screen) {
        initialize();
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || names().isEmpty()
                || !screen.getTitle().getString().contains("PVP")) {
            return;
        }
        List<String> configured = names();
        for (var slot : screen.getScreenHandler().slots) {
            if (slot.inventory == client.player.getInventory() || !slot.hasStack()
                    || !slot.getStack().isOf(Items.PLAYER_HEAD)) {
                continue;
            }
            String displayName = slot.getStack().getName().getString();
            String lowered = displayName.toLowerCase(Locale.ROOT);
            boolean blocked = configured.stream()
                    .map(name -> name.toLowerCase(Locale.ROOT))
                    .anyMatch(name -> name.contains(lowered));
            if (!blocked) {
                continue;
            }
            client.player.closeHandledScreen();
            LegacyCommandFeedback.send("\u0412\u044B \u0438\u0437\u0431\u0435\u0436\u0430\u043B\u0438 PvP \u0441 \u00A7c"
                    + displayName + "\u00A7r!");
        }
    }

    private static void load() {
        try {
            Files.createDirectories(FILE.getParent());
            if (!Files.exists(FILE)) {
                Files.createFile(FILE);
                return;
            }
            try (BufferedReader reader = Files.newBufferedReader(FILE, Charset.defaultCharset())) {
                String line;
                while ((line = reader.readLine()) != null) {
                    NAMES.add(line.trim());
                }
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    public static synchronized void save() {
        try {
            Files.createDirectories(FILE.getParent());
            try (BufferedWriter writer = Files.newBufferedWriter(FILE, Charset.defaultCharset(),
                    StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING)) {
                for (String name : NAMES) {
                    writer.write(name.replace(" ", ""));
                    writer.write("\r\n");
                }
            }
        } catch (Exception exception) {
            CelestialPortClient.LOGGER.error("Unable to save legacy PvP blacklist {}", FILE, exception);
            exception.printStackTrace();
        }
    }
}
