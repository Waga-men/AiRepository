package celestial.port.core.setting;

import celestial.port.core.LegacyString;

import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class MultiSelectSetting extends Setting<Set<String>> {
    private final List<String> options;

    public MultiSelectSetting(
            String id,
            String displayName,
            Collection<String> defaultValue,
            List<String> options
    ) {
        super(id, displayName, validateDefault(defaultValue, options));
        this.options = normalizeOptions(options);
    }

    private static Set<String> validateDefault(Collection<String> values, List<String> options) {
        List<String> normalizedOptions = normalizeOptions(options);
        return canonicalSelection(values, normalizedOptions);
    }

    private static List<String> normalizeOptions(List<String> options) {
        if (options == null || options.isEmpty()) {
            throw new IllegalArgumentException("Multi-select setting requires at least one option");
        }
        List<String> normalized = options.stream()
                .map(option -> requireText(option, "option"))
                .toList();
        if (normalized.stream().map(option -> option.toLowerCase(Locale.ROOT)).distinct().count() != normalized.size()) {
            throw new IllegalArgumentException("Multi-select options must be unique");
        }
        return normalized;
    }

    private static Set<String> canonicalSelection(Collection<String> values, List<String> options) {
        if (values == null) {
            throw new NullPointerException("values");
        }
        Set<String> requested = new LinkedHashSet<>();
        for (String value : values) {
            String candidate = requireText(value, "value");
            String canonical = options.stream()
                    .filter(option -> option.equalsIgnoreCase(candidate))
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("Unknown option: " + value));
            requested.add(canonical);
        }

        LinkedHashSet<String> ordered = new LinkedHashSet<>();
        options.stream().filter(requested::contains).forEach(ordered::add);
        return Collections.unmodifiableSet(ordered);
    }

    @Override
    protected Set<String> normalize(Set<String> value) {
        return canonicalSelection(value, options);
    }

    public List<String> options() {
        return options;
    }

    public boolean selected(String option) {
        String repaired = LegacyString.repair(option);
        return value().stream().anyMatch(selected -> selected.equalsIgnoreCase(repaired));
    }

    public void setSelected(Collection<String> selected) {
        setValue(new LinkedHashSet<>(selected));
    }

    public void toggle(String option) {
        LinkedHashSet<String> next = new LinkedHashSet<>(value());
        String repaired = LegacyString.repair(requireText(option, "option"));
        String canonical = options.stream()
                .filter(candidate -> candidate.equalsIgnoreCase(repaired))
                .findFirst()
                .orElseThrow(() -> new IllegalArgumentException("Unknown option: " + option));
        if (!next.remove(canonical)) {
            next.add(canonical);
        }
        setValue(next);
    }
}
