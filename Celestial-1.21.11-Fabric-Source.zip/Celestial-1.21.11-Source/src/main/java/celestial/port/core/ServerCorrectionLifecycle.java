package celestial.port.core;

import celestial.port.CelestialPortClient;
import celestial.port.client.ui.ClientFeedback;
import celestial.port.modules.movement.Strafe;
import celestial.port.modules.movement.TimerModule;
import celestial.port.modules.movement.WaterSpeed;
import net.minecraft.block.FluidBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;

public final class ServerCorrectionLifecycle {
    private ServerCorrectionLifecycle() {
    }

    public static void onPlayerPositionLook() {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null || client.world == null) {
            return;
        }

        boolean liquidSetback = client.world.getBlockState(BlockPos.ofFloored(
                        player.getX(), player.getY() - 0.01, player.getZ()))
                .getBlock() instanceof FluidBlock || player.isTouchingWater();

        for (Module module : CelestialPortClient.MODULES.modules()) {
            if (!module.enabled() || !module.supportsDisableOnFlag() || !module.disableOnFlag()) {
                continue;
            }

            boolean waterCorrection;
            boolean disabled;
            switch (module.id()) {
                case "flight", "long_jump", "spider", "speed", "damage_speed", "no_clip" -> {
                    waterCorrection = false;
                    disabled = module.disableFromServerCorrection();
                }
                case "timer" -> {
                    waterCorrection = false;
                    disabled = module.disableFromServerCorrection();
                    if (disabled) {
                        TimerModule.forceVanillaAfterServerCorrection();
                    }
                }
                case "jesus" -> {
                    waterCorrection = true;
                    disabled = liquidSetback && module.disableFromServerCorrection();
                }
                case "water_speed" -> {
                    waterCorrection = true;
                    disabled = liquidSetback
                            && module instanceof WaterSpeed waterSpeed
                            && waterSpeed.allowsServerCorrection(player)
                            && module.disableFromServerCorrection();
                }
                default -> {
                    continue;
                }
            }
            if (disabled) {
                ClientFeedback.flagDetector(legacyName(module.id()), waterCorrection);
            }
        }

        Strafe.onServerCorrection();
    }

    private static String legacyName(String id) {
        return switch (id) {
            case "long_jump" -> "LongJump";
            case "water_speed" -> "WaterSpeed";
            case "damage_speed" -> "DamageSpeed";
            case "no_clip" -> "NoClip";
            default -> Character.toUpperCase(id.charAt(0)) + id.substring(1);
        };
    }
}
