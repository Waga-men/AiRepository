package celestial.port.core.setting;

import java.util.Objects;

public final class ActionSetting extends Setting<Boolean> {
    private final Runnable action;

    public ActionSetting(String id, String displayName, Runnable action) {
        super(id, displayName, false);
        this.action = Objects.requireNonNull(action, "action");
    }

    public void activate() {
        action.run();
    }

    @Override
    protected Boolean normalize(Boolean value) {
        return false;
    }
}
