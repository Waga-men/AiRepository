package celestial.port.core.setting;

import celestial.port.core.LegacyString;

import java.util.Locale;
import java.util.Objects;
import java.util.regex.Pattern;
import java.util.function.BooleanSupplier;

public abstract class Setting<T> {
    private static final Pattern VALID_ID = Pattern.compile("[a-z0-9][a-z0-9_.-]*");

    private final String id;
    private final String displayName;
    private final T defaultValue;
    private T value;
    private BooleanSupplier visibility = () -> true;

    protected Setting(String id, String displayName, T defaultValue) {
        this.id = normalizeId(id);
        this.displayName = requireText(displayName, "displayName");

        this.defaultValue = Objects.requireNonNull(defaultValue, "defaultValue");
        this.value = this.defaultValue;
    }

    public final String id() {
        return id;
    }

    public final String displayName() {
        return displayName;
    }

    public final T value() {
        return value;
    }

    public final T defaultValue() {
        return defaultValue;
    }

    public final void setValue(T value) {
        this.value = normalize(Objects.requireNonNull(value, "value"));
    }

    public final void reset() {
        value = defaultValue;
    }

    public final boolean visible() {
        return visibility.getAsBoolean();
    }

    @SuppressWarnings("unchecked")
    public final <S extends Setting<T>> S visibleWhen(BooleanSupplier predicate) {
        visibility = Objects.requireNonNull(predicate, "predicate");
        return (S) this;
    }

    protected abstract T normalize(T value);

    public static String normalizeId(String id) {
        String normalized = requireText(id, "id").toLowerCase(Locale.ROOT);
        if (!VALID_ID.matcher(normalized).matches()) {
            throw new IllegalArgumentException("Invalid id: " + id);
        }
        return normalized;
    }

    protected static String requireText(String value, String name) {
        Objects.requireNonNull(value, name);
        String stripped = value.strip();
        if (stripped.isEmpty()) {
            throw new IllegalArgumentException(name + " must not be blank");
        }
        return LegacyString.repair(stripped);
    }
}
