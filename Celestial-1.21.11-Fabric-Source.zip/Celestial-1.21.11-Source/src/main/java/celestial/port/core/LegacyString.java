package celestial.port.core;

import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

public final class LegacyString {
    private static final Charset WINDOWS_1251 = Charset.forName("windows-1251");

    private LegacyString() {
    }

    public static String repair(String value) {
        String repaired = Objects.requireNonNull(value, "value");
        for (int layer = 0; layer < 3; layer++) {
            if (!WINDOWS_1251.newEncoder().canEncode(repaired)) {
                break;
            }
            String decoded;
            try {
                decoded = StandardCharsets.UTF_8.newDecoder()
                        .onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT)
                        .decode(ByteBuffer.wrap(repaired.getBytes(WINDOWS_1251)))
                        .toString();
            } catch (CharacterCodingException ignored) {
                break;
            }
            if (decoded.equals(repaired)) {
                break;
            }
            repaired = decoded;
        }
        return repaired;
    }
}
