package celestial.port.core.setting;

public final class ColorSetting extends Setting<Integer> {
    private final boolean alphaEditable;

    public ColorSetting(String id, String displayName, int defaultArgb) {
        this(id, displayName, defaultArgb, true);
    }

    public ColorSetting(String id, String displayName, int defaultArgb, boolean alphaEditable) {
        super(id, displayName, defaultArgb);
        this.alphaEditable = alphaEditable;
    }

    @Override
    protected Integer normalize(Integer value) {
        return value;
    }

    public int argb() {
        return value();
    }

    public void setArgb(int argb) {
        setValue(argb);
    }

    public boolean alphaEditable() {
        return alphaEditable;
    }
}
