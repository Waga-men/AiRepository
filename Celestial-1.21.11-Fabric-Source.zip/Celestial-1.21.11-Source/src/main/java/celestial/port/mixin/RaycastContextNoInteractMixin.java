package celestial.port.mixin;

import celestial.port.modules.player.NoInteract;
import net.minecraft.block.BlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.util.shape.VoxelShapes;
import net.minecraft.world.BlockView;
import net.minecraft.world.RaycastContext;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(RaycastContext.class)
public abstract class RaycastContextNoInteractMixin {
    @Inject(method = "getBlockShape", at = @At("RETURN"), cancellable = true)
    private void celestial$skipNoInteractBlocks(BlockState state, BlockView world, BlockPos pos,
                                                CallbackInfoReturnable<VoxelShape> cir) {
        if (NoInteract.skipsBlockRaycast(state)) {
            cir.setReturnValue(VoxelShapes.empty());
        }
    }
}
