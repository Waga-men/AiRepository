package celestial.port.mixin;

import celestial.port.modules.movement.AntiWeb;
import net.minecraft.block.BlockState;
import net.minecraft.block.CobwebBlock;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityCollisionHandler;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CobwebBlock.class)
public abstract class CobwebBlockAntiWebMixin {
    @Inject(method = "onEntityCollision", at = @At("TAIL"))
    private void celestial$recordCobwebCollision(BlockState state, World world, BlockPos pos,
                                                  Entity entity, EntityCollisionHandler handler,
                                                  boolean intersects, CallbackInfo ci) {
        AntiWeb.onCobwebCollision(entity);
    }
}
