package celestial.port.mixin;

import celestial.port.client.command.LegacyTeleportCoordinator;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerTeleportMixin {
    private static final String FORCE_MAIN_THREAD =
            "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(" +
                    "Lnet/minecraft/network/packet/Packet;" +
                    "Lnet/minecraft/network/listener/PacketListener;" +
                    "Lnet/minecraft/network/PacketApplyBatcher;)V";

    @Inject(method = "onGameJoin", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$handleTeleportJoin(GameJoinS2CPacket packet, CallbackInfo ci) {
        LegacyTeleportCoordinator.beforeGameJoin();
    }
}
