package celestial.port.mixin;

import celestial.port.modules.render.ShieldBreakNotifications;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerShieldBreakMixin {
    private static final String FORCE_MAIN_THREAD =
            "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(" +
                    "Lnet/minecraft/network/packet/Packet;" +
                    "Lnet/minecraft/network/listener/PacketListener;" +
                    "Lnet/minecraft/network/PacketApplyBatcher;)V";

    @Inject(method = "onEntityStatus", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$notifyShieldBreak(EntityStatusS2CPacket packet, CallbackInfo ci) {
        ShieldBreakNotifications.onEntityStatus(packet);
    }

    @Inject(method = "onPlaySound", at = @At("TAIL"))
    private void celestial$notifyModernShieldBreak(PlaySoundS2CPacket packet, CallbackInfo ci) {
        ShieldBreakNotifications.onPlaySound(packet);
    }
}
