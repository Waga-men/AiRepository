package celestial.port.mixin;

import celestial.port.modules.movement.Jesus;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.shape.VoxelShape;
import net.minecraft.world.BlockView;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(FluidBlock.class)
public abstract class FluidBlockMixin {
    @Inject(method = "getCollisionShape", at = @At("HEAD"), cancellable = true)
    private void celestial$walkOnFluid(BlockState state, BlockView world, BlockPos pos,
                                       ShapeContext context, CallbackInfoReturnable<VoxelShape> cir) {
        VoxelShape shape = Jesus.fluidCollisionShape();
        if (shape != null) {
            cir.setReturnValue(shape);
        }
    }
}
