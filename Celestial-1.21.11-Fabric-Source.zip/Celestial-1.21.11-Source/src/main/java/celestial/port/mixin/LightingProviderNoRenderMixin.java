package celestial.port.mixin;

import celestial.port.modules.rendering.NoRender;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.HeightLimitView;
import net.minecraft.world.chunk.light.LightingProvider;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LightingProvider.class)
public abstract class LightingProviderNoRenderMixin {
    @Shadow
    @Final
    protected HeightLimitView world;

    @Inject(method = "checkBlock", at = @At("HEAD"), cancellable = true)
    private void celestial$skipClientBlockLightRecalculation(BlockPos pos, CallbackInfo ci) {
        if (world instanceof ClientWorld && NoRender.shouldSkipLightRecalculation()) {
            ci.cancel();
        }
    }
}
