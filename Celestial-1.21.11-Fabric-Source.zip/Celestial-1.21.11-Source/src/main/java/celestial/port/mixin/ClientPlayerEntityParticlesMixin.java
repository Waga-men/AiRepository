package celestial.port.mixin;

import celestial.port.modules.visual.Particles;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
abstract class ClientPlayerEntityParticlesMixin {
    @Inject(method = "addCritParticles", at = @At("HEAD"), cancellable = true)
    private void celestial$replaceCritParticles(Entity target, CallbackInfo ci) {
        if (Particles.replaceCritParticles(target)) {
            ci.cancel();
        }
    }
}
