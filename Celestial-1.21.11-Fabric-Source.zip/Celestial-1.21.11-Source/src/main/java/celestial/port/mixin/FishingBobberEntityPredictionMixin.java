package celestial.port.mixin;

import celestial.port.modules.visual.Prediction;
import net.minecraft.entity.projectile.FishingBobberEntity;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(FishingBobberEntity.class)
public abstract class FishingBobberEntityPredictionMixin implements Prediction.FishingState {
    @Unique
    private boolean celestial$predictionFlying = true;

    @Override
    public boolean celestial$isPredictionFlying() {
        return celestial$predictionFlying;
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/entity/projectile/FishingBobberEntity;state:"
                            + "Lnet/minecraft/entity/projectile/FishingBobberEntity$State;",
                    opcode = Opcodes.PUTFIELD,
                    ordinal = 0,
                    shift = At.Shift.AFTER
            )
    )
    private void celestial$recordHookedState(CallbackInfo ci) {
        celestial$predictionFlying = false;
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/entity/projectile/FishingBobberEntity;state:"
                            + "Lnet/minecraft/entity/projectile/FishingBobberEntity$State;",
                    opcode = Opcodes.PUTFIELD,
                    ordinal = 1,
                    shift = At.Shift.AFTER
            )
    )
    private void celestial$recordBobbingState(CallbackInfo ci) {
        celestial$predictionFlying = false;
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/entity/projectile/FishingBobberEntity;state:"
                            + "Lnet/minecraft/entity/projectile/FishingBobberEntity$State;",
                    opcode = Opcodes.PUTFIELD,
                    ordinal = 2,
                    shift = At.Shift.AFTER
            )
    )
    private void celestial$recordFlyingState(CallbackInfo ci) {
        celestial$predictionFlying = true;
    }
}
