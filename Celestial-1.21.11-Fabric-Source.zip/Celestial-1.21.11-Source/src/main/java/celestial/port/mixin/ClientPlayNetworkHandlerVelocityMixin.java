package celestial.port.mixin;

import celestial.port.modules.combat.VelocityModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.FishingBobberEntity;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerVelocityMixin {

    @Inject(
            method = "onExplosion",
            at = @At(
                    value = "INVOKE_ASSIGN",
                    target = "Lnet/minecraft/network/packet/s2c/play/ExplosionS2CPacket;center()Lnet/minecraft/util/math/Vec3d;"
            ),
            cancellable = true
    )
    private void celestial$cancelExplosion(ExplosionS2CPacket packet, CallbackInfo ci) {
        if (VelocityModule.active()) {
            ci.cancel();
        }
    }

    @Inject(method = "onEntityStatus", at = @At("HEAD"), cancellable = true)
    private void celestial$cancelFishingHookPull(EntityStatusS2CPacket packet, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!VelocityModule.active() || client.world == null || client.player == null
                || packet.getStatus() != 31) {
            return;
        }
        Entity entity = packet.getEntity(client.world);
        if (entity instanceof FishingBobberEntity bobber
                && bobber.getHookedEntity() == client.player) {
            ci.cancel();
        }
    }

    @Inject(method = "onEntityVelocityUpdate", at = @At("HEAD"), cancellable = true)
    private void celestial$cancelLocalEntityVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        var player = MinecraftClient.getInstance().player;
        if (VelocityModule.active() && player != null && packet.getEntityId() == player.getId()) {

            ci.cancel();
        }
    }
}
