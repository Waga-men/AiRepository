package celestial.port.mixin;

import celestial.port.modules.rendering.NoRender;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntityNoRenderMixin {
    @Inject(
            method = "getEffectFadeFactor(Lnet/minecraft/registry/entry/RegistryEntry;F)F",
            at = @At("RETURN"),
            cancellable = true,
            require = 1
    )
    private void celestial$hideBadEffectFade(
            RegistryEntry<StatusEffect> effect, float tickProgress,
            CallbackInfoReturnable<Float> cir
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        LivingEntity entity = (LivingEntity) (Object) this;
        if (NoRender.shouldHideBadEffectVisuals()
                && client.player != null
                && entity == client.player
                && (effect == StatusEffects.NAUSEA || effect == StatusEffects.DARKNESS)) {
            cir.setReturnValue(0.0F);
        }
    }
}
