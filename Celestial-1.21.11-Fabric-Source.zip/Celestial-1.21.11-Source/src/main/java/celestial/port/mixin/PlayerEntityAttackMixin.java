package celestial.port.mixin;

import celestial.port.modules.combat.HitSoundsModule;
import celestial.port.modules.impl.AutoSprint;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(PlayerEntity.class)
abstract class PlayerEntityAttackMixin {
    @Unique
    private Vec3d celestial$preAttackVelocity;
    @Unique
    private boolean celestial$preAttackSprint;

    @Inject(method = "attack", at = @At("HEAD"))
    private void celestial$rememberSprintMomentum(Entity target, CallbackInfo ci) {
        if ((Object) this == MinecraftClient.getInstance().player) {
            HitSoundsModule.onAttackAttempt(target);
        }
        if ((Object) this == MinecraftClient.getInstance().player
                && AutoSprint.preserveSprintOnHit()) {
            PlayerEntity player = (PlayerEntity) (Object) this;
            celestial$preAttackVelocity = player.getVelocity();
            celestial$preAttackSprint = player.isSprinting();
        } else {
            celestial$preAttackVelocity = null;
            celestial$preAttackSprint = false;
        }
    }

    @Inject(method = "attack", at = @At("RETURN"))
    private void celestial$restoreSprintMomentum(Entity target, CallbackInfo ci) {
        if (celestial$preAttackVelocity == null) {
            return;
        }
        PlayerEntity player = (PlayerEntity) (Object) this;
        Vec3d velocity = player.getVelocity();
        player.setVelocity(celestial$preAttackVelocity.x, velocity.y, celestial$preAttackVelocity.z);
        player.setSprinting(celestial$preAttackSprint);
        celestial$preAttackVelocity = null;
    }
}
