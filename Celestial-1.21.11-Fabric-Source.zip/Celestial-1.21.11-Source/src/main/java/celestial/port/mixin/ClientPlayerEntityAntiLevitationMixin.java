package celestial.port.mixin;

import celestial.port.modules.impl.AntiLevitation;
import celestial.port.modules.player.Disabler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityAntiLevitationMixin {
    @Shadow
    private static Vec2f applyDirectionalMovementSpeedFactors(Vec2f input) {
        throw new AssertionError();
    }

    @Inject(method = "tick", at = @At("HEAD"))
    private void celestial$captureAntiLevitationState(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (!player.networkHandler.isLoaded()) {
            return;
        }
        AntiLevitation.beginPlayerTick(player);
        Disabler.afterAntiLevitationDispatchSlot(player);
    }

    @ModifyVariable(method = "move", at = @At("HEAD"), argsOnly = true)
    private Vec3d celestial$adjustAntiLevitationMovement(Vec3d movement) {
        return AntiLevitation.adjustMovement((ClientPlayerEntity) (Object) this, movement);
    }

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void celestial$beginAntiLevitationPacketContext(CallbackInfo ci) {
        AntiLevitation.beginMovementPackets((ClientPlayerEntity) (Object) this);
    }

    @Inject(method = "sendMovementPackets", at = @At("TAIL"))
    private void celestial$endAntiLevitationPacketContext(CallbackInfo ci) {
        AntiLevitation.endMovementPackets();
    }

    @Redirect(
            method = "sendMovementPackets",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;isOnGround()Z"
            )
    )
    private boolean celestial$spoofAntiLevitationOnGround(ClientPlayerEntity player) {
        return AntiLevitation.packetOnGround(player, player.isOnGround());
    }

    @Redirect(
            method = "sendMovementPackets",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;getEntityPos()Lnet/minecraft/util/math/Vec3d;"
            )
    )
    private Vec3d celestial$spoofAntiLevitationPosition(ClientPlayerEntity player) {
        return AntiLevitation.packetPosition(player, player.getEntityPos());
    }

    @Redirect(
            method = "sendMovementPackets",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;getY()D"
            ),
            require = 2
    )
    private double celestial$spoofAntiLevitationY(ClientPlayerEntity player) {
        return AntiLevitation.packetY(player, player.getY());
    }

    @ModifyConstant(
            method = "sendMovementPackets",
            constant = @Constant(doubleValue = 2.0E-4)
    )
    private double celestial$legacyAntiLevitationPositionThreshold(double vanillaThreshold) {
        return AntiLevitation.packetPositionThreshold(vanillaThreshold);
    }

    @Inject(method = "applyMovementSpeedFactors", at = @At("HEAD"), cancellable = true)
    private void celestial$cancelAntiLevitationSlowdowns(Vec2f input, CallbackInfoReturnable<Vec2f> cir) {
        if (AntiLevitation.cancelsInputSlowdown()) {
            if (input.lengthSquared() == 0.0F) {
                cir.setReturnValue(input);
            } else {

                cir.setReturnValue(applyDirectionalMovementSpeedFactors(input));
            }
        }
    }
}
