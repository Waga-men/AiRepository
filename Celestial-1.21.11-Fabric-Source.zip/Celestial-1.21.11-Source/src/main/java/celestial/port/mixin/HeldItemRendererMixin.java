package celestial.port.mixin;

import celestial.port.modules.visual.SwingAnimations;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.item.HeldItemRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemDisplayContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.util.Arm;
import net.minecraft.util.Hand;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HeldItemRenderer.class)
public abstract class HeldItemRendererMixin {
    @Shadow
    public abstract void renderItem(LivingEntity entity, ItemStack stack, ItemDisplayContext renderMode,
                                    MatrixStack matrices, OrderedRenderCommandQueue queue, int light);

    @Inject(
            method = "renderFirstPersonItem",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/util/math/MatrixStack;push()V",
                    shift = At.Shift.AFTER
            )
    )
    private void celestial$applyLegacyHandOffset(AbstractClientPlayerEntity player, float tickProgress,
                                                  float pitch, Hand hand, float swingProgress,
                                                  ItemStack item, float equipProgress, MatrixStack matrices,
                                                  OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        SwingAnimations module = SwingAnimations.instance();
        if (module != null) {
            module.applyHandOffset(matrices, hand);
        }
    }

    @Inject(method = "renderFirstPersonItem", at = @At("HEAD"), cancellable = true)
    private void celestial$renderLegacyIdleItem(AbstractClientPlayerEntity player, float tickProgress,
                                                 float pitch, Hand hand, float swingProgress,
                                                 ItemStack item, float equipProgress, MatrixStack matrices,
                                                 OrderedRenderCommandQueue queue, int light, CallbackInfo ci) {
        SwingAnimations module = SwingAnimations.instance();
        if (module == null || player.isUsingSpyglass() || item.isEmpty()
                || item.contains(DataComponentTypes.MAP_ID) || item.isOf(Items.CROSSBOW)
                || player.isUsingItem() && player.getItemUseTimeLeft() > 0 && player.getActiveHand() == hand
                || player.isUsingRiptide()) {
            return;
        }

        boolean mainHand = hand == Hand.MAIN_HAND;
        Arm arm = mainHand ? player.getMainArm() : player.getMainArm().getOpposite();
        if (!module.replacesIdleTransform(player, arm)) {
            return;
        }

        matrices.push();
        module.applyHandOffset(matrices, hand);
        module.applyIdleTransform(matrices, player, arm, swingProgress, equipProgress);
        renderItem(player, item,
                arm == Arm.RIGHT ? ItemDisplayContext.FIRST_PERSON_RIGHT_HAND
                        : ItemDisplayContext.FIRST_PERSON_LEFT_HAND,
                matrices, queue, light);
        matrices.pop();
        ci.cancel();
    }
}
