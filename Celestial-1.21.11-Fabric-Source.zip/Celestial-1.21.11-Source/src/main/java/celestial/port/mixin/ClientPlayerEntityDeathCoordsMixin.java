package celestial.port.mixin;

import celestial.port.modules.impl.DeathCoords;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityDeathCoordsMixin {
    @Inject(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V"
            ),
            order = 1010
    )
    private void celestial$reportDeathCoordinatesBeforeVanillaUpdate(CallbackInfo ci) {
        DeathCoords.beforeVanillaPlayerTick((ClientPlayerEntity) (Object) this);
    }
}
