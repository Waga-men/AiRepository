package celestial.port.mixin;

import celestial.port.client.ui.AutoBuyScreen;
import celestial.port.client.ui.CelestialScreen;
import celestial.port.client.ui.XRayScreen;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(GameRenderer.class)
abstract class GameRendererClickGuiBlurMixin {
    private static final Identifier CELESTIAL_CLICK_GUI_BLUR =
            Identifier.of("celestial", "legacy_click_gui_blur");

    @ModifyArg(
            method = "renderBlur()V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gl/ShaderLoader;loadPostEffect(Lnet/minecraft/util/Identifier;Ljava/util/Set;)Lnet/minecraft/client/gl/PostEffectProcessor;",
                    ordinal = 0
            ),
            index = 0,
            require = 1,
            expect = 1,
            allow = 1
    )
    private Identifier celestial$selectClickGuiBlur(Identifier vanillaEffect) {
        if (MinecraftClient.getInstance().currentScreen instanceof CelestialScreen screen
                && screen.legacyBlurEnabled()) {
            return CELESTIAL_CLICK_GUI_BLUR;
        }
        if (MinecraftClient.getInstance().currentScreen instanceof XRayScreen screen
                && screen.legacyBlurEnabled()) {
            return CELESTIAL_CLICK_GUI_BLUR;
        }
        if (MinecraftClient.getInstance().currentScreen instanceof AutoBuyScreen screen
                && screen.legacyBlurEnabled()) {
            return CELESTIAL_CLICK_GUI_BLUR;
        }
        return vanillaEffect;
    }
}
