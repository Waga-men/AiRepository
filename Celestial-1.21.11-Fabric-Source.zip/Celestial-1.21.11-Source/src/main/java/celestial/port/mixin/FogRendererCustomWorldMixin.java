package celestial.port.mixin;

import celestial.port.modules.rendering.CustomWorld;
import net.minecraft.client.render.fog.FogRenderer;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(FogRenderer.class)
abstract class FogRendererCustomWorldMixin {
    @ModifyArgs(
            method = "applyFog",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/fog/FogRenderer;applyFog(Ljava/nio/ByteBuffer;ILorg/joml/Vector4f;FFFFFF)V"
            )
    )
    private void celestial$customFog(Args args) {
        if (!CustomWorld.customFogActive()) {
            return;
        }
        int color = CustomWorld.selectedFogColor();
        args.set(2, new Vector4f(
                ((color >>> 16) & 255) / 255.0F,
                ((color >>> 8) & 255) / 255.0F,
                (color & 255) / 255.0F,
                ((color >>> 24) & 255) / 255.0F
        ));
        float multiplier = CustomWorld.selectedFogDistance();
        for (int index = 3; index <= 8; index++) {
            float original = args.get(index);
            if (Float.isFinite(original) && original > 0.0F) {
                args.set(index, original * multiplier);
            }
        }
    }
}
