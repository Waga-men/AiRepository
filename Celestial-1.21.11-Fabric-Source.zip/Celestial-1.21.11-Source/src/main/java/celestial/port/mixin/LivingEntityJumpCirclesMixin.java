package celestial.port.mixin;

import celestial.port.modules.visual.JumpCircles;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LivingEntity.class)
public abstract class LivingEntityJumpCirclesMixin {
    @Unique
    private int celestial$jumpCirclesAirTicks;

    @Inject(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/Entity;tick()V",
                    shift = At.Shift.AFTER
            ),
            require = 1
    )
    private void celestial$trackRemoteFirstAirTick(CallbackInfo ci) {
        LivingEntity entity = (LivingEntity) (Object) this;
        if (!(entity instanceof AbstractClientPlayerEntity player)
                || !JumpCircles.shouldTrackRemote(player)) {
            return;
        }

        if (!player.isOnGround() || player.getVelocity().y > 0.0 || player.isJumping()) {
            celestial$jumpCirclesAirTicks++;
        } else {
            celestial$jumpCirclesAirTicks = 0;
        }
        if (player.fallDistance > 0.0F) {
            celestial$jumpCirclesAirTicks = 0;
        }
        if (celestial$jumpCirclesAirTicks == 1) {
            JumpCircles.onRemoteFirstAirTick(player);
        }
    }

    @Inject(method = "jump", at = @At("RETURN"), require = 1)
    private void celestial$recordLocalJump(CallbackInfo ci) {
        JumpCircles.onLocalJump((LivingEntity) (Object) this);
    }
}
