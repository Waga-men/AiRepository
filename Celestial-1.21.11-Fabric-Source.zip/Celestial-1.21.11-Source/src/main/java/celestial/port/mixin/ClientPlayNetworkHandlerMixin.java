package celestial.port.mixin;

import celestial.port.modules.player.NoServerRotationsModule;
import celestial.port.modules.player.ItemsCooldownModule;
import celestial.port.modules.combat.AutoExplosionModule;
import celestial.port.core.PvpContext;
import celestial.port.modules.impl.TimeChanger;
import celestial.port.modules.inventory.AutoFish;
import celestial.port.modules.legacyutility.AutoWay;
import celestial.port.modules.legacyutility.RWHelper;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRotationS2CPacket;
import net.minecraft.network.packet.s2c.play.PlaySoundS2CPacket;
import net.minecraft.network.packet.s2c.play.CooldownUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.EntitiesDestroyS2CPacket;
import net.minecraft.network.packet.s2c.play.BossBarS2CPacket;
import net.minecraft.network.packet.s2c.play.OpenScreenS2CPacket;
import net.minecraft.network.packet.s2c.play.WorldTimeUpdateS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerMixin {
    @Inject(method = "onEntitiesDestroy", at = @At("HEAD"))
    private void celestial$finishAutoExplosion(EntitiesDestroyS2CPacket packet, CallbackInfo ci) {
        AutoExplosionModule.onEntitiesDestroy(packet);
    }

    @Inject(method = "onBossBar", at = @At("HEAD"))
    private void celestial$trackPvpBossBar(BossBarS2CPacket packet, CallbackInfo ci) {
        PvpContext.onBossBar(packet);
        AutoWay.onBossBar(packet);
    }

    @Inject(method = "onOpenScreen", at = @At("HEAD"), cancellable = true)
    private void celestial$closeLegacyReallyWorldMenu(OpenScreenS2CPacket packet, CallbackInfo ci) {
        if (RWHelper.onOpenScreen(packet)) {
            ci.cancel();
        }
    }

    @Inject(method = "onCooldownUpdate", at = @At("TAIL"))
    private void celestial$extendLegacyItemCooldown(CooldownUpdateS2CPacket packet, CallbackInfo ci) {
        ItemsCooldownModule.onCooldownUpdate(packet);
    }

    @ModifyVariable(method = "onWorldTimeUpdate", at = @At("HEAD"), argsOnly = true)
    private WorldTimeUpdateS2CPacket celestial$keepSelectedTime(WorldTimeUpdateS2CPacket packet) {
        return TimeChanger.rewrite(packet);
    }

    @Inject(method = "onPlaySound", at = @At(
            value = "INVOKE",
            target = "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(" +
                    "Lnet/minecraft/network/packet/Packet;" +
                    "Lnet/minecraft/network/listener/PacketListener;" +
                    "Lnet/minecraft/network/PacketApplyBatcher;)V",
            ordinal = 0,
            shift = At.Shift.AFTER))
    private void celestial$runLegacyAutoFish(PlaySoundS2CPacket packet, CallbackInfo ci) {
        AutoFish.onPlaySound(packet);
    }

    @ModifyVariable(method = "onPlayerPositionLook", at = @At("HEAD"), argsOnly = true)
    private PlayerPositionLookS2CPacket celestial$rewritePositionLook(PlayerPositionLookS2CPacket packet) {
        return NoServerRotationsModule.rewrite(packet);
    }

    @ModifyVariable(method = "onPlayerRotation", at = @At("HEAD"), argsOnly = true)
    private PlayerRotationS2CPacket celestial$rewriteRotation(PlayerRotationS2CPacket packet) {
        return NoServerRotationsModule.rewrite(packet);
    }
}
