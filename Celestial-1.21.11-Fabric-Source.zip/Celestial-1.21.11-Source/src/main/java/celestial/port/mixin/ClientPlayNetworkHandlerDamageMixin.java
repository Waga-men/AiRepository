package celestial.port.mixin;

import celestial.port.modules.combat.HitSoundsModule;
import celestial.port.core.ServerCorrectionLifecycle;
import celestial.port.modules.movement.LongJump;
import celestial.port.modules.movement.DamageSpeed;
import celestial.port.modules.movement.Speed;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerDamageMixin {
    private static final String FORCE_MAIN_THREAD =
            "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(" +
                    "Lnet/minecraft/network/packet/Packet;" +
                    "Lnet/minecraft/network/listener/PacketListener;" +
                    "Lnet/minecraft/network/PacketApplyBatcher;)V";

    @Inject(method = "onEntityStatus", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$verifyLongJumpDamage(EntityStatusS2CPacket packet, CallbackInfo ci) {
        HitSoundsModule.onEntityStatus(packet);
        LongJump.onEntityStatus(packet);
        Speed.onEntityStatus(packet);
        DamageSpeed.onEntityStatus(packet);
    }

    @Inject(method = "onEntityDamage", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$classifyLongJumpDamage(EntityDamageS2CPacket packet, CallbackInfo ci) {
        HitSoundsModule.onEntityDamage(packet);
        LongJump.onEntityDamage(packet);
        Speed.onEntityDamage(packet);
        DamageSpeed.onEntityDamage(packet);
    }

    @Inject(method = "onExplosion", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$rejectExplosionDamage(ExplosionS2CPacket packet, CallbackInfo ci) {
        LongJump.onExplosion();
        Speed.onExplosion();
        DamageSpeed.onExplosion();
    }

    @Inject(method = "onPlayerPositionLook", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER), order = 900)
    private void celestial$runLegacyFlagDetector(PlayerPositionLookS2CPacket packet, CallbackInfo ci) {
        ServerCorrectionLifecycle.onPlayerPositionLook();
    }
}
