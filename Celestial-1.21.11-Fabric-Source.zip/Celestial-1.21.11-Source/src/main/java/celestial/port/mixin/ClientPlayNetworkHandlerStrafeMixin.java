package celestial.port.mixin;

import celestial.port.modules.movement.Strafe;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityDamageS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerStrafeMixin {
    private static final String FORCE_MAIN_THREAD =
            "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(" +
                    "Lnet/minecraft/network/packet/Packet;" +
                    "Lnet/minecraft/network/listener/PacketListener;" +
                    "Lnet/minecraft/network/PacketApplyBatcher;)V";

    @Inject(method = "onEntityDamage", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$verifyStrafeDamage(EntityDamageS2CPacket packet, CallbackInfo ci) {
        Strafe.onEntityDamage(packet);
    }

    @Inject(method = "onExplosion", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$rejectStrafeExplosion(ExplosionS2CPacket packet, CallbackInfo ci) {
        Strafe.onExplosion();
    }
}
