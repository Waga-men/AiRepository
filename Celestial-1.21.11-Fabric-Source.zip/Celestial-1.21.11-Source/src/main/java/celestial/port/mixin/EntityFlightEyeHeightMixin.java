package celestial.port.mixin;

import celestial.port.modules.impl.Flight;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityPose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityFlightEyeHeightMixin {
    @Inject(method = "getEyeHeight", at = @At("HEAD"), cancellable = true)
    private void celestial$flightEyeHeight(
            EntityPose pose, CallbackInfoReturnable<Float> cir
    ) {
        if (celestial$usesFlightEyeHeight()) {
            cir.setReturnValue(1.62F);
        }
    }

    @Inject(method = "getStandingEyeHeight", at = @At("HEAD"), cancellable = true)
    private void celestial$flightStandingEyeHeight(CallbackInfoReturnable<Float> cir) {
        if (celestial$usesFlightEyeHeight()) {
            cir.setReturnValue(1.62F);
        }
    }

    @Inject(method = "getEyeY", at = @At("HEAD"), cancellable = true)
    private void celestial$flightEyeY(CallbackInfoReturnable<Double> cir) {
        if (celestial$usesFlightEyeHeight()) {
            cir.setReturnValue(((Entity) (Object) this).getY() + 1.62F);
        }
    }

    private boolean celestial$usesFlightEyeHeight() {
        return (Object) this instanceof ClientPlayerEntity player
                && Flight.forcesLegacyEyeHeight(player);
    }
}
