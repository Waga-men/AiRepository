package celestial.port.mixin;

import celestial.port.modules.utility.ElytraFix;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public abstract class HandledScreenElytraFixMixin {
    @Inject(
            method = "onMouseClick(Lnet/minecraft/screen/slot/Slot;II"
                    + "Lnet/minecraft/screen/slot/SlotActionType;)V",
            at = @At("HEAD"), cancellable = true
    )
    private void celestial$guardLegacyProtectedInventoryItems(
            Slot slot, int slotId, int button, SlotActionType actionType, CallbackInfo ci
    ) {
        var player = MinecraftClient.getInstance().player;
        if (player != null && ElytraFix.shouldCancelClick(
                player.currentScreenHandler.syncId, slotId, actionType)) {
            ci.cancel();
        }
    }
}
