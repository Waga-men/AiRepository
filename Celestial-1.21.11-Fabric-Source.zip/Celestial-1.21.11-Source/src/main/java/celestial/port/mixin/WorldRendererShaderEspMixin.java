package celestial.port.mixin;

import celestial.port.modules.visual.ShaderESP;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(WorldRenderer.class)
abstract class WorldRendererShaderEspMixin {
    @ModifyArg(
            method = "render",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gl/ShaderLoader;loadPostEffect(Lnet/minecraft/util/Identifier;Ljava/util/Set;)Lnet/minecraft/client/gl/PostEffectProcessor;"
            ),
            index = 0
    )
    private Identifier celestial$selectOutlinePostEffect(Identifier vanillaEffect) {
        return ShaderESP.selectPostEffect(vanillaEffect);
    }
}
