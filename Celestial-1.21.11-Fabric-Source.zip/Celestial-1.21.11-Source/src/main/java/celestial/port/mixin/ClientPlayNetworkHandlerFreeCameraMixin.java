package celestial.port.mixin;

import celestial.port.modules.player.FreeCameraModule;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.network.packet.s2c.play.EntityVelocityUpdateS2CPacket;
import net.minecraft.network.packet.s2c.play.ExplosionS2CPacket;
import net.minecraft.network.packet.s2c.play.GameJoinS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerPositionLookS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRespawnS2CPacket;
import net.minecraft.network.packet.s2c.play.PlayerRotationS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerFreeCameraMixin {
    private static final String FORCE_MAIN_THREAD =
            "Lnet/minecraft/network/NetworkThreadUtils;forceMainThread(" +
                    "Lnet/minecraft/network/packet/Packet;" +
                    "Lnet/minecraft/network/listener/PacketListener;" +
                    "Lnet/minecraft/network/PacketApplyBatcher;)V";

    @Inject(method = "onPlayerPositionLook", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER), cancellable = true)
    private void celestial$holdFreeCameraPosition(PlayerPositionLookS2CPacket packet, CallbackInfo ci) {
        if (FreeCameraModule.onPlayerPositionLook(packet)) {
            ci.cancel();
        }
    }

    @Inject(method = "onPlayerRotation", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER), cancellable = true)
    private void celestial$holdFreeCameraRotation(PlayerRotationS2CPacket packet, CallbackInfo ci) {
        if (FreeCameraModule.onPlayerRotation(packet)) {
            ci.cancel();
        }
    }

    @Inject(method = "onEntityVelocityUpdate", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER), cancellable = true)
    private void celestial$cancelFreeCameraVelocity(EntityVelocityUpdateS2CPacket packet, CallbackInfo ci) {
        if (FreeCameraModule.shouldCancelVelocity(packet)) {
            ci.cancel();
        }
    }

    @Inject(method = "onExplosion", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER), cancellable = true)
    private void celestial$cancelFreeCameraExplosion(ExplosionS2CPacket packet, CallbackInfo ci) {
        if (FreeCameraModule.shouldCancelExplosion(packet)) {
            ci.cancel();
        }
    }

    @Inject(method = "onGameJoin", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$disableFreeCameraOnJoin(GameJoinS2CPacket packet, CallbackInfo ci) {
        FreeCameraModule.onGameJoin();
    }

    @Inject(method = "onPlayerRespawn", at = @At(
            value = "INVOKE", target = FORCE_MAIN_THREAD, shift = At.Shift.AFTER))
    private void celestial$disableFreeCameraOnRespawn(PlayerRespawnS2CPacket packet, CallbackInfo ci) {
        FreeCameraModule.onGameJoin();
    }
}
