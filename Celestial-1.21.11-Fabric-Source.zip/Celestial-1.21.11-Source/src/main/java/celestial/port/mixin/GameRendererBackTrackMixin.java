package celestial.port.mixin;

import celestial.port.modules.combat.BackTrackModule;
import net.minecraft.client.render.GameRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
abstract class GameRendererBackTrackMixin {
    @Inject(method = "updateCrosshairTarget", at = @At("TAIL"))
    private void celestial$backTrackCrosshair(float tickProgress, CallbackInfo ci) {
        BackTrackModule.updateCrosshairTarget(tickProgress);
    }
}
