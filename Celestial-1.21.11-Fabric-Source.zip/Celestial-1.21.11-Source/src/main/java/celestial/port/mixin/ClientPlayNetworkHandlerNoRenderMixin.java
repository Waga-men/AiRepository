package celestial.port.mixin;

import celestial.port.modules.rendering.NoRender;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerNoRenderMixin {
    @Redirect(
            method = "onEntityStatus",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/GameRenderer;showFloatingItem(Lnet/minecraft/item/ItemStack;)V"
            )
    )
    private void celestial$conditionallyShowTotemAnimation(GameRenderer renderer, ItemStack stack) {
        if (!NoRender.shouldHideTotemAnimation()) {
            renderer.showFloatingItem(stack);
        }
    }
}
