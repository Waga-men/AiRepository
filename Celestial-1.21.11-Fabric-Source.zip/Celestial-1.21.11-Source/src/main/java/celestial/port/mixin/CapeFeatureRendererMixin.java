package celestial.port.mixin;

import celestial.port.modules.visual.CustomModel;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.CapeFeatureRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(CapeFeatureRenderer.class)
public abstract class CapeFeatureRendererMixin {
    @Unique
    private boolean celestial$miniCapeTransform;

    @Inject(
            method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void celestial$hideFinnCape(MatrixStack matrices,
                                        OrderedRenderCommandQueue queue,
                                        int light,
                                        PlayerEntityRenderState state,
                                        float limbAngle,
                                        float limbDistance,
                                        CallbackInfo ci) {
        celestial$miniCapeTransform = false;
        if (CustomModel.isFinn(state)) {
            ci.cancel();
        } else if (CustomModel.isMini(state)) {
            matrices.push();
            matrices.scale(0.5F, 0.5F, 0.5F);
            matrices.translate(0.0F, 1.5F, 0.05F);
            celestial$miniCapeTransform = true;
        }
    }

    @Inject(
            method = "render(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;ILnet/minecraft/client/render/entity/state/PlayerEntityRenderState;FF)V",
            at = @At("RETURN")
    )
    private void celestial$restoreMiniCapeTransform(MatrixStack matrices,
                                                    OrderedRenderCommandQueue queue,
                                                    int light,
                                                    PlayerEntityRenderState state,
                                                    float limbAngle,
                                                    float limbDistance,
                                                    CallbackInfo ci) {
        if (celestial$miniCapeTransform) {
            matrices.pop();
            celestial$miniCapeTransform = false;
        }
    }
}
