package celestial.port.mixin;

import celestial.port.modules.impl.AirJump;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityAirJumpMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void celestial$applyLegacyAirJump(CallbackInfo ci) {
        AirJump.beforePlayerTick((ClientPlayerEntity) (Object) this);
    }

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void celestial$applyLegacyMatrixAirJump(CallbackInfo ci) {
        AirJump.beforeMovementPackets((ClientPlayerEntity) (Object) this);
    }
}
