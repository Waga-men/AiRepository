package celestial.port.mixin;

import celestial.port.modules.visual.Particles;
import net.minecraft.client.particle.EmitterParticle;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.ModifyConstant;

@Mixin(EmitterParticle.class)
abstract class EmitterParticleParticlesMixin {
    @ModifyConstant(method = "tick", constant = @Constant(intValue = 16))
    private int celestial$legacyCritEmitterCount(int vanillaCount) {
        return Particles.critEmitterCount(vanillaCount);
    }
}
