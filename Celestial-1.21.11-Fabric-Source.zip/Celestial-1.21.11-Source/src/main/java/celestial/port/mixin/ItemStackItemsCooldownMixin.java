package celestial.port.mixin;

import celestial.port.modules.player.ItemsCooldownModule;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemStack.class)
abstract class ItemStackItemsCooldownMixin {
    @Inject(method = "finishUsing", at = @At("HEAD"))
    private void celestial$markConsumedApple(
            World world, LivingEntity user, CallbackInfoReturnable<ItemStack> cir
    ) {
        if (world.isClient() && user instanceof PlayerEntity player) {
            ItemsCooldownModule.onFinishedUsing((ItemStack) (Object) this, player);
        }
    }
}
