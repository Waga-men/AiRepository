package celestial.port.mixin;

import celestial.port.modules.impl.NoClip;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerNoClipMixin {
    @Inject(method = "breakBlock", at = @At("RETURN"))
    private void celestial$finishNoClipBreak(BlockPos pos,
                                             CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ() && MinecraftClient.getInstance().player != null) {
            NoClip.onBlockBroken(MinecraftClient.getInstance().player);
        }
    }
}
