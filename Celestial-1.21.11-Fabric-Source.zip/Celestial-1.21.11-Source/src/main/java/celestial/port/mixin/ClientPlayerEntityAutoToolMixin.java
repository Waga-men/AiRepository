package celestial.port.mixin;

import celestial.port.modules.inventory.AutoTool;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityAutoToolMixin {
    @Inject(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V"
            )
    )
    private void celestial$beforeAutoToolPlayerTick(CallbackInfo ci) {
        AutoTool.beforePlayerTick((ClientPlayerEntity) (Object) this);
    }
}
