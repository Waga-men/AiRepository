package celestial.port.mixin;

import celestial.port.modules.movement.Strafe;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.MovementType;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityStrafeMixin {
    @Shadow
    private boolean lastSprinting;

    @Shadow
    private static Vec2f applyDirectionalMovementSpeedFactors(Vec2f input) {
        throw new AssertionError();
    }

    @Unique
    private double celestial$strafeStartX;

    @Unique
    private double celestial$strafeStartZ;

    @Inject(method = "tick", at = @At("HEAD"))
    private void celestial$beginStrafeTick(CallbackInfo ci) {
        Strafe.beginPlayerTick((ClientPlayerEntity) (Object) this);
    }

    @Inject(method = "move", at = @At("HEAD"))
    private void celestial$captureStrafeMoveStart(
            MovementType movementType, Vec3d movement, CallbackInfo ci
    ) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        celestial$strafeStartX = player.getX();
        celestial$strafeStartZ = player.getZ();
    }

    @Inject(method = "move", at = @At("TAIL"))
    private void celestial$finishStrafeMove(
            MovementType movementType, Vec3d movement, CallbackInfo ci
    ) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        Strafe.afterMovement(player, Math.hypot(
                player.getX() - celestial$strafeStartX,
                player.getZ() - celestial$strafeStartZ));
    }

    @Inject(method = "applyMovementSpeedFactors", at = @At("HEAD"), cancellable = true)
    private void celestial$cancelStrafeInputSlowdowns(
            Vec2f input, CallbackInfoReturnable<Vec2f> cir
    ) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (!Strafe.cancelsInputSlowdown(player)) {
            return;
        }
        if (input.lengthSquared() == 0.0F) {
            cir.setReturnValue(input);
        } else {

            cir.setReturnValue(applyDirectionalMovementSpeedFactors(input));
        }
    }

    @Redirect(
            method = "sendSprintingPacket",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;isSprinting()Z"
            )
    )
    private boolean celestial$rewriteStrafeSprintState(ClientPlayerEntity player) {
        boolean requested = player.isSprinting();
        return Strafe.rewriteSprintState(player, requested, lastSprinting);
    }
}
