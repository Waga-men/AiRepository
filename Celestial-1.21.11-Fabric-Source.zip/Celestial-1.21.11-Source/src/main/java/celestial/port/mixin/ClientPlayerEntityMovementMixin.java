package celestial.port.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.modules.combat.AttackAuraModule;
import celestial.port.modules.combat.AutoExplosionModule;
import celestial.port.modules.combat.BowSpamModule;
import celestial.port.modules.impl.AutoSprint;
import celestial.port.modules.impl.Flight;
import celestial.port.modules.movement.AntiWeb;
import celestial.port.modules.movement.Jesus;
import celestial.port.modules.movement.LongJump;
import celestial.port.modules.movement.NoSlow;
import celestial.port.modules.movement.Speed;
import celestial.port.modules.movement.Spider;
import celestial.port.modules.movement.Strafe;
import celestial.port.modules.player.FreeCameraModule;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.PlayerInput;
import net.minecraft.util.math.Vec2f;
import net.minecraft.util.math.Vec3d;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMovementMixin {
    @Shadow
    private boolean lastSprinting;
    @Shadow
    private PlayerInput lastPlayerInput;

    @Unique
    private boolean celestial$focusedYawOpen;
    @Unique
    private float celestial$savedRenderYaw;
    @Unique
    private float celestial$savedCameraYaw;
    @Unique
    private boolean celestial$focusedCamera;

    @Inject(method = "tick", at = @At("HEAD"))
    private void celestial$beforePlayerTick(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (FreeCameraModule.beginActivationBoundary(
                player, lastPlayerInput, lastSprinting)) {
            lastPlayerInput = PlayerInput.DEFAULT;
            lastSprinting = false;
        }
        AutoSprint.beforePlayerTick(player);
        AttackAuraModule.prepareFocusedMovement(player);
        AttackAuraModule.beforePlayerTick(player);
        AttackAuraModule.beforeVehicleDecision(player);
        BowSpamModule.beforePlayerTick(player);
        boolean focused = AttackAuraModule.beginFocusedMovementYaw(player);
        try {
            Flight.beforePlayerTick(player);
            NoSlow.beforePlayerTick(player);
            Jesus.beforePlayerTick(player);
            Speed.beforePlayerTick(player);
            AntiWeb.beforePlayerTick(player);
        } finally {
            if (focused) {
                AttackAuraModule.endFocusedMovementYaw(player);
            }
        }
    }

    @Inject(method = "tickMovement", at = @At("HEAD"), require = 1, allow = 1)
    private void celestial$beginFocusedMovementPhysics(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        float renderYaw = player.renderYaw;
        float cameraYaw = player.getYaw();
        boolean camera = MinecraftClient.getInstance().getCameraEntity() == player;
        celestial$focusedYawOpen = AttackAuraModule.beginFocusedMovementYaw(player);
        if (celestial$focusedYawOpen) {
            celestial$savedRenderYaw = renderYaw;
            celestial$savedCameraYaw = cameraYaw;
            celestial$focusedCamera = camera;
        }
    }

    @Inject(method = "tickMovement", at = @At("RETURN"), require = 1, allow = 1)
    private void celestial$endFocusedMovementPhysics(CallbackInfo ci) {
        if (!celestial$focusedYawOpen) {
            return;
        }
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        try {
            AttackAuraModule.endFocusedMovementYaw(player);
        } finally {
            if (celestial$focusedCamera) {

                player.lastRenderYaw = celestial$savedRenderYaw;
                player.renderYaw = celestial$savedRenderYaw
                        + (celestial$savedCameraYaw - celestial$savedRenderYaw) * 0.5F;
            }
            celestial$focusedYawOpen = false;
            celestial$focusedCamera = false;
        }
    }

    @ModifyExpressionValue(
            method = "tick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/input/Input;playerInput:Lnet/minecraft/util/PlayerInput;",
                    opcode = Opcodes.GETFIELD
            ),
            require = 3,
            allow = 3
    )
    private PlayerInput celestial$correctAttackAuraPlayerInput(PlayerInput input) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (FreeCameraModule.freezesMovementPackets(player)) {
            return lastPlayerInput;
        }
        return AttackAuraModule.correctPlayerInput(player, input);
    }

    @ModifyExpressionValue(
            method = "tickMovement",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;canStartSprinting()Z"
            ),
            require = 1,
            allow = 1
    )
    private boolean celestial$correctAttackAuraSprintPhysics(boolean canStart) {
        return AttackAuraModule.canStartSprintingDuringCriticalStop(
                (ClientPlayerEntity) (Object) this, canStart);
    }

    @Inject(method = "sendMovementPackets", at = @At("HEAD"), cancellable = true)
    private void celestial$beforeMovementPackets(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (FreeCameraModule.freezesMovementPackets(player)) {
            ci.cancel();
            return;
        }
        AttackAuraModule.beginMovementPackets(player);
        AutoExplosionModule.beforeMovementPackets(player);
        Speed.beforePostMotion(player);
        NoSlow.beforeMovementPackets(player);
        boolean focused = AttackAuraModule.beginFocusedMovementYaw(player);
        try {
            LongJump.beforeMovementPackets(player);
            Jesus.beforeMovementPackets(player);
            Spider.beforeMovementPackets(player);
            Speed.beforeMovementPackets(player);
        } finally {
            if (focused) {
                AttackAuraModule.endFocusedMovementYaw(player);
            }
        }

        LegacyTeleportCoordinator.beginMovementPackets(player);
    }

    @Inject(method = "sendMovementPackets", at = @At("TAIL"))
    private void celestial$afterMovementPackets(CallbackInfo ci) {
        AttackAuraModule.endMovementPackets((ClientPlayerEntity) (Object) this);
        AutoExplosionModule.afterMovementPackets();
        LegacyTeleportCoordinator.endMovementPackets(
                (ClientPlayerEntity) (Object) this);
    }

    @Redirect(
            method = "sendMovementPackets",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V"
            ),
            require = 4
    )
    private void celestial$rewriteScheduledAuraMovementPacket(
            ClientPlayNetworkHandler networkHandler, Packet<?> packet
    ) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        networkHandler.sendPacket(
                AttackAuraModule.rewriteScheduledMovementPacket(player, packet));
    }

    @Inject(method = "sendSprintingPacket", at = @At("HEAD"), cancellable = true)
    private void celestial$spoofLongJumpSprint(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (FreeCameraModule.freezesMovementPackets(player)) {
            ci.cancel();
            return;
        }
        if (!player.hasVehicle() && LongJump.shouldSpoofSprint()) {

            Strafe.rewriteSprintState(player, player.isSprinting(), lastSprinting);
            boolean requested = !lastSprinting;
            player.networkHandler.sendPacket(new ClientCommandC2SPacket(player,
                    requested ? ClientCommandC2SPacket.Mode.START_SPRINTING
                            : ClientCommandC2SPacket.Mode.STOP_SPRINTING));
            lastSprinting = requested;
            ci.cancel();
        }
    }

    @ModifyVariable(method = "move", at = @At("HEAD"), argsOnly = true)
    private Vec3d celestial$adjustJesusMovement(Vec3d movement) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (LegacyTeleportCoordinator.hasPendingTeleport()) {

            return Vec3d.ZERO;
        }
        movement = Flight.adjustMovement(player, movement);
        movement = Strafe.adjustMovement(player, movement);
        movement = Jesus.adjustMovement(player, movement);
        movement = Speed.adjustMovement(player, movement);
        return FreeCameraModule.adjustMovement(player, movement);
    }

    @Inject(method = "move", at = @At("TAIL"))
    private void celestial$finishJesusMovement(CallbackInfo ci) {
        Jesus.afterMovement();
    }

    @Inject(method = "applyMovementSpeedFactors", at = @At("HEAD"), cancellable = true)
    private void celestial$cancelJesusInputSlowdowns(Vec2f input, CallbackInfoReturnable<Vec2f> cir) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        if (Flight.cancelsInputSlowdown(player)
                || Jesus.cancelsInputSlowdown()
                || FreeCameraModule.cancelsInputSlowdown(player)) {
            cir.setReturnValue(input);
        }
    }

    @Redirect(
            method = "applyMovementSpeedFactors",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;getActiveItemSpeedMultiplier()F"
            )
    )
    private float celestial$legacyNoSlowMultiplier(ClientPlayerEntity player) {
        return NoSlow.activeItemSpeedMultiplier(player);
    }
}
