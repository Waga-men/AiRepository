package celestial.port.mixin;

import celestial.port.client.ui.CelestialHud;
import celestial.port.modules.visual.BlurVisuals;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.scoreboard.ScoreboardObjective;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameHud.class)
public abstract class InGameHudBlurMixin {
    @Inject(method = "renderHotbar", at = @At("HEAD"))
    private void celestial$blurHotbar(DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci) {
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(0.0F, -CelestialHud.legacyHotbarOffset());
        BlurVisuals.renderHotbarBlur(context);
    }

    @Inject(method = "renderHotbar", at = @At("RETURN"))
    private void celestial$restoreHotbarTransform(
            DrawContext context, RenderTickCounter tickCounter, CallbackInfo ci
    ) {
        context.getMatrices().popMatrix();
    }

    @Redirect(
            method = "renderHotbar",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/DrawContext;drawGuiTexture(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/util/Identifier;IIII)V"
            )
    )
    private void celestial$replaceVanillaHotbarBackplates(
            DrawContext context, RenderPipeline pipeline, Identifier texture,
            int x, int y, int width, int height
    ) {
        if (!BlurVisuals.suppressHotbarTexture(texture)) {
            context.drawGuiTexture(pipeline, texture, x, y, width, height);
        }
    }

    @Inject(
            method = "renderScoreboardSidebar(Lnet/minecraft/client/gui/DrawContext;Lnet/minecraft/scoreboard/ScoreboardObjective;)V",
            at = @At("HEAD")
    )
    private void celestial$blurScoreboard(
            DrawContext context, ScoreboardObjective objective, CallbackInfo ci
    ) {
        BlurVisuals.renderScoreboardBlur(context, objective);
    }
}
