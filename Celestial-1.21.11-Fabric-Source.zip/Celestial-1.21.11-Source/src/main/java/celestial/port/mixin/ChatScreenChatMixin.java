package celestial.port.mixin;

import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.util.StringHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ChatScreen.class)
public abstract class ChatScreenChatMixin {
    @Redirect(
            method = "sendMessage",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/ChatScreen;normalize(Ljava/lang/String;)Ljava/lang/String;"
            )
    )
    private String celestial$preserveLegacyChatWhitespace(ChatScreen screen, String message) {

        return StringHelper.truncateChat(message.trim());
    }
}
