package celestial.port.mixin;

import celestial.port.modules.legacyutility.AirDropSteal;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public abstract class GenericContainerScreenAirDropStealMixin {
    @Inject(method = "drawForeground", at = @At("HEAD"))
    private void celestial$captureAirDropContainer(
            DrawContext context, int mouseX, int mouseY, CallbackInfo ci
    ) {
        if ((Object) this instanceof GenericContainerScreen screen) {
            AirDropSteal.capture(screen);
        }
    }
}
