package celestial.port.mixin;

import celestial.port.modules.movement.Strafe;
import net.minecraft.entity.Entity;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientCommandC2SPacket.class)
public abstract class ClientCommandC2SPacketStrafeMixin {
    @Inject(
            method = "<init>(Lnet/minecraft/entity/Entity;" +
                    "Lnet/minecraft/network/packet/c2s/play/ClientCommandC2SPacket$Mode;I)V",
            at = @At("TAIL")
    )
    private void celestial$observeStrafeSprintCommand(
            Entity entity, ClientCommandC2SPacket.Mode mode,
            int mountJumpHeight, CallbackInfo ci
    ) {
        Strafe.observeSprintCommand(mode);
    }
}
