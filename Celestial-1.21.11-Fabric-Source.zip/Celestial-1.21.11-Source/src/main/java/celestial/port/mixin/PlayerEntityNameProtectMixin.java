package celestial.port.mixin;

import celestial.port.modules.player.NameProtectModule;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityNameProtectMixin {
    @Inject(method = "getName", at = @At("HEAD"), cancellable = true)
    private void celestial$protectLocalPlayerName(CallbackInfoReturnable<Text> cir) {
        String replacement = NameProtectModule.protectedPlayerName(
                (PlayerEntity) (Object) this, false);
        if (replacement != null) {
            cir.setReturnValue(Text.literal(replacement));
        }
    }

    @Inject(method = "getDisplayName", at = @At("HEAD"), cancellable = true)
    private void celestial$protectPlayerDisplayName(CallbackInfoReturnable<Text> cir) {
        String replacement = NameProtectModule.protectedPlayerName(
                (PlayerEntity) (Object) this, true);
        if (replacement != null) {
            cir.setReturnValue(Text.literal(replacement));
        }
    }
}
