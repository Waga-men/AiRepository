package celestial.port.mixin;

import celestial.port.core.macro.MacroManager;
import net.minecraft.client.Keyboard;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.KeyInput;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Keyboard.class)
public abstract class KeyboardMacroMixin {
    @Shadow @Final private MinecraftClient client;

    @Inject(
            method = "onKey(JILnet/minecraft/client/input/KeyInput;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/option/InactivityFpsLimiter;onInput()V",
                    shift = At.Shift.AFTER
            )
    )
    private void celestial$dispatchMacroPress(long window, int action, KeyInput input, CallbackInfo ci) {
        if (action == GLFW.GLFW_PRESS) {
            MacroManager.onKeyboardPress(client, window, input.key());
        }
    }
}
