package celestial.port.mixin;

import celestial.port.modules.combat.ItemsFixModule;
import net.minecraft.network.listener.ClientPlayPacketListener;
import net.minecraft.network.packet.s2c.play.UpdateSelectedSlotS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(UpdateSelectedSlotS2CPacket.class)
public abstract class UpdateSelectedSlotS2CPacketItemsFixMixin {
    @Inject(
            method = "apply(Lnet/minecraft/network/listener/ClientPlayPacketListener;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void celestial$rejectForcedServerSlot(ClientPlayPacketListener listener,
                                                   CallbackInfo ci) {
        if (ItemsFixModule.cancelServerSlotChange(
                (UpdateSelectedSlotS2CPacket) (Object) this)) {
            ci.cancel();
        }
    }
}
