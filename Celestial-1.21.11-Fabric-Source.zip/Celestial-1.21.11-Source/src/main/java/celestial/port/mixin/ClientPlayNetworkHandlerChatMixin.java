package celestial.port.mixin;

import celestial.port.client.chat.LegacyOutgoingChatDispatcher;
import celestial.port.client.command.LegacyTeleportCoordinator;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerChatMixin {

    @Inject(
            method = "sendChatMessage",
            at = @At(
                    value = "INVOKE",
                    target = "Ljava/time/Instant;now()Ljava/time/Instant;",
                    ordinal = 0
            ),
            cancellable = true
    )
    private void celestial$dispatchLegacyOutgoingChat(String message, CallbackInfo ci) {
        if (LegacyOutgoingChatDispatcher.afterExternalBaritone(message)) {
            ci.cancel();
        }
    }

    @Inject(
            method = "sendChatCommand",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/brigadier/CommandDispatcher;parse(Ljava/lang/String;Ljava/lang/Object;)Lcom/mojang/brigadier/ParseResults;",
                    ordinal = 0
            ),
            cancellable = true
    )
    private void celestial$dispatchLegacyOutgoingCommand(String command, CallbackInfo ci) {
        if (LegacyTeleportCoordinator.bypassesOutgoingCommand()) {
            return;
        }
        if (LegacyOutgoingChatDispatcher.includingBaritone(
                MinecraftClient.getInstance().player, "/" + command)) {
            ci.cancel();
        }
    }
}
