package celestial.port.mixin;

import celestial.port.client.ui.LegacyMenuBackdropBlur;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(GameRenderer.class)
abstract class GameRendererMainMenuBlurMixin {
    @Inject(method = "renderBlur", at = @At("HEAD"), cancellable = true)
    private void celestial$renderAltRegions(CallbackInfo ci) {
        if (LegacyMenuBackdropBlur.consumePendingAltRegions()) {
            ci.cancel();
        }
    }

    @ModifyArg(
            method = "renderBlur",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gl/ShaderLoader;loadPostEffect(Lnet/minecraft/util/Identifier;Ljava/util/Set;)Lnet/minecraft/client/gl/PostEffectProcessor;"
            ),
            index = 0
    )
    private Identifier celestial$selectMainMenuBlur(Identifier vanillaEffect) {
        return LegacyMenuBackdropBlur.selectPostEffect(vanillaEffect);
    }
}
