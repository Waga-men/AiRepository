package celestial.port.mixin;

import celestial.port.client.ui.LegacyClientState;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientLegacyClientStateMixin {
    @Inject(method = "run", at = @At("HEAD"))
    private void celestial$loadLegacyClientState(CallbackInfo ci) {
        LegacyClientState.initialize((MinecraftClient) (Object) this);
    }

    @Inject(method = "stop", at = @At("HEAD"))
    private void celestial$saveLegacyClientState(CallbackInfo ci) {
        LegacyClientState.save((MinecraftClient) (Object) this);
    }
}
