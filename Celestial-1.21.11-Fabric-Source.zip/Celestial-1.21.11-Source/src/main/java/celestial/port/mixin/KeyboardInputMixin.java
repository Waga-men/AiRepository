package celestial.port.mixin;

import celestial.port.modules.movement.Speed;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.input.Input;
import net.minecraft.client.input.KeyboardInput;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(KeyboardInput.class)
public abstract class KeyboardInputMixin extends Input {
    @Inject(method = "tick", at = @At("TAIL"))
    private void celestial$suppressFreeCameraMovement(CallbackInfo ci) {
        var player = MinecraftClient.getInstance().player;
        if (player != null) {
            playerInput = Speed.adjustInput(player, playerInput);
        }
    }
}
