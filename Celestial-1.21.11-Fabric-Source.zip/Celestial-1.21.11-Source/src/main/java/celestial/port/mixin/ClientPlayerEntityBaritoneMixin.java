package celestial.port.mixin;

import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.modules.combat.AttackAuraModule;
import celestial.port.modules.legacyutility.BaritoneBridge;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityBaritoneMixin {
    @Shadow
    private float lastYawClient;

    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void celestial$beginBaritoneRotation(CallbackInfo ci) {
        BaritoneBridge.beginMovementPackets((ClientPlayerEntity) (Object) this);
    }

    @Redirect(
            method = "sendMovementPackets",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F",
                    ordinal = 0
            )
    )
    private float celestial$baritoneYawDelta(ClientPlayerEntity player) {
        float yaw = AttackAuraModule.movementPacketYaw(player, player.getYaw());
        yaw = LegacyTeleportCoordinator.movementPacketYaw(player, yaw);
        return BaritoneBridge.movementPacketYaw(player, yaw);
    }

    @Redirect(
            method = "sendMovementPackets",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;getYaw()F",
                    ordinal = 3
            )
    )
    private float celestial$baritoneLastYaw(ClientPlayerEntity player) {
        float yaw = AttackAuraModule.movementPacketYaw(player, player.getYaw());
        yaw = LegacyTeleportCoordinator.movementPacketYaw(player, yaw);
        return BaritoneBridge.movementPacketYaw(player, yaw);
    }

    @Inject(method = "sendMovementPackets", at = @At("TAIL"))
    private void celestial$finishBaritoneRotation(CallbackInfo ci) {
        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        float appliedYaw = BaritoneBridge.appliedMovementYaw(player);
        if (!Float.isNaN(appliedYaw)) {
            lastYawClient = appliedYaw;
        }
        BaritoneBridge.endMovementPackets(player);
    }
}
