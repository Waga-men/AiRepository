package celestial.port.mixin;

import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.modules.combat.AutoExplosionModule;
import celestial.port.modules.impl.Flight;
import celestial.port.modules.movement.Jesus;
import celestial.port.modules.movement.Speed;
import celestial.port.modules.movement.Spider;
import celestial.port.modules.inventory.ClickPearl;
import celestial.port.modules.legacyutility.BaritoneBridge;
import celestial.port.modules.player.FreeCameraModule;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ClientCommonNetworkHandler.class)
public abstract class ClientCommonNetworkHandlerMovementMixin {
    @ModifyVariable(method = "sendPacket", at = @At("HEAD"), argsOnly = true)
    private Packet<?> celestial$rewriteJesusMovementPacket(Packet<?> packet) {
        packet = AutoExplosionModule.rewriteMovementPacket(packet);
        packet = Flight.rewriteOutgoing(packet);
        packet = Jesus.rewriteMovementPacket(packet);
        packet = Spider.rewriteMovementPacket(packet);
        packet = Speed.rewriteMovementPacket(packet);
        packet = ClickPearl.rewriteMovementPacket(packet);
        packet = FreeCameraModule.rewriteMovementPacket(packet);

        packet = LegacyTeleportCoordinator.rewriteMovementPacket(packet);

        return BaritoneBridge.rewriteMovementPacket(packet);
    }
}
