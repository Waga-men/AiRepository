package celestial.port.mixin;

import celestial.port.modules.visual.XRay;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientCommonNetworkHandler.class)
public abstract class ClientCommonNetworkHandlerXRayMixin {
    @Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true)
    private void celestial$cancelXRayAbort(Packet<?> packet, CallbackInfo ci) {
        if (XRay.shouldCancelOutgoing(packet)) {
            ci.cancel();
        }
    }
}
