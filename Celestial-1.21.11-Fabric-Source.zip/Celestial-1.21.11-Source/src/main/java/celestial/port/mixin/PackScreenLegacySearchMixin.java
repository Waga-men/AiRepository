package celestial.port.mixin;

import net.minecraft.client.gui.screen.pack.PackListWidget;
import net.minecraft.client.gui.screen.pack.PackScreen;
import net.minecraft.client.gui.screen.pack.ResourcePackOrganizer;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.stream.Stream;

@Mixin(PackScreen.class)
public abstract class PackScreenLegacySearchMixin {
    @Shadow @Final
    private ResourcePackOrganizer organizer;

    @Shadow
    private PackListWidget availablePackList;

    @Shadow
    private PackListWidget selectedPackList;

    @Inject(method = "setSearch", at = @At("HEAD"), cancellable = true)
    private void celestial$filterOnlyAvailablePackNames(String query, CallbackInfo ci) {
        if (selectedPackList != null) {
            selectedPackList.set(organizer.getEnabledPacks(), null);
        }
        if (availablePackList != null) {
            Stream<ResourcePackOrganizer.Pack> packs = organizer.getDisabledPacks();
            if (!query.isBlank()) {
                packs = packs.filter(pack -> pack.getName().toLowerCase().contains(query));
            }
            availablePackList.set(packs, null);
        }
        ci.cancel();
    }
}
