package celestial.port.mixin;

import celestial.port.modules.legacyutility.AirDropSteal;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
abstract class ClientPlayerInteractionManagerAirDropStealMixin {
    @Inject(
            method = "attackBlock",
            at = @At("HEAD"),
            cancellable = true
    )
    private void celestial$cancelAirDropBlockAttack(
            BlockPos pos, Direction direction, CallbackInfoReturnable<Boolean> cir
    ) {
        if (AirDropSteal.shouldCancelAttackInput()) {
            cir.setReturnValue(false);
        }
    }
}
