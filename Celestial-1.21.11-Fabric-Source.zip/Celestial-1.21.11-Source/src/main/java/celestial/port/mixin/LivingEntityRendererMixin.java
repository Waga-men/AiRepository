package celestial.port.mixin;

import celestial.port.modules.combat.BackTrackModule;
import celestial.port.modules.rendering.RotationView;
import celestial.port.modules.visual.CustomModel;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.PlayerEntityModel;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.EntityPose;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;

@Mixin(LivingEntityRenderer.class)
public abstract class LivingEntityRendererMixin {
    @Shadow
    protected EntityModel<?> model;

    @Shadow
    protected abstract void setupTransforms(LivingEntityRenderState state,
                                            MatrixStack matrices,
                                            float bodyYaw,
                                            float scale);

    @Shadow
    protected abstract void scale(LivingEntityRenderState state, MatrixStack matrices);

    @Unique
    private static final Field[] celestial$BACKTRACK_STATE_FIELDS = Arrays.stream(
                    PlayerEntityRenderState.class.getFields())
            .filter(field -> !Modifier.isStatic(field.getModifiers())
                    && !Modifier.isFinal(field.getModifiers()))
            .toArray(Field[]::new);

    @Unique
    private EntityModel<?> celestial$previousPlayerModel;
    @Unique
    private boolean celestial$playerModelSwapped;
    @Unique
    private MatrixStack.Entry celestial$backTrackBaseMatrix;

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("HEAD")
    )
    private void celestial$selectCustomPlayerModel(LivingEntityRenderState state,
                                                   MatrixStack matrices,
                                                   OrderedRenderCommandQueue queue,
                                                   CameraRenderState cameraState,
                                                   CallbackInfo ci) {
        celestial$playerModelSwapped = false;
        celestial$backTrackBaseMatrix = null;
        if (!((Object) this instanceof PlayerEntityRenderer<?>)
                || !(state instanceof PlayerEntityRenderState playerState)) {
            return;
        }

        celestial$backTrackBaseMatrix = matrices.peek().copy();

        PlayerEntityModel replacement = CustomModel.replacement(playerState);
        if (replacement == null) {
            return;
        }
        celestial$previousPlayerModel = model;
        model = replacement;
        celestial$playerModelSwapped = true;

        if (CustomModel.isMini(playerState)) {
            playerState.baby = true;
        }
    }

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/util/math/MatrixStack;pop()V",
                    shift = At.Shift.BEFORE
            )
    )
    private void celestial$submitServerRotationModel(LivingEntityRenderState state,
                                                     MatrixStack matrices,
                                                     OrderedRenderCommandQueue queue,
                                                     CameraRenderState cameraState,
                                                     CallbackInfo ci) {
        if ((Object) this instanceof PlayerEntityRenderer<?>
                && state instanceof PlayerEntityRenderState playerState
                && model instanceof PlayerEntityModel playerModel) {
            RotationView.submitServerRotation(playerState, playerModel, matrices, queue);
        }
    }

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/util/math/MatrixStack;pop()V",
                    shift = At.Shift.BEFORE
            )
    )
    private void celestial$submitBackTrackModel(LivingEntityRenderState state,
                                                 MatrixStack matrices,
                                                 OrderedRenderCommandQueue queue,
                                                 CameraRenderState cameraState,
                                                 CallbackInfo ci) {
        if (!((Object) this instanceof PlayerEntityRenderer<?>)
                || !(state instanceof PlayerEntityRenderState playerState)
                || !(model instanceof PlayerEntityModel playerModel)
                || celestial$backTrackBaseMatrix == null) {
            return;
        }

        BackTrackModule.ChamsGhost ghost = BackTrackModule.chamsGhost(playerState);
        if (ghost == null) {
            return;
        }
        PlayerEntityRenderState ghostState = celestial$copyPlayerState(playerState);
        if (ghostState == null) {
            return;
        }

        ghostState.x = ghost.position().x;
        ghostState.y = ghost.position().y;
        ghostState.z = ghost.position().z;
        ghostState.bodyYaw = ghost.yaw();
        ghostState.relativeHeadYaw = 0.0F;
        ghostState.pitch = ghost.pitch();

        ghostState.invisible = false;
        ghostState.invisibleToPlayer = false;

        MatrixStack ghostMatrices = new MatrixStack();
        ghostMatrices.peek().copy(celestial$backTrackBaseMatrix);
        ghostMatrices.translate(
                ghost.position().x - playerState.x,
                ghost.position().y - playerState.y,
                ghost.position().z - playerState.z);

        if (ghostState.isInPose(EntityPose.SLEEPING) && ghostState.sleepingDirection != null) {
            float offset = ghostState.standingEyeHeight - 0.1F;
            ghostMatrices.translate(
                    -ghostState.sleepingDirection.getOffsetX() * offset,
                    0.0F,
                    -ghostState.sleepingDirection.getOffsetZ() * offset);
        }

        float baseScale = ghostState.baseScale;
        ghostMatrices.scale(baseScale, baseScale, baseScale);
        setupTransforms(ghostState, ghostMatrices, ghost.yaw(), baseScale);
        ghostMatrices.scale(-1.0F, -1.0F, 1.0F);
        scale(ghostState, ghostMatrices);
        ghostMatrices.translate(0.0F, -1.501F, 0.0F);

        RenderLayer layer = BackTrackModule.chamsLayer(ghost.glow());
        queue.submitModel(
                playerModel,
                ghostState,
                ghostMatrices,
                layer,
                ghostState.light,
                OverlayTexture.DEFAULT_UV,
                ghost.argb(),
                null,
                0,
                null
        );
    }

    @Unique
    private static PlayerEntityRenderState celestial$copyPlayerState(PlayerEntityRenderState source) {
        PlayerEntityRenderState copy = new PlayerEntityRenderState();
        try {
            for (Field field : celestial$BACKTRACK_STATE_FIELDS) {
                field.set(copy, field.get(source));
            }
            return copy;
        } catch (IllegalAccessException ignored) {
            return null;
        }
    }

    @Inject(
            method = "render(Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("RETURN")
    )
    private void celestial$restorePlayerModel(LivingEntityRenderState state,
                                              MatrixStack matrices,
                                              OrderedRenderCommandQueue queue,
                                              CameraRenderState cameraState,
                                              CallbackInfo ci) {
        celestial$backTrackBaseMatrix = null;
        if (celestial$playerModelSwapped) {
            model = celestial$previousPlayerModel;
            celestial$previousPlayerModel = null;
            celestial$playerModelSwapped = false;
        }
    }
}
