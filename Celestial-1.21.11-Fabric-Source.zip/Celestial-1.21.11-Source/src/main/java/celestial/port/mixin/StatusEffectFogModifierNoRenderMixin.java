package celestial.port.mixin;

import celestial.port.modules.rendering.NoRender;
import net.minecraft.block.enums.CameraSubmersionType;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.fog.StatusEffectFogModifier;
import net.minecraft.entity.Entity;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.entry.RegistryEntry;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(StatusEffectFogModifier.class)
public abstract class StatusEffectFogModifierNoRenderMixin {
    @Shadow
    public abstract RegistryEntry<StatusEffect> getStatusEffect();

    @Inject(
            method = "shouldApply(Lnet/minecraft/block/enums/CameraSubmersionType;Lnet/minecraft/entity/Entity;)Z",
            at = @At("HEAD"),
            cancellable = true,
            require = 1
    )
    private void celestial$hideBadEffectFog(
            CameraSubmersionType submersionType, Entity entity,
            CallbackInfoReturnable<Boolean> cir
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        RegistryEntry<StatusEffect> effect = getStatusEffect();
        if (NoRender.shouldHideBadEffectVisuals()
                && client.player != null
                && entity == client.player
                && (effect == StatusEffects.BLINDNESS || effect == StatusEffects.DARKNESS)) {
            cir.setReturnValue(false);
        }
    }
}
