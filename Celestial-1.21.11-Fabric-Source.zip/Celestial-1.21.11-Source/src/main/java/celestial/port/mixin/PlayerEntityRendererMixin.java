package celestial.port.mixin;

import celestial.port.modules.combat.AttackAuraModule;
import celestial.port.modules.rendering.ESP;
import celestial.port.modules.visual.CustomModel;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.PlayerEntityRenderer;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.state.CameraRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.PlayerLikeEntity;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntityRenderer.class)
public abstract class PlayerEntityRendererMixin {
    @Inject(
            method = "updateRenderState(Lnet/minecraft/entity/PlayerLikeEntity;Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;F)V",
            at = @At("TAIL"),
            require = 1,
            allow = 1
    )
    private void celestial$focusAuraThirdPersonRotation(PlayerLikeEntity player,
                                                        PlayerEntityRenderState state,
                                                        float tickProgress,
                                                        CallbackInfo ci) {
        AttackAuraModule.applyThirdPersonRotation(player, state);
    }

    @Inject(
            method = "renderLabelIfPresent(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;Lnet/minecraft/client/render/state/CameraRenderState;)V",
            at = @At("HEAD"),
            cancellable = true
    )
    private void celestial$suppressEspPlayerLabel(PlayerEntityRenderState state,
                                                   MatrixStack matrices,
                                                   OrderedRenderCommandQueue queue,
                                                   CameraRenderState cameraState,
                                                   CallbackInfo ci) {
        if (ESP.suppressesVanillaPlayerLabels()) {
            ci.cancel();
        }
    }

    @Inject(
            method = "getTexture(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)Lnet/minecraft/util/Identifier;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void celestial$useFinnTexture(PlayerEntityRenderState state,
                                          CallbackInfoReturnable<Identifier> cir) {
        if (CustomModel.isFinn(state)) {
            cir.setReturnValue(CustomModel.FINN_TEXTURE);
        }
    }

    @Inject(
            method = "getPositionOffset(Lnet/minecraft/client/render/entity/state/PlayerEntityRenderState;)Lnet/minecraft/util/math/Vec3d;",
            at = @At("RETURN"),
            cancellable = true
    )
    private void celestial$removeFinnSneakOffset(PlayerEntityRenderState state,
                                                 CallbackInfoReturnable<Vec3d> cir) {
        if (CustomModel.isFinn(state) && state.isInSneakingPose) {
            cir.setReturnValue(cir.getReturnValue().add(0.0, state.baseScale * 2.0F / 16.0F, 0.0));
        }
    }
}
