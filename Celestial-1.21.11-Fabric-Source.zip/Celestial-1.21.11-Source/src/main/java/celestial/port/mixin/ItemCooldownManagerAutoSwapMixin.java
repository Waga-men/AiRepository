package celestial.port.mixin;

import celestial.port.modules.combat.AutoSwapModule;
import celestial.port.modules.player.ItemsCooldownModule;
import net.minecraft.entity.player.ItemCooldownManager;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ItemCooldownManager.class)
public abstract class ItemCooldownManagerAutoSwapMixin {
    @Inject(method = "set(Lnet/minecraft/util/Identifier;I)V", at = @At("HEAD"))
    private void celestial$cooldownStarted(Identifier group, int duration, CallbackInfo ci) {
        AutoSwapModule.onCooldownStarted((ItemCooldownManager) (Object) this, group);
    }

    @Inject(method = "onCooldownUpdate(Lnet/minecraft/util/Identifier;)V", at = @At("HEAD"))
    private void celestial$cooldownEnded(Identifier group, CallbackInfo ci) {
        AutoSwapModule.onCooldownEnded((ItemCooldownManager) (Object) this, group);
    }

    @Inject(
            method = "getCooldownProgress(Lnet/minecraft/item/ItemStack;F)F",
            at = @At("RETURN"), cancellable = true, require = 2, allow = 2
    )
    private void celestial$legacyCooldownProgress(
            ItemStack stack, float tickProgress, CallbackInfoReturnable<Float> cir
    ) {
        cir.setReturnValue(ItemsCooldownModule.cooldownProgress(
                (ItemCooldownManager) (Object) this, stack, cir.getReturnValueF()
        ));
    }
}
