package celestial.port.mixin;

import celestial.port.modules.combat.BackTrackModule;
import celestial.port.modules.movement.LongJump;
import celestial.port.modules.movement.Speed;
import celestial.port.modules.player.FreeCameraModule;
import net.minecraft.entity.player.PlayerEntity;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityMovementMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void celestial$sampleBackTrackBeforeMovement(CallbackInfo ci) {
        BackTrackModule.sampleBeforeTick((PlayerEntity) (Object) this);
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/entity/player/PlayerEntity;noClip:Z",
                    opcode = Opcodes.PUTFIELD,
                    shift = At.Shift.AFTER
            ),
            require = 1,
            allow = 1
    )
    private void celestial$reassertFreeCameraNoClip(CallbackInfo ci) {
        FreeCameraModule.reassertNoClip((PlayerEntity) (Object) this);
    }

    @Inject(method = "getOffGroundSpeed", at = @At("HEAD"), cancellable = true)
    private void celestial$longJumpOffGroundSpeed(CallbackInfoReturnable<Float> cir) {
        Float speed = LongJump.offGroundSpeed((PlayerEntity) (Object) this);
        if (speed == null) {
            speed = Speed.offGroundSpeed((PlayerEntity) (Object) this);
        }
        if (speed != null) {
            cir.setReturnValue(speed);
        }
    }
}
