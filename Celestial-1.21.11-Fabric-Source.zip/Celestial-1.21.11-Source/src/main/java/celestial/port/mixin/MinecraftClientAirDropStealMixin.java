package celestial.port.mixin;

import celestial.port.modules.legacyutility.AirDropSteal;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
abstract class MinecraftClientAirDropStealMixin {
    @Inject(method = "doAttack", at = @At("HEAD"), cancellable = true)
    private void celestial$cancelAirDropAttack(CallbackInfoReturnable<Boolean> cir) {
        if (AirDropSteal.shouldCancelAttackInput()) {
            cir.setReturnValue(false);
        }
    }
}
