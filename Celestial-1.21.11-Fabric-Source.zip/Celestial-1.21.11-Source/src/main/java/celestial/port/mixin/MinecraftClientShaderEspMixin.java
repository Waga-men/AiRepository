package celestial.port.mixin;

import celestial.port.modules.visual.ShaderESP;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(MinecraftClient.class)
abstract class MinecraftClientShaderEspMixin {
    @Inject(method = "hasOutline", at = @At("HEAD"), cancellable = true)
    private void celestial$shaderEspOutline(Entity entity, CallbackInfoReturnable<Boolean> cir) {
        if (ShaderESP.active()) {
            cir.setReturnValue(ShaderESP.shouldOutline(entity));
        }
    }
}
