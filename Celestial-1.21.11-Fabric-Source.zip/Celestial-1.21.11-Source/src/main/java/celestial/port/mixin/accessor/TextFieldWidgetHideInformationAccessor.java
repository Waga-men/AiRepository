package celestial.port.mixin.accessor;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.widget.TextFieldWidget;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(TextFieldWidget.class)
public interface TextFieldWidgetHideInformationAccessor {
    @Accessor("firstCharacterIndex")
    int celestial$getFirstCharacterIndex();

    @Accessor("textX")
    int celestial$getTextX();

    @Accessor("textY")
    int celestial$getTextY();

    @Accessor("textRenderer")
    TextRenderer celestial$getTextRenderer();
}
