package celestial.port.mixin;

import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.modules.combat.AttackAuraModule;
import celestial.port.modules.movement.ElytraFlight;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityElytraFlightMixin {
    @Inject(method = "tick", at = @At("TAIL"))
    private void celestial$retryElytraFlightInventoryRestore(CallbackInfo ci) {
        ElytraFlight.retryPendingRestore((ClientPlayerEntity) (Object) this);
    }

    @Redirect(
            method = "sendMovementPackets",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/ClientPlayerEntity;getPitch()F"
            )
    )
    private float celestial$elytraFlightPacketPitch(ClientPlayerEntity player) {
        float pitch = AttackAuraModule.movementPacketPitch(player, player.getPitch());
        pitch = ElytraFlight.movementPacketPitch(player, pitch);
        return LegacyTeleportCoordinator.movementPacketPitch(player, pitch);
    }
}
