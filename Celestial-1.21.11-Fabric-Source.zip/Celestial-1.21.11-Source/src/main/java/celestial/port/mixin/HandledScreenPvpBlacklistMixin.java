package celestial.port.mixin;

import celestial.port.core.pvp.PvpBlacklistManager;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(HandledScreen.class)
public abstract class HandledScreenPvpBlacklistMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void celestial$avoidConfiguredPvp(CallbackInfo ci) {
        if (!((Object) this instanceof GenericContainerScreen)) {
            return;
        }
        PvpBlacklistManager.onHandledScreenTick((HandledScreen<?>) (Object) this);
    }
}
