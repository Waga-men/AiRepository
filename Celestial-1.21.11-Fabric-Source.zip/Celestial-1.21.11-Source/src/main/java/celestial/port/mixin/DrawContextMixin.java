package celestial.port.mixin;

import celestial.port.modules.player.NameProtectModule;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.OrderedText;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(DrawContext.class)
public abstract class DrawContextMixin {
    @ModifyVariable(
            method = "drawText(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/text/OrderedText;IIIZ)V",
            at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private OrderedText celestial$protectOrderedText(OrderedText text) {
        return NameProtectModule.protect(text);
    }
}
