package celestial.port.mixin;

import celestial.port.client.chat.LegacyOutgoingChatDispatcher;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Screen.class)
public abstract class ScreenRunCommandChatMixin {

    @Inject(method = "handleRunCommand", at = @At("HEAD"), cancellable = true)
    private static void celestial$dispatchLegacyRunCommand(
            ClientPlayerEntity player, String command, Screen parent, CallbackInfo ci
    ) {
        if (LegacyOutgoingChatDispatcher.includingBaritone(player, command)) {
            ci.cancel();
        }
    }
}
