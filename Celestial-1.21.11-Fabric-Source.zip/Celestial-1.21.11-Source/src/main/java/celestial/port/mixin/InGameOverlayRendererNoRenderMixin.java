package celestial.port.mixin;

import celestial.port.modules.rendering.NoRender;
import net.minecraft.client.gui.hud.InGameOverlayRenderer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.util.math.MatrixStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(InGameOverlayRenderer.class)
public abstract class InGameOverlayRendererNoRenderMixin {
    @Inject(
            method = "renderFireOverlay(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/texture/Sprite;)V",
            at = @At("HEAD"),
            cancellable = true,
            require = 1
    )
    private static void celestial$hideFireOverlay(
            MatrixStack matrices, VertexConsumerProvider vertexConsumers, Sprite sprite,
            CallbackInfo ci
    ) {
        if (NoRender.shouldHideFireOverlay()) {
            ci.cancel();
        }
    }
}
