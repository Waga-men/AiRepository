package celestial.port.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import celestial.port.modules.visual.ChunkAnimator;
import net.minecraft.client.render.WorldRenderer;
import net.minecraft.client.render.chunk.ChunkBuilder;
import net.minecraft.util.math.BlockPos;
import org.joml.Matrix4f;
import org.joml.Matrix4fc;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererChunkAnimatorMixin {
    @Unique
    private ChunkBuilder.BuiltChunk celestial$currentBuiltChunk;

    @Redirect(
            method = "renderBlockLayers",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/chunk/ChunkBuilder$BuiltChunk;getOrigin()Lnet/minecraft/util/math/BlockPos;"
            )
    )
    private BlockPos celestial$captureBuiltChunk(ChunkBuilder.BuiltChunk chunk) {
        celestial$currentBuiltChunk = chunk;
        return chunk.getOrigin();
    }

    @ModifyArg(
            method = "renderBlockLayers",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gl/DynamicUniforms$ChunkSectionsValue;<init>(Lorg/joml/Matrix4fc;IIIFII)V"
            ),
            index = 0
    )
    private Matrix4fc celestial$animateSectionMatrix(Matrix4fc original) {
        ChunkBuilder.BuiltChunk chunk = celestial$currentBuiltChunk;
        if (chunk == null) {
            return original;
        }
        float offset = ChunkAnimator.verticalOffset(chunk);
        return offset == 0.0F ? original : new Matrix4f(original).translate(0.0F, offset, 0.0F);
    }

    @ModifyArg(
            method = "renderBlockLayers",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gl/DynamicUniforms$ChunkSectionsValue;<init>(Lorg/joml/Matrix4fc;IIIFII)V"
            ),
            index = 4
    )
    private float celestial$keepAnimatedSectionOpaque(float vanillaVisibility) {
        ChunkBuilder.BuiltChunk chunk = celestial$currentBuiltChunk;
        return chunk == null ? vanillaVisibility : ChunkAnimator.visibility(chunk, vanillaVisibility);
    }

    @ModifyExpressionValue(
            method = "fillBlockEntityRenderStates(Lnet/minecraft/client/render/Camera;FLnet/minecraft/client/render/state/WorldRenderState;)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/chunk/ChunkBuilder$BuiltChunk;method_76298(J)F",
                    ordinal = 0
            ),
            require = 1,
            allow = 1
    )
    private float celestial$keepAnimatedBlockEntitiesVisible(
            float vanillaVisibility,
            @Local ChunkBuilder.BuiltChunk chunk
    ) {
        return ChunkAnimator.visibility(chunk, vanillaVisibility);
    }

    @ModifyExpressionValue(
            method = "isRenderingReady(Lnet/minecraft/util/math/BlockPos;)Z",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/chunk/ChunkBuilder$BuiltChunk;method_76298(J)F",
                    ordinal = 0
            ),
            require = 1,
            allow = 1
    )
    private float celestial$keepAnimatedSectionReady(
            float vanillaVisibility,
            @Local ChunkBuilder.BuiltChunk chunk
    ) {
        return ChunkAnimator.visibility(chunk, vanillaVisibility);
    }
}
