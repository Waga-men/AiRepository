package celestial.port.mixin.accessor;

import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.ProfileResult;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.SocialInteractionsManager;
import net.minecraft.client.realms.RealmsPeriodicCheckers;
import net.minecraft.client.session.ProfileKeys;
import net.minecraft.client.session.Session;
import net.minecraft.client.session.report.AbuseReportContext;
import net.minecraft.client.session.telemetry.TelemetryManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.concurrent.CompletableFuture;

@Mixin(MinecraftClient.class)
public interface MinecraftClientSessionAccessor {
    @Accessor("gameProfileFuture")
    CompletableFuture<ProfileResult> celestial$getGameProfileFuture();

    @Mutable
    @Accessor("gameProfileFuture")
    void celestial$setGameProfileFuture(CompletableFuture<ProfileResult> profile);

    @Accessor("session")
    Session celestial$getSession();

    @Mutable
    @Accessor("session")
    void celestial$setSession(Session session);

    @Accessor("userApiService")
    UserApiService celestial$getUserApiService();

    @Mutable
    @Accessor("userApiService")
    void celestial$setUserApiService(UserApiService service);

    @Accessor("userPropertiesFuture")
    CompletableFuture<UserApiService.UserProperties> celestial$getUserPropertiesFuture();

    @Mutable
    @Accessor("userPropertiesFuture")
    void celestial$setUserPropertiesFuture(
            CompletableFuture<UserApiService.UserProperties> properties);

    @Mutable
    @Accessor("socialInteractionsManager")
    void celestial$setSocialInteractionsManager(SocialInteractionsManager manager);

    @Mutable
    @Accessor("telemetryManager")
    void celestial$setTelemetryManager(TelemetryManager manager);

    @Mutable
    @Accessor("profileKeys")
    void celestial$setProfileKeys(ProfileKeys keys);

    @Mutable
    @Accessor("realmsPeriodicCheckers")
    void celestial$setRealmsPeriodicCheckers(RealmsPeriodicCheckers checkers);

    @Accessor("abuseReportContext")
    void celestial$setAbuseReportContext(AbuseReportContext context);
}
