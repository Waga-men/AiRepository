package celestial.port.mixin;

import celestial.port.modules.visual.Particles;
import net.minecraft.client.particle.BillboardParticle;
import net.minecraft.client.particle.DamageParticle;
import net.minecraft.client.texture.Sprite;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.MathHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(DamageParticle.class)
abstract class DamageParticleParticlesMixin extends BillboardParticle {
    protected DamageParticleParticlesMixin(
            ClientWorld world, double x, double y, double z, Sprite sprite
    ) {
        super(world, x, y, z, sprite);
    }

    @Unique
    private float celestial$legacyAge;

    @Inject(method = "tick", at = @At("HEAD"), cancellable = true)
    private void celestial$tickLegacyCrit(CallbackInfo ci) {
        if (!Particles.customCritsActive()) {
            celestial$legacyAge = Math.max(celestial$legacyAge, age);
            return;
        }

        celestial$legacyAge = Math.max(celestial$legacyAge, age);
        lastX = x;
        lastY = y;
        lastZ = z;

        float speed = Particles.critParticleSpeed();
        celestial$legacyAge += speed;
        age = (int) celestial$legacyAge;
        if (celestial$legacyAge >= (float) maxAge) {
            markDead();
        }

        collidesWithWorld = true;
        move(velocityX * (double) speed,
                velocityY * (double) speed,
                velocityZ * (double) speed);
        green = (float) ((double) green * 0.96);
        blue = (float) ((double) blue * 0.9);
        if (onGround) {
            velocityX *= (double) 0.7F;
            velocityZ *= (double) 0.7F;
        }
        ci.cancel();
    }

    @Inject(method = "getSize", at = @At("HEAD"), cancellable = true)
    private void celestial$legacyFractionalCritSize(
            float tickProgress, CallbackInfoReturnable<Float> cir
    ) {
        if (!Particles.customCritsActive()) {
            return;
        }
        float growth = (celestial$legacyAge + tickProgress) / (float) maxAge * 32.0F;
        cir.setReturnValue(scale * MathHelper.clamp(growth, 0.0F, 1.0F));
    }
}
