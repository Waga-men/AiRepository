package celestial.port.mixin;

import celestial.port.modules.combat.AttackAuraModule;
import celestial.port.modules.combat.HitBoxModule;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityMixin {
    @Inject(
            method = "getYaw",
            at = @At("RETURN"),
            cancellable = true,
            require = 1,
            allow = 1
    )
    private void celestial$focusedMovementYaw(CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(AttackAuraModule.focusedMovementYaw(
                (Entity) (Object) this, cir.getReturnValue()));
    }

    @Inject(method = "getTargetingMargin", at = @At("RETURN"), cancellable = true)
    private void celestial$targetingMargin(CallbackInfoReturnable<Float> cir) {
        cir.setReturnValue(HitBoxModule.targetingMargin((Entity) (Object) this));
    }
}
