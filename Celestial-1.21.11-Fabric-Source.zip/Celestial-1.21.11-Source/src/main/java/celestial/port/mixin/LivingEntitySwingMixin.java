package celestial.port.mixin;

import celestial.port.modules.visual.SwingAnimations;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.LivingEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(LivingEntity.class)
public abstract class LivingEntitySwingMixin {
    @Inject(method = "getHandSwingDuration", at = @At("HEAD"), cancellable = true)
    private void celestial$useLegacySwingDuration(CallbackInfoReturnable<Integer> cir) {
        if (!((Object)this instanceof ClientPlayerEntity)) {
            return;
        }
        SwingAnimations module = SwingAnimations.instance();
        if (module != null && module.changesSwingDuration()) {
            cir.setReturnValue(module.swingDuration());
        }
    }
}
