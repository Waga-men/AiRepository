package celestial.port.mixin;

import celestial.port.modules.rendering.NoRender;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(WorldRenderer.class)
public abstract class WorldRendererNoRenderMixin {
    @Inject(
            method = "hasBlindnessOrDarkness(Lnet/minecraft/client/render/Camera;)Z",
            at = @At("HEAD"),
            cancellable = true,
            require = 1
    )
    private void celestial$keepSkyVisible(Camera camera, CallbackInfoReturnable<Boolean> cir) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (NoRender.shouldHideBadEffectVisuals()
                && client.player != null
                && camera.getFocusedEntity() == client.player) {
            cir.setReturnValue(false);
        }
    }
}
