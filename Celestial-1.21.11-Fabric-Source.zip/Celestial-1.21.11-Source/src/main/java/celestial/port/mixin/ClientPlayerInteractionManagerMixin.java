package celestial.port.mixin;

import celestial.port.modules.player.FastBreak;
import celestial.port.modules.player.InventoryMove;
import celestial.port.modules.player.NoInteract;
import celestial.port.modules.combat.AutoExplosionModule;
import celestial.port.modules.combat.AutoPotionModule;
import celestial.port.modules.rendering.BlockESP;
import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Constant;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.ModifyConstant;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerMixin {
    @Unique
    private BlockPos celestial$autoExplosionPlacement;

    @ModifyArgs(
            method = "method_41929(Lnet/minecraft/util/Hand;Lnet/minecraft/entity/player/PlayerEntity;Lorg/apache/commons/lang3/mutable/MutableObject;I)Lnet/minecraft/network/packet/Packet;",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/network/packet/c2s/play/PlayerInteractItemC2SPacket;<init>(Lnet/minecraft/util/Hand;IFF)V"
            ),
            require = 1,
            allow = 1
    )
    private void celestial$applyAutoPotionUseRotation(Args args) {
        if (!AutoPotionModule.hasScopedUseRotation()) {
            return;
        }
        args.set(2, AutoPotionModule.scopedUseYaw());
        args.set(3, AutoPotionModule.scopedUsePitch());
    }

    @Inject(method = "interactBlock", at = @At("HEAD"))
    private void celestial$captureAutoExplosionObsidian(
            ClientPlayerEntity player, Hand hand, BlockHitResult hit,
            CallbackInfoReturnable<ActionResult> cir
    ) {
        celestial$autoExplosionPlacement = AutoExplosionModule.captureObsidianPlacement(
                player, hand, hit);
    }

    @Inject(method = "interactBlock", at = @At("RETURN"))
    private void celestial$armAutoExplosionFromPlacedObsidian(
            ClientPlayerEntity player, Hand hand, BlockHitResult hit,
            CallbackInfoReturnable<ActionResult> cir
    ) {
        try {
            AutoExplosionModule.finishObsidianPlacement(
                    player, celestial$autoExplosionPlacement, cir.getReturnValue());
        } finally {
            celestial$autoExplosionPlacement = null;
        }
    }

    @Inject(method = "clickSlot", at = @At("HEAD"), cancellable = true)
    private void celestial$beginInventoryMoveSlotPulse(
            int syncId, int slotId, int button, SlotActionType actionType, PlayerEntity player,
            CallbackInfo ci
    ) {
        if (InventoryMove.beforeSlotClick()) {
            ci.cancel();
        }
    }

    @Inject(method = "clickSlot", at = @At("RETURN"))
    private void celestial$finishInventoryMoveSlotPulse(
            int syncId, int slotId, int button, SlotActionType actionType, PlayerEntity player,
            CallbackInfo ci
    ) {
        InventoryMove.afterSlotClick();
    }

    @Inject(method = "attackBlock", at = @At("HEAD"), cancellable = true)
    private void celestial$cancelNoInteractBlockAttack(BlockPos pos, Direction direction,
                                                       CallbackInfoReturnable<Boolean> cir) {
        if (NoInteract.cancelsBlockBreaking()) {
            cir.setReturnValue(false);
        }
    }

    @ModifyExpressionValue(
            method = "updateBlockBreakingProgress",
            at = @At(
                    value = "FIELD",
                    target = "Lnet/minecraft/client/network/ClientPlayerInteractionManager;currentBreakingProgress:F",
                    opcode = Opcodes.GETFIELD,
                    ordinal = 2
            ),
            require = 1
    )
    private float celestial$applyCompletionThreshold(float actualProgress) {
        return FastBreak.active() && actualProgress >= FastBreak.completionThreshold()
                ? 1.0F : actualProgress;
    }

    @ModifyConstant(
            method = "attackBlock",
            constant = @Constant(intValue = 5),
            require = 1
    )
    private int celestial$replaceInitialBreakingCooldown(int vanillaCooldown) {
        return FastBreak.active() ? 0 : vanillaCooldown;
    }

    @ModifyConstant(
            method = "updateBlockBreakingProgress",
            constant = @Constant(intValue = 5),
            require = 2
    )
    private int celestial$replaceContinuedBreakingCooldown(int vanillaCooldown) {
        return FastBreak.active() ? 0 : vanillaCooldown;
    }

    @Inject(method = "breakBlock", at = @At("RETURN"))
    private void celestial$rememberBrokenBlock(BlockPos pos, CallbackInfoReturnable<Boolean> cir) {
        if (cir.getReturnValueZ()) {
            BlockESP.onBlockBroken(pos);
        }
    }
}
