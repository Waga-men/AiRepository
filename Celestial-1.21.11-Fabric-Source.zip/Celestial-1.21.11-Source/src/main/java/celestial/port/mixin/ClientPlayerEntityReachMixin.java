package celestial.port.mixin;

import celestial.port.modules.combat.ReachModule;
import celestial.port.modules.player.NoInteract;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.ProjectileUtil;
import net.minecraft.predicate.entity.EntityPredicates;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.function.Predicate;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityReachMixin {
    @Inject(
            method = "getCrosshairTarget(FLnet/minecraft/entity/Entity;)Lnet/minecraft/util/hit/HitResult;",
            at = @At("HEAD"),
            cancellable = true
    )
    private void celestial$legacyReachCrosshair(float tickProgress, Entity camera,
                                                 CallbackInfoReturnable<HitResult> cir) {
        if (!ReachModule.requiresLegacyCrosshair()) {
            return;
        }

        ClientPlayerEntity player = (ClientPlayerEntity) (Object) this;
        double blockRange = ReachModule.legacyBlockScanRange(player);
        double entityScanRange = ReachModule.legacyEntityScanRange(player);
        double entityCutoff = ReachModule.legacyEntityCutoff(player);

        Vec3d start = camera.getCameraPosVec(tickProgress);
        HitResult blockHit = camera.raycast(blockRange, tickProgress, false);
        double selectedDistanceSquared = start.squaredDistanceTo(blockHit.getPos());

        Vec3d direction = camera.getRotationVec(1.0F);
        Vec3d ray = direction.multiply(entityScanRange);
        Vec3d end = start.add(ray);
        Box searchBox = camera.getBoundingBox().stretch(ray).expand(1.0);
        Predicate<Entity> predicate = EntityPredicates.CAN_HIT
                .and(entity -> !NoInteract.skipsCrosshairEntity(entity));
        EntityHitResult entityHit = ProjectileUtil.raycast(
                camera, start, end, searchBox, predicate, selectedDistanceSquared);

        if (entityHit == null) {
            cir.setReturnValue(blockHit);
            return;
        }

        Vec3d hitPosition = entityHit.getPos();
        if (!player.isCreative() && start.distanceTo(hitPosition) > entityCutoff) {
            Vec3d delta = hitPosition.subtract(start);
            Direction side = Direction.getFacing(delta.x, delta.y, delta.z);
            cir.setReturnValue(BlockHitResult.createMissed(
                    hitPosition, side, BlockPos.ofFloored(hitPosition)));
            return;
        }
        cir.setReturnValue(entityHit);
    }
}
