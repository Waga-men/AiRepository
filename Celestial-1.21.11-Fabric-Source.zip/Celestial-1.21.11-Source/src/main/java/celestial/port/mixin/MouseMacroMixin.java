package celestial.port.mixin;

import celestial.port.core.macro.MacroManager;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.Mouse;
import net.minecraft.client.input.MouseInput;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(Mouse.class)
public abstract class MouseMacroMixin {
    @Shadow @Final private MinecraftClient client;

    @Inject(
            method = "onMouseButton(JLnet/minecraft/client/input/MouseInput;I)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/option/InactivityFpsLimiter;onInput()V",
                    shift = At.Shift.AFTER
            )
    )
    private void celestial$dispatchMacroPress(long window, MouseInput input, int action, CallbackInfo ci) {
        if (action == GLFW.GLFW_PRESS) {
            MacroManager.onMousePress(client, window, input.button());
        }
    }
}
