package celestial.port.mixin;

import celestial.port.modules.inventory.AutoTotem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.entity.EntityType;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.network.packet.s2c.play.EntityStatusS2CPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayNetworkHandler.class)
public abstract class ClientPlayNetworkHandlerAutoTotemMixin {
    @Inject(method = "onEntityStatus", at = @At("TAIL"))
    private void celestial$trackTotemPop(EntityStatusS2CPacket packet, CallbackInfo ci) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world != null) {
            AutoTotem.onTotemStatus(packet.getStatus(), packet.getEntity(client.world));
        }
    }

    @Inject(method = "onEntitySpawn", at = @At("TAIL"))
    private void celestial$reactToCrystalSpawn(EntitySpawnS2CPacket packet, CallbackInfo ci) {
        if (packet.getEntityType() == EntityType.END_CRYSTAL) {
            AutoTotem.onCrystalSpawn(packet.getX(), packet.getY(), packet.getZ());
        }
    }
}
