package celestial.port.mixin;

import celestial.port.modules.visual.Prediction;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityPredictionMixin {
    @Inject(method = "tick", at = @At("HEAD"))
    private void celestial$capturePredictionTrajectories(CallbackInfo ci) {
        Prediction.captureAtPlayerTick((ClientPlayerEntity) (Object) this);
    }
}
