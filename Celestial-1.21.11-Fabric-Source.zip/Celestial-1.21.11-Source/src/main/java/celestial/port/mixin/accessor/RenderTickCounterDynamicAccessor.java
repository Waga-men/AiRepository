package celestial.port.mixin.accessor;

import net.minecraft.client.render.RenderTickCounter;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(RenderTickCounter.Dynamic.class)
public interface RenderTickCounterDynamicAccessor {
    @Accessor("tickTime")
    float celestial$getTickTime();

    @Mutable
    @Accessor("tickTime")
    void celestial$setTickTime(float tickTime);
}
