package celestial.port.mixin;

import celestial.port.event.SuccessfulAttackCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerInteractionManager.class)
abstract class ClientPlayerInteractionManagerSuccessfulAttackMixin {
    @Inject(
            method = "attackEntity",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/player/PlayerEntity;attack(Lnet/minecraft/entity/Entity;)V",
                    shift = At.Shift.AFTER
            )
    )
    private void celestial$emitSuccessfulAttack(PlayerEntity player, Entity target, CallbackInfo ci) {
        if (player == MinecraftClient.getInstance().player) {
            SuccessfulAttackCallback.EVENT.invoker().onSuccessfulAttack(player, target);
        }
    }
}
