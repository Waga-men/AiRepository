package celestial.port.mixin;

import celestial.port.modules.utility.MinecraftOptimizer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.client.render.FrameGraphBuilder;
import net.minecraft.client.render.WorldRenderer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(WorldRenderer.class)
abstract class WorldRendererOptimizerMixin {
    @Inject(method = "renderParticles", at = @At("HEAD"), cancellable = true)
    private void celestial$skipParticles(FrameGraphBuilder graph, GpuBufferSlice fog, CallbackInfo ci) {
        if (MinecraftOptimizer.shouldSkipParticles()) {
            ci.cancel();
        }
    }
}
