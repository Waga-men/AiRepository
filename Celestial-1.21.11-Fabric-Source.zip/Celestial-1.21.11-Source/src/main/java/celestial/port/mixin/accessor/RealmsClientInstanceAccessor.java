package celestial.port.mixin.accessor;

import net.minecraft.client.realms.RealmsClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(RealmsClient.class)
public interface RealmsClientInstanceAccessor {
    @Accessor("instance")
    static RealmsClient celestial$getInstance() {
        throw new AssertionError();
    }

    @Mutable
    @Accessor("instance")
    static void celestial$setInstance(RealmsClient client) {
        throw new AssertionError();
    }
}
