package celestial.port.mixin.accessor;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(Entity.class)
public interface EntityCollisionInvoker {
    @Invoker("adjustMovementForCollisions")
    Vec3d celestial$invokeAdjustMovementForCollisions(Vec3d movement);
}
