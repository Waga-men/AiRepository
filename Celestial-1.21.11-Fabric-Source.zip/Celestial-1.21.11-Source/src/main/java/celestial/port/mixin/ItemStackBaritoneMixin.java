package celestial.port.mixin;

import celestial.port.modules.legacyutility.BaritoneBridge;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ItemStack.class)
public abstract class ItemStackBaritoneMixin {
    @Inject(method = "postMine", at = @At("TAIL"))
    private void celestial$baritoneAutoRepair(
            World world,
            BlockState state,
            BlockPos pos,
            PlayerEntity player,
            CallbackInfo ci
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (!world.isClient() || player != client.player || client.getNetworkHandler() == null
                || !BaritoneBridge.shouldAutoRepair()) {
            return;
        }

        ItemStack stack = (ItemStack) (Object) this;
        if (stack.getDamage() + 3 == stack.getMaxDamage()) {
            client.getNetworkHandler().sendChatCommand("repair all");
        }
    }
}
