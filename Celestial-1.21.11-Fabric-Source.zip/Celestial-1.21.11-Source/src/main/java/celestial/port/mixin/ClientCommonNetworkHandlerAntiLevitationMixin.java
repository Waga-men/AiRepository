package celestial.port.mixin;

import celestial.port.modules.impl.AntiLevitation;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(ClientCommonNetworkHandler.class)
public abstract class ClientCommonNetworkHandlerAntiLevitationMixin {
    @ModifyVariable(method = "sendPacket", at = @At("HEAD"), argsOnly = true)
    private Packet<?> celestial$rewriteAntiLevitationPacket(Packet<?> packet) {
        return AntiLevitation.rewriteOutgoing(packet);
    }
}
