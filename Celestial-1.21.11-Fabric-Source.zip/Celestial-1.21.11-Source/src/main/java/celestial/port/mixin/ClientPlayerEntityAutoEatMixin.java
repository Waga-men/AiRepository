package celestial.port.mixin;

import celestial.port.modules.impl.AutoEat;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityAutoEatMixin {
    @Inject(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/network/AbstractClientPlayerEntity;tick()V"
            ),
            order = 1020
    )
    private void celestial$captureAutoEatBeforeVanillaUpdate(CallbackInfo ci) {
        AutoEat.captureBeforeVanillaPlayerTick((ClientPlayerEntity) (Object) this);
    }
}
