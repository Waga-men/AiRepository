package celestial.port.mixin;

import celestial.port.modules.impl.NoClip;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(Entity.class)
public abstract class EntityNoClipMixin {
    @Shadow
    private Vec3d adjustMovementForCollisions(Vec3d movement) {
        throw new AssertionError();
    }

    @Redirect(
            method = "move",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/Entity;adjustMovementForCollisions(Lnet/minecraft/util/math/Vec3d;)Lnet/minecraft/util/math/Vec3d;"
            )
    )
    private Vec3d celestial$noClipCollision(Entity entity, Vec3d requested) {
        Vec3d collided = adjustMovementForCollisions(requested);
        if (entity instanceof ClientPlayerEntity player) {
            return NoClip.adjustCollision(player, requested, collided);
        }
        return collided;
    }
}
