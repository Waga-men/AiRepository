package celestial.port.mixin;

import celestial.port.modules.visual.ChunkAnimator;
import net.minecraft.client.render.chunk.ChunkBuilder;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChunkBuilder.BuiltChunk.class)
public abstract class BuiltChunkMixin {
    @Inject(method = "setSectionPos(J)V", at = @At("TAIL"), require = 1, allow = 1)
    private void celestial$registerAnimation(long sectionPos, CallbackInfo ci) {
        ChunkAnimator.onBuiltChunk((ChunkBuilder.BuiltChunk) (Object) this);
    }
}
