package celestial.port.mixin;

import celestial.port.modules.player.NameProtectModule;
import net.minecraft.text.OrderedText;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(targets = "net.minecraft.client.gui.hud.ChatHud$Interactable")
public abstract class ChatHudMixin {
    @ModifyVariable(
            method = "text(IFLnet/minecraft/text/OrderedText;)Z",
            at = @At("HEAD"), argsOnly = true, ordinal = 0)
    private OrderedText celestial$protectChatText(OrderedText text) {
        return NameProtectModule.protect(text);
    }
}
