package celestial.port.mixin;

import celestial.port.modules.combat.NoFriendsModule;
import celestial.port.modules.combat.SuperBowModule;
import celestial.port.modules.player.ItemsCooldownModule;
import celestial.port.modules.player.FreeCameraModule;
import celestial.port.modules.player.InventoryMove;
import celestial.port.modules.impl.AutoSprint;
import celestial.port.modules.rendering.RotationView;
import celestial.port.modules.utility.ElytraFix;
import net.minecraft.client.network.ClientCommonNetworkHandler;
import net.minecraft.network.packet.Packet;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientCommonNetworkHandler.class)
public abstract class ClientCommonNetworkHandlerMixin {
    @Inject(method = "sendPacket", at = @At("HEAD"), cancellable = true)
    private void celestial$captureServerRotation(Packet<?> packet, CallbackInfo ci) {
        if (FreeCameraModule.shouldCancelOutgoing(packet)) {
            ci.cancel();
            return;
        }
        RotationView.onOutgoingPacket(packet);
        SuperBowModule.onOutgoingPacket(packet);
        InventoryMove.onOutgoingPacket(packet);
        boolean cancelled = ItemsCooldownModule.onOutgoingPacket(packet);
        cancelled |= ElytraFix.shouldCancelOutgoing(packet);
        cancelled |= NoFriendsModule.shouldCancelOutgoing(packet);
        cancelled |= AutoSprint.shouldCancelOutgoing(packet);
        if (cancelled) {
            ci.cancel();
        }
    }

}
