package celestial.port.mixin;

import celestial.port.modules.visual.BlurVisuals;
import com.mojang.blaze3d.systems.RenderPass;
import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.gl.PostEffectProcessor;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(PostEffectPass.class)
public abstract class PostEffectPassMixin {
    @Shadow @Final private Identifier outputTargetId;

    @Redirect(
            method = "method_67884",
            at = @At(
                    value = "INVOKE",
                    target = "Lcom/mojang/blaze3d/systems/RenderPass;draw(II)V"
            )
    )
    private void celestial$limitHudBlur(RenderPass pass, int firstVertex, int vertexCount) {
        BlurVisuals.FramebufferScissor scissor = BlurVisuals.activeScissor();
        if (scissor == null || !PostEffectProcessor.MAIN.equals(outputTargetId)) {
            pass.draw(firstVertex, vertexCount);
            return;
        }

        try {
            celestial$drawMasked(pass, firstVertex, vertexCount, scissor);
        } finally {
            pass.disableScissor();
        }
    }

    private static void celestial$drawMasked(
            RenderPass pass, int firstVertex, int vertexCount,
            BlurVisuals.FramebufferScissor scissor
    ) {
        BlurVisuals.RoundedStencil stencil = scissor.roundedStencil();
        if (stencil == null) {
            celestial$drawScissored(pass, firstVertex, vertexCount,
                    scissor.x(), scissor.y(), scissor.width(), scissor.height());
            return;
        }

        int row = 0;
        while (row < scissor.height()) {
            Span span = celestial$roundedSpan(scissor, stencil, row);
            int stripStart = row++;
            while (row < scissor.height()
                    && span.equals(celestial$roundedSpan(scissor, stencil, row))) {
                row++;
            }

            int stripHeight = row - stripStart;
            if (span.width() > 0) {
                celestial$drawScissored(pass, firstVertex, vertexCount,
                        span.x(), scissor.y() + stripStart,
                        span.width(), stripHeight);
            }
        }
    }

    private static Span celestial$roundedSpan(
            BlurVisuals.FramebufferScissor scissor,
            BlurVisuals.RoundedStencil stencil, int row
    ) {
        int first = 0;
        int pixelY = scissor.y() + row;
        while (first < scissor.width()
                && !stencil.containsPixel(scissor.x() + first, pixelY)) {
            first++;
        }
        if (first >= scissor.width()) return new Span(scissor.x(), 0);

        int last = scissor.width() - 1;
        while (last > first
                && !stencil.containsPixel(scissor.x() + last, pixelY)) {
            last--;
        }
        return new Span(scissor.x() + first, last - first + 1);
    }

    private static void celestial$drawScissored(
            RenderPass pass, int firstVertex, int vertexCount,
            int x, int y, int width, int height
    ) {
        pass.enableScissor(x, y, width, height);
        pass.draw(firstVertex, vertexCount);
    }

    private record Span(int x, int width) {
    }
}
