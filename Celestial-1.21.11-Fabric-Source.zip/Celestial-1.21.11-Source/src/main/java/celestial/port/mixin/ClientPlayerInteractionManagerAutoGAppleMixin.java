package celestial.port.mixin;

import celestial.port.modules.combat.AutoGAppleModule;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerInteractionManager;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientPlayerInteractionManager.class)
public abstract class ClientPlayerInteractionManagerAutoGAppleMixin {
    @Inject(method = "interactBlock", at = @At("HEAD"), cancellable = true)
    private void celestial$passAutoGAppleBlockUse(ClientPlayerEntity player,
                                                   Hand hand,
                                                   BlockHitResult hitResult,
                                                   CallbackInfoReturnable<ActionResult> cir) {
        if (AutoGAppleModule.ownsBlockInteraction(player)) {
            cir.setReturnValue(ActionResult.PASS);
        }
    }
}
