package celestial.port.mixin;

import celestial.port.modules.combat.AutoGAppleModule;
import net.minecraft.client.MinecraftClient;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientAutoGAppleMixin {
    @Shadow
    private void handleInputEvents() {
    }

    @Inject(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/gui/screen/Screen;tick()V",
                    shift = At.Shift.AFTER
            )
    )
    private void celestial$allowAutoGAppleInputThroughScreen(CallbackInfo ci) {
        MinecraftClient client = (MinecraftClient) (Object) this;
        if (client.currentScreen != null
                && client.getOverlay() == null
                && AutoGAppleModule.allowsScreenInput(client.currentScreen)) {
            handleInputEvents();
        }
    }
}
