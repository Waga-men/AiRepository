package celestial.port.mixin;

import celestial.port.modules.visual.ShaderESP;
import com.mojang.blaze3d.buffers.GpuBuffer;
import com.mojang.blaze3d.buffers.GpuBufferSlice;
import net.minecraft.client.gl.Framebuffer;
import net.minecraft.client.gl.PostEffectPass;
import net.minecraft.client.render.FrameGraphBuilder;
import net.minecraft.client.util.Handle;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.Map;

@Mixin(PostEffectPass.class)
abstract class PostEffectPassShaderEspMixin {
    @Shadow
    @Final
    private Map<String, GpuBuffer> uniformBuffers;

    @Inject(method = "render", at = @At("HEAD"))
    private void celestial$configureShaderEsp(
            FrameGraphBuilder frameGraph,
            Map<Identifier, Handle<Framebuffer>> framebuffers,
            GpuBufferSlice projectionMatrix,
            CallbackInfo ci
    ) {
        ShaderESP.configureUniforms(uniformBuffers);
    }
}
