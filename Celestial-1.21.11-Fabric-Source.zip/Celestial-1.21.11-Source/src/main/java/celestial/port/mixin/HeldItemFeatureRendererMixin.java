package celestial.port.mixin;

import celestial.port.modules.visual.CustomModel;
import net.minecraft.client.render.command.OrderedRenderCommandQueue;
import net.minecraft.client.render.entity.feature.HeldItemFeatureRenderer;
import net.minecraft.client.render.entity.state.ArmedEntityRenderState;
import net.minecraft.client.render.entity.state.PlayerEntityRenderState;
import net.minecraft.client.render.item.ItemRenderState;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.item.ItemStack;
import net.minecraft.util.Arm;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;

@Mixin(HeldItemFeatureRenderer.class)
public abstract class HeldItemFeatureRendererMixin {
    @ModifyArgs(
            method = "renderItem(Lnet/minecraft/client/render/entity/state/ArmedEntityRenderState;Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/util/Arm;Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/command/OrderedRenderCommandQueue;I)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/util/math/MatrixStack;translate(FFF)V"
            )
    )
    private void celestial$positionFinnHeldItem(Args args,
                                                ArmedEntityRenderState state,
                                                ItemRenderState itemState,
                                                ItemStack stack,
                                                Arm arm,
                                                MatrixStack matrices,
                                                OrderedRenderCommandQueue queue,
                                                int light) {
        if (state instanceof PlayerEntityRenderState playerState && CustomModel.isFinn(playerState)) {
            args.set(0, 0.0F);
            args.set(1, 0.125F);
            args.set(2, state.sneaking ? -0.4F : -0.525F);
        }
    }
}
