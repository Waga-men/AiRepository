package celestial.port.mixin;

import net.minecraft.client.util.Window;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

@Mixin(Window.class)
public abstract class WindowTitleMixin {
    private static final String CELESTIAL_LEGACY_TITLE = "Celestial Recode";

    @ModifyArg(
        method = "<init>",
        at = @At(
            value = "INVOKE",
            target = "Lorg/lwjgl/glfw/GLFW;glfwCreateWindow(IILjava/lang/CharSequence;JJ)J",
            remap = false
        ),
        index = 2
    )
    private CharSequence celestial$useLegacyTitleAtCreation(CharSequence title) {
        return CELESTIAL_LEGACY_TITLE;
    }

    @ModifyVariable(method = "setTitle", at = @At("HEAD"), argsOnly = true)
    private String celestial$keepLegacyTitle(String title) {
        return CELESTIAL_LEGACY_TITLE;
    }
}
