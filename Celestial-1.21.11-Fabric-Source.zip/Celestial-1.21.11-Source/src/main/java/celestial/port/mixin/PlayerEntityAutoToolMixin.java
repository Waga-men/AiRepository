package celestial.port.mixin;

import celestial.port.modules.inventory.AutoTool;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(PlayerEntity.class)
public abstract class PlayerEntityAutoToolMixin {
    @Inject(method = "getBlockBreakingSpeed", at = @At("HEAD"), cancellable = true)
    private void celestial$useAutoToolBreakingSpeed(BlockState state,
                                                     CallbackInfoReturnable<Float> cir) {
        PlayerEntity player = (PlayerEntity) (Object) this;
        ItemStack effective = AutoTool.effectiveMiningStack(player);
        if (effective != null) {
            cir.setReturnValue(AutoTool.legacyMiningSpeed(player, effective, state));
        }
    }

    @Inject(method = "canHarvest", at = @At("HEAD"), cancellable = true)
    private void celestial$useAutoToolHarvestCheck(BlockState state,
                                                   CallbackInfoReturnable<Boolean> cir) {
        ItemStack effective = AutoTool.effectiveMiningStack((PlayerEntity) (Object) this);
        if (effective != null) {
            cir.setReturnValue(!state.isToolRequired()
                    || !effective.isEmpty() && effective.isSuitableFor(state));
        }
    }
}
