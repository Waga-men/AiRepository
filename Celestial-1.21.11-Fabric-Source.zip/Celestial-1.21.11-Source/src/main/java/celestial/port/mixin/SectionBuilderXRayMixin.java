package celestial.port.mixin;

import celestial.port.modules.visual.XRay;
import celestial.port.modules.utility.MinecraftOptimizer;
import net.minecraft.block.Blocks;
import net.minecraft.block.BlockState;
import net.minecraft.client.render.chunk.ChunkRendererRegion;
import net.minecraft.client.render.chunk.SectionBuilder;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(SectionBuilder.class)
public abstract class SectionBuilderXRayMixin {
    @Redirect(
            method = "build",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/render/chunk/ChunkRendererRegion;getBlockState(" +
                            "Lnet/minecraft/util/math/BlockPos;)Lnet/minecraft/block/BlockState;"
            )
    )
    private BlockState celestial$collectXRayBlock(ChunkRendererRegion region, BlockPos position) {
        BlockState state = region.getBlockState(position);
        XRay.onBlockTessellated(state, position);
        return MinecraftOptimizer.shouldCullBlock(state) ? Blocks.AIR.getDefaultState() : state;
    }
}
