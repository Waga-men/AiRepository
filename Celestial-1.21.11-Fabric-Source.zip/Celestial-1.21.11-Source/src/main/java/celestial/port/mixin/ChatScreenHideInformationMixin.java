package celestial.port.mixin;

import celestial.port.client.ui.LegacyClientState;
import celestial.port.client.ui.LegacyHudFont;
import celestial.port.mixin.accessor.TextFieldWidgetHideInformationAccessor;
import celestial.port.client.ui.LegacyMenuBackdropBlur;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ChatScreen.class)
public abstract class ChatScreenHideInformationMixin extends Screen {
    @Unique
    private static final String[] CELESTIAL$HIDDEN_PREFIXES = {
            "l", "reg", "login", "call", "tpa", "register", "warp"
    };

    @Shadow
    protected TextFieldWidget chatField;

    protected ChatScreenHideInformationMixin() {
        super(Text.empty());
    }

    @Inject(method = "init", at = @At("TAIL"))
    private void celestial$addHideInformationButton(CallbackInfo ci) {
        addDrawableChild(new LegacyButton(2, height - 30, 120, 15,
                celestial$buttonText(), button -> {
            LegacyClientState.setHideInformation(!LegacyClientState.hideInformation());
            button.setMessage(celestial$buttonText());
        }));
    }

    @Inject(method = "render", at = @At("TAIL"))
    private void celestial$blurPrivateChatInput(
            DrawContext context, int mouseX, int mouseY, float deltaTicks, CallbackInfo ci
    ) {
        LegacyMenuBackdropBlur.clearLegacyChatBlur(this);
        if (!LegacyClientState.hideInformation() || chatField == null) return;

        TextFieldWidgetHideInformationAccessor accessor =
                (TextFieldWidgetHideInformationAccessor) chatField;
        String text = chatField.getText();
        int first = Math.max(0, Math.min(accessor.celestial$getFirstCharacterIndex(), text.length()));
        TextRenderer renderer = accessor.celestial$getTextRenderer();
        String visible = renderer.trimToWidth(text.substring(first), chatField.getInnerWidth());
        String lower = visible.toLowerCase();

        boolean hidden = false;
        for (String prefix : CELESTIAL$HIDDEN_PREFIXES) {
            if (lower.startsWith("/" + prefix)) {
                hidden = true;
                break;
            }
        }
        if (!hidden) return;

        float left = accessor.celestial$getTextX() - 2.0F;
        float top = accessor.celestial$getTextY() - 2.0F;
        LegacyMenuBackdropBlur.queueLegacyChatBlur(this, context,
                left, top, left + renderer.getWidth(visible) + 10.0F, top + 12.0F);
    }

    @Unique
    private static Text celestial$buttonText() {
        return Text.literal("Hide Information: " + LegacyClientState.hideInformation());
    }

    private static final class LegacyButton extends ButtonWidget {
        private static final net.minecraft.text.StyleSpriteSource FONT =
                LegacyHudFont.font(16);

        private LegacyButton(
                int x, int y, int width, int height,
                net.minecraft.text.Text message, PressAction action
        ) {
            super(x, y, width, height, message, action,
                    DEFAULT_NARRATION_SUPPLIER);
        }

        @Override
        protected void drawIcon(
                DrawContext context, int mouseX, int mouseY, float deltaTicks
        ) {
            context.fill(getX(), getY(), getX() + getWidth(), getY() + getHeight(),
                    active ? 0x7D0F0F0F : 0x7D050505);
            int color = !active ? 0xFFA0A0A0
                    : isHovered() ? 0xFFFFFFA0 : 0xFFE0E0E0;
            TextRenderer renderer = MinecraftClient.getInstance().textRenderer;
            LegacyHudFont.drawCentered(context, renderer, getMessage().getString(),
                    getX() + getWidth() * 0.5f,
                    getY() + (getHeight() - 5) * 0.5f,
                    color, FONT, true);
        }
    }
}
