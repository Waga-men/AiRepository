package celestial.port.mixin;

import celestial.port.modules.movement.TimerModule;
import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityTimerMixin {
    @Inject(method = "sendMovementPackets", at = @At("HEAD"))
    private void celestial$sampleSmartTimerMovement(CallbackInfo ci) {
        TimerModule.sampleMovement((ClientPlayerEntity) (Object) this);
    }
}
