package celestial.port.mixin;

import celestial.port.modules.utility.FastWorld;
import net.minecraft.client.MinecraftClient;
import net.minecraft.server.integrated.IntegratedServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(MinecraftClient.class)
public abstract class MinecraftClientFastWorldMixin {
    @Redirect(
            method = "cleanUpAfterCrash",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/client/MinecraftClient;disconnectWithSavingScreen()V"
            )
    )
    private void celestial$fastWorldKeepWorldAttached(MinecraftClient client) {
        if (!FastWorld.skipsCrashWorldUnload()) {
            client.disconnectWithSavingScreen();
        }
    }

    @Redirect(
            method = "cleanUpAfterCrash",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/server/integrated/IntegratedServer;stop(Z)V"
            ),
            require = 1,
            allow = 1
    )
    private void celestial$fastWorldKeepIntegratedServerRunning(IntegratedServer server, boolean waitForShutdown) {
        if (!FastWorld.skipsCrashWorldUnload()) {
            server.stop(waitForShutdown);
        }
    }
}
