package celestial.port.mixin;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import celestial.port.modules.combat.HitBoxModule;
import net.minecraft.client.render.debug.EntityHitboxDebugRenderer;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;

@Mixin(EntityHitboxDebugRenderer.class)
public abstract class EntityHitboxDebugRendererHitBoxMixin {
    @ModifyExpressionValue(
            method = "drawHitbox(Lnet/minecraft/entity/Entity;FZ)V",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/Entity;getBoundingBox()Lnet/minecraft/util/math/Box;",
                    ordinal = 0
            ),
            require = 1,
            allow = 1
    )
    private Box celestial$expandDisplayedHitbox(Box original, @Local(argsOnly = true) Entity entity) {
        return original.expand(HitBoxModule.targetingMargin(entity));
    }
}
