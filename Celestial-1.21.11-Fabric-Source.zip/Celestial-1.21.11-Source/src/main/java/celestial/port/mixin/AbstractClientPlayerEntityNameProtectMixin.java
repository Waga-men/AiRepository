package celestial.port.mixin;

import celestial.port.modules.player.NameProtectModule;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.entity.player.SkinTextures;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityNameProtectMixin {
    @Inject(method = "getSkin", at = @At("HEAD"), cancellable = true)
    private void celestial$useDefaultStreamerSkin(CallbackInfoReturnable<SkinTextures> cir) {
        if (NameProtectModule.streamerModeActive()) {
            AbstractClientPlayerEntity player = (AbstractClientPlayerEntity) (Object) this;
            cir.setReturnValue(DefaultSkinHelper.getSkinTextures(player.getGameProfile()));
        }
    }
}
