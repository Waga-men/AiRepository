package celestial.port.mixin;

import celestial.port.modules.movement.ElytraFlight;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.projectile.FireworkRocketEntity;
import net.minecraft.util.math.Vec3d;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(FireworkRocketEntity.class)
public abstract class FireworkRocketEntityElytraFlightMixin {
    @Redirect(
            method = "tick",
            at = @At(
                    value = "INVOKE",
                    target = "Lnet/minecraft/entity/LivingEntity;setVelocity(Lnet/minecraft/util/math/Vec3d;)V"
            )
    )
    private void celestial$suppressElytraFlightBoost(LivingEntity shooter, Vec3d velocity) {
        if (!ElytraFlight.shouldSuppressFireworkBoost(shooter)) {
            shooter.setVelocity(velocity);
        }
    }
}
