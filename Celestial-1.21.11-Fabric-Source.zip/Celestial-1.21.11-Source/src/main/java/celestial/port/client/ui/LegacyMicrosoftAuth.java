package celestial.port.client.ui;

import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import net.raphimc.minecraftauth.MinecraftAuth;
import net.raphimc.minecraftauth.java.JavaAuthManager;
import net.raphimc.minecraftauth.java.model.MinecraftProfile;
import net.raphimc.minecraftauth.java.model.MinecraftToken;
import net.raphimc.minecraftauth.msa.service.impl.DeviceCodeMsaAuthService;

import java.net.URI;
import java.util.Objects;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicBoolean;

final class LegacyMicrosoftAuth {
    private static final ExecutorService EXECUTOR = Executors.newSingleThreadExecutor(task -> {
        Thread thread = new Thread(task, "Celestial Microsoft authentication");
        thread.setDaemon(true);
        return thread;
    });

    private LegacyMicrosoftAuth() {
    }

    static Operation deviceCode(Callback callback) {
        Objects.requireNonNull(callback, "callback");
        Operation operation = new Operation();
        operation.attach(EXECUTOR.submit(() -> {
            try {
                JavaAuthManager manager = JavaAuthManager.create(MinecraftAuth.createHttpClient())
                        .login((httpClient, config) -> new DeviceCodeMsaAuthService(
                                httpClient, config, code -> {
                            if (operation.cancelled()) return;
                            URI verificationUri = URI.create(code.getVerificationUri());
                            URI directUri = URI.create(code.getDirectVerificationUri());
                            callback.onDeviceCode(new DevicePrompt(
                                    verificationUri, directUri, code.getUserCode()));
                        }));
                complete(operation, callback, manager);
            } catch (InterruptedException interrupted) {
                Thread.currentThread().interrupt();
                if (!operation.cancelled()) callback.onFailure();
            } catch (Exception | LinkageError ignored) {
                if (!operation.cancelled()) callback.onFailure();
            }
        }));
        return operation;
    }

    static Operation restore(String encryptedState, Callback callback) {
        Objects.requireNonNull(encryptedState, "encryptedState");
        Objects.requireNonNull(callback, "callback");
        Operation operation = new Operation();
        operation.attach(EXECUTOR.submit(() -> {
            try {
                JsonElement parsed = JsonParser.parseString(encryptedState);
                if (!parsed.isJsonObject()) throw new IllegalArgumentException("Invalid account state");
                JavaAuthManager manager = JavaAuthManager.fromJson(
                        MinecraftAuth.createHttpClient(), parsed.getAsJsonObject());
                complete(operation, callback, manager);
            } catch (Exception | LinkageError ignored) {
                if (!operation.cancelled()) callback.onFailure();
            }
        }));
        return operation;
    }

    private static void complete(
            Operation operation, Callback callback, JavaAuthManager manager
    ) throws Exception {
        MinecraftProfile profile = manager.getMinecraftProfile().getUpToDate();
        MinecraftToken token = manager.getMinecraftToken().getUpToDate();
        if (profile == null || token == null || profile.getId() == null
                || profile.getName() == null || profile.getName().isBlank()
                || token.getToken() == null || token.getToken().isBlank()) {
            throw new IllegalStateException("Incomplete Microsoft account");
        }
        String persistedState = JavaAuthManager.toJson(manager).toString();
        if (!operation.cancelled()) {
            callback.onSuccess(new Result(
                    profile.getName(), profile.getId(), token.getToken(), persistedState));
        }
    }

    interface Callback {
        void onDeviceCode(DevicePrompt prompt);

        void onSuccess(Result result);

        void onFailure();
    }

    record DevicePrompt(URI verificationUri, URI directVerificationUri, String userCode) {
        DevicePrompt {
            Objects.requireNonNull(verificationUri, "verificationUri");
            Objects.requireNonNull(directVerificationUri, "directVerificationUri");
            Objects.requireNonNull(userCode, "userCode");
        }
    }

    record Result(String profileName, UUID profileUuid, String accessToken, String persistedState) {
        Result {
            Objects.requireNonNull(profileName, "profileName");
            Objects.requireNonNull(profileUuid, "profileUuid");
            Objects.requireNonNull(accessToken, "accessToken");
            Objects.requireNonNull(persistedState, "persistedState");
        }

        @Override
        public String toString() {
            return "Result[profileName=" + profileName
                    + ", profileUuid=" + profileUuid + ", credentials=<redacted>]";
        }
    }

    static final class Operation {
        private final AtomicBoolean cancelled = new AtomicBoolean();
        private Future<?> task;

        private synchronized void attach(Future<?> task) {
            this.task = task;
            if (cancelled.get()) task.cancel(true);
        }

        synchronized void cancel() {
            cancelled.set(true);
            if (task != null) task.cancel(true);
        }

        boolean cancelled() {
            return cancelled.get();
        }
    }
}
