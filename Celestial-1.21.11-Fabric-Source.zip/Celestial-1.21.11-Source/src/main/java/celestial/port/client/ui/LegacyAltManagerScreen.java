package celestial.port.client.ui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.ConnectScreen;
import net.minecraft.client.network.CookieStorage;
import net.minecraft.client.network.ServerAddress;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

public final class LegacyAltManagerScreen extends Screen {
    private static final long ACCOUNT_DOUBLE_CLICK_WINDOW_MS = 300L;

    private static final String[] NAME_START = {
            "Le", "Fer", "Ale", "Je", "Lo", "Wel", "Ro", "Di", "An", "Mor", "Jag",
            "Mer", "Jar", "Leo", "Gui", "Fi", "Thi", "Cris", "Fa", "Ri", "Au", "Rei",
            "Ant", "Mu", "Jo", "Ema", "Lu", "Ri", "Thi", "Ti", "And", "Edi", "Ric",
            "Tra", "Re", "Pan", "Al", "Be", "Cal", "Clo", "Ar", "Je", "Sa", "Hen", "Lu"
    };
    private static final String[] NAME_MIDDLE = {
            "an", "na", "xan", "i", "dri", "ri", "lher", "ling", "red", "li", "a",
            "lori", "cres", "mur", "on", "ba", "vu", "ve", "car", "gus", "bi", "nu",
            "nar", "la", ""
    };
    private static final String[] NAME_END = {
            "dro", "do", "dre", "son", "val", "er", "der", "me", "ton", "o", "pe",
            "to", "go", "el", "et", "ut", "sy", "io", "rt", "nho", "son", "nt",
            "go", "lho", "nal", "ca", "de", "na", "ne", "la", ""
    };

    private final Screen parent;
    private final LegacyAltStore store = LegacyAltStore.instance();
    private final Random random = new Random();
    private final Map<Tool, Float> buttonHover = new EnumMap<>(Tool.class);
    private final Map<LegacyAltStore.AltAccount, Float> rowFade = new HashMap<>();
    private final Map<LegacyAltStore.AltAccount, Long> headStarted = new HashMap<>();

    private LegacyAltStore.AltAccount selected;
    private LegacyAltStore.AltAccount accountClickCandidate;
    private int accountClickCount;
    private long accountClickDeadlineMs;
    private String status = "";
    private float targetScroll;
    private float scroll;
    private boolean draggingPanel;
    private double panelDragX;
    private double panelDragY;
    private int panelX;
    private int panelY;
    private LegacyMicrosoftAuth.Operation authOperation;
    private long authGeneration;

    public LegacyAltManagerScreen(Screen parent) {
        super(Text.literal("Alt Manager"));
        this.parent = parent;
        this.panelX = store.panelX();
        this.panelY = store.panelY();
        for (Tool tool : Tool.values()) buttonHover.put(tool, 0.0f);
    }

    @Override
    protected void init() {
        clampPanel();
    }

    @Override
    public void renderBackground(
            DrawContext context, int mouseX, int mouseY, float deltaTicks
    ) {
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        List<LegacyAltStore.AltAccount> accounts = store.accounts();
        int maximum = Math.max(0, accounts.size() * 45 - 40);
        targetScroll = Math.max(-maximum, Math.min(0, targetScroll));
        scroll += (targetScroll - scroll)
                * (1.0f - (float) Math.exp(-Math.max(0.0f, deltaTicks) * 0.5f));
        if (Math.abs(targetScroll - scroll) < 0.01f) scroll = targetScroll;

        clampPanel();
        int panelHeight = 85 + store.servers().size() * 11;
        List<ToolbarButton> toolbar = toolbarButtons(accounts);
        LegacyMenuRender.wallpaper(context, width, height);
        boolean shaders = LegacyMainMenuScreen.shadersEnabled();
        if (shaders) {
            LegacyAltManagerBackdropBlur.apply(
                    context, width, height, toolbar.stream()
                            .map(ToolbarButton::blurRegion)
                            .toList(), accounts.size(), (int) scroll,
                    panelX, panelY, panelHeight);
        } else {
            LegacyMenuRender.rounded(context, 0, 0, width, 40, 0, 0x7D0F0F0F);
        }

        context.enableScissor(0, 41, width, height);
        for (int index = 0; index < accounts.size(); index++) {
            LegacyAltStore.AltAccount account = accounts.get(index);
            int entryY = 50 + index * 45 + (int) scroll;
            if (entryY + 32 < 41 || entryY > height) continue;
            float fade = LegacyMenuRender.approach(
                    rowFade.getOrDefault(account, 0.0f), true, deltaTicks, 4.0f);
            rowFade.put(account, fade);
            int targetEntryY = 50 + index * 45 + (int) targetScroll;
            renderAccount(context, account, entryY, targetEntryY,
                    mouseX, mouseY, fade, shaders);
        }
        context.disableScissor();

        renderInfoPanel(context, mouseX, mouseY, shaders, panelHeight);
        renderToolbar(context, mouseX, mouseY, deltaTicks, toolbar, shaders);
        renderStatus(context);
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    private void renderStatus(DrawContext context) {
        float x = width - LegacyMenuRender.width(textRenderer, status,
                LegacyMenuRender.FONT_DX) - 2;
        if (status.startsWith("Logged as ")) {
            String label = "Logged as ";
            drawLegacyText(context, label, x, height - 10,
                    0xFF55FF55, LegacyMenuRender.FONT_DX);
            drawLegacyText(context, status.substring(label.length()),
                    x + LegacyMenuRender.width(textRenderer, label, LegacyMenuRender.FONT_DX),
                    height - 10, 0xFFFFFFFF, LegacyMenuRender.FONT_DX);
        } else {
            drawLegacyText(context, status, x, height - 10,
                    status.isEmpty() ? 0xFFFFFFFF : 0xFFFF5555,
                    LegacyMenuRender.FONT_DX);
        }
    }

    private void renderAccount(
            DrawContext context, LegacyAltStore.AltAccount account,
            int entryY, int targetEntryY, int mouseX, int mouseY,
            float fade, boolean shaders
    ) {
        if (shaders) {
            LegacyAltManagerBackdropBlur.externalShadow(
                    context, 15, entryY, 200, 32, 10);
        } else {
            LegacyMenuRender.rounded(context, 15, entryY, 200, 32,
                    0, 0x7D0F0F0F);
        }
        int alpha = (int) (fade * 255.0f);
        int tint = LegacyMenuRender.withAlpha(0xFFFFFFFF, alpha);
        long started = headStarted.computeIfAbsent(
                account, ignored -> System.currentTimeMillis());
        String skinName = account.profileName() == null || account.profileName().isBlank()
                ? account.username() : account.profileName();
        Identifier head = client == null ? null : LegacyAltHeadCache.request(client, skinName);
        if (System.currentTimeMillis() - started < 1500L || head == null) {
            LegacyMenuRender.texture(context, LegacyMenuRender.ATOM,
                    17, entryY + 1, 29, 29, tint);
        } else {
            LegacyMenuRender.texture(context, head,
                    17, entryY + 1, 29, 29, tint);
        }
        boolean nameHovered = !draggingPanel && LegacyMenuRender.inside(mouseX, mouseY,
                50, entryY + 5, 165, 20);
        boolean dateHovered = !draggingPanel && LegacyMenuRender.inside(mouseX, mouseY,
                50, targetEntryY + 5, 165, 20);
        int nameColor = nameHovered || selected == account
                ? LegacyMenuRender.withAlpha(0xFFC87DFF, alpha)
                : LegacyMenuRender.withAlpha(0xFFFFFFFF, alpha);
        int dateColor = dateHovered || selected == account
                ? LegacyMenuRender.withAlpha(0xFFC87DFF, alpha)
                : LegacyMenuRender.withAlpha(0xFFFFFFFF, alpha);
        String shownName = account.profileName() == null || account.profileName().isBlank()
                ? account.username() : account.profileName();
        drawLegacyText(context, shownName,
                50, entryY + 5, nameColor, LegacyMenuRender.FONT_DZ);
        drawLegacyText(context, account.addedText(),
                50, entryY + 20, dateColor, LegacyMenuRender.FONT_DS);
    }

    private void renderToolbar(
            DrawContext context, int mouseX, int mouseY, float deltaTicks,
            List<ToolbarButton> toolbar, boolean shaders
    ) {
        for (ToolbarButton button : toolbar) {
            drawTool(context, button, mouseX, mouseY, deltaTicks, shaders);
        }
    }

    private void drawTool(
            DrawContext context, ToolbarButton button, int mouseX, int mouseY,
            float deltaTicks, boolean shaders
    ) {
        boolean hovered = button.enabled() && button.contains(mouseX, mouseY);
        float progress = LegacyMenuRender.approach(buttonHover.get(button.tool()),
                hovered, deltaTicks, 15.0f);
        buttonHover.put(button.tool(), progress);
        LegacyMenuRender.button(context, textRenderer,
                button.x(), button.y(), button.width(), button.height(),
                "", button.enabled(), hovered, progress, shaders);
        int color = !button.enabled()
                ? 0xFFA0A0A0 : hovered ? 0xFFFFFFA0 : 0xFFE0E0E0;
        float textX = button.x() + button.width() / 2.0f
                - LegacyMenuRender.width(textRenderer, button.label(),
                LegacyMenuRender.FONT_DV) / 2.0f;
        drawLegacyText(context, button.label(), textX, button.y() + 5,
                color, LegacyMenuRender.FONT_DV);
    }

    private List<ToolbarButton> toolbarButtons(
            List<LegacyAltStore.AltAccount> accounts
    ) {
        boolean canLoginOrDelete = selected != null;
        boolean canClear = accounts.stream().anyMatch(account -> account.type() != 1);
        if (width >= 590) {
            return List.of(
                    toolbarButton(Tool.ADD, 15, 10, 80, "Add alt", true),
                    toolbarButton(Tool.LOGIN, 105, 10, 80, "Login", canLoginOrDelete),
                    toolbarButton(Tool.RANDOM, 195, 10, 80, "Random name", true),
                    toolbarButton(Tool.CLEAR_RANDOM, 285, 10, 80,
                            "Clear random", canClear),
                    toolbarButton(Tool.ADD_SERVER, 375, 10, 110,
                            "Add server to QuickJoin", true),
                    toolbarButton(Tool.DELETE, width - 95, 10, 80,
                            "Delete", canLoginOrDelete)
            );
        }

        int margin = 5;
        int gap = 5;
        int available = Math.max(3, width - margin * 2 - gap * 2);
        int baseWidth = available / 3;
        int remainder = available % 3;
        int firstWidth = baseWidth + (remainder > 0 ? 1 : 0);
        int secondWidth = baseWidth + (remainder > 1 ? 1 : 0);
        int thirdWidth = baseWidth;
        int firstX = margin;
        int secondX = firstX + firstWidth + gap;
        int thirdX = secondX + secondWidth + gap;

        return List.of(
                toolbarButton(Tool.ADD, firstX, 3, firstWidth,
                        "Add alt", true),
                toolbarButton(Tool.LOGIN, secondX, 3, secondWidth,
                        "Login", canLoginOrDelete),
                toolbarButton(Tool.RANDOM, thirdX, 3, thirdWidth,
                        "Random name", true),
                toolbarButton(Tool.CLEAR_RANDOM, firstX, 22, firstWidth,
                        "Clear random", canClear),
                toolbarButton(Tool.ADD_SERVER, secondX, 22, secondWidth,
                        "Add server", true),
                toolbarButton(Tool.DELETE, thirdX, 22, thirdWidth,
                        "Delete", canLoginOrDelete)
        );
    }

    private static ToolbarButton toolbarButton(
            Tool tool, int x, int y, int width, String label, boolean enabled
    ) {
        return new ToolbarButton(tool, x, y, width, 15, label, enabled);
    }

    private void renderInfoPanel(
            DrawContext context, int mouseX, int mouseY, boolean shaders,
            int panelHeight
    ) {
        List<LegacyAltStore.QuickServer> servers = sortedServers();
        if (shaders) {
            LegacyAltManagerBackdropBlur.externalShadow(
                    context, panelX, panelY, 140, panelHeight, 10);
        } else {
            LegacyMenuRender.rounded(context, panelX, panelY, 140, panelHeight,
                    0, 0x7D1E1E1E);
        }
        String title = "Alts Info";
        drawLegacyText(context, title,
                panelX + 70.0f - LegacyMenuRender.width(textRenderer, title,
                        LegacyMenuRender.FONT_DA) / 2.0f,
                panelY + 10, 0xFFFFFFFF, LegacyMenuRender.FONT_DA);
        String current = "Current: " + (client == null ? "Player" : client.getSession().getUsername());
        drawLegacyText(context, current,
                panelX + 70.0f - LegacyMenuRender.width(textRenderer, current,
                        LegacyMenuRender.FONT_DX) / 2.0f,
                panelY + 30, 0xFFFFFFFF, LegacyMenuRender.FONT_DX);
        String count = "Alts count: " + store.accounts().size();
        drawLegacyText(context, count,
                panelX + 70.0f - LegacyMenuRender.width(textRenderer, count,
                        LegacyMenuRender.FONT_DX) / 2.0f,
                panelY + 41, 0xFFFFFFFF, LegacyMenuRender.FONT_DX);
        String quickJoin = "Quick Join";
        drawLegacyText(context, quickJoin,
                panelX + 70.0f - LegacyMenuRender.width(textRenderer, quickJoin,
                        LegacyMenuRender.FONT_DZ) / 2.0f,
                panelY + 65, 0xFFFFFFFF, LegacyMenuRender.FONT_DZ);
        for (int index = 0; index < servers.size(); index++) {
            LegacyAltStore.QuickServer server = servers.get(index);
            int serverY = panelY + 83 + index * 11;
            boolean hovered = LegacyMenuRender.inside(mouseX, mouseY,
                    panelX + 35, serverY, 70, 10);
            int color = hovered ? 0xFFC87DFF : 0xFFFFFFFF;
            drawLegacyText(context, server.name(),
                    panelX + 70.0f - LegacyMenuRender.width(textRenderer, server.name(),
                            LegacyMenuRender.FONT_DV) / 2.0f,
                    serverY, color, LegacyMenuRender.FONT_DV);
        }
    }

    private void drawLegacyText(
            DrawContext context, String value, float x, float y,
            int color, StyleSpriteSource font
    ) {
        int shadow = (color & 0x00FCFCFC) >> 2 | color & 0xC8141414;
        float textY = font == LegacyMenuRender.FONT_DA ? y + 4.0f
                : font == LegacyMenuRender.FONT_DZ ? y + 2.0f
                : font == LegacyMenuRender.FONT_DX ? y - 1.0f
                : font == LegacyMenuRender.FONT_DV ? y - 2.5f
                : y - 3.0f;
        float shadowY = textY + 0.5f;
        LegacyMenuRender.draw(context, textRenderer, value,
                x + 0.5f, shadowY, shadow, font);
        LegacyMenuRender.draw(context, textRenderer, value,
                x + 0.75f, shadowY, shadow, font);
        LegacyMenuRender.draw(context, textRenderer, value,
                x, textY, color, font);
        LegacyMenuRender.draw(context, textRenderer, value,
                x + 0.25f, textY, color, font);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mouseX = click.x();
        double mouseY = click.y();
        if (authOperation != null) return true;
        List<LegacyAltStore.AltAccount> accounts = store.accounts();
        for (int index = 0; index < accounts.size(); index++) {
            int entryY = 50 + index * 45 + (int) scroll;
            if (!LegacyMenuRender.inside(mouseX, mouseY, 50, entryY + 5, 165, 20)) continue;
            LegacyAltStore.AltAccount account = accounts.get(index);
            if (click.button() == 2) {
                store.remove(account);
                if (selected == account) selected = null;
                return true;
            }
            if (click.button() != 2) {
                if (registerAccountClick(account, Util.getMeasuringTimeMs())) {
                    login(account);
                    selected = null;
                }
                return true;
            }
        }

        List<LegacyAltStore.QuickServer> servers = sortedServers();
        for (int index = 0; index < servers.size(); index++) {
            int serverY = panelY + 83 + index * 11;
            if (!LegacyMenuRender.inside(mouseX, mouseY,
                    panelX + 35, serverY, 70, 10)) continue;
            LegacyAltStore.QuickServer server = servers.get(index);
            if (click.button() == 2) store.removeServer(server);
            else connect(server);
            return true;
        }

        if (click.button() == 0 && toolbarClick(mouseX, mouseY)) return true;
        if (click.button() == 0 && LegacyMenuRender.inside(mouseX, mouseY,
                panelX, panelY, 140, 140)) {
            draggingPanel = true;
            panelDragX = mouseX - panelX;
            panelDragY = mouseY - panelY;
            selected = null;
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    private boolean registerAccountClick(
            LegacyAltStore.AltAccount account, long nowMs
    ) {
        if (accountClickCount > 0 && nowMs > accountClickDeadlineMs) {
            resetAccountClickState();
        }

        accountClickCount++;
        selected = account;
        if (accountClickCount == 1) {
            accountClickCandidate = account;
            accountClickDeadlineMs = nowMs + ACCOUNT_DOUBLE_CLICK_WINDOW_MS;
            return false;
        }

        boolean matchingAccount = account == accountClickCandidate;
        resetAccountClickState();
        return matchingAccount;
    }

    private void resetAccountClickState() {
        accountClickCandidate = null;
        accountClickCount = 0;
        accountClickDeadlineMs = 0L;
    }

    private List<LegacyAltStore.QuickServer> sortedServers() {
        List<LegacyAltStore.QuickServer> servers = new ArrayList<>(store.servers());
        servers.sort(Comparator.comparingInt((LegacyAltStore.QuickServer server) ->
                LegacyMenuRender.width(textRenderer, server.name(), LegacyMenuRender.FONT_DX)).reversed());
        return servers;
    }

    private boolean toolbarClick(double mouseX, double mouseY) {
        ToolbarButton clicked = toolbarButtons(store.accounts()).stream()
                .filter(button -> button.contains(mouseX, mouseY))
                .findFirst()
                .orElse(null);
        if (clicked == null) return false;

        switch (clicked.tool()) {
            case ADD -> {
                if (client != null) LegacyMenuRender.playClick(client);
                selected = null;
                if (client != null) client.setScreen(new LegacyAddAltScreen(this));
            }
            case LOGIN -> {
                if (selected != null) {
                    if (client != null) LegacyMenuRender.playClick(client);
                    login(selected);
                }
                selected = null;
            }
            case RANDOM -> {
                if (client != null) LegacyMenuRender.playClick(client);
                String generated = randomName();
                LegacyAltStore.AltAccount account = store.addOffline(generated, false);
                login(account);
                selected = null;
            }
            case CLEAR_RANDOM -> {
                if (store.accounts().stream().anyMatch(account -> account.type() != 1)) {
                    if (client != null) LegacyMenuRender.playClick(client);
                    store.clearRandom();
                }
                selected = null;
            }
            case ADD_SERVER -> {
                if (client != null) LegacyMenuRender.playClick(client);
                selected = null;
                if (client != null) client.setScreen(new LegacyAddServerScreen(this));
            }
            case DELETE -> {
                if (selected != null) {
                    if (client != null) LegacyMenuRender.playClick(client);
                    store.remove(selected);
                    selected = null;
                }
            }
        }
        return true;
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        if (draggingPanel && click.button() == 0) {
            panelX = (int) Math.round(click.x() - panelDragX);
            panelY = (int) Math.round(click.y() - panelDragY);
            clampPanel();
            return true;
        }
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (draggingPanel && click.button() == 0) {
            draggingPanel = false;
            store.setPanelPosition(panelX, panelY);
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(
            double mouseX, double mouseY, double horizontalAmount, double verticalAmount
    ) {
        if (mouseX >= 0 && mouseX < 215 && mouseY >= 0 && mouseY < height) {
            targetScroll += (float) verticalAmount * 20.0f;
            int maximum = Math.max(0, store.accounts().size() * 45 - 40);
            targetScroll = Math.max(-maximum, Math.min(0, targetScroll));
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    private void login(LegacyAltStore.AltAccount account) {
        if (client == null || authOperation != null) return;
        if (!account.microsoft()) {
            status = LegacyOfflineSession.switchTo(client, account.username());
            return;
        }

        status = "Waiting logging...";
        long generation = ++authGeneration;
        LegacyMicrosoftAuth.Callback callback = new LegacyMicrosoftAuth.Callback() {
            @Override
            public void onDeviceCode(LegacyMicrosoftAuth.DevicePrompt prompt) {
                onClientThread(generation, () -> {
                    status = "Microsoft code copied: " + prompt.userCode();
                    if (client != null) {
                        try {
                            client.keyboard.setClipboard(prompt.userCode());
                            Util.getOperatingSystem().open(prompt.directVerificationUri());
                        } catch (RuntimeException | LinkageError ignored) {
                            status = "Microsoft code: " + prompt.userCode();
                        }
                    }
                });
            }

            @Override
            public void onSuccess(LegacyMicrosoftAuth.Result result) {
                onClientThread(generation, () -> finishMicrosoftLogin(account, result));
            }

            @Override
            public void onFailure() {
                onClientThread(generation, () -> {
                    authOperation = null;
                    status = "Login failed!";
                });
            }
        };

        java.util.Optional<String> credential = store.credentialState(account);
        authOperation = credential.isPresent()
                ? LegacyMicrosoftAuth.restore(credential.get(), callback)
                : LegacyMicrosoftAuth.deviceCode(callback);
    }

    private void finishMicrosoftLogin(
            LegacyAltStore.AltAccount account, LegacyMicrosoftAuth.Result result
    ) {
        authOperation = null;
        if (client == null) return;
        try {
            String loginStatus = LegacyOfflineSession.switchTo(client, result);
            status = loginStatus;
            if (loginStatus.startsWith("Logged as ")) {
                selected = store.updateMicrosoft(account, result);
            }
        } catch (RuntimeException | LinkageError ignored) {
            status = "Login failed!";
        }
    }

    private void onClientThread(long generation, Runnable action) {
        if (client == null) return;
        client.execute(() -> {
            if (generation != authGeneration || client.currentScreen != this) return;
            action.run();
        });
    }

    private void connect(LegacyAltStore.QuickServer server) {
        if (client == null) return;
        if (!ServerAddress.isValid(server.address())) {
            status = "Invalid server address: " + server.address();
            return;
        }
        ServerInfo info = new ServerInfo(server.name(), server.address(), ServerInfo.ServerType.OTHER);
        ConnectScreen.connect(this, client, ServerAddress.parse(server.address()), info,
                false, new CookieStorage(Map.of(), Map.of(), false));
    }

    private String randomName() {
        String start = NAME_START[random.nextInt(NAME_START.length)];
        if (System.currentTimeMillis() % 10L > 5L) start = start.toLowerCase();
        String generated = start
                + NAME_MIDDLE[random.nextInt(NAME_MIDDLE.length)]
                + NAME_END[random.nextInt(NAME_END.length)]
                + System.currentTimeMillis() % 2000L;
        return generated.length() <= 16 ? generated : generated.substring(0, 16);
    }

    private void clampPanel() {
        int maximumX = Math.max(220, width - 140);
        int maximumY = Math.max(50, height - 85 - store.servers().size() * 11);
        panelX = Math.max(220, Math.min(maximumX, panelX));
        panelY = Math.max(50, Math.min(maximumY, panelY));
    }

    @Override
    public void close() {
        cancelAuthentication();
        store.setPanelPosition(panelX, panelY);
        if (client != null) client.setScreen(parent);
    }

    @Override
    public void removed() {
        cancelAuthentication();
        store.setPanelPosition(panelX, panelY);
        super.removed();
    }

    private void cancelAuthentication() {
        authGeneration++;
        if (authOperation == null) return;
        authOperation.cancel();
        authOperation = null;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private enum Tool {
        ADD, LOGIN, RANDOM, CLEAR_RANDOM, ADD_SERVER, DELETE
    }

    private record ToolbarButton(
            Tool tool, int x, int y, int width, int height,
            String label, boolean enabled
    ) {
        private boolean contains(double mouseX, double mouseY) {
            return LegacyMenuRender.inside(
                    mouseX, mouseY, x, y, width, height);
        }

        private LegacyAltManagerBackdropBlur.Region blurRegion() {
            return new LegacyAltManagerBackdropBlur.Region(
                    x, y, width, height, 3.0f);
        }
    }
}
