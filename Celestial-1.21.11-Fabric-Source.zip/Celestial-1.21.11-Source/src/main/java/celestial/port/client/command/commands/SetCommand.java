package celestial.port.client.command.commands;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.client.command.LegacyModuleResolver;
import celestial.port.client.ui.ClientFeedback;
import celestial.port.core.Module;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.Setting;
import net.minecraft.text.Style;

public final class SetCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "set";
    }

    @Override
    public String description() {
        return "\u0421\u0442\u0430\u0432\u0438\u0442 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u0434\u043B\u044F "
                + "\u043E\u043F\u0440\u0435\u0434\u0435\u043B\u0435\u043D\u043D\u043E\u0439 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 \u0432 \u043C\u043E\u0434\u0443\u043B\u0435";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length == 0) {
            usage();
            return;
        }

        Module module = LegacyModuleResolver.module(arguments[0]).orElse(null);
        if (module == null || arguments.length < 3) {
            LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u043C\u043E\u0434\u0443\u043B\u044C "
                    + "\u0438\u043B\u0438 \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430!");
            return;
        }

        try {
            String settingName = arguments[1].replaceAll("_", " ");
            String value = arguments[2];
            Setting<?> rawSetting = LegacyModuleResolver.setting(module, settingName).orElse(null);
            if (rawSetting == null) {

                LegacyCommandFeedback.send("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438 "
                        + "\u0441 \u0438\u043C\u0435\u043D\u0435\u043C \u00A7c'" + value + "'");
                return;
            }
            BooleanSetting setting = (BooleanSetting) rawSetting;
            if (!value.equalsIgnoreCase("toggle")
                    && !value.equalsIgnoreCase("true")
                    && !value.equalsIgnoreCase("false")) {
                usage();
                return;
            }

            if (value.equalsIgnoreCase("toggle")) {
                setting.setEnabled(!setting.enabled());
                String message = "\u041D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430 '\u00A7c\u00A7l"
                        + settingName.trim() + "\u00A7r' \u0431\u044B\u043B\u0430 "
                        + (setting.enabled() ? "\u0432\u043A\u043B\u044E\u0447\u0435\u043D\u0430"
                        : "\u0432\u044B\u043A\u043B\u044E\u0447\u0435\u043D\u0430");
                LegacyCommandFeedback.send(message);
                ClientFeedback.info("Set Manager",
                        LegacyCommandFeedback.parse(message, Style.EMPTY), 5);
            } else {
                setting.setEnabled(Boolean.parseBoolean(value));
                LegacyCommandFeedback.send("\u0423\u0441\u0442\u0430\u043D\u043E\u0432\u043B\u0435\u043D\u043E \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u00A7c'"
                        + value + "'\u00A7r \u0434\u043B\u044F \u00A7c" + settingName.trim().toUpperCase());
            }
        } catch (ClassCastException exception) {
            LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0442\u0438\u043F \u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0438! "
                    + "\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435: true/false/toggle");
        }
    }

    private static void usage() {
        LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430! "
                + "\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435:");
        LegacyCommandFeedback.send("set \u00A7c\u043C\u043E\u0434\u0443\u043B\u044C \u00A77<\u043D\u0430\u0441\u0442\u0440\u043E\u0439\u043A\u0430> "
                + "<\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435>");
        LegacyCommandFeedback.send("\u041F\u0440\u0438\u043C\u0435\u0440: .set AttackAura "
                + "\u0442\u043E\u043B\u044C\u043A\u043E_\u043A\u0440\u0438\u0442\u044B false");
    }
}
