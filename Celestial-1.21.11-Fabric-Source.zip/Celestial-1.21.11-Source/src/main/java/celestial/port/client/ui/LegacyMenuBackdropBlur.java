package celestial.port.client.ui;

import celestial.port.modules.visual.BlurVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public final class LegacyMenuBackdropBlur {
    private static final Identifier POST_EFFECT =
            Identifier.of("celestial", "legacy_menu_blur");
    private static final int RADIUS = 3;
    private static PendingChatRegion pendingChatBlur;

    private LegacyMenuBackdropBlur() {
    }

    public static Identifier selectPostEffect(Identifier vanillaEffect) {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean legacyMenu = client.currentScreen instanceof LegacyMainMenuScreen;
        return legacyMenu
                && LegacyMainMenuScreen.shadersEnabled()
                ? POST_EFFECT : vanillaEffect;
    }

    public static boolean consumePendingAltRegions() {
        PendingChatRegion chatBlur = pendingChatBlur;
        pendingChatBlur = null;
        if (chatBlur != null
                && MinecraftClient.getInstance().currentScreen == chatBlur.owner()) {
            BlurVisuals.renderLegacyChatBlur(
                    chatBlur.left(), chatBlur.top(), chatBlur.right(), chatBlur.bottom());
            return true;
        }
        return LegacyAltManagerBackdropBlur.consumePendingPlan();
    }

    public static void queueLegacyChatBlur(
            Screen owner, DrawContext context,
            float left, float top, float right, float bottom
    ) {
        context.createNewRootLayer();
        context.applyBlur();

        context.fill(-2, -2, -1, -1, 0x00000000);
        pendingChatBlur = new PendingChatRegion(owner, left, top, right, bottom);
    }

    public static void clearLegacyChatBlur(Screen owner) {
        if (pendingChatBlur != null && pendingChatBlur.owner() == owner) {
            pendingChatBlur = null;
        }
    }

    static void apply(
            DrawContext context, int screenWidth, int screenHeight,
            int buttonX, int baseY
    ) {
        context.createNewRootLayer();

        context.applyBlur();

        List<Mask> masks = List.of(
                new Mask(buttonX, baseY, 200, 20),
                new Mask(buttonX, baseY + 24, 200, 20),
                new Mask(buttonX, baseY + 48, 200, 20),
                new Mask(buttonX, baseY + 72, 200, 20),
                new Mask(buttonX, baseY + 105, 98, 20),
                new Mask(buttonX + 102, baseY + 105, 98, 20)
        );
        redrawSharpWallpaperOutsideMasks(context, screenWidth, screenHeight, masks);
    }

    private static void redrawSharpWallpaperOutsideMasks(
            DrawContext context, int screenWidth, int screenHeight, List<Mask> masks
    ) {
        int y = 0;
        while (y < screenHeight) {
            List<Span> spans = sharpSpansAt(y, screenWidth, masks);
            int bandBottom = y + 1;
            while (bandBottom < screenHeight
                    && spans.equals(sharpSpansAt(bandBottom, screenWidth, masks))) {
                bandBottom++;
            }

            for (Span span : spans) {
                if (span.right <= span.left) continue;
                context.enableScissor(span.left, y, span.right, bandBottom);
                try {
                    LegacyMenuRender.wallpaper(context, screenWidth, screenHeight);
                } finally {
                    context.disableScissor();
                }
            }
            y = bandBottom;
        }
    }

    private static List<Span> sharpSpansAt(
            int y, int screenWidth, List<Mask> masks
    ) {
        List<Span> blurred = new ArrayList<>(2);
        for (Mask mask : masks) {
            Span span = mask.blurredSpanAt(y);
            if (span != null && span.right > 0 && span.left < screenWidth) {
                blurred.add(new Span(
                        Math.max(0, span.left), Math.min(screenWidth, span.right)));
            }
        }
        blurred.sort((first, second) -> Integer.compare(first.left, second.left));

        List<Span> sharp = new ArrayList<>(blurred.size() + 1);
        int cursor = 0;
        for (Span span : blurred) {
            if (span.left > cursor) sharp.add(new Span(cursor, span.left));
            cursor = Math.max(cursor, span.right);
        }
        if (cursor < screenWidth) sharp.add(new Span(cursor, screenWidth));
        return List.copyOf(sharp);
    }

    private record Mask(int x, int y, int width, int height) {
        private Span blurredSpanAt(int rowY) {
            int localY = rowY - y;
            if (localY < 0 || localY >= height) return null;

            int edgeRow = Math.min(localY, height - 1 - localY);
            int inset = 0;
            if (edgeRow < RADIUS) {
                double distance = RADIUS - edgeRow - 0.5;
                inset = (int) Math.ceil(RADIUS
                        - Math.sqrt(Math.max(0.0,
                        RADIUS * RADIUS - distance * distance)));
            }
            return new Span(x + inset, x + width - inset);
        }
    }

    private record PendingChatRegion(
            Screen owner, float left, float top, float right, float bottom
    ) {
    }

    private record Span(int left, int right) {
    }
}
