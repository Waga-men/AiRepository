package celestial.port.client.ui;

import celestial.port.modules.player.NameProtectModule;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.LivingEntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.client.render.entity.state.LivingEntityRenderState;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3x2f;
import org.lwjgl.glfw.GLFW;

import java.io.IOException;
import java.util.Locale;
import java.util.Map;
import java.util.function.IntUnaryOperator;

public final class LegacyTargetHud {
    private static final int WIDTH = 130;
    private static final int REPORTED_HEIGHT = 38;
    private static final int DRAWN_HEIGHT = 44;
    private static final int DEFAULT_X = 250;
    private static final int DEFAULT_Y = 150;
    private static final int TEXT_COLOR = 0xFFEBEBEB;
    private static final int INNER_BACKGROUND_RGB = 0x000A0A0A;

    private static final StyleSpriteSource FONT_DR = font(12);
    private static final StyleSpriteSource FONT_DS = font(13);
    private static final StyleSpriteSource FONT_DU = font(15);
    private static final StyleSpriteSource FONT_DX = font(18);
    private static final Identifier GRAB_TEXTURE = Identifier.of("celestial", "images/grab.png");

    private static final UiLayoutStore LAYOUT = new UiLayoutStore(
            FabricLoader.getInstance().getConfigDir().resolve("celestial"));

    private static final BackAnimation SCALE = new BackAnimation(0.25);

    private static final BackAnimation VISIBILITY = new BackAnimation(0.035);

    private static final RetargetAnimation CIRCLE_HEALTH = new RetargetAnimation(0.3);

    private static double barHealth;
    private static double healthPercent;
    private static LivingEntity retainedTarget;
    private static long previousFrameTime;

    private static int x = DEFAULT_X;
    private static int y = DEFAULT_Y;
    private static boolean layoutLoaded;
    private static boolean dragging;
    private static boolean lastLeftDown;
    private static double dragOffsetX;
    private static double dragOffsetY;

    private LegacyTargetHud() {
    }

    public static void render(
            DrawContext context,
            boolean targetHudEnabled,
            LivingEntity activeTarget,
            boolean typeOne,
            IntUnaryOperator colorAt,
            float tickProgress
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        ensureLayoutLoaded();
        boolean editor = client.currentScreen instanceof ChatScreen;
        updateDrag(client, context, editor && targetHudEnabled);

        if (!targetHudEnabled || client.player == null) {
            resetAnimation();
            return;
        }

        if (activeTarget != null) {
            retainedTarget = activeTarget;
        }
        LivingEntity displayed = editor ? client.player : retainedTarget;
        boolean appearing = editor || activeTarget != null;

        double deltaMillis = frameDeltaMillis();
        VISIBILITY.speed(appearing ? 0.055 : 0.12);
        VISIBILITY.update(appearing, deltaMillis);
        SCALE.update(appearing || VISIBILITY.value() > 0.6, deltaMillis);

        if (displayed == null) {
            return;
        }
        if (!appearing && SCALE.value() < 0.01) {
            retainedTarget = null;
            resetAnimation();
            return;
        }

        float maxHealth = displayed.getMaxHealth();
        double combinedFraction = maxHealth <= 0.0f
                ? 0.0 : (displayed.getHealth() + displayed.getAbsorptionAmount()) / maxHealth;
        healthPercent = easeOutInterpolate(
                healthPercent, combinedFraction * 100.0, deltaMillis * 0.02);

        int alpha = MathHelper.clamp((int) (255.0 * VISIBILITY.value()), 0, 255);
        float scale = (float) SCALE.value();
        if (scale <= 0.0f || alpha <= 0) {
            return;
        }

        context.getMatrices().pushMatrix();

        context.getMatrices().translate(
                (1.0f - scale) * (x + WIDTH * 0.5f),
                (1.0f - scale) * (y + REPORTED_HEIGHT * 0.5f));
        context.getMatrices().scale(scale, scale);

        if (typeOne) {
            renderTypeOne(context, client, displayed, alpha, colorAt,
                    tickProgress, deltaMillis);
        } else {
            renderTypeTwo(context, client, displayed, alpha, colorAt,
                    tickProgress, combinedFraction, deltaMillis);
        }

        if (editor) {
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(
                    x + 8.0f, y + REPORTED_HEIGHT / 4.0f);
            context.drawTexture(RenderPipelines.GUI_TEXTURED, GRAB_TEXTURE,
                    0, 0,
                    0.0f, 0.0f, 24, 24, 24, 24);
            context.getMatrices().popMatrix();
        }
        context.getMatrices().popMatrix();
    }

    public static void resetAnimation() {
        SCALE.reset();
        VISIBILITY.reset();
        CIRCLE_HEALTH.reset();
        barHealth = 0.0;
        healthPercent = 0.0;
        retainedTarget = null;

        previousFrameTime = Util.getMeasuringTimeMs();
    }

    public static void resetPosition(int resetX, int resetY) {
        ensureLayoutLoaded();
        x = resetX;
        y = resetY;
        dragging = false;
        lastLeftDown = false;
        saveLayout();
    }

    private static void renderTypeOne(
            DrawContext context,
            MinecraftClient client,
            LivingEntity target,
            int alpha,
            IntUnaryOperator colorAt,
            float tickProgress,
            double deltaMillis
    ) {
        drawLegacyBackground(context, alpha, colorAt);
        fillFractional(context, x + 5.3f, y + 5.3f, 32.4f, 32.4f,
                gray(30, alpha));

        double targetBar = target.getMaxHealth() <= 0.0f
                ? 0.0 : target.getHealth() / target.getMaxHealth() * 50.0;
        barHealth = MathHelper.clamp(easeOutInterpolate(
                barHealth, targetBar, deltaMillis * 0.01), 0.0, 50.0);
        fillFractional(context, x + 40.3f, y + 27.3f, 53.4f, 9.4f,
                gray(30, alpha));

        if (target.getHealth() > 0.0f) {
            int first = withAlpha(colorAt.applyAsInt(0), alpha);
            int second = withAlpha(colorAt.applyAsInt(90), alpha);
            int third = withAlpha(colorAt.applyAsInt(270), alpha);
            int fourth = withAlpha(colorAt.applyAsInt(180), alpha);
            float width = Math.max(0.001f, (float) barHealth);

            fillFractionalGradient(context, x + 42, y + 29,
                    width, 6, 0.0f, first, third, fourth, second);
            fillFractionalGradientGlow(context, x + 41, y + 26,
                    width + 2.0f, 12, 3.0f, 5.0f,
                    first, third, fourth, second);
        }

        drawHead(context, client, target, x + 6, y + 6, alpha, tickProgress);
        if (VISIBILITY.value() > 0.15) {
            drawClippedName(context, client.textRenderer, protectedName(target),
                    x + 40, y + 8, 43, withAlpha(TEXT_COLOR, alpha));
            String percent = String.format(Locale.ROOT, "%.1f", healthPercent) + "%";
            drawCentered(context, client.textRenderer, percent,
                    x + 68.0f, y + 30.5f, withAlpha(TEXT_COLOR, alpha), FONT_DS, true);
        }
        drawTypeOneEquipment(context, client, target, alpha);
    }

    private static void renderTypeTwo(
            DrawContext context,
            MinecraftClient client,
            LivingEntity target,
            int alpha,
            IntUnaryOperator colorAt,
            float tickProgress,
            double combinedFraction,
            double deltaMillis
    ) {
        drawLegacyBackground(context, alpha, colorAt);
        fillFractional(context, x + 5.3f, y + 5.3f, 32.4f, 32.4f,
                gray(30, alpha));

        CIRCLE_HEALTH.target(combinedFraction);
        CIRCLE_HEALTH.update(deltaMillis);
        float circleValue = (float) CIRCLE_HEALTH.value();
        int quietAlpha = Math.min(alpha, 80);
        drawHealthRing(context, x + WIDTH - 20.0f, y + 21.5f,
                14.0f, 8.5f, circleValue, gray(10, quietAlpha), alpha, colorAt);

        drawHead(context, client, target, x + 6, y + 6, alpha, tickProgress);
        if (VISIBILITY.value() > 0.15) {
            drawClippedName(context, client.textRenderer, protectedName(target),
                    x + 40, y + 8, 43, withAlpha(TEXT_COLOR, alpha));
        }
        drawTypeTwoEquipment(context, client, target, alpha);
    }

    private static void drawLegacyBackground(
            DrawContext context, int alpha, IntUnaryOperator colorAt
    ) {
        int topLeft = withAlpha(colorAt.applyAsInt(0), alpha);
        int bottomLeft = withAlpha(colorAt.applyAsInt(90), alpha);
        int topRight = withAlpha(colorAt.applyAsInt(180), alpha);
        int bottomRight = withAlpha(colorAt.applyAsInt(270), alpha);
        SmoothRoundedGui.fillGlowFourCorners(context,
                x - 1, y - 1, WIDTH + 2, DRAWN_HEIGHT + 2,
                3.0f, 8.0f, topLeft, topRight, bottomRight, bottomLeft);

        int inner = withAlpha(INNER_BACKGROUND_RGB,
                Math.min((int) (alpha * 1.4f), 255));
        SmoothRoundedGui.fillGlow(context,
                x, y + 1, WIDTH, DRAWN_HEIGHT - 2, 3.0f, 5.0f, inner);
    }

    private static void drawHead(
            DrawContext context,
            MinecraftClient client,
            LivingEntity target,
            int drawX,
            int drawY,
            int alpha,
            float tickProgress
    ) {
        if (VISIBILITY.value() <= 0.15) {
            return;
        }
        Identifier texture = textureFor(client, target, tickProgress);
        if (texture == null) {
            return;
        }
        float hurt = MathHelper.clamp((target.hurtTime - tickProgress) / 15.0f, 0.0f, 1.0f);

        int greenBlue = MathHelper.clamp((int) ((1.0f - hurt) * 255.0f), 0, 255);
        int tint = alpha << 24 | 0xFF << 16 | greenBlue << 8 | greenBlue;

        context.drawTexture(RenderPipelines.GUI_TEXTURED, texture,
                drawX, drawY, 8.0f, 8.0f,
                31, 31, 8, 8, 64, 64, tint);
    }

    private static Identifier textureFor(
            MinecraftClient client, LivingEntity target, float tickProgress
    ) {
        if (target instanceof net.minecraft.client.network.AbstractClientPlayerEntity player) {
            return player.getSkin().body().texturePath();
        }
        try {
            EntityRenderState state = client.getEntityRenderDispatcher()
                    .getAndUpdateRenderState(target, tickProgress);
            EntityRenderer<?, ?> renderer = client.getEntityRenderDispatcher().getRenderer(state);
            if (renderer instanceof LivingEntityRenderer<?, ?, ?> living
                    && state instanceof LivingEntityRenderState livingState) {
                return textureUnchecked(living, livingState);
            }
        } catch (RuntimeException ignored) {

        }
        return null;
    }

    @SuppressWarnings({"rawtypes", "unchecked"})
    private static Identifier textureUnchecked(
            LivingEntityRenderer renderer, LivingEntityRenderState state
    ) {
        return renderer.getTexture(state);
    }

    private static void drawTypeOneEquipment(
            DrawContext context, MinecraftClient client, LivingEntity target, int alpha
    ) {
        if (alpha < 3) {
            return;
        }
        int itemX = 40;
        String mainCount = "";
        ItemStack main = target.getMainHandStack();
        if (!main.isEmpty()) {
            mainCount = "x" + main.getCount();
            drawHeldItem(context, client, target, main,
                    x + itemX, y + 16, mainCount, alpha);
            itemX += 17;
        }
        ItemStack off = target.getOffHandStack();
        if (!off.isEmpty()) {
            int adjustment = mainCount.isEmpty()
                    ? 0 : fontWidth(client.textRenderer, mainCount, FONT_DR) - 7;
            String count = "x" + off.getCount();
            drawHeldItem(context, client, target, off,
                    x + 40 + adjustment + (mainCount.isEmpty() ? 0 : 17),
                    y + 16, count, alpha);
        }

        if (!(target instanceof PlayerEntity player)) {
            return;
        }
        int quiet = gray(10, Math.min(alpha, 80));
        drawArmorSlot(context, client, player, EquipmentSlot.HEAD,
                x + 96, y + 7, quiet, alpha, FONT_DS);
        drawArmorSlot(context, client, player, EquipmentSlot.CHEST,
                x + 112, y + 7, quiet, alpha, FONT_DS);
        drawArmorSlot(context, client, player, EquipmentSlot.LEGS,
                x + 96, y + 23, quiet, alpha, FONT_DX);
        drawArmorSlot(context, client, player, EquipmentSlot.FEET,
                x + 112, y + 23, quiet, alpha, FONT_DX);
    }

    private static void drawTypeTwoEquipment(
            DrawContext context, MinecraftClient client, LivingEntity target, int alpha
    ) {
        if (alpha < 3) {
            return;
        }
        String mainCount = "";
        ItemStack main = target.getMainHandStack();
        if (!main.isEmpty()) {
            mainCount = "x" + main.getCount();
            drawHeldItem(context, client, target, main,
                    x + 40, y + 14, mainCount, alpha);
        }
        ItemStack off = target.getOffHandStack();
        if (!off.isEmpty()) {
            int itemOffset = mainCount.isEmpty()
                    ? 0 : fontWidth(client.textRenderer, mainCount, FONT_DR) - 7 + 17;
            drawHeldItem(context, client, target, off,
                    x + 40 + itemOffset, y + 14, "x" + off.getCount(), alpha);
        }

        if (!(target instanceof PlayerEntity player) || !hasArmor(player)) {
            return;
        }
        fillFractional(context, x + 40.0f, y + 24.0f, 52.0f, 13.0f,
                gray(10, Math.min(alpha, 80)));
        drawScaledItem(context, client, player, player.getEquippedStack(EquipmentSlot.HEAD),
                x + 40, y + 24, 0.8f, FONT_DX);
        drawScaledItem(context, client, player, player.getEquippedStack(EquipmentSlot.CHEST),
                x + 53, y + 24, 0.8f, FONT_DX);
        drawScaledItem(context, client, player, player.getEquippedStack(EquipmentSlot.LEGS),
                x + 66, y + 24, 0.8f, FONT_DX);
        drawScaledItem(context, client, player, player.getEquippedStack(EquipmentSlot.FEET),
                x + 79, y + 24, 0.8f, FONT_DX);
    }

    private static void drawArmorSlot(
            DrawContext context,
            MinecraftClient client,
            PlayerEntity player,
            EquipmentSlot slot,
            int drawX,
            int drawY,
            int background,
            int alpha,
            StyleSpriteSource overlayFont
    ) {
        fillFractional(context, drawX, drawY, 13.0f, 13.0f, background);
        drawScaledItem(context, client, player, player.getEquippedStack(slot),
                drawX, drawY, 0.8f, overlayFont);
    }

    private static void drawHeldItem(
            DrawContext context,
            MinecraftClient client,
            LivingEntity target,
            ItemStack stack,
            int drawX,
            int drawY,
            String count,
            int alpha
    ) {
        drawScaledItem(context, client, target, stack, drawX, drawY, 0.5f, null);
        drawFont(context, client.textRenderer, count,
                drawX + fontWidth(client.textRenderer, count, FONT_DR) - 9,
                drawY - 5, withAlpha(0xFFFFFFFF, alpha), FONT_DR, false);
    }

    private static void drawScaledItem(
            DrawContext context,
            MinecraftClient client,
            LivingEntity target,
            ItemStack stack,
            int drawX,
            int drawY,
            float scale,
            StyleSpriteSource overlayFont
    ) {
        if (stack.isEmpty()) {
            return;
        }
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(drawX, drawY);
        context.getMatrices().scale(scale, scale);
        context.drawItem(target, stack, 0, 0, 0);
        if (overlayFont != null) {

            context.drawStackOverlay(client.textRenderer, stack, 0, 0);
        }
        context.getMatrices().popMatrix();
    }

    private static boolean hasArmor(PlayerEntity player) {
        return !player.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
                || !player.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
                || !player.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                || !player.getEquippedStack(EquipmentSlot.FEET).isEmpty();
    }

    private static void drawHealthRing(
            DrawContext context,
            float centerX,
            float centerY,
            float radius,
            float legacyLineWidth,
            float progress,
            int background,
            int alpha,
            IntUnaryOperator colorAt
    ) {
        float guiScale = Math.max(1.0f,
                (float) MinecraftClient.getInstance().getWindow().getScaleFactor());

        float logicalThickness = legacyLineWidth / guiScale;
        float visibleProgress = MathHelper.clamp(progress, 0.0f, 1.0f);
        float logicalFeather = 1.0f / guiScale;
        Matrix3x2f pose = new Matrix3x2f(context.getMatrices());
        float extent = radius + logicalThickness * 0.5f + logicalFeather + 1.0f;
        ScreenRect scissor = context.scissorStack.peekLast();
        ScreenRect transformed = new ScreenRect(
                (int) Math.floor(centerX - extent),
                (int) Math.floor(centerY - extent),
                (int) Math.ceil(extent * 2.0f),
                (int) Math.ceil(extent * 2.0f)).transformEachVertex(pose);
        ScreenRect bounds = scissor == null ? transformed : scissor.intersection(transformed);
        context.state.addSimpleElement(new RingState(
                pose, centerX, centerY, radius, logicalThickness, logicalFeather,
                visibleProgress,
                background, alpha, colorAt, scissor, bounds));

        String percent = (int) (progress * 100.0f) + "%";
        drawCentered(context, MinecraftClient.getInstance().textRenderer, percent,
                centerX + radius / 4.0f - 3.0f,
                centerY + radius / 4.0f - 4.0f,
                withAlpha(0xFFFFFFFF, alpha), FONT_DR, false);
    }

    private static void drawClippedName(
            DrawContext context,
            TextRenderer renderer,
            String name,
            int drawX,
            int drawY,
            int maximumWidth,
            int color
    ) {

        context.enableScissor(drawX - 1, drawY - 4,
                drawX + maximumWidth, drawY + 16);
        drawFont(context, renderer, name, drawX, drawY, color, FONT_DU, false);
        context.disableScissor();

        if (fontWidth(renderer, name, FONT_DU) <= maximumWidth) {
            return;
        }

        int baseAlpha = color >>> 24;
        float fadeWidth = maximumWidth * 0.25f;
        int fadeColumns = Math.max(1, (int) Math.ceil(fadeWidth));
        for (int column = 0; column < fadeColumns; column++) {
            float sample = column + 0.5f;
            float shaderInput = 1.0f - sample * 2.0f / maximumWidth;
            float fade = smoothstep(0.5f, 1.0f, shaderInput);
            int fadedAlpha = MathHelper.clamp((int) (baseAlpha * fade), 0, 255);
            if (fadedAlpha <= 0) {
                continue;
            }
            int left = drawX + maximumWidth + column;
            context.enableScissor(left, drawY - 4, left + 1, drawY + 16);
            drawFont(context, renderer, name, drawX, drawY,
                    withAlpha(color, fadedAlpha), FONT_DU, false);
            context.disableScissor();
        }
    }

    private static String protectedName(LivingEntity target) {

        return NameProtectModule.streamerModeActive()
                ? NameProtectModule.configuredAlias()
                : target.getName().getString();
    }

    private static void fillFractional(
            DrawContext context, float drawX, float drawY,
            float width, float height, int color
    ) {
        if (width <= 0.0f || height <= 0.0f) {
            return;
        }
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(drawX, drawY);
        context.getMatrices().scale(width, height);
        context.fill(0, 0, 1, 1, color);
        context.getMatrices().popMatrix();
    }

    private static void fillFractionalGradient(
            DrawContext context,
            float drawX,
            float drawY,
            float width,
            int height,
            float radius,
            int topLeft,
            int topRight,
            int bottomRight,
            int bottomLeft
    ) {
        int rasterWidth = Math.max(1, Math.round(width));
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(drawX, drawY);
        context.getMatrices().scale(width / rasterWidth, 1.0f);
        SmoothRoundedGui.fillFourCorners(context, 0, 0, rasterWidth, height,
                radius, topLeft, topRight, bottomRight, bottomLeft);
        context.getMatrices().popMatrix();
    }

    private static void fillFractionalGradientGlow(
            DrawContext context,
            float drawX,
            float drawY,
            float width,
            int height,
            float radius,
            float glowRadius,
            int topLeft,
            int topRight,
            int bottomRight,
            int bottomLeft
    ) {
        int rasterWidth = Math.max(1, Math.round(width));
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(drawX, drawY);
        context.getMatrices().scale(width / rasterWidth, 1.0f);
        SmoothRoundedGui.fillGlowFourCorners(context, 0, 0, rasterWidth, height,
                radius, glowRadius, topLeft, topRight, bottomRight, bottomLeft);
        context.getMatrices().popMatrix();
    }

    private static StyleSpriteSource font(int legacySize) {
        return LegacyHudFont.font(legacySize);
    }

    private static int fontWidth(
            TextRenderer renderer, String value, StyleSpriteSource source
    ) {
        return LegacyHudFont.width(renderer, value, source);
    }

    private static void drawFont(
            DrawContext context,
            TextRenderer renderer,
            String value,
            float drawX,
            float drawY,
            int color,
            StyleSpriteSource source,
            boolean shadow
    ) {
        LegacyHudFont.draw(context, renderer, value, drawX, drawY,
                color, source, shadow);
    }

    private static void drawCentered(
            DrawContext context,
            TextRenderer renderer,
            String value,
            float centerX,
            float drawY,
            int color,
            StyleSpriteSource source,
            boolean shadow
    ) {
        drawFont(context, renderer, value,
                centerX - fontWidth(renderer, value, source) * 0.5f,
                drawY, color, source, shadow);
    }

    private static int gray(int value, int alpha) {
        int channel = MathHelper.clamp(value, 0, 255);
        return MathHelper.clamp(alpha, 0, 255) << 24
                | channel << 16 | channel << 8 | channel;
    }

    private static int withAlpha(int color, int alpha) {
        return MathHelper.clamp(alpha, 0, 255) << 24 | color & 0xFFFFFF;
    }

    private static float smoothstep(float edge0, float edge1, float value) {
        float normalized = MathHelper.clamp(
                (value - edge0) / (edge1 - edge0), 0.0f, 1.0f);
        return normalized * normalized * (3.0f - 2.0f * normalized);
    }

    private static double frameDeltaMillis() {
        long now = Util.getMeasuringTimeMs();
        long previous = previousFrameTime;
        previousFrameTime = now;
        if (previous == 0L) {
            return 16.6666667;
        }

        return Math.max(0.0, (double) (now - previous));
    }

    private static double easeOutInterpolate(double start, double end, double fraction) {
        double t = MathHelper.clamp(fraction, 0.0, 1.0);
        double low = 0.0;
        double high = 1.0;
        for (int index = 0; index < 14; index++) {
            double parameter = (low + high) * 0.5;
            double xValue = cubicBezier(parameter, 0.0, 0.58);
            if (xValue < t) low = parameter;
            else high = parameter;
        }
        double eased = cubicBezier((low + high) * 0.5, 0.0, 1.0);
        return start + (end - start) * eased;
    }

    private static double cubicBezier(double t, double firstControl, double secondControl) {
        double inverse = 1.0 - t;
        return 3.0 * inverse * inverse * t * firstControl
                + 3.0 * inverse * t * t * secondControl + t * t * t;
    }

    private static void ensureLayoutLoaded() {
        if (layoutLoaded) {
            return;
        }
        layoutLoaded = true;
        UiLayoutStore.Position stored = LAYOUT.loadSectionMigratingLegacy(
                        "targetHud", "hud.celka",
                        Map.of("TargetHUDComponent", "TargetHUDComponent"))
                .get("TargetHUDComponent");
        if (stored != null) {
            x = stored.x();
            y = stored.y();
        }
    }

    private static void updateDrag(
            MinecraftClient client, DrawContext context, boolean editor
    ) {
        boolean leftDown = GLFW.glfwGetMouseButton(
                client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        double mouseX = client.mouse.getX() * context.getScaledWindowWidth()
                / client.getWindow().getWidth();
        double mouseY = client.mouse.getY() * context.getScaledWindowHeight()
                / client.getWindow().getHeight();

        if (editor && leftDown && !lastLeftDown
                && mouseX >= x - 3 && mouseX <= x - 3 + WIDTH
                && mouseY >= y - 4 && mouseY <= y - 4 + REPORTED_HEIGHT) {
            dragging = true;
            dragOffsetX = x - mouseX;
            dragOffsetY = y - mouseY;
        }
        if (editor && dragging && leftDown) {
            x = MathHelper.clamp((int) Math.round(mouseX + dragOffsetX),
                    0, Math.max(0, context.getScaledWindowWidth() - WIDTH));
            y = MathHelper.clamp((int) Math.round(mouseY + dragOffsetY),
                    0, Math.max(0, context.getScaledWindowHeight() - REPORTED_HEIGHT));
        }
        if (dragging && (!leftDown || !editor)) {
            dragging = false;
            saveLayout();
        }
        lastLeftDown = leftDown;
    }

    private static void saveLayout() {
        try {
            LAYOUT.saveSection("targetHud", Map.of(
                    "TargetHUDComponent", new UiLayoutStore.Position(x, y)));
        } catch (IOException ignored) {

        }
    }

    private static final class BackAnimation {
        private double speed;
        private double progress;
        private double value;

        private BackAnimation(double speed) {
            this.speed = speed;
        }

        private void speed(double speed) {
            this.speed = speed;
        }

        private void update(boolean forwards, double deltaMillis) {
            double direction = forwards ? 1.0 : -1.0;
            progress = MathHelper.clamp(
                    progress + direction * speed * deltaMillis * 0.01, 0.0, 1.0);
            double shifted = progress - 1.0;
            value = 1.0 + 2.70158 * shifted * shifted * shifted
                    + 1.70158 * shifted * shifted;
        }

        private double value() {
            return value;
        }

        private void reset() {
            progress = 0.0;
            value = 0.0;
        }
    }

    private static final class RetargetAnimation {
        private final double speed;
        private double start;
        private double target;
        private double value;
        private double progress;

        private RetargetAnimation(double speed) {
            this.speed = speed;
        }

        private void target(double target) {
            if (Double.compare(this.target, target) == 0) {
                return;
            }
            this.target = target;
            this.start = value;
            this.progress = 0.0;
        }

        private void update(double deltaMillis) {
            progress = MathHelper.clamp(
                    progress + speed * deltaMillis * 0.01, 0.0, 1.0);
            double eased = Math.sqrt(1.0 - Math.pow(progress - 1.0, 2.0));
            value = start + (target - start) * eased;
        }

        private double value() {
            return value;
        }

        private void reset() {
            start = 0.0;
            target = 0.0;
            value = 0.0;
            progress = 0.0;
        }
    }

    private record RingState(
            Matrix3x2f pose,
            float centerX,
            float centerY,
            float radius,
            float thickness,
            float feather,
            float progress,
            int background,
            int alpha,
            IntUnaryOperator colorAt,
            ScreenRect scissorArea,
            ScreenRect bounds
    ) implements SimpleGuiElementRenderState {

        private static final int SEGMENTS = 360;

        @Override
        public void setupVertices(VertexConsumer vertices) {
            drawArc(vertices, 1.0f, 0.0f, ignored -> background);
            drawArc(vertices, progress, -90.0f,
                    degree -> withAlpha(colorAt.applyAsInt(degree), alpha));
        }

        private void drawArc(
                VertexConsumer vertices,
                float amount,
                float startDegree,
                IntUnaryOperator colors
        ) {

            int vertexCount = Math.max(0, Math.min(SEGMENTS + 1,
                    (int) ((SEGMENTS + 1.0f) * amount)));
            int segmentCount = Math.max(0, vertexCount - 1);

            float outerEdge = radius + thickness * 0.5f;
            float innerEdge = Math.max(0.0f, radius - thickness * 0.5f);
            float halfFeather = feather * 0.5f;
            float outerFeather = outerEdge + halfFeather;
            float outerCore = Math.max(innerEdge, outerEdge - halfFeather);
            float innerCore = Math.min(outerEdge, innerEdge + halfFeather);
            float innerFeather = Math.max(0.0f, innerEdge - halfFeather);

            int[] vertexColors = new int[vertexCount];
            for (int index = 0; index < vertexCount; index++) {
                vertexColors[index] = colors.applyAsInt((int) startDegree + index);
            }

            for (int index = 0; index < segmentCount; index++) {
                float firstDegree = startDegree + index;
                float secondDegree = firstDegree + 1.0f;
                double firstAngle = Math.toRadians(firstDegree);
                double secondAngle = Math.toRadians(secondDegree);
                int firstColor = vertexColors[index];
                int secondColor = vertexColors[index + 1];

                quad(vertices, firstAngle, secondAngle,
                        outerFeather, outerCore,
                        firstColor & 0x00FFFFFF, firstColor,
                        secondColor & 0x00FFFFFF, secondColor);
                quad(vertices, firstAngle, secondAngle,
                        outerCore, innerCore,
                        firstColor, firstColor, secondColor, secondColor);
                quad(vertices, firstAngle, secondAngle,
                        innerCore, innerFeather,
                        firstColor, firstColor & 0x00FFFFFF,
                        secondColor, secondColor & 0x00FFFFFF);
            }
        }

        private void quad(
                VertexConsumer vertices,
                double firstAngle,
                double secondAngle,
                float outerRadius,
                float innerRadius,
                int firstOuterColor,
                int firstInnerColor,
                int secondOuterColor,
                int secondInnerColor
        ) {
            vertex(vertices,
                    centerX + (float) Math.cos(firstAngle) * outerRadius,
                    centerY + (float) Math.sin(firstAngle) * outerRadius,
                    firstOuterColor);
            vertex(vertices,
                    centerX + (float) Math.cos(firstAngle) * innerRadius,
                    centerY + (float) Math.sin(firstAngle) * innerRadius,
                    firstInnerColor);
            vertex(vertices,
                    centerX + (float) Math.cos(secondAngle) * innerRadius,
                    centerY + (float) Math.sin(secondAngle) * innerRadius,
                    secondInnerColor);
            vertex(vertices,
                    centerX + (float) Math.cos(secondAngle) * outerRadius,
                    centerY + (float) Math.sin(secondAngle) * outerRadius,
                    secondOuterColor);
        }

        private void vertex(VertexConsumer vertices, float drawX, float drawY, int color) {
            vertices.vertex(pose, drawX, drawY).color(color);
        }

        @Override
        public com.mojang.blaze3d.pipeline.RenderPipeline pipeline() {
            return RenderPipelines.GUI;
        }

        @Override
        public TextureSetup textureSetup() {
            return TextureSetup.empty();
        }
    }
}
