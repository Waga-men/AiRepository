package celestial.port.client.ui;

import celestial.port.core.ModuleManager;
import celestial.port.core.config.ConfigManager;
import net.minecraft.util.Util;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.TreeMap;
import java.util.regex.Pattern;

public final class ConfigProfiles {
    private static final Logger LOGGER = LoggerFactory.getLogger("celestial/config-profiles");
    private static final String EXTENSION = ".celka";
    private static final String LEGACY_JSON_EXTENSION = ".json";
    private static final Pattern SAFE_NAME = Pattern.compile("[\\p{L}\\p{N} _.-]{1,40}");
    private static final Pattern WINDOWS_DEVICE = Pattern.compile(
            "(?i)^(?:con|prn|aux|nul|com[1-9]|lpt[1-9])$");

    private final ModuleManager modules;
    private final Path directory;

    public ConfigProfiles(ModuleManager modules, Path directory) {
        this.modules = Objects.requireNonNull(modules, "modules");
        this.directory = Objects.requireNonNull(directory, "directory").toAbsolutePath().normalize();
        LegacyAutoConfigImporter.ensureImported(this.modules, this.directory);
    }

    public List<String> names() {
        if (!Files.isDirectory(directory)) return List.of();
        try (var stream = Files.list(directory)) {
            Map<String, ProfileFile> profiles = new TreeMap<>(String.CASE_INSENSITIVE_ORDER);
            for (Path path : stream.filter(candidate ->
                    Files.isRegularFile(candidate, LinkOption.NOFOLLOW_LINKS)).toList()) {
                String fileName = path.getFileName().toString();
                String extension = knownExtension(fileName);
                if (extension == null) continue;
                try {
                    String name = normalizeName(fileName);
                    ProfileFile candidate = new ProfileFile(
                            name, extension.equals(EXTENSION));
                    profiles.merge(name, candidate, (current, replacement) ->
                            replacement.canonical && !current.canonical
                                    ? replacement : current);
                } catch (IllegalArgumentException ignored) {

                }
            }
            return profiles.values().stream()
                    .map(ProfileFile::name)
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .toList();
        } catch (IOException ignored) {
            return List.of();
        }
    }

    public void save(String name) throws IOException {
        String normalized = normalizeName(name);
        Path target = canonicalPath(normalized);
        new ConfigManager(modules, target, ConfigManager.Scope.MODULES_ONLY).save();

        try {
            Path legacyJson = findExisting(normalized, LEGACY_JSON_EXTENSION);
            if (legacyJson != null) Files.deleteIfExists(legacyJson);
        } catch (IOException exception) {
            LOGGER.warn("Saved profile '{}' but could not remove its old JSON variant",
                    target.getFileName(), exception);
        }
    }

    public boolean load(String name) throws IOException {
        String normalized = normalizeName(name);
        Path source = resolveForLoad(name, normalized);
        if (source == null) return false;

        ConfigManager manager = new ConfigManager(
                modules, source, ConfigManager.Scope.MODULES_ONLY);
        boolean loaded = manager.load(LegacyAutoConfigImporter.readProfile(modules, source));
        if (loaded && hasExtension(source, LEGACY_JSON_EXTENSION)) {
            migrateLoadedJson(source, canonicalPath(normalized));
        }
        return loaded;
    }

    public boolean delete(String name) throws IOException {
        String normalized = normalizeName(name);
        Set<Path> variants = new LinkedHashSet<>();
        Path celka = findExisting(normalized, EXTENSION);
        Path json = findExisting(normalized, LEGACY_JSON_EXTENSION);
        if (celka != null) variants.add(celka);
        if (json != null) variants.add(json);
        boolean deleted = false;
        for (Path variant : variants) {
            deleted |= Files.deleteIfExists(variant);
        }
        return deleted;
    }

    public void openDirectory() throws IOException {
        Files.createDirectories(directory);
        Util.getOperatingSystem().open(directory);
    }

    public Path directory() {
        return directory;
    }

    private Path resolveForLoad(String rawName, String normalized) throws IOException {
        String requested = knownExtension(Objects.requireNonNull(rawName, "name"));
        String first = LEGACY_JSON_EXTENSION.equals(requested)
                ? LEGACY_JSON_EXTENSION : EXTENSION;
        String second = first.equals(EXTENSION) ? LEGACY_JSON_EXTENSION : EXTENSION;
        Path preferred = findExisting(normalized, first);
        return preferred != null ? preferred : findExisting(normalized, second);
    }

    private Path findExisting(String normalized, String extension) throws IOException {
        Path direct = checkedPath(normalized, extension);
        if (Files.isRegularFile(direct, LinkOption.NOFOLLOW_LINKS)) return direct;
        if (!Files.isDirectory(directory)) return null;
        String wanted = normalized + extension;
        try (var stream = Files.list(directory)) {
            return stream.filter(path -> Files.isRegularFile(
                            path, LinkOption.NOFOLLOW_LINKS))
                    .filter(path -> path.getFileName().toString().equalsIgnoreCase(wanted))
                    .findFirst()
                    .orElse(null);
        }
    }

    private void migrateLoadedJson(Path source, Path target) {
        if (Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) return;
        Path temporary = null;
        try {
            Files.createDirectories(target.getParent());
            temporary = Files.createTempFile(target.getParent(),
                    target.getFileName().toString() + ".", ".migrating");
            Files.copy(source, temporary, StandardCopyOption.REPLACE_EXISTING);
            try {

                Files.move(temporary, target);
            } catch (FileAlreadyExistsException ignored) {

                return;
            }
            Files.deleteIfExists(source);
        } catch (IOException exception) {

            LOGGER.warn("Could not migrate profile '{}' to '{}'",
                    source.getFileName(), target.getFileName(), exception);
        } finally {
            if (temporary != null) {
                try {
                    Files.deleteIfExists(temporary);
                } catch (IOException ignored) {

                }
            }
        }
    }

    private Path canonicalPath(String normalized) {
        return checkedPath(normalized, EXTENSION);
    }

    private Path checkedPath(String normalized, String extension) {
        Path resolved = directory.resolve(normalized + extension).normalize();
        if (!Objects.equals(resolved.getParent(), directory)) {
            throw new IllegalArgumentException("Invalid profile name");
        }
        return resolved;
    }

    private static String normalizeName(String rawName) {
        String raw = Objects.requireNonNull(rawName, "name");
        if (!raw.equals(raw.strip())) {
            throw new IllegalArgumentException("Profile name cannot start or end with spaces");
        }
        String name = raw;
        String extension = knownExtension(name);
        if (extension != null) {
            name = name.substring(0, name.length() - extension.length());
        }
        if (!SAFE_NAME.matcher(name).matches()
                || name.equals(".") || name.equals("..")
                || name.startsWith(".") || name.endsWith(".")
                || isWindowsDeviceName(name)) {
            throw new IllegalArgumentException("Use 1-40 letters, digits, spaces, '.', '_' or '-'");
        }
        return name;
    }

    private static boolean isWindowsDeviceName(String name) {
        int dot = name.indexOf('.');
        String stem = (dot < 0 ? name : name.substring(0, dot)).stripTrailing();
        return WINDOWS_DEVICE.matcher(stem).matches();
    }

    private static String knownExtension(String name) {
        String lower = name.toLowerCase(Locale.ROOT);
        if (lower.endsWith(EXTENSION)) return EXTENSION;
        if (lower.endsWith(LEGACY_JSON_EXTENSION)) return LEGACY_JSON_EXTENSION;
        return null;
    }

    private static boolean hasExtension(Path path, String extension) {
        return path.getFileName().toString().toLowerCase(Locale.ROOT).endsWith(extension);
    }

    private record ProfileFile(String name, boolean canonical) {
    }
}
