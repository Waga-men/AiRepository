package celestial.port.client.command;

import celestial.port.mixin.accessor.ClientWorldPropertiesAccessor;
import celestial.port.mixin.accessor.PlayerListHudAccessor;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientWorldEvents;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.minecraft.block.AbstractSkullBlock;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.GenericContainerScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.ServerInfo;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.Packet;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.scoreboard.ScoreHolder;
import net.minecraft.scoreboard.Scoreboard;
import net.minecraft.scoreboard.Team;
import net.minecraft.screen.slot.Slot;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;

public final class LegacyTeleportCoordinator {
    private static final Set<String> REALLY_WORLD_TEAM_IDS = Set.of(
            "CIT-ecf274193ae3",
            "CIT-d609637f2e08",
            "CIT-12bcaed73a86",
            "CIT-d15cde2cad46"
    );
    private static final Set<String> seenReallyWorldTeamIds = new HashSet<>();
    private static final ThreadLocal<Integer> movementPacketDepth =
            ThreadLocal.withInitial(() -> 0);
    private static final ThreadLocal<Integer> manualBurstDepth =
            ThreadLocal.withInitial(() -> 0);
    private static final ThreadLocal<Integer> rawCommandDepth =
            ThreadLocal.withInitial(() -> 0);

    private static boolean installed;
    private static Contract contract;
    private static Trader trader;
    private static PendingTeleport pendingTeleport;
    private static float verticalRetryOffset;
    private static int reconnectRequests;
    private static int flatWorldLoads;
    private static long retryTimerStarted = System.currentTimeMillis();
    private static String hubSelector;
    private static GenericContainerScreen lastContainerScreen;
    private static int containerScreenTicks;

    private LegacyTeleportCoordinator() {
    }

    public static synchronized void install() {
        if (installed) {
            return;
        }
        ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
            if (!overlay) {
                parseServerMessage(message.getString());
            }
            return true;
        });
        ClientReceiveMessageEvents.ALLOW_CHAT.register(
                (message, signed, sender, parameters, receivedAt) -> {
                    parseServerMessage(message.getString());
                    return true;
                });
        ClientTickEvents.END_CLIENT_TICK.register(LegacyTeleportCoordinator::tick);
        ClientWorldEvents.AFTER_CLIENT_WORLD_CHANGE.register(
                LegacyTeleportCoordinator::afterWorldChange);
        ClientPlayConnectionEvents.INIT.register((handler, client) -> resetConnectionState());
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> resetConnectionState());
        installed = true;
    }

    public static Contract contract() {
        return contract;
    }

    public static Trader trader() {
        return trader;
    }

    public static boolean hasPendingTeleport() {
        return pendingTeleport != null;
    }

    public static void resetRetryState() {
        reconnectRequests = 0;
        pendingTeleport = null;
        flatWorldLoads = 0;
    }

    public static void setHubSelector(String selector) {
        hubSelector = selector;
    }

    public static void clearHubSelector() {
        hubSelector = null;
    }

    public static void beforeGameJoin() {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || hubSelector == null || !useCompass(false)) {
            return;
        }
        hubSelector = null;
    }

    public static boolean useCompass(boolean force) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            return false;
        }
        int slot = -1;
        for (int index = 0; index < 9; index++) {
            if (player.getInventory().getStack(index).isOf(Items.COMPASS)) {
                slot = index;
                break;
            }
        }
        if (slot < 0) {
            return false;
        }
        if (force || player.age < 5) {
            player.getInventory().setSelectedSlot(slot);
            player.networkHandler.sendPacket(new UpdateSelectedSlotC2SPacket(slot));
            client.options.useKey.setPressed(true);
        }
        return true;
    }

    public static boolean isReallyWorld(MinecraftClient client) {
        ServerInfo server = client.getCurrentServerEntry();
        if (server == null) {
            return false;
        }
        String address = server.address.toLowerCase(Locale.ROOT);
        if (!address.contains("reallyworld") && !address.contains("playrw")) {
            return false;
        }
        Text footer = ((PlayerListHudAccessor) client.inGameHud.getPlayerListHud())
                .celestial$getFooter();
        if (footer == null) {
            return false;
        }
        String plainFooter = footer.getString().trim().toLowerCase(Locale.ROOT);
        if (!plainFooter.contains("\u0433\u0440\u0443\u043f\u043f\u0430: vk.com/reallyworlds")
                || !plainFooter.contains("\u0441\u0430\u0439\u0442: reallyworld.ru")) {
            return false;
        }
        captureReallyWorldTeamIds(client);
        return seenReallyWorldTeamIds.containsAll(REALLY_WORLD_TEAM_IDS);
    }

    public static boolean isSunrise(MinecraftClient client) {
        ServerInfo server = client.getCurrentServerEntry();
        return server != null
                && server.address.toLowerCase(Locale.ROOT).contains("sunmc");
    }

    public static String currentReallyWorldGrief() {
        try {
            MinecraftClient client = MinecraftClient.getInstance();
            Scoreboard scoreboard = client.world.getScoreboard();
            StringBuilder result = new StringBuilder();
            for (ScoreHolder holder : scoreboard.getKnownScoreHolders()) {
                String holderName = holder.getNameForScoreboard();
                String decorated = Team.decorateName(
                        scoreboard.getScoreHolderTeam(holderName), Text.literal(holderName)
                ).getString();
                if (!decorated.contains("GRIEF")) {
                    continue;
                }
                for (var entry : scoreboard.getScoreHolderObjectives(holder)
                        .object2IntEntrySet()) {
                    result.append(decorated)
                            .append(": \u00A7c")
                            .append(entry.getIntValue());
                }
            }
            return result.substring(result.lastIndexOf("-") + 1, result.lastIndexOf(":"));
        } catch (Exception ignored) {
            return "";
        }
    }

    public static void teleport(TeleportType type, float x, float y, float z) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            throw new IllegalStateException("client.player");
        }
        if (!isReallyWorld(client)) {
            player.setPosition(x, y, z);
            return;
        }
        String grief = currentReallyWorldGrief();
        if (grief.equalsIgnoreCase("mega")) {
            performImmediate(grief, TeleportType.MEGA, x, y, z);
        } else {
            pendingTeleport = new PendingTeleport(type, x, y - verticalRetryOffset, z);
        }
    }

    public static void beginMovementPackets(ClientPlayerEntity player) {
        if (player == MinecraftClient.getInstance().player) {
            push(movementPacketDepth);
        }
    }

    public static void endMovementPackets(ClientPlayerEntity player) {
        if (player == MinecraftClient.getInstance().player) {
            pop(movementPacketDepth);
        }
    }

    public static float movementPacketYaw(ClientPlayerEntity player, float original) {
        return pendingTeleport != null && player == MinecraftClient.getInstance().player
                ? -180.0F : original;
    }

    public static float movementPacketPitch(ClientPlayerEntity player, float original) {
        return pendingTeleport != null && player == MinecraftClient.getInstance().player
                ? 0.0F : original;
    }

    public static Packet<?> rewriteMovementPacket(Packet<?> packet) {
        if (pendingTeleport == null
                || movementPacketDepth.get() <= 0
                || manualBurstDepth.get() > 0
                || !(packet instanceof PlayerMoveC2SPacket movement)
                || !movement.changesLook()) {
            return packet;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            return packet;
        }
        if (movement.changesPosition()) {
            return new PlayerMoveC2SPacket.Full(
                    movement.getX(player.getX()),
                    movement.getY(player.getY()),
                    movement.getZ(player.getZ()),
                    -180.0F,
                    0.0F,
                    movement.isOnGround(),
                    movement.horizontalCollision()
            );
        }
        return new PlayerMoveC2SPacket.LookAndOnGround(
                -180.0F,
                0.0F,
                movement.isOnGround(),
                movement.horizontalCollision()
        );
    }

    public static boolean bypassesOutgoingCommand() {
        return rawCommandDepth.get() > 0;
    }

    public static void sendRawCommand(String commandWithoutSlash) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getNetworkHandler() == null) {
            throw new IllegalStateException("client.networkHandler");
        }
        push(rawCommandDepth);
        try {
            client.getNetworkHandler().sendChatCommand(commandWithoutSlash);
        } finally {
            pop(rawCommandDepth);
        }
    }

    /** Apache Commons Lang 3.5 {@code NumberUtils.isNumber}. */
    public static boolean isLegacyNumber(String value) {
        if (value == null || value.isEmpty()) {
            return false;
        }
        char[] chars = value.toCharArray();
        int size = chars.length;
        int start = chars[0] == '-' || chars[0] == '+' ? 1 : 0;
        if (size > start + 1 && chars[start] == '0') {
            if (chars[start + 1] == 'x' || chars[start + 1] == 'X') {
                int index = start + 2;
                if (index == size) {
                    return false;
                }
                for (; index < chars.length; index++) {
                    char character = chars[index];
                    if ((character < '0' || character > '9')
                            && (character < 'a' || character > 'f')
                            && (character < 'A' || character > 'F')) {
                        return false;
                    }
                }
                return true;
            }
            if (Character.isDigit(chars[start + 1])) {
                for (int index = start + 1; index < chars.length; index++) {
                    if (chars[index] < '0' || chars[index] > '7') {
                        return false;
                    }
                }
                return true;
            }
        }

        size--;
        int index = start;
        boolean hasExponent = false;
        boolean hasDecimalPoint = false;
        boolean allowSigns = false;
        boolean foundDigit = false;
        while (index < size || index < size + 1 && allowSigns && !foundDigit) {
            char character = chars[index];
            if (character >= '0' && character <= '9') {
                foundDigit = true;
                allowSigns = false;
            } else if (character == '.') {
                if (hasDecimalPoint || hasExponent) {
                    return false;
                }
                hasDecimalPoint = true;
            } else if (character == 'e' || character == 'E') {
                if (hasExponent || !foundDigit) {
                    return false;
                }
                hasExponent = true;
                allowSigns = true;
            } else if (character == '+' || character == '-') {
                if (!allowSigns) {
                    return false;
                }
                allowSigns = false;
                foundDigit = false;
            } else {
                return false;
            }
            index++;
        }
        if (index < chars.length) {
            char character = chars[index];
            if (character >= '0' && character <= '9') {
                return true;
            }
            if (character == 'e' || character == 'E') {
                return false;
            }
            if (character == '.') {
                return !hasDecimalPoint && !hasExponent && foundDigit;
            }
            if (!allowSigns && (character == 'd' || character == 'D'
                    || character == 'f' || character == 'F')) {
                return foundDigit;
            }
            if (character == 'l' || character == 'L') {
                return foundDigit && !hasExponent && !hasDecimalPoint;
            }
            return false;
        }
        return !allowSigns && foundDigit;
    }

    private static void tick(MinecraftClient client) {
        captureReallyWorldTeamIds(client);
        updateContainerScreenAge(client);
        tickHubSelector(client);
        tickRetry(client);
    }

    private static void tickRetry(MinecraftClient client) {
        if (pendingTeleport == null) {
            flatWorldLoads = 0;
            return;
        }
        ClientPlayerEntity player = client.player;
        ClientWorld world = client.world;
        if (player == null || world == null || client.getNetworkHandler() == null) {
            return;
        }
        if (isFlat(world)) {
            return;
        }
        if (reconnectRequests < 2 && flatWorldLoads < 2) {
            long now = System.currentTimeMillis();
            if (player.age > 5 && now - retryTimerStarted > 800L) {
                client.getNetworkHandler().sendChatMessage(".rct");
                reconnectRequests++;
                retryTimerStarted = now;
            }
            return;
        }
        if (player.age > 6 && flatWorldLoads >= 2) {
            PendingTeleport pending = pendingTeleport;
            performImmediate("", pending.type, pending.x, pending.y, pending.z);
            resetRetryState();
        }
    }

    private static void tickHubSelector(MinecraftClient client) {
        if (hubSelector == null) {
            return;
        }
        if (isReallyWorld(client)) {
            tickReallyWorldSelector(client);
        } else if (isSunrise(client)) {
            tickSunriseSelector(client);
        }
    }

    private static void tickReallyWorldSelector(MinecraftClient client) {
        String selector = hubSelector;
        if (selector == null || selector.isEmpty() || selector.isBlank()
                || lastContainerScreen == null) {
            return;
        }
        if (selector.equalsIgnoreCase("mega")) {
            clickContainerSlot(client, 20, 2);
            return;
        }
        List<Slot> slots = lastContainerScreen.getScreenHandler().slots;
        if (slots.isEmpty()) {
            return;
        }
        if (!lastContainerScreen.getTitle().getString().contains("\u0433\u0440\u0438\u0444\u0430")) {
            clickContainerSlot(client, 22, 0);
            return;
        }
        Slot selected = selectReallyWorldSlot(selector, slots);
        clickContainerSlot(client, slots.indexOf(selected), 2);
    }

    private static void tickSunriseSelector(MinecraftClient client) {
        if (lastContainerScreen == null) {
            return;
        }
        String selector = hubSelector;
        List<Slot> slots = lastContainerScreen.getScreenHandler().slots;
        for (Slot slot : slots) {
            if (!slot.hasStack() || !isPlayerHead(slot.getStack())) {
                continue;
            }
            String itemName = lettersOnly(slot.getStack().getName().getString());
            String expected = selector.trim().replaceAll("[0-9]", "");
            if (!itemName.equalsIgnoreCase(expected)) {
                continue;
            }
            int selected = Math.max(0, Math.min(90, slots.indexOf(slot)));
            clickContainerSlot(client, selected, 0);
            return;
        }
    }

    private static Slot selectReallyWorldSlot(String selector, List<Slot> slots) {
        Slot fallback = slots.get(1);
        try {
            int count = Integer.parseInt(selector);
            if (count == 1) {
                return fallback;
            }
            for (Slot slot : slots) {
                if (slot.hasStack() && isPlayerHead(slot.getStack())
                        && slot.getStack().getCount() == count) {
                    return slot;
                }
            }
            return fallback;
        } catch (NumberFormatException ignored) {
            return fallback;
        }
    }

    private static void clickContainerSlot(MinecraftClient client, int slotIndex, int minimumAge) {
        if (lastContainerScreen == null
                || client.player == null
                || client.interactionManager == null
                || containerScreenTicks <= minimumAge) {
            return;
        }
        List<Slot> slots = lastContainerScreen.getScreenHandler().slots;
        if (slotIndex < 0 || slotIndex >= slots.size()) {
            return;
        }
        Slot slot = slots.get(slotIndex);
        client.interactionManager.clickSlot(
                lastContainerScreen.getScreenHandler().syncId,
                slot.id,
                0,
                SlotActionType.PICKUP,
                client.player
        );
    }

    private static void updateContainerScreenAge(MinecraftClient client) {
        GenericContainerScreen screen = client.currentScreen instanceof GenericContainerScreen current
                ? current : null;
        if (screen != lastContainerScreen) {
            lastContainerScreen = screen;
            containerScreenTicks = screen == null ? 0 : 1;
        } else if (screen != null) {
            containerScreenTicks++;
        }
    }

    private static void afterWorldChange(MinecraftClient client, ClientWorld world) {
        if (pendingTeleport != null && world != null && isFlat(world)) {
            flatWorldLoads++;
        }
    }

    private static boolean isFlat(ClientWorld world) {
        return ((ClientWorldPropertiesAccessor) world.getLevelProperties()).celestial$isFlatWorld();
    }

    private static void parseServerMessage(String message) {
        try {
            if (message.contains("\u041F\u043E\u044F\u0432\u0438\u043B\u0441\u044F \u0442\u0430\u0439\u043D\u044B\u0439 \u0442\u043E\u0440\u0433\u043E\u0432\u0435\u0446:")) {
                String[] coordinates = message.substring(message.indexOf(":") + 2).split(" ");
                trader = new Trader(
                        Integer.parseInt(coordinates[0]),
                        Integer.parseInt(coordinates[1])
                );
            } else if (message.contains("\u041A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u044B")
                    && message.contains("\u0412\u0430\u0448\u0430 \u0446\u0435\u043B\u044C")) {
                if (message.contains("\u0412\u044B\u0448\u043B\u0430 c \u0441\u0435\u0440\u0432\u0435\u0440\u0430")) {
                    contract = null;
                    return;
                }
                if (message.contains("(") && message.contains(")")) {
                    String targetName = message.substring(
                            message.indexOf("-") + 1, message.indexOf("(") - 1);
                    String[] coordinates = message.substring(
                            message.indexOf("(") + 1, message.indexOf(")")
                    ).split(", ");
                    if (coordinates.length == 3
                            && isLegacyNumber(coordinates[0])
                            && isLegacyNumber(coordinates[1])
                            && isLegacyNumber(coordinates[2])) {
                        int x = Integer.parseInt(coordinates[0]);
                        int y = Integer.parseInt(coordinates[1]);
                        int z = Integer.parseInt(coordinates[2]);
                        sendDotWay(x, z);
                        contract = new Contract(targetName, x, y, z);
                    }
                }
            }
        } catch (Exception exception) {
            exception.printStackTrace();
            LegacyCommandFeedback.send(
                    "\u041E\u0448\u0438\u0431\u043A\u0430! \u041E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A\u0443 "
                            + "\u0437\u0430 \u0440\u0435\u0448\u0435\u043D\u0438\u0435\u043C \u043F\u0440\u043E\u0431\u043B\u0435\u043C\u044B");
        }
    }

    private static void sendDotWay(int x, int z) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.getNetworkHandler() != null) {
            client.getNetworkHandler().sendChatMessage(".way " + x + " " + z);
        }
    }

    private static void performImmediate(
            String selector, TeleportType type, float x, float y, float z
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            throw new IllegalStateException("client.player");
        }
        player.setVelocity(0.0, 0.0, 0.0);
        push(manualBurstDepth);
        try {
            sendBurst(player, type, x, y, z);
        } finally {
            pop(manualBurstDepth);
        }
        CompletableFuture.delayedExecutor(700L, TimeUnit.MILLISECONDS).execute(() ->
                client.execute(() -> finishImmediate(selector, x, z)));
    }

    private static void sendBurst(
            ClientPlayerEntity player, TeleportType type, float x, float y, float z
    ) {
        switch (type) {
            case NORMAL -> {
                for (int index = 0; index < 3; index++) {
                    sendPosition(player, x, y, z, true);
                    sendPosition(player, x, y - 3.0F, z, true);
                    sendPosition(player, x, y, z, true);
                }
                for (int index = 0; index < 12; index++) {
                    sendPosition(player, x, 500.0, z, true);
                    sendPosition(player, x, 500.0, z, true);
                }
                for (int index = 0; index < 12; index++) {
                    sendPosition(player, player.getX(), 500.0, player.getZ(), true);
                    sendPosition(player, player.getX(), 500.0, player.getZ(), true);
                }
            }
            case PLAYER -> {
                sendPosition(player, x, y, z, false);
                sendPosition(player, x, y, z, true);
                for (int index = 0; index < 41; index++) {
                    sendPosition(player, x, y + 2.0E7F, z, true);
                }
            }
            case MEGA -> {
                for (int index = 0; index < 3; index++) {
                    sendPosition(player, x, y, z, true);
                    sendPosition(player, x, y - 3.0F, z, true);
                    sendPosition(player, x, y, z, true);
                }
                for (int index = 0; index < 12; index++) {
                    sendPosition(player, x, y, z, true);
                    sendPosition(player, x, y, z, true);
                }
                for (int index = 0; index < 12; index++) {
                    sendPosition(player, player.getX(), y, player.getZ(), true);
                    sendPosition(player, player.getX(), y, player.getZ(), true);
                }
            }
        }
    }

    private static void sendPosition(
            ClientPlayerEntity player, double x, double y, double z, boolean onGround
    ) {
        player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                x, y, z, onGround, player.horizontalCollision));
    }

    private static void finishImmediate(String selector, float x, float z) {
        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        if (player == null) {
            return;
        }
        verticalRetryOffset = horizontalDistance(player, x, z) > 10.0
                ? verticalRetryOffset + 1.0F : 0.0F;
        if (client.world != null && isFlat(client.world)) {
            useCompass(true);
            hubSelector = selector;
        }
    }

    private static double horizontalDistance(ClientPlayerEntity player, double x, double z) {
        return Math.hypot(player.getX() - x, player.getZ() - z);
    }

    private static void captureReallyWorldTeamIds(MinecraftClient client) {
        if (client.world == null) {
            return;
        }
        for (String teamName : client.world.getScoreboard().getTeamNames()) {
            if (REALLY_WORLD_TEAM_IDS.contains(teamName)) {
                seenReallyWorldTeamIds.add(teamName);
            }
        }
    }

    private static boolean isPlayerHead(ItemStack stack) {
        return stack.getItem() instanceof BlockItem blockItem
                && blockItem.getBlock() instanceof AbstractSkullBlock;
    }

    private static String lettersOnly(String value) {
        return value.replaceAll("[^a-zA-Z\u0430-\u044F\u0410-\u042F]", "");
    }

    private static void resetConnectionState() {
        contract = null;
        seenReallyWorldTeamIds.clear();
        lastContainerScreen = null;
        containerScreenTicks = 0;
    }

    private static void push(ThreadLocal<Integer> depth) {
        depth.set(depth.get() + 1);
    }

    private static void pop(ThreadLocal<Integer> depth) {
        int next = depth.get() - 1;
        if (next <= 0) {
            depth.remove();
        } else {
            depth.set(next);
        }
    }

    public enum TeleportType {
        NORMAL,
        PLAYER,
        MEGA
    }

    public record Contract(String targetName, int x, int y, int z) {
    }

    public record Trader(int x, int z) {
    }

    private record PendingTeleport(TeleportType type, float x, float y, float z) {
    }
}
