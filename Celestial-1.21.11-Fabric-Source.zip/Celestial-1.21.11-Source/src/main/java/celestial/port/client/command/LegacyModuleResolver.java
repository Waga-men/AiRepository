package celestial.port.client.command;

import celestial.port.CelestialPortClient;
import celestial.port.core.Module;
import celestial.port.core.setting.Setting;

import java.util.Locale;
import java.util.Optional;

public final class LegacyModuleResolver {
    private LegacyModuleResolver() {
    }

    public static Optional<Module> module(String suppliedName) {
        if (suppliedName == null) {
            return Optional.empty();
        }
        String sought = compact(suppliedName);
        return CelestialPortClient.MODULES.modules().stream()
                .filter(module -> compact(module.displayName()).equals(sought)
                        || compact(module.id()).equals(sought))
                .findFirst();
    }

    public static Optional<Setting<?>> setting(Module module, String suppliedName) {
        if (module == null || suppliedName == null) {
            return Optional.empty();
        }
        String displayName = suppliedName.replace('_', ' ');
        return module.settings().stream()
                .filter(setting -> setting.displayName().equalsIgnoreCase(displayName))
                .findFirst();
    }

    public static String legacyName(Module module) {
        return module.displayName().replace(" ", "");
    }

    private static String compact(String value) {
        return value.toLowerCase(Locale.ROOT)
                .replace(" ", "")
                .replace("_", "")
                .replace("-", "");
    }
}
