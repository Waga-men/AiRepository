package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import net.minecraft.block.BlockState;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.screen.ingame.CreativeInventoryScreen;
import net.minecraft.client.gui.screen.ingame.HandledScreen;
import net.minecraft.client.gui.screen.ingame.InventoryScreen;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.shape.VoxelShape;

public final class VClipCommand implements LegacyDotCommandDispatcher.Command {
    private static final int EQUIPPED_ELYTRA = -2;

    @Override
    public String name() {
        return "vclip";
    }

    @Override
    public String description() {
        return "\u041a\u043b\u0438\u043f\u0430\u0435\u0442 \u0432\u0430\u0441 \u043d\u0430 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u0443\u044e \u0432\u0430\u043c\u0438 \u043f\u043e\u0437\u0438\u0446\u0438\u044e \u043f\u043e \u0432\u0435\u0440\u0442\u0438\u043a\u0430\u043b\u0438";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length == 0) {
            usage();
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        ClientPlayerEntity player = client.player;
        int elytra = findElytra(client, player);
        float amount = 0.0F;
        double targetY = 0.0;
        String argument = arguments[0];

        if (isLegacyNumber(argument)) {
            preparatoryGroup(player, elytra);
            amount = Float.parseFloat(argument);
            preparatoryGroup(player, elytra);
            targetY = player.getY() + amount;
        } else if (argument.equalsIgnoreCase("up")) {
            if (elytra == -1) {
                groundPulse(player);
            }
            boolean found = false;
            for (double candidate = player.getY() + 2.0; candidate < 255.0; candidate += 0.5) {
                if (canStandAt(player, candidate)) {
                    amount = (float) candidate;
                    found = true;
                    break;
                }
            }
            if (!found) {
                LegacyCommandFeedback.send("\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043d\u0430\u0439\u0442\u0438 \u0431\u043b\u043e\u043a \u0432\u044b\u0448\u0435 \u0432\u0430\u0441!");
                return;
            }
            groundPulse(player);
            targetY = amount;
        } else if (argument.equalsIgnoreCase("bd")) {
            if (elytra == -1) {
                groundPulse(player);
            }
            amount = (float) -player.getHeight();
            groundPulse(player);
            targetY = amount;
        } else if (argument.equalsIgnoreCase("down")) {
            DownTarget target = findDownTarget(player);
            if (target == null) {
                LegacyCommandFeedback.send("\u041d\u0435 \u0443\u0434\u0430\u043b\u043e\u0441\u044c \u043d\u0430\u0439\u0442\u0438 \u0431\u043b\u043e\u043a \u043f\u043e\u0434 \u0432\u0430\u043c\u0438!");
                return;
            }
            if (elytra == -1) {
                groundPulse(player);
            }
            amount = (float) (target.position().getY() + target.height());
            groundPulse(player);
            targetY = amount;
        }

        if (targetY == 0.0) {
            return;
        }

        double x = player.getX();
        double z = player.getZ();
        if (elytra != -1) {
            boolean swap = elytra != EQUIPPED_ELYTRA;
            if (swap) {
                click(client, player, elytra);
                click(client, player, 6);
            }
            sendPosition(player, x, player.getY(), z);
            sendPosition(player, x, player.getY(), z);
            player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                    player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            sendPosition(player, x, targetY, z);
            player.networkHandler.sendPacket(new ClientCommandC2SPacket(
                    player, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
            if (swap) {
                click(client, player, 6);
                click(client, player, elytra);
            }
        } else {
            int filler = MathHelper.clamp((int) Math.abs(amount / 11.0F), 0, 19);
            for (int index = 0; index < filler; index++) {
                player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(false, false));
            }
            sendPosition(player, x, targetY, z);
        }
        player.setPosition(x, targetY, z);
    }

    private static int findElytra(MinecraftClient client, ClientPlayerEntity player) {
        if (player.getEquippedStack(EquipmentSlot.CHEST).isOf(Items.ELYTRA)) {
            return EQUIPPED_ELYTRA;
        }
        if (client.currentScreen instanceof HandledScreen<?>
                && !(client.currentScreen instanceof InventoryScreen)
                && !(client.currentScreen instanceof CreativeInventoryScreen)) {
            return -1;
        }
        PlayerInventory inventory = player.getInventory();
        for (int inventorySlot = 0; inventorySlot < inventory.size(); inventorySlot++) {
            ItemStack stack = inventory.getStack(inventorySlot);
            if (!stack.isOf(Items.ELYTRA)
                    || !LivingEntity.canGlideWith(stack, EquipmentSlot.CHEST)) {
                continue;
            }
            return player.playerScreenHandler
                    .getSlotIndex(inventory, inventorySlot).orElse(-1);
        }
        return -1;
    }

    private static boolean canStandAt(ClientPlayerEntity player, double y) {
        Box target = player.getBoundingBox().offset(0.0, y - player.getY(), 0.0);
        return player.getEntityWorld().isSpaceEmpty(player, target)
                && !player.getEntityWorld().isSpaceEmpty(player, target.offset(0.0, -0.5, 0.0));
    }

    private static DownTarget findDownTarget(ClientPlayerEntity player) {
        for (double candidate = player.getY() - 2.0; candidate > 0.0; candidate -= 1.0) {
            BlockPos position = BlockPos.ofFloored(player.getX(), candidate, player.getZ());
            BlockState state = player.getEntityWorld().getBlockState(position)
                    .getBlock().getDefaultState();
            VoxelShape shape = state.getOutlineShape(player.getEntityWorld(), position);

            double height;
            if (shape.isEmpty()) {
                height = 1.0;
            } else {
                Box bounds = shape.getBoundingBox();
                height = bounds.maxY - bounds.minY;
            }
            if (canStandAt(player, candidate + height)) {
                return new DownTarget(position, height);
            }
        }
        return null;
    }

    private static void preparatoryGroup(ClientPlayerEntity player, int elytra) {
        if (elytra == -1) {
            groundPulse(player);
            return;
        }
        player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(false, false));
        player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(false, false));
    }

    private static void groundPulse(ClientPlayerEntity player) {
        for (int index = 0; index < 5; index++) {
            player.networkHandler.sendPacket(new PlayerMoveC2SPacket.OnGroundOnly(true, false));
        }
    }

    private static void sendPosition(ClientPlayerEntity player, double x, double y, double z) {
        player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                x, y, z, false, false));
    }

    private static void click(MinecraftClient client, ClientPlayerEntity player, int slot) {
        client.interactionManager.clickSlot(player.playerScreenHandler.syncId,
                slot, 1, SlotActionType.PICKUP, player);
    }

    /** Apache Commons Lang 3.5 {@code NumberUtils.isNumber}, used by vr_0. */
    private static boolean isLegacyNumber(String value) {
        if (value == null || value.isEmpty()) {
            return false;
        }
        char[] chars = value.toCharArray();
        int size = chars.length;
        int start = chars[0] == '-' || chars[0] == '+' ? 1 : 0;
        if (size > start + 1 && chars[start] == '0') {
            if (chars[start + 1] == 'x' || chars[start + 1] == 'X') {
                int index = start + 2;
                if (index == size) {
                    return false;
                }
                for (; index < chars.length; index++) {
                    char character = chars[index];
                    if ((character < '0' || character > '9')
                            && (character < 'a' || character > 'f')
                            && (character < 'A' || character > 'F')) {
                        return false;
                    }
                }
                return true;
            }
            if (Character.isDigit(chars[start + 1])) {
                for (int index = start + 1; index < chars.length; index++) {
                    if (chars[index] < '0' || chars[index] > '7') {
                        return false;
                    }
                }
                return true;
            }
        }

        size--;
        int index = start;
        boolean hasExponent = false;
        boolean hasDecimalPoint = false;
        boolean allowSigns = false;
        boolean foundDigit = false;
        while (index < size || index < size + 1 && allowSigns && !foundDigit) {
            char character = chars[index];
            if (character >= '0' && character <= '9') {
                foundDigit = true;
                allowSigns = false;
            } else if (character == '.') {
                if (hasDecimalPoint || hasExponent) {
                    return false;
                }
                hasDecimalPoint = true;
            } else if (character == 'e' || character == 'E') {
                if (hasExponent || !foundDigit) {
                    return false;
                }
                hasExponent = true;
                allowSigns = true;
            } else if (character == '+' || character == '-') {
                if (!allowSigns) {
                    return false;
                }
                allowSigns = false;
                foundDigit = false;
            } else {
                return false;
            }
            index++;
        }
        if (index < chars.length) {
            char character = chars[index];
            if (character >= '0' && character <= '9') {
                return true;
            }
            if (character == 'e' || character == 'E') {
                return false;
            }
            if (character == '.') {
                return !hasDecimalPoint && !hasExponent && foundDigit;
            }
            if (!allowSigns && (character == 'd' || character == 'D'
                    || character == 'f' || character == 'F')) {
                return foundDigit;
            }
            if (character == 'l' || character == 'L') {
                return foundDigit && !hasExponent && !hasDecimalPoint;
            }
            return false;
        }
        return !allowSigns && foundDigit;
    }

    private static void usage() {
        LegacyCommandFeedback.send("\u041d\u0435\u0432\u0435\u0440\u043d\u0430\u044f \u043a\u043e\u043c\u0430\u043d\u0434\u0430! \u041f\u043e\u0436\u0430\u043b\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435:");
        LegacyCommandFeedback.send("vclip \u00A7c\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435 \u00A77(\u043a\u043b\u0438\u043f\u0430\u0435\u0442 \u0432\u0430\u0441 \u0432\u0432\u0435\u0440\u0445 \u043d\u0430 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u0435 \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435)");
        LegacyCommandFeedback.send("vclip \u00A7c-\u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435 \u00A77(\u043a\u043b\u0438\u043f\u0430\u0435\u0442 \u0432\u0430\u0441 \u0432\u043d\u0438\u0437 \u043d\u0430 \u0432\u044b\u0431\u0440\u0430\u043d\u043d\u043e\u0435 \u0437\u043d\u0430\u0447\u0435\u043d\u0438\u0435)");
        LegacyCommandFeedback.send("vclip \u00A7cup \u00A77(\u0438\u0449\u0435\u0442 \u043e\u043f\u0442\u0438\u043c\u0430\u043b\u044c\u043d\u0443\u044e \u0432\u044b\u0441\u043e\u0442\u0443 \u0434\u043b\u044f \u043a\u043b\u0438\u043f\u0430 \u0432\u0432\u0435\u0440\u0445)");
        LegacyCommandFeedback.send("vclip \u00A7cdown \u00A77(\u0438\u0449\u0435\u0442 \u043e\u043f\u0442\u0438\u043c\u0430\u043b\u044c\u043d\u0443\u044e \u0432\u044b\u0441\u043e\u0442\u0443 \u0434\u043b\u044f \u043a\u043b\u0438\u043f\u0430 \u0432\u043d\u0438\u0437)");
        LegacyCommandFeedback.send("vclip \u00A7cbd \u00A77(\u043a\u043b\u0438\u043f\u0430\u0435\u0442 \u0432\u0430\u0441 \u043f\u043e\u0434 \u0431\u0435\u0434\u0440\u043e\u043a)");
    }

    private record DownTarget(BlockPos position, double height) {
    }
}
