package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.modules.legacyutility.AutoWay;

public final class WayCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "way";
    }

    @Override
    public String description() {
        return "\u041F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u043F\u0443\u0442\u044C \u0434\u043E \u043A\u043E\u043E\u0440\u0434\u0438\u043D\u0430\u0442";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length < 1) {
            LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430! "
                    + "\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435:");
            LegacyCommandFeedback.send("way \u00A7c[x] [z]");
            LegacyCommandFeedback.send("way \u00A7cstop/off");
            return;
        }
        if (arguments[0].equalsIgnoreCase("stop") || arguments[0].equalsIgnoreCase("off")) {
            AutoWay.stopManualWaypoint();
            return;
        }
        try {
            if (!arguments[0].isEmpty() || !arguments[1].isEmpty()) {
                AutoWay.setManualWaypoint(
                        Long.parseLong(arguments[0]), Long.parseLong(arguments[1]));
            }
        } catch (ArrayIndexOutOfBoundsException | NumberFormatException exception) {
            LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u043A\u043E\u043E\u0440\u0434\u0438\u043D\u0430\u0442!");
        }
    }
}
