package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.modules.player.NameProtectModule;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.scoreboard.Team;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import net.minecraft.world.GameMode;

import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class ParseCommand implements LegacyDotCommandDispatcher.Command {
    private static final Comparator<PlayerListEntry> TAB_ORDER = Comparator
            .comparing((PlayerListEntry entry) -> entry.getGameMode() == GameMode.SPECTATOR)
            .thenComparing(ParseCommand::teamName, String.CASE_INSENSITIVE_ORDER)
            .thenComparing(entry -> entry.getProfile().name(), String.CASE_INSENSITIVE_ORDER);

    @Override
    public String name() {
        return "parse";
    }

    @Override
    public String description() {
        return "\u0411\u0435\u0440\u0435\u0442 \u0432\u0441\u0435\u0445 \u0434\u043e\u043d\u0430\u0442\u0435\u0440\u043e\u0432 \u0438\u0437 \u0442\u0430\u0431\u0430 \u0438 "
                + "\u043f\u0430\u0440\u0441\u0438\u0442 \u0438\u0445 \u0432 \u0444\u0430\u0439\u043b";
    }

    @Override
    public void execute(String[] arguments) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.isInSingleplayer()) {
            LegacyCommandFeedback.send("\u042D\u0442\u0430 \u043A\u043E\u043C\u0430\u043D\u0434\u0430 \u043D\u0435 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0432 "
                    + "\u043E\u0434\u0438\u043D\u043E\u0447\u043D\u043E\u0439 \u0438\u0433\u0440\u0435!");
            return;
        }

        Map<String, List<String>> groups = new HashMap<>();
        List<PlayerListEntry> entries = new ArrayList<>(
                client.getNetworkHandler().getListedPlayerListEntries());
        entries.sort(TAB_ORDER);
        String self = client.player.getGameProfile().name();
        String alias = NameProtectModule.configuredAlias();
        for (PlayerListEntry entry : entries) {
            String username = entry.getProfile().name();
            String display = entry.getDisplayName() == null
                    ? Team.decorateName(entry.getScoreboardTeam(), Text.literal(username)).getString()
                    : entry.getDisplayName().getString();
            String[] words = display.split(" ");
            if (words.length < 2) {
                continue;
            }
            String rank = words[0];
            if (username.equals(self) || username.equals(alias)
                    || rank.equalsIgnoreCase(username)) {
                continue;
            }
            groups.computeIfAbsent(rank, ignored -> new ArrayList<>()).add(username);
        }

        if (groups.isEmpty()) {
            LegacyCommandFeedback.send("\u0412 \u0442\u0430\u0431\u0435 \u043d\u0435\u0442 \u0434\u043e\u043d\u0430\u0442\u0435\u0440\u043e\u0432!");
            return;
        }

        try {
            Path directory = FabricLoader.getInstance().getGameDir()
                    .resolve("Celestial").resolve("parse");
            Files.createDirectories(directory);
            String server = client.getCurrentServerEntry().address;
            int number = 1;
            Path output = directory.resolve(server + "#" + number + ".txt");
            while (Files.exists(output)) {
                output = directory.resolve(server + "#" + ++number + ".txt");
            }

            Util.getOperatingSystem().open(output);
            StringBuilder contents = new StringBuilder();
            groups.forEach((rank, names) -> {
                contents.append(rank).append(':').append('\n');
                names.forEach(name -> contents.append(name).append('\n'));
                contents.append('\n');
            });
            try (BufferedWriter writer = Files.newBufferedWriter(output, Charset.defaultCharset())) {
                writer.write(contents.substring(0, contents.length() - 2));
            }
            LegacyCommandFeedback.send("\u0424\u0430\u0439\u043B " + output.getFileName()
                    + " \u0443\u0441\u043F\u0435\u0448\u043D\u043E \u0441\u043E\u0437\u0434\u0430\u043D!");
        } catch (Exception exception) {
            exception.printStackTrace();
            LegacyCommandFeedback.send("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0441\u043E\u0437\u0434\u0430\u043D\u0438\u0438 \u0444\u0430\u0439\u043B\u0430! "
                    + "\u041E\u0431\u0440\u0430\u0442\u0438\u0442\u0435\u0441\u044C \u043A \u0440\u0430\u0437\u0440\u0430\u0431\u043E\u0442\u0447\u0438\u043A\u0443!");
        }
    }

    private static String teamName(PlayerListEntry entry) {
        return entry.getScoreboardTeam() == null ? "" : entry.getScoreboardTeam().getName();
    }
}
