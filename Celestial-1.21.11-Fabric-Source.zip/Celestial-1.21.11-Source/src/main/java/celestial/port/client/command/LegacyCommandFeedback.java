package celestial.port.client.command;

import net.minecraft.client.MinecraftClient;
import net.minecraft.text.MutableText;
import net.minecraft.text.Style;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

import java.util.Objects;

public final class LegacyCommandFeedback {
    private static final Style INITIAL_BODY_STYLE = Style.EMPTY
            .withColor(Formatting.WHITE)
            .withBold(true);

    private LegacyCommandFeedback() {
    }

    public static void send(String legacyFormattedBody) {
        var player = Objects.requireNonNull(
                MinecraftClient.getInstance().player, "client.player");
        player.sendMessage(prefixed(parse(legacyFormattedBody, INITIAL_BODY_STYLE)), false);
    }

    public static MutableText prefixed(Text body) {
        return Text.empty()
                .append(Text.literal("(").formatted(Formatting.GRAY))
                .append(Text.literal("Celestial").formatted(Formatting.LIGHT_PURPLE))
                .append(Text.literal(") ").formatted(Formatting.GRAY))
                .append(Text.literal("\u00BB ").formatted(Formatting.DARK_GRAY))
                .append(body);
    }

    public static MutableText parse(String value, Style initialStyle) {
        Objects.requireNonNull(value, "value");
        MutableText result = Text.empty();
        Style style = Objects.requireNonNull(initialStyle, "initialStyle");
        int start = 0;
        for (int index = 0; index + 1 < value.length(); index++) {
            if (value.charAt(index) != '§') {
                continue;
            }
            if (index > start) {
                result.append(Text.literal(value.substring(start, index)).setStyle(style));
            }
            Formatting formatting = Formatting.byCode(value.charAt(index + 1));
            if (formatting != null) {
                if (formatting == Formatting.RESET) {
                    style = Style.EMPTY;
                } else if (formatting.isColor()) {

                    style = Style.EMPTY.withColor(formatting);
                } else {
                    style = style.withFormatting(formatting);
                }
            }
            index++;
            start = index + 1;
        }
        if (start < value.length()) {
            result.append(Text.literal(value.substring(start)).setStyle(style));
        }
        return result;
    }
}
