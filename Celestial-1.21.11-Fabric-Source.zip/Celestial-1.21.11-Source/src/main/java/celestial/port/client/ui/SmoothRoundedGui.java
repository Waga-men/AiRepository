package celestial.port.client.ui;

import net.minecraft.client.gui.DrawContext;

public final class SmoothRoundedGui {
    private static final float DEFAULT_NOISE_STRENGTH = 10.0f;

    private SmoothRoundedGui() {
    }

    public static void fill(
            DrawContext context, int x, int y, int width, int height,
            float radius, int color
    ) {
        fillFourCorners(context, x, y, width, height, radius,
                color, color, color, color);
    }

    public static void fillVertical(
            DrawContext context, int x, int y, int width, int height,
            float radius, int top, int bottom
    ) {
        fillFourCorners(context, x, y, width, height, radius,
                top, top, bottom, bottom);
    }

    public static void fillFourCorners(
            DrawContext context, int x, int y, int width, int height,
            float radius, int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        LegacySdfGui.fill(context, x, y, width, height, radius,
                topLeft, topRight, bottomRight, bottomLeft);
    }

    public static void fillNoise(
            DrawContext context, int x, int y, int width, int height,
            float radius, int color
    ) {
        fillNoise(context, x, y, width, height, radius,
                DEFAULT_NOISE_STRENGTH, color);
    }

    public static void fillNoise(
            DrawContext context, int x, int y, int width, int height,
            float radius, float noiseStrength, int color
    ) {
        fillNoiseFourCorners(context, x, y, width, height, radius, noiseStrength,
                color, color, color, color);
    }

    public static void fillNoiseFourCorners(
            DrawContext context, int x, int y, int width, int height,
            float radius, float noiseStrength,
            int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        LegacySdfGui.fillNoise(context, x, y, width, height, radius, noiseStrength,
                topLeft, topRight, bottomRight, bottomLeft);
    }

    public static void fillGlow(
            DrawContext context, int x, int y, int width, int height,
            float radius, float glowRadius, int color
    ) {
        fillGlowFourCorners(context, x, y, width, height, radius, glowRadius,
                color, color, color, color);
    }

    public static void fillGlowFourCorners(
            DrawContext context, int x, int y, int width, int height,
            float radius, float glowRadius,
            int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        LegacySdfGui.fillGlow(context, x, y, width, height, radius, glowRadius,
                topLeft, topRight, bottomRight, bottomLeft);
    }
}
