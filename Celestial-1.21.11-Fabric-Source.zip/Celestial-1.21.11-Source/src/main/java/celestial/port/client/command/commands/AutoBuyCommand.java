package celestial.port.client.command.commands;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.modules.legacyutility.AutoBuy;
import net.minecraft.client.MinecraftClient;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.text.Style;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class AutoBuyCommand implements LegacyDotCommandDispatcher.Command {
    private static final Map<Integer, Identifier> LEGACY_ENCHANTMENTS = Map.ofEntries(
            enchant(0, "protection"), enchant(1, "fire_protection"),
            enchant(2, "feather_falling"), enchant(3, "blast_protection"),
            enchant(4, "projectile_protection"), enchant(5, "respiration"),
            enchant(6, "aqua_affinity"), enchant(7, "thorns"),
            enchant(8, "depth_strider"), enchant(9, "frost_walker"),
            enchant(10, "binding_curse"), enchant(16, "sharpness"),
            enchant(17, "smite"), enchant(18, "bane_of_arthropods"),
            enchant(19, "knockback"), enchant(20, "fire_aspect"),
            enchant(21, "looting"), enchant(22, "sweeping_edge"),
            enchant(32, "efficiency"), enchant(33, "silk_touch"),
            enchant(34, "unbreaking"), enchant(35, "fortune"),
            enchant(48, "power"), enchant(49, "punch"),
            enchant(50, "flame"), enchant(51, "infinity"),
            enchant(61, "luck_of_the_sea"), enchant(62, "lure"),
            enchant(70, "mending"), enchant(71, "vanishing_curse")
    );

    @Override
    public String name() {
        return "ab";
    }

    @Override
    public String description() {
        return "\u0410\u0432\u0442\u043e\u043c\u0430\u0442\u0438\u0447\u0435\u0441\u043a\u0438 \u043f\u043e\u043a\u0443\u043f\u0430\u0435\u0442 \u0432\u0435\u0449\u0438 \u0441 \u0430\u0443\u043a\u0446\u0438\u043e\u043d\u0430 \u043f\u043e \u0432\u044b\u0433\u043e\u0434\u043d\u043e\u0439 \u0446\u0435\u043d\u0435";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length == 0) {
            usage();
            return;
        }

        AutoBuy autoBuy = (AutoBuy) CelestialPortClient.MODULES.require("auto_buy");
        switch (arguments[0].toLowerCase(Locale.ROOT)) {
            case "add" -> add(autoBuy, arguments);
            case "remove", "delete" -> remove(autoBuy, arguments);
            case "clear" -> clear(autoBuy);
            case "list" -> list(autoBuy);
            case "delay" -> delay(autoBuy, arguments);
            default -> LegacyCommandFeedback.send(
                    "\u0418\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435 - add | remove | clear | list");
        }
    }

    private static void add(AutoBuy autoBuy, String[] arguments) {
        try {
            Item item = findItem(arguments[1]);
            if (item == null || item == Items.AIR) {
                throw new NullPointerException("item");
            }

            boolean countOmitted = arguments.length == 3 || arguments[3].contains("(");
            int enchantmentStart = countOmitted ? 3 : 4;
            HashMap<Integer, Integer> legacyEnchantments = new HashMap<>();
            for (int index = enchantmentStart; index < arguments.length; index++) {
                ParsedEnchantment parsed = parseEnchantment(arguments[index]);
                legacyEnchantments.put(parsed.legacyId(), parsed.level());
            }

            LinkedHashMap<Identifier, Integer> enchantments = new LinkedHashMap<>();
            for (Map.Entry<Integer, Integer> entry : legacyEnchantments.entrySet()) {
                Identifier modernId = LEGACY_ENCHANTMENTS.get(entry.getKey());
                Enchantment enchantment = findEnchantment(modernId);
                if (enchantment == null) {
                    LegacyCommandFeedback.send(
                            "\u0422\u0430\u043a\u043e\u0433\u043e \u0437\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u0438\u044f \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d\u043e!");
                    return;
                }
                if (entry.getValue() > enchantment.getMaxLevel()) {
                    LegacyCommandFeedback.send(
                            "\u0423\u0440\u043e\u0432\u0435\u043d\u044c \u0437\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u0438\u044f \u00A7c"
                                    + enchantment.description().getString()
                                    + "\u00A77 \u043d\u0435 \u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c \u0431\u043e\u043b\u044c\u0448\u0435 \u00A7c"
                                    + enchantment.getMaxLevel());
                    return;
                }
                enchantments.put(modernId, entry.getValue());
            }

            long count = item.getMaxCount() == 1 || countOmitted
                    ? 1L : Long.parseLong(arguments[2]);
            long price = Long.parseLong(arguments[countOmitted ? 2 : 3]);
            boolean updated = autoBuy.upsertLegacyCommandEntry(item, count, price, enchantments);
            LegacyCommandFeedback.send("\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u00A7c"
                    + item.getName().getString() + "\u00A7f "
                    + (updated ? "\u043e\u0431\u043d\u043e\u0432\u043b\u0435\u043d!" : "\u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0432 \u0441\u043f\u0438\u0441\u043e\u043a!"));
        } catch (NullPointerException exception) {
            LegacyCommandFeedback.send("\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d!");
        } catch (NumberFormatException exception) {
            LegacyCommandFeedback.send(
                    "\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u0444\u043e\u0440\u043c\u0430\u0442 \u0440\u0430\u0437\u043c\u0435\u0440\u0430 \u0438\u043b\u0438 \u0432\u0440\u0435\u043c\u0435\u043d\u0438!");
        } catch (ArrayIndexOutOfBoundsException exception) {
            LegacyCommandFeedback.send("\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u0444\u043e\u0440\u043c\u0430\u0442 \u0430\u0440\u0433\u0443\u043c\u0435\u043d\u0442\u043e\u0432!");
        }
    }

    private static void remove(AutoBuy autoBuy, String[] arguments) {
        try {
            Item item = findItem(arguments[1]);
            if (item == null || item == Items.AIR) {
                throw new NullPointerException("item");
            }
            if (autoBuy.removeLegacyCommandEntry(item)) {
                LegacyCommandFeedback.send("\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u00A7c"
                        + item.getName().getString() + "\u00A7f \u0443\u0434\u0430\u043b\u0435\u043d \u0438\u0437 \u0441\u043f\u0438\u0441\u043a\u0430!");
            } else {
                LegacyCommandFeedback.send("\u041f\u0440\u0435\u0434\u043c\u0435\u0442 \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d \u0432 \u0441\u043f\u0438\u0441\u043a\u0435!");
            }
        } catch (NullPointerException exception) {
            LegacyCommandFeedback.send(
                    "\u041d\u0435\u0432\u0435\u0440\u043d\u0430\u044f \u043a\u043e\u043c\u0430\u043d\u0434\u0430! \u041f\u043e\u0436\u0430\u043b\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435:");
            LegacyCommandFeedback.send("autobuy \u00A7cremove \u00A7f<item> (\u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0432\u0435\u0449\u044c)");
        } catch (ArrayIndexOutOfBoundsException exception) {
            LegacyCommandFeedback.send("\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u0444\u043e\u0440\u043c\u0430\u0442 \u0430\u0440\u0433\u0443\u043c\u0435\u043d\u0442\u043e\u0432!");
        }
    }

    private static void clear(AutoBuy autoBuy) {
        if (autoBuy.entries().isEmpty()) {
            LegacyCommandFeedback.send("\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0443\u0441\u0442!");
            return;
        }
        autoBuy.clearEntries();
        LegacyCommandFeedback.send("\u0421\u043f\u0438\u0441\u043e\u043a \u043e\u0447\u0438\u0449\u0435\u043d!");
    }

    private static void list(AutoBuy autoBuy) {
        List<AutoBuy.Entry> entries = autoBuy.entries();
        if (entries.isEmpty()) {
            LegacyCommandFeedback.send("\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0443\u0441\u0442!");
            return;
        }
        LegacyCommandFeedback.send("\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u043e\u0432:");
        MinecraftClient client = MinecraftClient.getInstance();
        for (int index = 0; index < entries.size(); index++) {
            AutoBuy.Entry entry = entries.get(index);
            String raw = "\u041f\u0440\u0435\u0434\u043c\u0435\u0442 - \u00A7c" + entry.item().getName().getString()
                    + "\n\u00A7f\u041a\u043e\u043b\u0438\u0447\u0435\u0441\u0442\u0432\u043e - \u00A7c" + entry.minimumCount()
                    + "\n\u00A7f\u041c\u0430\u043a\u0441. \u0446\u0435\u043d\u0430 - \u00A7c" + entry.maximumPrice()
                    + "\n\u00A7f\u0417\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u0438\u044f - " + enchantmentSummary(entry);
            if (index + 1 < entries.size()) {
                raw += "\n";
            }
            client.player.sendMessage(LegacyCommandFeedback.parse(raw, Style.EMPTY), false);
        }
    }

    private static void delay(AutoBuy autoBuy, String[] arguments) {
        if (arguments.length < 2) {
            LegacyCommandFeedback.send("\u0421\u0435\u0439\u0447\u0430\u0441 \u0441\u0442\u043e\u0438\u0442 \u0437\u0430\u0434\u0435\u0440\u0436\u043a\u0430: \u00A7c"
                    + (float) autoBuy.clickDelayMs() + "\u00A77 \u043c\u0438\u043b\u043b\u0438\u0441\u0435\u043a\u0443\u043d\u0434");
            return;
        }
        try {
            int delay = Integer.parseInt(arguments[1]);
            if (delay > 1000) {
                LegacyCommandFeedback.send("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043d\u0435 \u043c\u043e\u0436\u0435\u0442 \u0431\u044b\u0442\u044c \u0431\u043e\u043b\u044c\u0448\u0435 1000!");
                return;
            }
            autoBuy.setClickDelayMs(delay);
            LegacyCommandFeedback.send("\u0417\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u0443\u0441\u0442\u0430\u043d\u043e\u0432\u043b\u0435\u043d\u0430 \u043d\u0430 \u00A7c"
                    + delay + "\u00A77 \u043c\u0438\u043b\u043b\u0438\u0441\u0435\u043a\u0443\u043d\u0434");
        } catch (NumberFormatException exception) {
            LegacyCommandFeedback.send("\u041d\u0435\u0432\u0435\u0440\u043d\u044b\u0439 \u0444\u043e\u0440\u043c\u0430\u0442 \u0437\u0430\u0434\u0435\u0440\u0436\u043a\u0438!");
        }
    }

    private static String enchantmentSummary(AutoBuy.Entry entry) {
        if (entry.enchantments().isEmpty()) {
            return "\u00A7c\u041f\u0443\u0441\u0442\u043e";
        }
        List<String> result = new ArrayList<>();
        entry.enchantments().forEach((id, level) -> {
            Enchantment enchantment = findEnchantment(id);
            if (enchantment == null) {
                return;
            }
            String description = enchantment.description().getString();
            String prefix = description.substring(0, Math.min(2, description.length()));
            result.add("\u00A7c" + prefix + (level == 1 ? "" : level));
        });
        result.sort(Comparator.naturalOrder());
        return result.isEmpty() ? "\u00A7c\u041f\u0443\u0441\u0442\u043e" : String.join(", ", result);
    }

    private static ParsedEnchantment parseEnchantment(String token) {
        String[] parts = token.split("\\(");
        int legacyId = Integer.parseInt(parts[0]);
        int level = Integer.parseInt(parts.length <= 1
                ? "-1" : parts[1].replace(")", ""));
        return new ParsedEnchantment(legacyId, level);
    }

    private static Item findItem(String raw) {
        Identifier id = Identifier.tryParse(raw.contains(":") ? raw : "minecraft:" + raw);
        return id != null && Registries.ITEM.containsId(id) ? Registries.ITEM.get(id) : null;
    }

    private static Enchantment findEnchantment(Identifier id) {
        if (id == null) {
            return null;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return null;
        }
        var registry = client.player.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
        for (var entry : registry.getEntrySet()) {
            if (entry.getKey().getValue().equals(id)) {
                return entry.getValue();
            }
        }
        return null;
    }

    private static Map.Entry<Integer, Identifier> enchant(int legacyId, String modernPath) {
        return Map.entry(legacyId, Identifier.ofVanilla(modernPath));
    }

    private static void usage() {
        LegacyCommandFeedback.send("\u041d\u0435\u0432\u0435\u0440\u043d\u0430\u044f \u043a\u043e\u043c\u0430\u043d\u0434\u0430! \u041f\u043e\u0436\u0430\u043b\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435:");
        LegacyCommandFeedback.send("ab \u00A7cadd \u00A7f<item> <count> <max price> <enchants> \u00A7f(\u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0432\u0435\u0449\u044c)");
        LegacyCommandFeedback.send("ab \u00A7cremove \u00A7f<item> (\u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0432\u0435\u0449\u044c)");
        LegacyCommandFeedback.send("ab \u00A7clist\u00A7f (\u043f\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a \u0432\u0441\u0435\u0445 \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u043e\u0432)");
        LegacyCommandFeedback.send("ab \u00A7cclear\u00A7f (\u043e\u0447\u0438\u0441\u0442\u0438\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a \u0432\u0441\u0435\u0445 \u043f\u0440\u0435\u0434\u043c\u0435\u0442\u043e\u0432)");
        LegacyCommandFeedback.send("ab \u00A7cdelay\u00A7f <delay> (\u0437\u0430\u0434\u0435\u0440\u0436\u043a\u0430 \u043d\u0430 \u043f\u043e\u043a\u0443\u043f\u043a\u0443 \u0432 \u043c\u0438\u043b\u043b\u0438\u0441\u0435\u043a\u0443\u043d\u0434\u0430\u0445)");
        LegacyCommandFeedback.send("\u041f\u0440\u0438\u043c\u0435\u0440: ab \u00A7cadd\u00A7f diamond_sword 10000 16(5)");
        LegacyCommandFeedback.send("10000 - \u043c\u0430\u043a\u0441. \u0446\u0435\u043d\u0430, 16 - id \u0437\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u0438\u044f, 5 - \u0443\u0440\u043e\u0432\u0435\u043d\u044c \u0437\u0430\u0447\u0430\u0440\u043e\u0432\u0430\u043d\u0438\u044f");
    }

    private record ParsedEnchantment(int legacyId, int level) {
    }
}
