package celestial.port.client.ui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.sound.PositionedSoundInstance;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

final class LegacyMenuRender {
    static final Identifier WALLPAPER = Identifier.of("celestial", "wallpaper.png");
    static final Identifier ATOM = Identifier.of("celestial", "images/atomwhite.png");
    static final Identifier MICROSOFT = Identifier.of("celestial", "images/altmanager/microsoft.png");
    static final Identifier MOJANG = Identifier.of("celestial", "images/altmanager/mojang.png");

    static final StyleSpriteSource FONT_DS = font(13);
    static final StyleSpriteSource FONT_DU = font(15);
    static final StyleSpriteSource FONT_DV = font(16);
    static final StyleSpriteSource FONT_DX = font(18);
    static final StyleSpriteSource FONT_DZ = font(25);
    static final StyleSpriteSource FONT_DA = font(30);

    private LegacyMenuRender() {
    }

    static void wallpaper(DrawContext context, int width, int height) {
        context.drawTexturedQuad(WALLPAPER, 0, 0, width, height,
                0.0f, 1.0f, 0.0f, 1.0f);
    }

    static void texture(
            DrawContext context, Identifier texture,
            int x, int y, int width, int height, int color
    ) {
        context.drawTexture(RenderPipelines.GUI_TEXTURED, texture,
                x, y, 0.0f, 0.0f, width, height, width, height, color);
    }

    static void textureRegion(
            DrawContext context, Identifier texture,
            int x, int y, int width, int height,
            float u, float v, int regionWidth, int regionHeight,
            int textureWidth, int textureHeight, int color
    ) {
        context.drawTexture(RenderPipelines.GUI_TEXTURED, texture,
                x, y, u, v, width, height, regionWidth, regionHeight,
                textureWidth, textureHeight, color);
    }

    static void rounded(
            DrawContext context, int x, int y, int width, int height,
            float radius, int color
    ) {
        SmoothRoundedGui.fill(context, x, y, width, height, radius, color);
    }

    static void fourCorners(
            DrawContext context, int x, int y, int width, int height,
            float radius, int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        SmoothRoundedGui.fillFourCorners(context, x, y, width, height, radius,
                topLeft, topRight, bottomRight, bottomLeft);
    }

    static void softShadow(
            DrawContext context, int x, int y, int width, int height,
            int radius, int blur, int color
    ) {
        SmoothRoundedGui.fillGlow(context, x, y, width, height,
                radius, blur, color);
    }

    static void button(
            DrawContext context, TextRenderer renderer,
            int x, int y, int width, int height, String label,
            boolean enabled, boolean hovered, float hoverProgress, boolean shaders
    ) {
        float progress = clamp(hoverProgress);
        if (shaders) {

            externalButtonShadow(context, x, y, width, height);
            if (enabled && progress > 0.0f) {
                int animatedWidth = Math.max(1, (int) (width * progress));
                int animatedX = (int) (x + width / 2.0f - animatedWidth / 2.0f);
                int alpha = (int) (progress * 127.5f);
                int first = withAlpha(0xFFC783FF, alpha);
                int second = withAlpha(0xFFB62EB9, alpha);
                fourCorners(context, animatedX, y, animatedWidth, height, 3,
                        first, first, second, second);
            }
        } else {
            rounded(context, x, y, width, height, 0,
                    enabled ? 0x7D0F0F0F : 0x7D050505);
        }

        int color = !enabled ? 0xFFA0A0A0 : hovered ? 0xFFFFFFA0 : 0xFFE0E0E0;

        float textX = x + width / 2.0f - width(renderer, label, FONT_DV) / 2.0f;

        float textY = y + (height - 11) / 2.0f + 0.5f;
        drawDenseButtonText(context, renderer, label,
                textX + 0.5f, textY + 0.5f,
                legacyShadowColor(color));
        drawDenseButtonText(context, renderer, label, textX, textY, color);
    }

    private static void drawDenseButtonText(
            DrawContext context, TextRenderer renderer, String label,
            float x, float y, int color
    ) {
        draw(context, renderer, label, x, y, color, FONT_DV);
        draw(context, renderer, label, x + 0.25f, y, color, FONT_DV);
    }

    private static int legacyShadowColor(int color) {
        return (color & 0x00FCFCFC) >> 2 | color & 0xC8141414;
    }

    private static void externalButtonShadow(
            DrawContext context, int x, int y, int width, int height
    ) {
        float scale = Math.max(1.0f,
                (float) MinecraftClient.getInstance().getWindow().getScaleFactor());
        float blur = 15.0f / scale;
        int padding = Math.max(2, (int) Math.ceil(blur + 1.0f));

        buttonShadowPart(context, x, y, width, height, blur,
                x - padding, y - padding, x + width + padding, y);
        buttonShadowPart(context, x, y, width, height, blur,
                x - padding, y + height, x + width + padding, y + height + padding);
        buttonShadowPart(context, x, y, width, height, blur,
                x - padding, y, x, y + height);
        buttonShadowPart(context, x, y, width, height, blur,
                x + width, y, x + width + padding, y + height);
    }

    private static void buttonShadowPart(
            DrawContext context, int x, int y, int width, int height, float blur,
            int clipLeft, int clipTop, int clipRight, int clipBottom
    ) {
        if (clipRight <= clipLeft || clipBottom <= clipTop) return;
        context.enableScissor(clipLeft, clipTop, clipRight, clipBottom);
        try {
            SmoothRoundedGui.fillGlow(context, x, y, width, height,
                    3.0f, blur, 0xFF000000);
        } finally {
            context.disableScissor();
        }
    }

    static void textField(
            DrawContext context, TextRenderer renderer,
            int x, int y, int width, int height,
            String value, boolean password, boolean focused, long blinkStarted
    ) {
        if (LegacyMainMenuScreen.shadersEnabled()) {
            softShadow(context, x, y, width, height, 0, 15, 0xFF000000);
            softShadow(context, x, y, width, height, 0, 10, 0xAF323232);
        } else {
            rounded(context, x, y, width, height, 0, 0x7D0F0F0F);
        }
        String visible = password ? "•".repeat(value.codePointCount(0, value.length())) : value;
        int available = Math.max(1, width - 8);
        while (!visible.isEmpty() && width(renderer, visible, FONT_DX) > available) {
            visible = visible.substring(1);
        }
        context.enableScissor(x + 2, y, x + width - 2, y + height);
        float textY = y + (height - 8) / 2.0f;
        draw(context, renderer, visible, x + 4, textY, 0xFFE0E0E0, FONT_DX);
        if (focused) {
            float cursorX = x + 4 + width(renderer, visible, FONT_DX);
            draw(context, renderer, "_", cursorX + 1, textY, 0xFFE0E0E0, FONT_DX);
        }
        context.disableScissor();
    }

    static Text text(String value, StyleSpriteSource font) {
        return Text.literal(value).styled(style -> style.withFont(font));
    }

    static int width(TextRenderer renderer, String value, StyleSpriteSource font) {
        return renderer.getWidth(text(value, font));
    }

    static void draw(
            DrawContext context, TextRenderer renderer, String value,
            float x, float y, int color, StyleSpriteSource font
    ) {
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x - (float) Math.floor(x), y - (float) Math.floor(y));
        context.drawText(renderer, text(value, font),
                (int) Math.floor(x), (int) Math.floor(y), color, false);
        context.getMatrices().popMatrix();
    }

    static boolean inside(double mouseX, double mouseY, int x, int y, int width, int height) {
        return mouseX >= x && mouseY >= y && mouseX < x + width && mouseY < y + height;
    }

    static void playClick(MinecraftClient client) {
        client.getSoundManager().play(
                PositionedSoundInstance.ui(SoundEvents.UI_BUTTON_CLICK, 1.0f));
    }

    static int withAlpha(int color, int alpha) {
        return Math.max(0, Math.min(255, alpha)) << 24 | color & 0xFFFFFF;
    }

    static float approach(float current, boolean target, float deltaTicks, float speed) {
        float response = 1.0f - (float) Math.exp(-Math.max(0.0f, deltaTicks) * speed / 20.0f);
        float result = current + ((target ? 1.0f : 0.0f) - current) * response;
        if (Math.abs(result - (target ? 1.0f : 0.0f)) < 0.002f) {
            return target ? 1.0f : 0.0f;
        }
        return clamp(result);
    }

    private static StyleSpriteSource font(int size) {
        return new StyleSpriteSource.Font(Identifier.of("celestial", "montserrat_" + size));
    }

    private static float clamp(float value) {
        return Math.max(0.0f, Math.min(1.0f, value));
    }
}
