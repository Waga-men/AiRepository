package celestial.port.client.ui;

import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.ModuleManager;
import celestial.port.core.setting.ActionSetting;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.core.setting.Setting;
import celestial.port.core.setting.TextSetting;
import celestial.port.modules.render.ClickGuiModule;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class CelestialScreen extends Screen {
    private static final Category[] LEGACY_ORDER = {
            Category.COMBAT, Category.MOVEMENT, Category.RENDER, Category.PLAYER, Category.UTILITY
    };
    private static final StyleSpriteSource FONT_11 = font(11);
    private static final StyleSpriteSource FONT_12 = font(12);
    private static final StyleSpriteSource FONT_13 = font(13);
    private static final StyleSpriteSource FONT_14 = font(14);
    private static final StyleSpriteSource FONT_15 = font(15);
    private static final StyleSpriteSource FONT_16 = font(16);
    private static final StyleSpriteSource FONT_17 = font(17);
    private static final StyleSpriteSource FONT_21 = font(21);
    private static final StyleSpriteSource FONT_25 = font(25);
    private static final LegacyNameMetrics LEGACY_NAME_METRICS = LegacyNameMetrics.load();
    private static final Map<String, Integer> LEGACY_SORT_WIDTH_CORRECTIONS = Map.of(

            "Prediction", 2,
            "Anti Levitation", 2,
            "AutoArmor", 1
    );

    private static final int COLUMN_WIDTH = 110;
    private static final int COLUMN_GAP = 18;
    private static final int COLUMN_STEP = COLUMN_WIDTH + COLUMN_GAP;
    private static final int HEADER_HEIGHT = 17;
    private static final int PANEL_HEIGHT = 250;
    private static final int CONFIG_HEIGHT = 168;
    private static final int MODULE_HEIGHT = 20;

    private static final int PANEL_BODY = 0x96FFFFFF;
    private static final int DISABLED_ROW = 0xFFFFFFFF;
    private static final int DISABLED_HOVER = 0xFFFFFFFF;
    private static final int WHITE = 0xFFFFFFFF;
    private static final int BLACK = 0xFF000000;
    private static final int MUTED = 0xFF9A9A9A;
    private final ModuleManager moduleManager;
    private final Runnable closeAction;
    private final ConfigProfiles profiles;
    private final UiLayoutStore layoutStore;
    private final List<Panel> panels = new ArrayList<>();
    private final List<HitTarget> hitTargets = new ArrayList<>();
    private final Set<String> expandedModules = new HashSet<>();
    private final Set<String> expandedSettings = new HashSet<>();
    private final Map<String, Float> moduleAnimations = new HashMap<>();
    private final Map<String, Float> settingAnimations = new HashMap<>();
    private final Map<String, Float> hoverAnimations = new HashMap<>();
    private final Map<String, Float> toggleAnimations = new HashMap<>();
    private final Map<Category, List<Module>> sortedModules = new EnumMap<>(Category.class);

    private List<String> cachedProfileNames = List.of();
    private long nextProfileRefreshNanos;
    private boolean profileCacheDirty = true;

    private Panel draggedPanel;
    private double dragOffsetX;
    private double dragOffsetY;
    private NumberSetting draggedNumber;
    private Rect draggedNumberBounds;
    private ColorSetting draggedColor;
    private Rect draggedColorBounds;
    private ColorDragPart draggedColorPart;
    private TextSetting editingText;
    private int editingTextCursor;
    private int editingTextAnchor;
    private BindSetting editingBind;
    private Module bindingModule;
    private String configName = "";
    private String selectedProfile = "";
    private boolean editingConfigName;
    private float configScroll;
    private float configTargetScroll;
    private String lastProfileClick = "";
    private long lastProfileClickAt;
    private String status = "LMB toggle  RMB settings  MMB bind";
    private long statusVisibleUntilNanos;
    private Tooltip tooltip;
    private float frameAnimationStep = 0.22f;

    public CelestialScreen(ModuleManager moduleManager) {
        this(moduleManager, () -> { });
    }

    public CelestialScreen(ModuleManager moduleManager, Runnable closeAction) {
        this(moduleManager, closeAction, new ConfigProfiles(moduleManager,
                FabricLoader.getInstance().getConfigDir().resolve("celestial").resolve("profiles")));
    }

    public CelestialScreen(ModuleManager moduleManager, Runnable closeAction, ConfigProfiles profiles) {
        super(Text.literal("Celestial"));
        this.moduleManager = Objects.requireNonNull(moduleManager, "moduleManager");
        this.closeAction = Objects.requireNonNull(closeAction, "closeAction");
        this.profiles = Objects.requireNonNull(profiles, "profiles");
        Path layoutDirectory = profiles.directory().getParent();
        this.layoutStore = new UiLayoutStore(layoutDirectory == null
                ? profiles.directory() : layoutDirectory);

        for (int index = 0; index < LEGACY_ORDER.length; index++) {
            Category category = LEGACY_ORDER[index];
            panels.add(new Panel(category, legacyTitle(category), 18 + COLUMN_STEP * index, 10, PANEL_HEIGHT));
        }
        panels.add(new Panel(null, "Configs", 18 + COLUMN_STEP * 5, 10, CONFIG_HEIGHT));
        applyStoredPanelPositions();
    }

    @Override
    public void removed() {
        super.removed();
        savePanelPositions();
        closeAction.run();
    }

    @Override
    protected void init() {
        super.init();

    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        if (client == null || client.world == null) {
            super.renderBackground(context, mouseX, mouseY, deltaTicks);
            return;
        }

        if (theme().blurEnabled()) {
            context.applyBlur();
        }
        client.inGameHud.renderDeferredSubtitles();
    }

    public boolean legacyBlurEnabled() {
        return theme().blurEnabled();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        ClickGuiModule theme = theme();
        hitTargets.clear();
        tooltip = null;
        float animationStep = Math.min(1.0f, Math.max(0.12f, deltaTicks * 0.22f));
        frameAnimationStep = animationStep;
        for (Panel panel : panels) {
            panel.scroll += (panel.targetScroll - panel.scroll) * animationStep;
            drawPanel(context, panel, mouseX, mouseY, animationStep, theme);
        }

        if (tooltip != null) drawTooltip(context, tooltip);
        if (System.nanoTime() < statusVisibleUntilNanos) drawPrompt(context, status);
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    private void drawPanel(
            DrawContext context,
            Panel panel,
            int mouseX,
            int mouseY,
            float animationStep,
            ClickGuiModule theme
    ) {
        if (theme.blurEnabled()) {
            fillLegacyShadow(context, panel.x, panel.y + 1,
                    COLUMN_WIDTH, panel.height + 1, 5.5f, 15.0f, 0x7DFFFFFF);
        }

        SmoothRoundedGui.fillNoise(context, panel.x, panel.y + 1,
                COLUMN_WIDTH, panel.height + 1, 5.5f, PANEL_BODY);

        Rect clip = new Rect(panel.x, panel.y + 4, COLUMN_WIDTH,
                panel.category == null ? 133 : 247);
        context.enableScissor(clip.x, clip.y, clip.right(), clip.bottom());
        if (panel.category == null) {
            drawConfigProfiles(context, panel, clip, mouseX, mouseY, theme, animationStep);
        } else {
            Rect content = new Rect(panel.x, panel.y + HEADER_HEIGHT + 2,
                    COLUMN_WIDTH, 231);
            drawModules(context, panel, content, mouseX, mouseY, animationStep, theme);
        }
        context.disableScissor();

        if (panel.category == null) {
            drawConfigControls(context, panel, mouseX, mouseY, theme);
        }

        drawHorizontalGradient(context, panel.x, panel.y + 7, COLUMN_WIDTH, 8, 0,
                theme.primaryColor(), shade(theme.secondaryColor(), 0.7f));
        drawGradientHeader(context, panel.x, panel.y, COLUMN_WIDTH, 15,
                theme.primaryColor(), shade(theme.secondaryColor(), 0.7f));

        drawCenteredFont(context, panel.title, panel.x + COLUMN_WIDTH / 2.0f + 0.5f,
                panel.y + 4.0f, WHITE, FONT_21, true);
        hitTargets.add(new HitTarget(new Rect(panel.x, panel.y, COLUMN_WIDTH, HEADER_HEIGHT),
                Action.PANEL_HEADER, panel, null, null, null));
    }

    private void drawModules(
            DrawContext context,
            Panel panel,
            Rect viewport,
            int mouseX,
            int mouseY,
            float animationStep,
            ClickGuiModule theme
    ) {
        List<Module> modules = sortedModules.computeIfAbsent(panel.category, category ->
                moduleManager.byCategory(category).stream()

                        .sorted((first, second) -> {
                            int byWidth = legacyNameWidth(second.displayName())
                                    - legacyNameWidth(first.displayName());
                            return byWidth != 0 ? byWidth
                                    : second.displayName().compareTo(first.displayName());
                        })
                        .toList());
        int enabledEndColor = shade(theme.secondaryColor(), 0.7f);

        int y = viewport.y - (int) Math.round(panel.scroll);
        float measuredHeight = 0;
        for (Module module : modules) {
            updateSettingAnimations(module, animationStep);
            float target = expandedModules.contains(module.id()) ? 1.0f : 0.0f;
            float progress = moduleAnimations.getOrDefault(module.id(), 0.0f);
            progress += (target - progress) * animationStep;
            if (Math.abs(target - progress) < 0.008f) progress = target;
            moduleAnimations.put(module.id(), progress);

            int fullSettingsHeight = target > 0.0f || progress > 0.0f
                    ? settingsHeight(module) : 0;
            int animatedHeight = Math.round(fullSettingsHeight * progress);
            Rect row = new Rect(panel.x + 1, y, COLUMN_WIDTH - 2, MODULE_HEIGHT);
            Rect card = new Rect(row.x + 2, row.y + 2, row.width - 4,
                    Math.max(16, row.height - 4 + animatedHeight));
            boolean hovered = row.contains(mouseX, mouseY) && viewport.contains(mouseX, mouseY);
            if (card.intersects(viewport)) {
                if (theme.shadowsEnabled()) {

                    fillLegacyShadow(context, card.x, card.y,
                            card.width + 1, card.height, 0, 5, 0x5A000000);
                }
                if (module.enabled()) {
                    drawGradientCard(context, card, theme.primaryColor(), enabledEndColor);
                } else {
                    fillRounded(context, card.x, card.y, card.width, card.height, 1,
                            hovered ? DISABLED_HOVER : DISABLED_ROW);
                }
            }
            if (row.intersects(viewport)) {
                drawModuleRow(context, panel, module, row, viewport, mouseX, mouseY, progress, theme);
            }
            y += MODULE_HEIGHT;
            measuredHeight += MODULE_HEIGHT;

            if (animatedHeight > 0) {
                Rect settingClip = new Rect(viewport.x, y, viewport.width, animatedHeight);
                Rect clipped = settingClip.intersection(viewport);
                if (clipped.height > 0) {
                    context.enableScissor(clipped.x, clipped.y, clipped.right(), clipped.bottom());
                    drawSettings(context, panel, module, clipped, y, mouseX, mouseY, theme);
                    context.disableScissor();
                }
                y += animatedHeight;
                measuredHeight += animatedHeight;
            }
        }

        panel.maxScroll = Math.max(0, measuredHeight - viewport.height);
        panel.targetScroll = clamp(panel.targetScroll, 0, panel.maxScroll);
        panel.scroll = clamp(panel.scroll, 0, panel.maxScroll);
    }

    private void drawModuleRow(
            DrawContext context,
            Panel panel,
            Module module,
            Rect row,
            Rect viewport,
            int mouseX,
            int mouseY,
            float openProgress,
            ClickGuiModule theme
    ) {
        boolean hovered = row.contains(mouseX, mouseY) && viewport.contains(mouseX, mouseY);
        float hoverProgress = hoverAnimations.getOrDefault(module.id(), 0.0f);
        hoverProgress += ((hovered ? 1.0f : 0.0f) - hoverProgress)
                * Math.min(1.0f, frameAnimationStep * 1.35f);
        if (Math.abs((hovered ? 1.0f : 0.0f) - hoverProgress) < 0.008f) {
            hoverProgress = hovered ? 1.0f : 0.0f;
        }
        hoverAnimations.put(module.id(), hoverProgress);

        String label = bindingModule == module ? "Press a key..." : module.displayName();
        String shownLabel = trim(label, row.width - 20, FONT_16);

        drawCenteredFont(context, shownLabel, row.x + row.width - 54.5f, row.y + 4.5f,
                module.enabled() ? WHITE : BLACK, FONT_16, module.enabled());

        if (hasVisibleSettings(module)) {
            drawModuleArrow(context, row.right() - 6, row.y + 9.5f, openProgress,
                    module.enabled() ? WHITE : BLACK);
        }

        hitTargets.add(new HitTarget(row.intersection(viewport), Action.MODULE, panel, module, null, null));
        if (hoverProgress > 0.01f && (tooltip == null || hoverProgress >= tooltip.alpha)) {
            tooltip = new Tooltip(panel.x + COLUMN_WIDTH + 5, row.y + 10.0f / 3.0f,
                    module.description().isBlank() ? module.displayName() : module.description(),
                    hoverProgress);
        }
    }

    private void drawSettings(
            DrawContext context,
            Panel panel,
            Module module,
            Rect viewport,
            int y,
            int mouseX,
            int mouseY,
            ClickGuiModule theme
    ) {
        for (Setting<?> setting : module.settings()) {
            if (!setting.visible()) continue;
            y = drawSetting(context, panel, module, setting, y, viewport, mouseX, mouseY, theme);
        }
        if (module.supportsDisableOnFlag()) {
            drawLegacyModuleToggle(context, panel, module, y, viewport,
                    "Выкл при флаге: " + module.disableOnFlag(), Action.FLAG_TOGGLE);
            y += 20;
        }
        if (module.supportsOnlyWithDisabler()) {
            drawLegacyModuleToggle(context, panel, module, y, viewport,
                    "Только с Disabler: " + module.onlyWithDisabler(), Action.DISABLER_TOGGLE);
        }
    }

    private void drawLegacyModuleToggle(
            DrawContext context, Panel panel, Module module, int y, Rect viewport,
            String label, Action action
    ) {
        Rect row = new Rect(panel.x + 3, y, COLUMN_WIDTH - 4, 20);
        drawFontFractional(context, trim(label, row.width - 4, FONT_14),
                row.x + 2.0f, row.y + 8.0f / 3.0f,
                module.enabled() ? WHITE : BLACK, FONT_14, false);
        addVisibleTarget(row, viewport, action, panel, module, null, null);
    }

    private int drawSetting(
            DrawContext context,
            Panel panel,
            Module module,
            Setting<?> setting,
            int y,
            Rect viewport,
            int mouseX,
            int mouseY,
            ClickGuiModule theme
    ) {
        int x = panel.x + 3;
        int w = COLUMN_WIDTH - 6;
        String key = settingKey(module, setting);
        int foreground = module.enabled() ? WHITE : BLACK;
        int faded = module.enabled() ? 0xFFD2D2D2 : 0xFF565656;

        if (setting instanceof ActionSetting) {
            Rect row = new Rect(x, y, w + 2, 19);
            String shown = trim(setting.displayName(), row.width - 20, FONT_14);
            int buttonX = row.x + 11;
            int buttonWidth = fontWidth(shown, FONT_14) + 4;
            if (theme.shadowsEnabled()) {
                fillLegacyShadow(context, buttonX, row.y + 2,
                        buttonWidth + 1, 10, 0, 4, 0xA5000000);
            }
            if (module.enabled()) {
                drawHorizontalGradient(context, buttonX, row.y + 2,
                        buttonWidth, 10, 2, theme.primaryColor(), theme.secondaryColor());
            } else {
                fillRounded(context, buttonX, row.y + 2, buttonWidth, 10, 2, WHITE);
            }
            drawFont(context, shown, buttonX + 2, row.y + 2,
                    module.enabled() ? WHITE : BLACK, FONT_14, false);
            addVisibleTarget(row, viewport, Action.SETTING_ACTION, panel, module, setting, null);
            return y + 19;
        }

        if (setting instanceof BooleanSetting value) {
            Rect row = new Rect(x - 1, y, w + 2, 22);
            drawFontFractional(context, trim(setting.displayName(), 72, FONT_14),
                    row.x + 3.0f, row.y + 3.5f, foreground, FONT_14, false);
            Rect toggle = new Rect(row.right() - 22, row.y + 4, 18, 8);
            if (theme.shadowsEnabled()) {
                fillLegacyShadow(context, toggle.x, toggle.y,
                        toggle.width, toggle.height, 0, 6, 0xCD000000);
            }
            if (value.enabled()) {
                drawHorizontalGradient(context,
                        toggle.x, toggle.y, toggle.width, toggle.height, 3.5f,
                        theme.primaryColor(), theme.secondaryColor());
            } else {
                fillRounded(context, toggle.x, toggle.y, toggle.width, toggle.height,
                        4, 0xFF7C939B);
            }
            float target = value.enabled() ? 1.0f : 0.0f;
            float knob = toggleAnimations.getOrDefault(key, target);
            knob += (target - knob) * Math.min(1.0f, frameAnimationStep);
            if (Math.abs(target - knob) < 0.008f) knob = target;
            toggleAnimations.put(key, knob);
            int knobCenter = toggle.x + 4 + Math.round(knob * 10.0f);
            fillLegacyPoint(context, knobCenter, toggle.y + 4.0f, 7.5f, WHITE);
            addVisibleTarget(row, viewport, Action.BOOLEAN, panel, module, setting, null);
            return y + 22;
        }

        if (setting instanceof NumberSetting value) {
            Rect component = new Rect(panel.x + 22, y, 63, 30);
            drawFontFractional(context, trim(setting.displayName(), 65, FONT_14),
                    component.x - 16.0f, component.y + 0.5f,
                    foreground, FONT_14, false);
            String number = legacySliderValue(value.value(), value.step());
            int trackY = component.y + 15;
            context.fill(component.x, trackY, component.right(), trackY + 1, foreground);
            double range = value.maximum() - value.minimum();
            double ratio = range == 0 ? 0 : (value.value() - value.minimum()) / range;
            float fill = (float) (component.width * clamp(ratio, 0, 1));
            float centerX = component.x + fill;
            float centerY = component.y + 15.0f;
            int outerColor = module.enabled() ? WHITE : theme.primaryColor();
            int innerColor = module.enabled() ? theme.primaryColor() : WHITE;
            fillFractionalRect(context, component.x, trackY, fill, 1.0f, outerColor);
            if (theme.shadowsEnabled()) {
                fillLegacyShadow(context, Math.round(centerX) - 3,
                        trackY - 3, 7, 7, 0, 10, outerColor);
            }
            fillLegacyPoint(context, centerX, centerY, 7.0f, outerColor);
            fillLegacyPoint(context, centerX, centerY, 5.0f, innerColor);
            String minimum = legacyFloat(value.minimum());
            String maximum = legacyFloat(value.maximum());
            drawFont(context, minimum, component.x - 16, component.y + 11,
                    faded, FONT_12, false);
            drawFont(context, maximum,
                    component.right() + 20 - fontWidth(maximum, FONT_12), component.y + 11,
                    faded, FONT_12, false);
            drawCenteredFont(context, number, centerX, component.y + 19.0f,
                    foreground, FONT_11, false);
            Rect interaction = new Rect(component.x, component.y - 5, component.width, 30);
            addVisibleTarget(interaction, viewport, Action.NUMBER,
                    panel, module, setting, null, interaction);
            return y + 30;
        }

        if (setting instanceof ModeSetting value) {
            Rect row = new Rect(x, y, w + 1, 29);
            drawFont(context, trim(setting.displayName() + ":", row.width - 10, FONT_14),
                    row.x + 3, row.y, foreground, FONT_14, false);
            float selectedX = row.x + 2.5f;
            int selectedY = row.y + 11;
            int selectedWidth = row.width - 6;
            int selectedHeight = 12;
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(selectedX, selectedY);
            if (theme.shadowsEnabled()) {
                fillLegacyShadow(context, 0, 0,
                        selectedWidth, selectedHeight, 0, 7, 0x96000000);
            }
            context.fill(0, 0, selectedWidth, selectedHeight, 0x8C1E1E1E);
            context.getMatrices().popMatrix();
            String current = trim(value.value(), selectedWidth - 14, FONT_15);
            drawFontFractional(context, current, row.x + 5.0f, row.y + 11.5f,
                    WHITE, FONT_15, true);
            float progress = settingProgress(key);
            if (value.options().size() > 1) {
                drawModuleArrow(context, row.x + 97, row.y + 16.5f, progress, WHITE);
            }
            addVisibleTarget(row, viewport, Action.MODE_HEADER, panel, module, setting, null);
            int optionsY = y + 29;
            int fullExtra = modeExtraHeight(value);
            int visibleExtra = Math.round(fullExtra * progress);
            if (visibleExtra > 0) {
                int visualTop = y + 23;
                int fullVisualHeight = fullExtra + 2;
                int visibleVisualHeight = Math.round(fullVisualHeight * progress);
                Rect optionsClip = new Rect(row.x, visualTop, row.width, visibleVisualHeight)
                        .intersection(viewport);
                context.enableScissor(optionsClip.x, optionsClip.y,
                        optionsClip.right(), optionsClip.bottom());
                Rect options = new Rect(row.x + 4, visualTop,
                        row.width - 8, fullVisualHeight);
                if (theme.shadowsEnabled()) {
                    fillLegacyShadow(context, options.x - 1, options.y,
                            options.width + 3, options.height + 1,
                            0, 5, 0x96000000);
                }
                fillRounded(context, options.x, options.y, options.width, options.height, 4, 0x8C1E1E1E);
                for (int index = 0; index < value.options().size(); index++) {
                    String option = value.options().get(index);
                    int textY = y + 27 + index * 14;
                    Rect optionRow = new Rect(row.x + 15, y + 27 + index * 14,
                            row.width - 30, 11);
                    String shown = trim(option, row.width - 16, FONT_16);
                    drawCenteredFont(context, shown, row.x + row.width / 2.0f,
                            textY + 0.5f,
                            value.is(option) ? theme.primaryColor() : WHITE,
                            FONT_16, true);
                    addVisibleTarget(optionRow, optionsClip, Action.MODE_OPTION,
                            panel, module, setting, option);
                }
                context.disableScissor();
            }
            return optionsY + visibleExtra;
        }

        if (setting instanceof MultiSelectSetting value) {
            Rect row = new Rect(x - 1, y, w + 2, 29);
            drawFont(context, trim(setting.displayName() + ":", row.width - 10, FONT_15),
                    row.x + 3, row.y, foreground, FONT_15, false);
            float selectedX = row.x + 2.5f;
            int selectedY = row.y + 11;
            int selectedWidth = row.width - 6;
            int selectedHeight = 12;
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(selectedX, selectedY);
            if (theme.shadowsEnabled()) {
                fillLegacyShadow(context, 0, 0,
                        selectedWidth, selectedHeight, 0, 7, 0x96000000);
            }
            context.fill(0, 0, selectedWidth, selectedHeight, 0x8C1E1E1E);
            context.getMatrices().popMatrix();
            String summary = value.value().isEmpty() ? "Нету :(" : String.join(", ", value.value());
            drawFont(context, trim(summary, selectedWidth - 14, FONT_14),
                    row.x + 5, row.y + 12, WHITE, FONT_14, true);
            float progress = settingProgress(key);
            if (value.options().size() > 1) {
                drawModuleArrow(context, row.x + 97, row.y + 16.5f, progress, WHITE);
            }
            addVisibleTarget(row, viewport, Action.MULTI_HEADER, panel, module, setting, null);
            int optionsY = y + 29;
            int fullExtra = multiExtraHeight(value);
            int visibleExtra = Math.round(fullExtra * progress);
            if (visibleExtra > 0) {
                int visualTop = y + 23;
                int fullVisualHeight = fullExtra + 1;
                int visibleVisualHeight = Math.round((fullExtra + 3) * progress);
                Rect optionsClip = new Rect(row.x, visualTop, row.width, visibleVisualHeight)
                        .intersection(viewport);
                context.enableScissor(optionsClip.x, optionsClip.y,
                        optionsClip.right(), optionsClip.bottom());
                Rect options = new Rect(row.x + 4, visualTop,
                        row.width - 9, Math.max(1, fullVisualHeight));
                if (theme.shadowsEnabled()) {
                    fillLegacyShadow(context, options.x - 1, options.y,
                            options.width + 3, fullExtra + 3,
                            0, 5, 0x96000000);
                }
                fillRounded(context, options.x, options.y, options.width, options.height, 4, 0x8C1E1E1E);
                for (int index = 0; index < value.options().size(); index++) {
                    String option = value.options().get(index);
                    int textY = y + 26 + index * 14;
                    Rect optionRow = new Rect(row.x + 15, y + 28 + index * 14,
                            row.width - 30, 12);
                    boolean selectedOption = value.selected(option);
                    String shown = trim(option, row.width - 16, FONT_15);
                    drawCenteredFont(context, shown, row.x + row.width / 2.0f,
                            textY,
                            selectedOption ? theme.primaryColor() : WHITE,
                            FONT_15, true);
                    addVisibleTarget(optionRow, optionsClip, Action.MULTI_OPTION,
                            panel, module, setting, option);
                }
                context.disableScissor();
            }
            return optionsY + visibleExtra;
        }

        if (setting instanceof ColorSetting value) {
            Rect row = new Rect(x - 1, y, w + 2, 18);
            drawFont(context, trim(setting.displayName() + ":", 74, FONT_15),
                    row.x + 3, row.y + 2, foreground, FONT_15, false);
            Rect swatch = new Rect(row.right() - 13, row.y + 5, 10, 4);
            if (theme.shadowsEnabled()) {
                fillLegacyShadow(context, swatch.x - 1, swatch.y - 1,
                        11, 5, 0, 15, 0x96000000);
            }
            fillRounded(context, swatch.x, swatch.y, swatch.width, swatch.height,
                    1, value.argb());
            addVisibleTarget(row, viewport, Action.COLOR_HEADER, panel, module, setting, null);
            int pickerY = y + 18;
            float progress = settingProgress(key);
            int visibleExtra = Math.round(80.0f * progress);
            if (visibleExtra > 0) {
                Rect pickerClip = new Rect(row.x, pickerY, row.width, visibleExtra)
                        .intersection(viewport);
                context.enableScissor(pickerClip.x, pickerClip.y,
                        pickerClip.right(), pickerClip.bottom());
                Rect sv = new Rect(row.x + 3, pickerY, 74, 74);
                Rect hue = new Rect(sv.right() + 3, pickerY, 9, 75);
                Rect alpha = new Rect(sv.right() + 15, pickerY, 9, 75);
                if (theme.shadowsEnabled()) {
                    fillLegacyShadow(context, sv.x, sv.y,
                            sv.width, sv.height, 0, 10, 0x96000000);
                    fillLegacyShadow(context, hue.x, hue.y,
                            hue.width, hue.height - 1, 0, 10, 0x96000000);
                }
                drawColorPicker(context, sv, hue, alpha, value);
                addVisibleTarget(sv, pickerClip, Action.COLOR_SV,
                        panel, module, setting, null, sv);
                addVisibleTarget(hue, pickerClip, Action.COLOR_HUE,
                        panel, module, setting, null, hue);
                if (value.alphaEditable()) {
                    addVisibleTarget(alpha, pickerClip, Action.COLOR_ALPHA,
                            panel, module, setting, null, alpha);
                }
                context.disableScissor();
            }
            return pickerY + visibleExtra;
        }

        if (setting instanceof TextSetting value) {
            Rect row = new Rect(x + 1, y, w - 3, 23);
            drawTextSetting(context, row, value, foreground);
            addVisibleTarget(row, viewport, Action.TEXT, panel, module, setting, null);
            return y + 23;
        }

        if (setting instanceof BindSetting value) {
            Rect row = new Rect(x, y, w + 2, 16);
            String shown = editingBind == value
                    ? "Press a key..." : setting.displayName() + ": " + keyName(value.key());
            drawFontFractional(context, trim(shown, row.width - 4, FONT_14),
                    row.x + 2.0f, row.y + 4.0f / 3.0f,
                    foreground, FONT_14, false);
            addVisibleTarget(row, viewport, Action.BIND, panel, module, setting, null);
            return y + 16;
        }

        Rect row = settingRow(x, y, w, 18, viewport);
        drawFont(context, trim(setting.displayName(), row.width - 10), row.x + 5, row.y + 5, foreground);
        return y + 18;
    }

    private void drawConfigProfiles(
            DrawContext context, Panel panel, Rect viewport, int mouseX, int mouseY,
            ClickGuiModule theme, float animationStep
    ) {
        List<String> names = profileNames();
        float minimumScroll = Math.min(0, -names.size() * 18 + 115);
        configTargetScroll = (float) clamp(configTargetScroll, minimumScroll, 0);
        configScroll += (configTargetScroll - configScroll)
                * Math.min(1.0f, Math.max(0.12f, animationStep));
        if (Math.abs(configTargetScroll - configScroll) < 0.05f) {
            configScroll = configTargetScroll;
        }
        int y = panel.y + 22 + Math.round(configScroll);

        if (!names.isEmpty()) {
            for (String name : names) {
                Rect row = new Rect(panel.x + 3, y, COLUMN_WIDTH - 6, 14);
                boolean hovered = row.contains(mouseX, mouseY);
                boolean selected = name.equalsIgnoreCase(selectedProfile);
                if (theme.shadowsEnabled()) {
                    fillLegacyShadow(context, row.x, row.y,
                            row.width, row.height, 0, 8, 0x5A000000);
                }
                if (selected) {
                    drawGradientCard(context, row, theme.primaryColor(),
                            shade(theme.secondaryColor(), 0.7f));
                } else {
                    fillRounded(context, row.x, row.y, row.width, row.height, 1,
                            hovered ? 0xFFF5F5F5 : 0xFFFFFFFF);
                }
                String shown = trim(name, row.width - 10, FONT_16);
                drawCenteredFont(context, shown, row.x + row.width / 2.0f,
                        row.y + 3.5f, selected ? WHITE : BLACK, FONT_16, false);
                if (row.intersects(viewport)) {
                    hitTargets.add(new HitTarget(row.intersection(viewport),
                            Action.CONFIG_PROFILE, panel, null, null, name));
                }
                y += 18;
            }
        }
    }

    private void drawConfigControls(
            DrawContext context, Panel panel, int mouseX, int mouseY,
            ClickGuiModule theme
    ) {

        Rect input = new Rect(panel.x + 13, 166, COLUMN_WIDTH - 27, 10);
        fillRounded(context, input.x, input.y, input.width, input.height, 1,
                0x4B323232);
        String shown = configName.isEmpty() && !editingConfigName ? "Config name..." : configName;
        if (editingConfigName) shown += "_";
        drawFont(context, trim(shown, input.width - 12, FONT_17), input.x + 10, input.y + 2,
                WHITE,
                FONT_17, true);
        hitTargets.add(new HitTarget(input, Action.CONFIG_INPUT, panel, null, null, null));

        int buttonsY = 152;
        Rect add = new Rect(panel.x + 13, buttonsY, 24, 10);
        Rect remove = new Rect(add.x + 29, buttonsY, 24, 10);
        Rect files = new Rect(remove.x + 29, buttonsY, 25, 10);
        boolean canSave = !configName.isBlank() || !selectedProfile.isBlank();
        boolean canDelete = !selectedProfile.isBlank();
        drawConfigButton(context, add, "+", mouseX, mouseY, panel,
                Action.CONFIG_SAVE, theme, canSave);
        drawConfigButton(context, remove, "-", mouseX, mouseY, panel,
                Action.CONFIG_DELETE, theme, canDelete);
        drawConfigButton(context, files, "Files", mouseX, mouseY, panel,
                Action.CONFIG_FILES, theme, true);
        panel.maxScroll = 0;
        panel.scroll = 0;
        panel.targetScroll = 0;
    }

    private void drawConfigButton(
            DrawContext context, Rect button, String label, int mouseX, int mouseY,
            Panel panel, Action action, ClickGuiModule theme, boolean enabled
    ) {
        boolean hovered = button.contains(mouseX, mouseY);
        fillRounded(context, button.x, button.y, button.width, button.height, 1,
                0x4B323232);
        StyleSpriteSource buttonFont = label.equals("Files") ? FONT_16 : FONT_25;
        int labelColor = !enabled ? 0xFFC3C3C3
                : hovered ? theme.primaryColor() : WHITE;
        drawCenteredFont(context, label, button.x + button.width / 2.0f, button.y + 1.0f,
                labelColor, buttonFont, true);
        if (enabled) {
            hitTargets.add(new HitTarget(button, action, panel, null, null, null));
        }
    }

    private void drawTextSetting(
            DrawContext context, Rect row, TextSetting setting, int color
    ) {
        boolean active = editingText == setting;
        if (!active && setting.value().isEmpty()) {
            drawFont(context, trim(setting.displayName(), row.width - 4, FONT_15),
                    row.x + 2, row.y + 3, color, FONT_15, false);
            return;
        }

        String value = setting.value();
        int maxWidth = row.width - 4;
        int start = active ? textVisibleStart(value, editingTextCursor, maxWidth) : 0;
        int end = start;
        while (end < value.length()) {
            int next = value.offsetByCodePoints(end, 1);
            if (fontWidth(value.substring(start, next), FONT_13) > maxWidth) break;
            end = next;
        }
        String visible = value.substring(start, end);
        int textX = row.x + 2;
        if (active && hasTextSelection()) {
            int selectionStart = Math.max(start, textSelectionStart());
            int selectionEnd = Math.min(end, textSelectionEnd());
            if (selectionEnd > selectionStart) {
                int left = textX + fontWidth(value.substring(start, selectionStart), FONT_13);
                int right = textX + fontWidth(value.substring(start, selectionEnd), FONT_13);
                context.fill(left, row.y + 5, right, row.y + 16, 0x805A78B8);
            }
        }
        drawFont(context, visible, textX, row.y + 4, color, FONT_13, false);
        if (active && editingTextCursor >= start && editingTextCursor <= end) {
            int cursorX = textX + fontWidth(value.substring(start, editingTextCursor), FONT_13);
            context.fill(cursorX, row.y + 5, cursorX + 1, row.y + 16, color);
        }
    }

    private int textVisibleStart(String value, int cursor, int maxWidth) {
        int start = 0;
        while (start < cursor
                && fontWidth(value.substring(start, cursor), FONT_13) > maxWidth - 1) {
            start = value.offsetByCodePoints(start, 1);
        }
        return start;
    }

    private int textCursorAt(String value, int start, double localX) {
        if (localX <= 0) return start;
        int cursor = start;
        int previousWidth = 0;
        while (cursor < value.length()) {
            int next = value.offsetByCodePoints(cursor, 1);
            int width = fontWidth(value.substring(start, next), FONT_13);
            if (localX < (previousWidth + width) / 2.0) return cursor;
            previousWidth = width;
            cursor = next;
        }
        return value.length();
    }

    private void drawColorPicker(
            DrawContext context, Rect sv, Rect hue, Rect alpha, ColorSetting setting
    ) {
        float[] hsb = Color.RGBtoHSB((setting.argb() >>> 16) & 0xFF,
                (setting.argb() >>> 8) & 0xFF, setting.argb() & 0xFF, null);
        for (int column = 0; column < sv.width; column += 2) {
            float saturation = (float) column / Math.max(1, sv.width - 1);
            int top = 0xFF000000 | (Color.HSBtoRGB(hsb[0], saturation, 1.0f) & 0xFFFFFF);
            context.fillGradient(sv.x + column, sv.y,
                    Math.min(sv.right(), sv.x + column + 2), sv.bottom(), top, 0xFF000000);
        }
        for (int band = 0; band < 5; band++) {
            int topY = hue.y + Math.round(band * hue.height / 5.0f);
            int bottomY = hue.y + Math.round((band + 1) * hue.height / 5.0f);
            int top = 0xFF000000 | (Color.HSBtoRGB(band / 5.0f, 1.0f, 1.0f) & 0xFFFFFF);
            int bottom = 0xFF000000 | (Color.HSBtoRGB((band + 1) / 5.0f, 1.0f, 1.0f) & 0xFFFFFF);
            context.fillGradient(hue.x, topY, hue.right(), bottomY, top, bottom);
        }
        int markerX = sv.x + Math.round(hsb[1] * (sv.width - 1));
        int markerY = sv.y + Math.round((1.0f - hsb[2]) * (sv.height - 1));
        fillRounded(context, markerX - 3, markerY - 3, 6, 6, 3, BLACK);
        fillRounded(context, markerX - 2, markerY - 2, 5, 5, 2.5f, WHITE);

        int hueY = hue.y + Math.round(hsb[0] * (hue.height - 1));
        context.fill(hue.x - 1, hueY - 2, hue.right() + 1, hueY + 2, BLACK);
        context.fill(hue.x, hueY - 1, hue.right(), hueY + 1, WHITE);

        if (setting.alphaEditable()) {
            drawCheckerboard(context, alpha);
            int rgb = setting.argb() & 0x00FFFFFF;
            context.fillGradient(alpha.x, alpha.y, alpha.right(), alpha.bottom(),
                    0x32000000 | rgb, 0xFF000000 | rgb);
            float alphaRatio = (setting.argb() >>> 24) / 255.0f;
            int alphaY = alpha.y + Math.round(alphaRatio * (alpha.height - 1));
            context.fill(alpha.x - 1, alphaY - 2, alpha.right() + 1, alphaY + 2, BLACK);
            context.fill(alpha.x, alphaY - 1, alpha.right(), alphaY + 1, WHITE);
        }
    }

    private static void drawCheckerboard(DrawContext context, Rect bounds) {
        context.fill(bounds.x, bounds.y, bounds.right(), bounds.bottom(), 0xFF808080);
        for (int y = bounds.y; y < bounds.bottom(); y += 2) {
            for (int x = bounds.x + ((y - bounds.y) & 2); x < bounds.right(); x += 4) {
                context.fill(x, y, Math.min(bounds.right(), x + 2),
                        Math.min(bounds.bottom(), y + 2), WHITE);
            }
        }
    }

    private void addVisibleTarget(
            Rect row, Rect viewport, Action action, Panel panel,
            Module module, Setting<?> setting, String value
    ) {
        addVisibleTarget(row, viewport, action, panel, module, setting, value, row);
    }

    private void addVisibleTarget(
            Rect row, Rect viewport, Action action, Panel panel,
            Module module, Setting<?> setting, String value, Rect valueBounds
    ) {
        if (row.intersects(viewport)) {
            hitTargets.add(new HitTarget(row.intersection(viewport), action,
                    panel, module, setting, value, valueBounds));
        }
    }

    private int settingsHeight(Module module) {
        int height = 0;
        for (Setting<?> setting : module.settings()) {
            if (!setting.visible()) continue;
            if (setting instanceof ActionSetting) height += 19;
            else if (setting instanceof BooleanSetting) height += 22;
            else if (setting instanceof NumberSetting) height += 30;
            else if (setting instanceof ModeSetting mode) {
                height += 29 + Math.round(modeExtraHeight(mode)
                        * settingProgress(settingKey(module, setting)));
            } else if (setting instanceof MultiSelectSetting multi) {
                height += 29 + Math.round(multiExtraHeight(multi)
                        * settingProgress(settingKey(module, setting)));
            } else if (setting instanceof ColorSetting) {
                height += 18 + Math.round(80.0f
                        * settingProgress(settingKey(module, setting)));
            } else if (setting instanceof TextSetting) height += 23;
            else if (setting instanceof BindSetting) height += 16;
            else height += 18;
        }
        if (module.supportsDisableOnFlag()) height += 20;
        if (module.supportsOnlyWithDisabler()) height += 20;
        return height;
    }

    private void updateSettingAnimations(Module module, float animationStep) {
        for (Setting<?> setting : module.settings()) {
            if (!(setting instanceof ModeSetting)
                    && !(setting instanceof MultiSelectSetting)
                    && !(setting instanceof ColorSetting)) {
                continue;
            }
            String key = settingKey(module, setting);
            float target = expandedSettings.contains(key) && setting.visible() ? 1.0f : 0.0f;
            float progress = settingAnimations.getOrDefault(key, 0.0f);
            progress += (target - progress) * Math.min(1.0f, animationStep);
            if (Math.abs(target - progress) < 0.008f) progress = target;
            settingAnimations.put(key, progress);
        }
    }

    private float settingProgress(String key) {
        return settingAnimations.getOrDefault(key, 0.0f);
    }

    private static float modeOptionStep(ModeSetting setting) {
        return setting.options().size() > 5 ? 14.5f : 15.0f;
    }

    private static int modeExtraHeight(ModeSetting setting) {
        return Math.round(setting.options().size() * modeOptionStep(setting));
    }

    private static int multiExtraHeight(MultiSelectSetting setting) {
        return Math.round(1.0f + setting.options().size() * 14.1f);
    }

    private boolean hasVisibleSettings(Module module) {
        return module.settings().stream().anyMatch(Setting::visible)
                || module.supportsDisableOnFlag()
                || module.supportsOnlyWithDisabler();
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (bindingModule != null) {
            bindingModule.setKey(BindSetting.forMouseButton(click.button()));
            setStatus(bindingModule.displayName() + ": " + keyName(bindingModule.key()));
            bindingModule = null;
            return true;
        }
        if (editingBind != null) {
            editingBind.setKey(BindSetting.forMouseButton(click.button()));
            setStatus(editingBind.displayName() + ": " + keyName(editingBind.key()));
            editingBind = null;
            return true;
        }
        for (int index = hitTargets.size() - 1; index >= 0; index--) {
            HitTarget target = hitTargets.get(index);
            if (!target.bounds.contains(click.x(), click.y())) continue;
            if (handleTarget(target, click, doubled)) return true;
        }
        editingText = null;
        editingBind = null;
        editingConfigName = false;
        return super.mouseClicked(click, doubled);
    }

    private boolean handleTarget(HitTarget target, Click click, boolean doubled) {
        switch (target.action) {
            case PANEL_HEADER -> {
                if (click.button() == 0) {
                    draggedPanel = target.panel;
                    dragOffsetX = click.x() - target.panel.x;
                    dragOffsetY = click.y() - target.panel.y;
                    return true;
                }
            }
            case MODULE -> {
                if (click.button() == 0) {
                    target.module.toggle();
                    setStatus(target.module.displayName()
                            + (target.module.enabled() ? " enabled" : " disabled"));
                    return true;
                }
                if (click.button() == 1) {
                    if (hasVisibleSettings(target.module)) {
                        toggleSet(expandedModules, target.module.id());
                        setStatus(target.module.displayName() + " settings");
                    } else {
                        setStatus(target.module.displayName() + " has no settings");
                    }
                    return true;
                }
                if (click.button() == 2) {
                    bindingModule = target.module;
                    editingText = null;
                    editingBind = null;
                    editingConfigName = false;
                    return true;
                }
            }
            case BOOLEAN -> {
                if (click.button() == 0 && target.setting instanceof BooleanSetting setting) {
                    setting.toggle();
                    setStatus(setting.displayName() + ": " + (setting.enabled() ? "on" : "off"));
                    return true;
                }
            }
            case SETTING_ACTION -> {
                if (click.button() == 0 && target.setting instanceof ActionSetting setting) {
                    setting.activate();
                    return true;
                }
            }
            case NUMBER -> {
                if (target.setting instanceof NumberSetting setting) {
                    if (click.button() == 2) {
                        setting.reset();
                        setStatus(setting.displayName() + " reset");
                        return true;
                    }
                    if (click.button() == 0) {
                        draggedNumber = setting;
                        draggedNumberBounds = target.valueBounds;
                        updateNumber(setting, target.valueBounds, click.x());
                        return true;
                    }
                }
            }
            case MODE_HEADER, MULTI_HEADER -> {
                if (click.button() == 1) {
                    toggleSet(expandedSettings, settingKey(target.module, target.setting));
                    return true;
                }
            }
            case MODE_OPTION -> {
                if (target.setting instanceof ModeSetting setting) {
                    setting.select(target.value);
                    setStatus(setting.displayName() + ": " + setting.value());
                    return true;
                }
            }
            case MULTI_OPTION -> {
                if (target.setting instanceof MultiSelectSetting setting) {
                    setting.toggle(target.value);
                    setStatus(setting.displayName() + ": " + setting.value().size() + " selected");
                    return true;
                }
            }
            case COLOR_HEADER -> {
                if (click.button() == 1 && target.setting instanceof ColorSetting setting) {
                    toggleSet(expandedSettings, settingKey(target.module, setting));
                    return true;
                }
            }
            case COLOR_SV, COLOR_HUE, COLOR_ALPHA -> {
                if (click.button() == 0 && target.setting instanceof ColorSetting setting) {
                    draggedColor = setting;
                    draggedColorBounds = target.valueBounds;
                    draggedColorPart = switch (target.action) {
                        case COLOR_HUE -> ColorDragPart.HUE;
                        case COLOR_ALPHA -> ColorDragPart.ALPHA;
                        default -> ColorDragPart.SV;
                    };
                    updateColor(setting, target.valueBounds,
                            click.x(), click.y(), draggedColorPart);
                    return true;
                }
            }
            case FLAG_TOGGLE -> {
                if (click.button() == 0 && target.module != null) {
                    target.module.setDisableOnFlag(!target.module.disableOnFlag());
                    return true;
                }
            }
            case DISABLER_TOGGLE -> {
                if (click.button() == 0 && target.module != null) {
                    target.module.setOnlyWithDisabler(!target.module.onlyWithDisabler());
                    return true;
                }
            }
            case TEXT -> {
                if (click.button() == 0 && target.setting instanceof TextSetting setting) {
                    int visibleStart = editingText == setting
                            ? textVisibleStart(setting.value(), editingTextCursor,
                            target.valueBounds.width - 4)
                            : 0;
                    editingText = setting;
                    editingTextCursor = textCursorAt(setting.value(), visibleStart,
                            click.x() - target.valueBounds.x - 2);
                    editingTextAnchor = editingTextCursor;
                    editingBind = null;
                    bindingModule = null;
                    editingConfigName = false;
                    return true;
                }
            }
            case BIND -> {
                if (click.button() == 0 && target.setting instanceof BindSetting setting) {
                    editingBind = setting;
                    editingText = null;
                    bindingModule = null;
                    editingConfigName = false;
                    return true;
                }
            }
            case CONFIG_PROFILE -> {
                if (click.button() == 0) {
                    long now = System.currentTimeMillis();
                    boolean activate = doubled || (target.value.equalsIgnoreCase(lastProfileClick)
                            && now - lastProfileClickAt <= 300L);
                    selectedProfile = target.value;
                    configName = target.value;
                    lastProfileClick = target.value;
                    lastProfileClickAt = now;
                    if (activate) {
                        try {
                            setStatus(profiles.load(target.value)
                                    ? "Loaded " + target.value : "Missing " + target.value);
                        } catch (IOException | RuntimeException exception) {
                            setStatus("Load failed: " + concise(exception));
                        }
                    } else {
                        setStatus("Selected " + target.value + " (double click to load)");
                    }
                    return true;
                }
            }
            case CONFIG_INPUT -> {
                if (click.button() == 0) {
                    editingConfigName = true;
                    editingText = null;
                    editingBind = null;
                    bindingModule = null;
                    return true;
                }
            }
            case CONFIG_SAVE -> {
                if (click.button() == 0) {
                    saveProfile();
                    return true;
                }
            }
            case CONFIG_DELETE -> {
                if (click.button() == 0) {
                    String name = selectedProfile;
                    try {
                        if (name.isBlank()) {
                            setStatus("Select a config first");
                            return true;
                        }
                        setStatus(profiles.delete(name) ? "Deleted " + name : "Missing " + name);
                        profileCacheDirty = true;
                        selectedProfile = "";
                        if (name.equalsIgnoreCase(configName)) configName = "";
                    } catch (IOException | RuntimeException exception) {
                        setStatus("Delete failed: " + concise(exception));
                    }
                    return true;
                }
            }
            case CONFIG_FILES -> {
                if (click.button() == 0) {
                    try {
                        profiles.openDirectory();
                        setStatus("Opened profiles folder");
                    } catch (IOException | RuntimeException exception) {
                        setStatus("Open failed: " + concise(exception));
                    }
                    return true;
                }
            }
        }
        return false;
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (bindingModule != null) {
            bindingModule.setKey(clearKey(key) ? BindSetting.UNBOUND : key);
            setStatus(bindingModule.displayName() + ": " + keyName(bindingModule.key()));
            bindingModule = null;
            return true;
        }
        if (editingBind != null) {
            editingBind.setKey(clearKey(key) ? BindSetting.UNBOUND : key);
            setStatus(editingBind.displayName() + ": " + keyName(editingBind.key()));
            editingBind = null;
            return true;
        }
        if (editingText != null) {
            return handleTextKey(input);
        }
        if (editingConfigName) {
            if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
                saveProfile();
                editingConfigName = false;
                return true;
            }
            if (key == GLFW.GLFW_KEY_ESCAPE) {
                editingConfigName = false;
                return true;
            }
            if (key == GLFW.GLFW_KEY_BACKSPACE && !configName.isEmpty()) {
                configName = removeLastCodePoint(configName);
                return true;
            }
        }
        if (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT) {
            int direction = key == GLFW.GLFW_KEY_LEFT ? -1 : 1;
            for (Panel panel : panels) panel.x += direction * 15;
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (editingText != null && input.isValidChar()) {
            replaceTextSelection(input.asString());
            return true;
        }
        if (editingConfigName && input.isValidChar() && configName.length() < 40) {
            String typed = input.asString();
            if (typed.chars().allMatch(character -> Character.isLetterOrDigit(character)
                    || character == ' ' || character == '_' || character == '-' || character == '.')) {
                configName += typed;
            }
            return true;
        }
        return super.charTyped(input);
    }

    private boolean handleTextKey(KeyInput input) {
        int key = input.key();
        boolean control = (input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0;
        boolean shift = (input.modifiers() & GLFW.GLFW_MOD_SHIFT) != 0;
        String value = editingText.value();

        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER
                || key == GLFW.GLFW_KEY_ESCAPE) {
            editingText = null;
            return true;
        }
        if (control && key == GLFW.GLFW_KEY_A) {
            editingTextAnchor = 0;
            editingTextCursor = value.length();
            return true;
        }
        if (control && (key == GLFW.GLFW_KEY_C || key == GLFW.GLFW_KEY_X)) {
            if (hasTextSelection() && client != null) {
                client.keyboard.setClipboard(selectedText());
                if (key == GLFW.GLFW_KEY_X) replaceTextSelection("");
            }
            return true;
        }
        if (control && key == GLFW.GLFW_KEY_V) {
            if (client != null) replaceTextSelection(client.keyboard.getClipboard());
            return true;
        }
        if (key == GLFW.GLFW_KEY_HOME || key == GLFW.GLFW_KEY_END) {
            moveTextCursor(key == GLFW.GLFW_KEY_HOME ? 0 : value.length(), shift);
            return true;
        }
        if (key == GLFW.GLFW_KEY_LEFT || key == GLFW.GLFW_KEY_RIGHT) {
            if (!shift && hasTextSelection()) {
                moveTextCursor(key == GLFW.GLFW_KEY_LEFT
                        ? textSelectionStart() : textSelectionEnd(), false);
                return true;
            }
            int next = key == GLFW.GLFW_KEY_LEFT
                    ? previousTextBoundary(value, editingTextCursor, control)
                    : nextTextBoundary(value, editingTextCursor, control);
            moveTextCursor(next, shift);
            return true;
        }
        if (key == GLFW.GLFW_KEY_BACKSPACE) {
            if (hasTextSelection()) {
                replaceTextSelection("");
            } else if (editingTextCursor > 0) {
                int previous = value.offsetByCodePoints(editingTextCursor, -1);
                editingTextAnchor = previous;
                replaceTextSelection("");
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_DELETE) {
            if (hasTextSelection()) {
                replaceTextSelection("");
            } else if (editingTextCursor < value.length()) {
                editingTextAnchor = value.offsetByCodePoints(editingTextCursor, 1);
                replaceTextSelection("");
            }
            return true;
        }
        return true;
    }

    private void replaceTextSelection(String replacement) {
        if (editingText == null) return;
        String value = editingText.value();
        int start = textSelectionStart();
        int end = textSelectionEnd();
        String insertion = replacement == null ? "" : replacement;
        int capacity = Math.max(0, editingText.maximumLength() - (value.length() - (end - start)));
        if (insertion.length() > capacity) {
            int cut = capacity;
            if (cut > 0 && cut < insertion.length()
                    && Character.isHighSurrogate(insertion.charAt(cut - 1))) {
                cut--;
            }
            insertion = insertion.substring(0, cut);
        }
        editingText.set(value.substring(0, start) + insertion + value.substring(end));
        editingTextCursor = start + insertion.length();
        editingTextAnchor = editingTextCursor;
    }

    private void moveTextCursor(int position, boolean selecting) {
        int clamped = Math.max(0, Math.min(editingText.value().length(), position));
        editingTextCursor = clamped;
        if (!selecting) editingTextAnchor = clamped;
    }

    private boolean hasTextSelection() {
        return editingTextCursor != editingTextAnchor;
    }

    private int textSelectionStart() {
        return Math.min(editingTextCursor, editingTextAnchor);
    }

    private int textSelectionEnd() {
        return Math.max(editingTextCursor, editingTextAnchor);
    }

    private String selectedText() {
        return editingText.value().substring(textSelectionStart(), textSelectionEnd());
    }

    private static int previousTextBoundary(String value, int cursor, boolean byWord) {
        if (cursor <= 0) return 0;
        int next = value.offsetByCodePoints(cursor, -1);
        if (!byWord) return next;
        while (next > 0 && Character.isWhitespace(value.codePointAt(next))) {
            next = value.offsetByCodePoints(next, -1);
        }
        while (next > 0) {
            int previous = value.offsetByCodePoints(next, -1);
            if (Character.isWhitespace(value.codePointAt(previous))) break;
            next = previous;
        }
        return next;
    }

    private static int nextTextBoundary(String value, int cursor, boolean byWord) {
        if (cursor >= value.length()) return value.length();
        int next = value.offsetByCodePoints(cursor, 1);
        if (!byWord) return next;
        while (next < value.length() && !Character.isWhitespace(value.codePointAt(next))) {
            next = value.offsetByCodePoints(next, 1);
        }
        while (next < value.length() && Character.isWhitespace(value.codePointAt(next))) {
            next = value.offsetByCodePoints(next, 1);
        }
        return next;
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        if (draggedPanel != null && click.button() == 0) {
            draggedPanel.x = (int) Math.round(click.x() - dragOffsetX);
            draggedPanel.y = (int) Math.round(click.y() - dragOffsetY);
            return true;
        }
        if (draggedNumber != null && draggedNumberBounds != null && click.button() == 0) {
            updateNumber(draggedNumber, draggedNumberBounds, click.x());
            return true;
        }
        if (draggedColor != null && draggedColorBounds != null && click.button() == 0) {
            updateColor(draggedColor, draggedColorBounds,
                    click.x(), click.y(), draggedColorPart);
            return true;
        }
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (click.button() == 0 && (draggedPanel != null || draggedNumber != null || draggedColor != null)) {
            boolean movedPanel = draggedPanel != null;
            draggedPanel = null;
            draggedNumber = null;
            draggedNumberBounds = null;
            draggedColor = null;
            draggedColorBounds = null;
            draggedColorPart = null;
            if (movedPanel) savePanelPositions();
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        for (Panel panel : panels) {
            Rect body = new Rect(panel.x, panel.y, COLUMN_WIDTH, panel.height + 3);
            if (!body.contains(mouseX, mouseY)) continue;
            if (panel.category == null) {
                float minimum = Math.min(0, -profileNames().size() * 18 + 115);
                configTargetScroll = (float) clamp(
                        configTargetScroll + Math.signum(verticalAmount) * 15,
                        minimum, 0);
            } else {
                panel.targetScroll = clamp(panel.targetScroll - verticalAmount * 15, 0, panel.maxScroll);
            }
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private void saveProfile() {
        try {
            String name = configName.isBlank() ? selectedProfile : configName.strip();
            if (name.isBlank()) {
                setStatus("Enter or select a config");
                return;
            }
            if (name.equalsIgnoreCase("autocfg")) {
                setStatus("autocfg is reserved");
                return;
            }
            profiles.save(name);
            profileCacheDirty = true;
            selectedProfile = name;
            configName = "";
            setStatus("Saved " + selectedProfile);
        } catch (IOException | RuntimeException exception) {
            setStatus("Save failed: " + concise(exception));
        }
    }

    private void updateNumber(NumberSetting setting, Rect bounds, double mouseX) {
        double ratio = clamp((mouseX - bounds.x) / Math.max(1, bounds.width), 0, 1);
        double value = setting.minimum() + (setting.maximum() - setting.minimum()) * ratio;
        setting.set(Math.round(value * 100.0) / 100.0);
        setStatus(setting.displayName() + ": " + formatNumber(setting.value()));
    }

    private List<String> profileNames() {
        long now = System.nanoTime();
        if (profileCacheDirty || now >= nextProfileRefreshNanos) {
            cachedProfileNames = profiles.names().stream()
                    .sorted(Comparator.<String>comparingInt(value ->
                                    fontWidth(value, FONT_16)).reversed()
                            .thenComparing(String.CASE_INSENSITIVE_ORDER.reversed()))
                    .toList();
            profileCacheDirty = false;

            nextProfileRefreshNanos = now + 500_000_000L;
        }
        return cachedProfileNames;
    }

    private void updateColor(
            ColorSetting setting, Rect bounds, double mouseX, double mouseY, ColorDragPart part
    ) {
        int argb = setting.argb();
        float[] hsb = Color.RGBtoHSB((argb >>> 16) & 0xFF, (argb >>> 8) & 0xFF, argb & 0xFF, null);
        if (part == ColorDragPart.ALPHA) {
            int alpha = Math.round(255.0f * (float) clamp(
                    (mouseY - bounds.y) / Math.max(1, bounds.height - 1), 0, 1));
            setting.setArgb(alpha << 24 | argb & 0x00FFFFFF);
            return;
        }
        if (part == ColorDragPart.HUE) {
            hsb[0] = (float) clamp(
                    (mouseY - bounds.y) / Math.max(1, bounds.height - 1), 0, 1);
        } else {
            hsb[1] = (float) clamp(
                    (mouseX - bounds.x) / Math.max(1, bounds.width - 1), 0, 1);
            hsb[2] = 1.0f - (float) clamp(
                    (mouseY - bounds.y) / Math.max(1, bounds.height - 1), 0, 1);
        }
        int alpha = argb & 0xFF000000;
        setting.setArgb(alpha | (Color.HSBtoRGB(hsb[0], hsb[1], hsb[2]) & 0xFFFFFF));
    }

    private void applyStoredPanelPositions() {
        Map<String, UiLayoutStore.Position> stored = layoutStore.loadSection("clickGui");
        List<Rect> accepted = new ArrayList<>();
        for (int index = 0; index < panels.size(); index++) {
            Panel panel = panels.get(index);
            UiLayoutStore.Position position = stored.get(panel.layoutId());
            if (position == null) continue;
            int storedHeight = panel.category == null ? CONFIG_HEIGHT : PANEL_HEIGHT;
            Rect candidate = new Rect(position.x(), position.y(), COLUMN_WIDTH, storedHeight);

            boolean collapsed = accepted.stream().anyMatch(existing ->
                    overlapArea(existing, candidate) > COLUMN_WIDTH * HEADER_HEIGHT);
            if (!collapsed) {
                panel.x = position.x();
                panel.y = position.y();
                accepted.add(candidate);
            } else {
                panel.x = 18 + COLUMN_STEP * index;
                panel.y = 10;
                accepted.add(new Rect(panel.x, panel.y, COLUMN_WIDTH, storedHeight));
            }
        }
    }

    private static int overlapArea(Rect first, Rect second) {
        int overlapWidth = Math.max(0, Math.min(first.right(), second.right())
                - Math.max(first.x, second.x));
        int overlapHeight = Math.max(0, Math.min(first.bottom(), second.bottom())
                - Math.max(first.y, second.y));
        return overlapWidth * overlapHeight;
    }

    private void savePanelPositions() {
        Map<String, UiLayoutStore.Position> positions = new LinkedHashMap<>();
        for (Panel panel : panels) {
            positions.put(panel.layoutId(), new UiLayoutStore.Position(panel.x, panel.y));
        }
        try {
            layoutStore.saveSection("clickGui", positions);
        } catch (IOException exception) {
            setStatus("Layout save failed: " + concise(exception));
        }
    }

    private void setStatus(String message) {
        status = message;
        statusVisibleUntilNanos = System.nanoTime() + 2_500_000_000L;
    }

    private void drawTooltip(DrawContext context, Tooltip value) {
        int tooltipWidth = fontWidth(value.text, FONT_15) + 5;
        int wholeY = (int) Math.floor(value.y);
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(0.0f, value.y - wholeY);
        fillRounded(context, value.x, wholeY, tooltipWidth, 10, 1,
                multiplyAlpha(0xFF1E1E1E, value.alpha));
        context.getMatrices().popMatrix();
        drawFontFractional(context, value.text, value.x + 1.0f, value.y - 0.5f,
                multiplyAlpha(WHITE, value.alpha), FONT_15, true);
    }

    private void drawPrompt(DrawContext context, String message) {
        String shown = trim(message, Math.max(40, width - 30));
        int boxWidth = fontWidth(shown) + 14;
        int x = (width - boxWidth) / 2;
        int y = height - 20;
        fillRounded(context, x, y, boxWidth, 16, 3, 0xDD090909);
        drawFont(context, shown, x + 7, y + 4, WHITE);
    }

    private void drawGradientHeader(DrawContext context, int x, int y, int width, int height, int first, int second) {
        drawHorizontalGradient(context, x, y, width, height, 6, first, second);
    }

    private void drawGradientCard(DrawContext context, Rect row, int first, int second) {
        drawHorizontalGradient(context,
                row.x, row.y, row.width, row.height - 1, 1, first, second);
    }

    private static void drawHorizontalGradient(
            DrawContext context, int x, int y, int width, int height,
            float radius, int left, int right
    ) {
        SmoothRoundedGui.fillFourCorners(context, x, y, width, height, radius,
                left, right, right, left);
    }

    private static void drawLegacyNoise(
            DrawContext context, int x, int y, int width, int height, int radius
    ) {
        if (width <= 4 || height <= 4) return;
        int effective = Math.max(0, Math.min(radius, Math.min(width, height) / 2));

        context.fillGradient(x + effective, y + 1, x + width - effective, y + height - 1,
                0x05FFFFFF, 0x05000000);
        for (int band = 0; band < 4; band++) {
            int hash = (x * 0x1f1f1f1f) ^ (y * 0x045D9F3B) ^ band * 0x27D4EB2D;
            int localY = 2 + Math.floorMod(hash, Math.max(1, height - 4));
            int inset = roundedInset(localY, height, effective) + 1;
            int color = (3 + (hash >>> 29 & 0x3)) << 24
                    | ((hash & 0x10000) == 0 ? 0xFFFFFF : 0x000000);
            context.fill(x + inset, y + localY, x + width - inset, y + localY + 1, color);
        }
    }

    private static int roundedInset(int line, int height, int radius) {
        if (radius <= 0) return 0;
        if (line < radius) {
            double dy = radius - line - 0.5;
            return (int) Math.ceil(radius - Math.sqrt(radius * radius - dy * dy));
        }
        if (line >= height - radius) {
            double dy = line - (height - radius) + 0.5;
            return (int) Math.ceil(radius - Math.sqrt(radius * radius - dy * dy));
        }
        return 0;
    }

    private static int shade(int color, float brightness) {
        float value = Math.max(0.0f, brightness);
        int alpha = color >>> 24;
        int red = Math.min(255, (int) (((color >>> 16) & 0xFF) * value));
        int green = Math.min(255, (int) (((color >>> 8) & 0xFF) * value));
        int blue = Math.min(255, (int) ((color & 0xFF) * value));
        return alpha << 24 | red << 16 | green << 8 | blue;
    }

    private static int multiplyAlpha(int color, float multiplier) {
        int alpha = Math.round((color >>> 24) * (float) clamp(multiplier, 0.0f, 1.0f));
        return alpha << 24 | color & 0x00FFFFFF;
    }

    private static void fillLegacyShadow(
            DrawContext context, int x, int y, int width, int height,
            float radius, float glowRadius, int color
    ) {
        LegacyHudShadow.Batch batch = LegacyHudShadow.batch();
        batch.add(x, y, width, height, (int) glowRadius, color);
        batch.submit(context);
    }

    private static void drawModuleArrow(
            DrawContext context, float centerX, float centerY, float openProgress, int color
    ) {
        context.getMatrices().pushMatrix();

        context.getMatrices().translate(centerX - 0.25f, centerY);
        context.getMatrices().rotate((float) (Math.PI * clamp(openProgress, 0.0f, 1.0f)));
        context.getMatrices().scale(0.5f, 0.5f);
        context.fill(-3, -2, 4, -1, color);
        context.fill(-2, -1, -1, 0, multiplyAlpha(color, 0.77f));
        context.fill(-1, -1, 3, 0, color);
        context.fill(-1, 0, 0, 1, multiplyAlpha(color, 0.77f));
        context.fill(0, 0, 2, 1, color);
        context.fill(0, 1, 1, 2, multiplyAlpha(color, 0.64f));
        context.getMatrices().popMatrix();
    }

    private static void fillRounded(
            DrawContext context, int x, int y, int width, int height, float radius, int color
    ) {
        SmoothRoundedGui.fill(context, x, y, width, height, radius, color);
    }

    private static void fillFractionalRect(
            DrawContext context, float x, float y, float width, float height, int color
    ) {
        if (width <= 0.0f || height <= 0.0f) return;
        int rasterWidth = Math.max(1, (int) Math.ceil(width));
        int rasterHeight = Math.max(1, (int) Math.ceil(height));
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(width / rasterWidth, height / rasterHeight);
        context.fill(0, 0, rasterWidth, rasterHeight, color);
        context.getMatrices().popMatrix();
    }

    private static void fillLegacyPoint(
            DrawContext context, float centerX, float centerY, float diameter, int color
    ) {
        int raster = Math.max(1, (int) Math.ceil(diameter));
        float scale = diameter / raster;
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(
                centerX - diameter * 0.5f,
                centerY - diameter * 0.5f);
        context.getMatrices().scale(scale, scale);
        SmoothRoundedGui.fill(context, 0, 0, raster, raster, raster * 0.5f, color);
        context.getMatrices().popMatrix();
    }

    private ClickGuiModule theme() {
        Module module = moduleManager.find("click_gui").orElse(null);
        return module instanceof ClickGuiModule clickGui ? clickGui : FALLBACK_THEME;
    }

    private static final ClickGuiModule FALLBACK_THEME = new ClickGuiModule();

    private static StyleSpriteSource font(int legacySize) {
        return new StyleSpriteSource.Font(
                Identifier.of("celestial", "montserrat_" + legacySize));
    }

    private void drawFont(DrawContext context, String value, int x, int y, int color) {
        drawFont(context, value, x, y, color, FONT_14, false);
    }

    private Text fontText(String value, StyleSpriteSource source) {
        return Text.literal(value).styled(style -> style.withFont(source));
    }

    private void drawFont(
            DrawContext context, String value, int x, int y, int color,
            StyleSpriteSource source, boolean shadow
    ) {
        Text text = fontText(value, source);
        if (shadow) {

            context.getMatrices().pushMatrix();
            context.getMatrices().translate(0.5f, 0.5f);
            context.drawText(textRenderer, text, x, y, legacyShadowColor(color), false);
            context.getMatrices().popMatrix();
        }
        context.drawText(textRenderer, text, x, y, color, false);
    }

    private void drawFontFractional(
            DrawContext context, String value, float x, float y, int color,
            StyleSpriteSource source, boolean shadow
    ) {
        int wholeX = (int) Math.floor(x);
        int wholeY = (int) Math.floor(y);
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x - wholeX, y - wholeY);
        drawFont(context, value, wholeX, wholeY, color, source, shadow);
        context.getMatrices().popMatrix();
    }

    private void drawCenteredFont(
            DrawContext context, String value, float centerX, float y, int color,
            StyleSpriteSource source, boolean shadow
    ) {
        drawFontFractional(context, value, centerX - fontWidth(value, source) / 2.0f,
                y, color, source, shadow);
    }

    private static int legacyShadowColor(int color) {
        return (color & 0x00FCFCFC) >> 2 | color & 0xC8141414;
    }

    private int fontWidth(String value) {
        return fontWidth(value, FONT_14);
    }

    private int fontWidth(String value, StyleSpriteSource source) {
        return textRenderer.getWidth(fontText(value, source));
    }

    private int legacyNameWidth(String value) {
        int measured = LEGACY_NAME_METRICS.width(value);
        int width = measured >= 0 ? measured : fontWidth(value, FONT_13);
        return width + LEGACY_SORT_WIDTH_CORRECTIONS.getOrDefault(value, 0);
    }

    private String trim(String value, int maximumWidth) {
        return trim(value, maximumWidth, FONT_14);
    }

    private String trim(String value, int maximumWidth, StyleSpriteSource source) {
        if (maximumWidth <= 0 || fontWidth(value, source) <= maximumWidth) return value;
        String ellipsis = "...";
        int low = 0;
        int high = value.codePointCount(0, value.length());
        while (low < high) {
            int middle = (low + high + 1) >>> 1;
            int end = value.offsetByCodePoints(0, middle);
            if (fontWidth(value.substring(0, end) + ellipsis, source) <= maximumWidth) low = middle;
            else high = middle - 1;
        }
        return value.substring(0, value.offsetByCodePoints(0, low)) + ellipsis;
    }

    private static String settingKey(Module module, Setting<?> setting) {
        return module.id() + "/" + setting.id();
    }

    private static void toggleSet(Set<String> values, String key) {
        if (!values.remove(key)) values.add(key);
    }

    private static boolean clearKey(int key) {
        return key == GLFW.GLFW_KEY_ESCAPE || key == GLFW.GLFW_KEY_DELETE;
    }

    private static String removeLastCodePoint(String value) {
        int end = value.offsetByCodePoints(value.length(), -1);
        return value.substring(0, end);
    }

    private static String keyName(int key) {
        if (key == BindSetting.UNBOUND) return "NONE";
        if (BindSetting.isMouseButton(key)) {
            return switch (BindSetting.mouseButton(key)) {
                case GLFW.GLFW_MOUSE_BUTTON_LEFT -> "LEFT";
                case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> "RIGHT";
                case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "MIDDLE";
                default -> "MOUSE" + (BindSetting.mouseButton(key) + 1);
            };
        }
        if (key < 0) return Integer.toString(key);
        String name = GLFW.glfwGetKeyName(key, 0);
        return name == null ? Integer.toString(key) : name.toUpperCase(Locale.ROOT);
    }

    private static String formatNumber(double value) {
        if (Math.abs(value - Math.rint(value)) < 0.000_001) {
            return String.format(Locale.ROOT, "%.0f", value);
        }
        String formatted = String.format(Locale.ROOT, "%.2f", value);
        while (formatted.endsWith("0")) formatted = formatted.substring(0, formatted.length() - 1);
        return formatted;
    }

    private static String legacyFloat(double value) {
        return Float.toString((float) value);
    }

    private static String legacySliderValue(double value, double step) {
        float legacyValue = (float) value;
        float legacyStep = (float) step;
        if (!(legacyStep > 0.0f)) return Float.toString(legacyValue);
        double snapped = Math.round(legacyValue / legacyStep) * (double) legacyStep;
        float rounded = new BigDecimal(snapped)
                .setScale(3, RoundingMode.HALF_UP)
                .floatValue();
        return Float.toString(rounded);
    }

    private static String concise(Exception exception) {
        String message = exception.getMessage();
        return message == null || message.isBlank() ? exception.getClass().getSimpleName() : message;
    }

    private static String legacyTitle(Category category) {
        return category == Category.UTILITY ? "Util" : category.displayName();
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static Rect settingRow(int x, int y, int width, int height, Rect viewport) {
        return new Rect(x, y, width, height);
    }

    private enum Action {
        PANEL_HEADER,
        MODULE,
        SETTING_ACTION,
        BOOLEAN,
        NUMBER,
        MODE_HEADER,
        MODE_OPTION,
        MULTI_HEADER,
        MULTI_OPTION,
        COLOR_HEADER,
        COLOR_SV,
        COLOR_HUE,
        COLOR_ALPHA,
        FLAG_TOGGLE,
        DISABLER_TOGGLE,
        TEXT,
        BIND,
        CONFIG_PROFILE,
        CONFIG_INPUT,
        CONFIG_SAVE,
        CONFIG_DELETE,
        CONFIG_FILES
    }

    private enum ColorDragPart {
        SV,
        HUE,
        ALPHA
    }

    private static final class Panel {
        private final Category category;
        private final String title;
        private final int height;
        private int x;
        private int y;
        private double scroll;
        private double targetScroll;
        private double maxScroll;

        private Panel(Category category, String title, int x, int y, int height) {
            this.category = category;
            this.title = title;
            this.x = x;
            this.y = y;
            this.height = height;
        }

        private String layoutId() {
            return category == null ? "configs" : category.name().toLowerCase(Locale.ROOT);
        }
    }

    private static final class LegacyNameMetrics {
        private static final int LEGACY_GLYPH_COUNT = 1110;
        private final int[] glyphWidths;

        private LegacyNameMetrics(int[] glyphWidths) {
            this.glyphWidths = glyphWidths;
        }

        private static LegacyNameMetrics load() {
            try (InputStream stream = CelestialScreen.class.getResourceAsStream(
                    "/assets/celestial/font/montserrat.ttf")) {
                if (stream == null) return new LegacyNameMetrics(null);
                Font font = Font.createFont(Font.TRUETYPE_FONT, stream).deriveFont(13.0f);
                BufferedImage image = new BufferedImage(512, 512, BufferedImage.TYPE_INT_ARGB);
                Graphics2D graphics = image.createGraphics();
                try {
                    graphics.setFont(font);
                    graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
                            RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
                    graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                            RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
                    FontMetrics metrics = graphics.getFontMetrics();
                    int[] widths = new int[LEGACY_GLYPH_COUNT];
                    for (int index = 0; index < widths.length; index++) {
                        char glyph = (char) index;
                        if (glyph >= '\u0100' && glyph <= '\u040E') {
                            widths[index] = -1;
                        } else {
                            widths[index] = metrics.getStringBounds(
                                    String.valueOf(glyph), graphics).getBounds().width;
                        }
                    }
                    return new LegacyNameMetrics(widths);
                } finally {
                    graphics.dispose();
                }
            } catch (Exception ignored) {
                return new LegacyNameMetrics(null);
            }
        }

        private int width(String value) {
            if (glyphWidths == null) return -1;
            int width = 0;
            for (int index = 0; index < value.length(); index++) {
                char glyph = value.charAt(index);
                if (glyph < glyphWidths.length && glyphWidths[glyph] >= 0) {
                    width += glyphWidths[glyph];
                }
            }
            return width / 2;
        }
    }

    private record HitTarget(
            Rect bounds,
            Action action,
            Panel panel,
            Module module,
            Setting<?> setting,
            String value,
            Rect valueBounds
    ) {
        private HitTarget(
                Rect bounds, Action action, Panel panel, Module module,
                Setting<?> setting, String value
        ) {
            this(bounds, action, panel, module, setting, value, bounds);
        }
    }

    private record Tooltip(int x, float y, String text, float alpha) {
    }

    private record Rect(int x, int y, int width, int height) {
        private int right() { return x + width; }
        private int bottom() { return y + height; }

        private boolean contains(double pointX, double pointY) {
            return pointX >= x && pointX < right() && pointY >= y && pointY < bottom();
        }

        private boolean intersects(Rect other) {
            return right() > other.x && x < other.right() && bottom() > other.y && y < other.bottom();
        }

        private Rect intersection(Rect other) {
            int left = Math.max(x, other.x);
            int top = Math.max(y, other.y);
            int right = Math.min(right(), other.right());
            int bottom = Math.min(bottom(), other.bottom());
            return new Rect(left, top, Math.max(0, right - left), Math.max(0, bottom - top));
        }
    }
}
