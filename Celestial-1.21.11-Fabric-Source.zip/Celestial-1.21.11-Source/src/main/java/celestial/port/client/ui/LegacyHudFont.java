package celestial.port.client.ui;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public final class LegacyHudFont {
    private static final int LEGACY_GLYPH_COUNT = 1110;
    private static final char SECTION_SIGN = '\u00A7';
    private static final int[] LEGACY_COLORS = createColorPalette();
    private static final Map<StyleSpriteSource, Metrics> METRICS = new HashMap<>();

    private LegacyHudFont() {
    }

    public static StyleSpriteSource font(int legacySize) {
        StyleSpriteSource source = new StyleSpriteSource.Font(Identifier.of(
                "celestial", "legacy_montserrat_" + legacySize));
        METRICS.put(source, Metrics.load(legacySize));
        return source;
    }

    public static int width(
            TextRenderer renderer, String value, StyleSpriteSource source
    ) {
        if (value == null) return 0;
        Metrics metrics = METRICS.get(source);
        return metrics == null
                ? fallbackRawWidth(renderer, value, source) / 2
                : metrics.width(value);
    }

    public static float widthFloat(
            TextRenderer renderer, String value, StyleSpriteSource source
    ) {
        if (value == null) return 0.0f;
        Metrics metrics = METRICS.get(source);
        return metrics == null
                ? fallbackRawWidth(renderer, value, source) * 0.5f
                : metrics.widthFloat(value);
    }

    public static void draw(
            DrawContext context,
            TextRenderer renderer,
            String value,
            float x,
            float y,
            int color,
            StyleSpriteSource source,
            boolean shadow
    ) {
        draw(context, renderer, value, x, y, color, source, shadow, true);
    }

    public static void draw(
            DrawContext context,
            TextRenderer renderer,
            String value,
            float x,
            float y,
            int color,
            StyleSpriteSource source,
            boolean shadow,
            boolean normalize
    ) {
        if (value == null) return;
        String filtered = legacyString(value);
        int normalizedColor = resolveDrawColor(color, normalize);
        if (shadow) {
            drawPass(context, renderer, filtered, x + 0.5f, y + 0.5f,
                    normalizedColor, source, true);
        }
        drawPass(context, renderer, filtered, x, y,
                normalizedColor, source, false);
    }

    public static void drawCentered(
            DrawContext context,
            TextRenderer renderer,
            String value,
            float centerX,
            float y,
            int color,
            StyleSpriteSource source,
            boolean shadow
    ) {
        draw(context, renderer, value,
                centerX - width(renderer, value, source) * 0.5f,
                y, color, source, shadow);
    }

    private static Text text(String value, StyleSpriteSource source) {
        return Text.literal(value).styled(style -> style.withFont(source));
    }

    private static void drawPass(
            DrawContext context,
            TextRenderer renderer,
            String value,
            float x,
            float y,
            int color,
            StyleSpriteSource source,
            boolean shadow
    ) {
        Metrics metrics = METRICS.get(source);
        int passColor = shadow ? shadowColor(color) : color;
        int currentColor = passColor;
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x - 1.0f, y - 3.0f);
        context.getMatrices().scale(0.5f, 0.5f);
        int cursor = 0;
        for (int index = 0; index < value.length(); index++) {
            char glyph = value.charAt(index);
            if (glyph == SECTION_SIGN) {
                if (index + 1 >= value.length()) break;
                char formatting = value.charAt(++index);
                int paletteIndex = "0123456789abcdefklmnor".indexOf(formatting);
                if (formatting == 'r') {
                    currentColor = passColor;
                } else if (paletteIndex < 16) {
                    if (paletteIndex < 0) paletteIndex = 15;
                    if (shadow) paletteIndex += 16;
                    currentColor = passColor & 0xFF000000
                            | LEGACY_COLORS[paletteIndex];
                }
                continue;
            }
            if (!legacyGlyph(glyph)) continue;
            String glyphText = String.valueOf(glyph);
            context.drawText(renderer,
                    text(glyphText, source), cursor, 0, currentColor, false);
            cursor += metrics == null
                    ? renderer.getWidth(text(glyphText, source))
                    : metrics.advance(glyph);
        }
        context.getMatrices().popMatrix();
    }

    private static boolean legacyGlyph(int codePoint) {
        return codePoint >= 0x20 && codePoint < LEGACY_GLYPH_COUNT
                && (codePoint < 0x100 || codePoint > 0x40E);
    }

    private static String legacyString(String value) {
        StringBuilder filtered = new StringBuilder(value.length());
        for (int index = 0; index < value.length(); index++) {
            char glyph = value.charAt(index);
            if (legacyGlyph(glyph)) filtered.append(glyph);
        }
        return filtered.toString();
    }

    private static int fallbackRawWidth(
            TextRenderer renderer, String value, StyleSpriteSource source
    ) {
        String filtered = legacyString(value);
        int width = 0;
        for (int index = 0; index < filtered.length(); index++) {
            char glyph = filtered.charAt(index);
            if (glyph == SECTION_SIGN) {
                if (index + 1 < filtered.length()) index++;
                continue;
            }
            width += renderer.getWidth(text(String.valueOf(glyph), source));
        }
        return width;
    }

    private static int normalizeColor(int color) {
        if (color == 0x20FFFFFF) color = 0xFFFFFFFF;
        if ((color & 0xFC000000) == 0) color |= 0xFF000000;
        return color;
    }

    static int resolveDrawColor(int color, boolean normalize) {
        return normalize ? normalizeColor(color) : color;
    }

    private static int shadowColor(int color) {
        return (color & 0x00FCFCFC) >> 2 | color & 0xC8141414;
    }

    private static int[] createColorPalette() {
        int[] colors = new int[32];
        for (int index = 0; index < colors.length; index++) {
            int dim = (index >> 3 & 1) * 85;
            int red = (index >> 2 & 1) * 170 + dim;
            int green = (index >> 1 & 1) * 170 + dim;
            int blue = (index & 1) * 170 + dim;
            if (index == 6) red += 85;
            if (index >= 16) {
                red /= 4;
                green /= 4;
                blue /= 4;
            }
            colors[index] = red << 16 | green << 8 | blue;
        }
        return colors;
    }

    private static final class Metrics {
        private final int[] advances;

        private Metrics(int[] advances) {
            this.advances = advances;
        }

        private static Metrics load(int size) {
            try (InputStream input = LegacyHudFont.class.getResourceAsStream(
                    "/assets/celestial/font/montserrat.ttf")) {
                if (input == null) return null;
                Font font = Font.createFont(Font.TRUETYPE_FONT, input)
                        .deriveFont((float) size);
                BufferedImage image = new BufferedImage(
                        1, 1, BufferedImage.TYPE_INT_ARGB);
                Graphics2D graphics = image.createGraphics();
                try {
                    graphics.setFont(font);
                    graphics.setRenderingHint(RenderingHints.KEY_FRACTIONALMETRICS,
                            RenderingHints.VALUE_FRACTIONALMETRICS_OFF);
                    graphics.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                            RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                    graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                            RenderingHints.VALUE_ANTIALIAS_ON);
                    FontMetrics fontMetrics = graphics.getFontMetrics();
                    int[] advances = new int[LEGACY_GLYPH_COUNT];
                    for (int codePoint = 0; codePoint < advances.length; codePoint++) {
                        if (!legacyGlyph(codePoint)) {
                            advances[codePoint] = -1;
                            continue;
                        }
                        String glyph = new String(Character.toChars(codePoint));
                        advances[codePoint] = fontMetrics.getStringBounds(glyph, graphics)
                                .getBounds().width;
                    }
                    return new Metrics(advances);
                } finally {
                    graphics.dispose();
                }
            } catch (Exception ignored) {
                return null;
            }
        }

        private int advance(int codePoint) {
            return advances == null || !legacyGlyph(codePoint)
                    ? 0 : advances[codePoint];
        }

        private int width(String value) {
            return (int) (rawWidth(value) * 0.5f);
        }

        private float widthFloat(String value) {
            return rawWidth(value) * 0.5f;
        }

        private int rawWidth(String value) {
            if (advances == null || value == null) return 0;
            String filtered = legacyString(value);
            int width = 0;
            for (int index = 0; index < filtered.length(); index++) {
                char glyph = filtered.charAt(index);
                if (glyph == SECTION_SIGN) {
                    if (index + 1 < filtered.length()) index++;
                    continue;
                }
                width += advances[glyph];
            }
            return width;
        }
    }
}
