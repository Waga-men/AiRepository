package celestial.port.client.ui;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.platform.DestFactor;
import com.mojang.blaze3d.platform.SourceFactor;
import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.textures.FilterMode;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

final class LegacyHudShadow {
    private static final VertexFormat VERTEX_FORMAT = VertexFormat.builder()
            .add("Position", VertexFormatElement.POSITION)
            .add("Color", VertexFormatElement.COLOR)
            .add("UV0", VertexFormatElement.UV0)
            .build();

    private static final BlendFunction LEGACY_BLEND = new BlendFunction(
            SourceFactor.SRC_ALPHA, DestFactor.ONE_MINUS_SRC_ALPHA,
            SourceFactor.ONE, DestFactor.ZERO);

    private static final RenderPipeline PIPELINE = RenderPipeline.builder()
            .withLocation(Identifier.of("celestial", "pipeline/legacy_hud_shadow_texture"))
            .withVertexShader(Identifier.of("celestial", "core/legacy_hud_shadow_texture"))
            .withFragmentShader(Identifier.of("celestial", "core/legacy_hud_shadow_texture"))
            .withSampler("Sampler0")
            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
            .withUniform("Projection", UniformType.UNIFORM_BUFFER)
            .withBlend(LEGACY_BLEND)
            .withCull(false)
            .withDepthWrite(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withVertexFormat(VERTEX_FORMAT, VertexFormat.DrawMode.QUADS)
            .build();

    private static final Map<Integer, CachedMask> CACHE = new HashMap<>();

    private LegacyHudShadow() {
    }

    static Batch batch() {
        return new Batch();
    }

    static final class Batch {
        private final List<ShadowQuad> quads = new ArrayList<>();
        private CachedMask lastMask;

        void add(
                float x, float y, float width, float height,
                int blurRadius, int color
        ) {
            if (width <= 0.0f || height <= 0.0f || blurRadius <= 0
                    || (color >>> 24) == 0) {
                return;
            }
            double expandedWidth = (double) width + blurRadius * 2.0;
            double expandedHeight = (double) height + blurRadius * 2.0;
            int pixelWidth = (int) expandedWidth;
            int pixelHeight = (int) expandedHeight;
            if (pixelWidth <= 0 || pixelHeight <= 0) return;

            lastMask = cachedMask(expandedWidth, expandedHeight, blurRadius,
                    pixelWidth, pixelHeight);
            quads.add(new ShadowQuad(
                    x - blurRadius - 0.25f,
                    y - blurRadius + 0.25f,
                    pixelWidth, pixelHeight, color));
        }

        void submit(DrawContext context) {
            if (quads.isEmpty() || lastMask == null) return;

            Matrix3x2f pose = new Matrix3x2f(context.getMatrices());
            float minX = Float.POSITIVE_INFINITY;
            float minY = Float.POSITIVE_INFINITY;
            float maxX = Float.NEGATIVE_INFINITY;
            float maxY = Float.NEGATIVE_INFINITY;
            for (ShadowQuad quad : quads) {
                minX = Math.min(minX, quad.x);
                minY = Math.min(minY, quad.y);
                maxX = Math.max(maxX, quad.x + quad.width);
                maxY = Math.max(maxY, quad.y + quad.height);
            }
            ScreenRect scissor = context.scissorStack.peekLast();
            ScreenRect transformed = new ScreenRect(
                    (int) Math.floor(minX), (int) Math.floor(minY),
                    (int) Math.ceil(maxX) - (int) Math.floor(minX),
                    (int) Math.ceil(maxY) - (int) Math.floor(minY))
                    .transformEachVertex(pose);
            ScreenRect bounds = scissor == null
                    ? transformed : scissor.intersection(transformed);

            context.state.addSimpleElement(new ShadowBatchState(
                    pose, List.copyOf(quads), lastMask.textureSetup,
                    scissor, bounds));
        }
    }

    private static CachedMask cachedMask(
            double expandedWidth, double expandedHeight, int radius,
            int pixelWidth, int pixelHeight
    ) {
        double legacyKeyValue = expandedWidth * expandedHeight
                + expandedWidth * radius + radius;
        int legacyKey = String.valueOf(legacyKeyValue).hashCode();
        CachedMask cached = CACHE.get(legacyKey);
        if (cached != null) return cached;

        int[] firstPass = new int[pixelWidth * pixelHeight];
        int innerWidth = pixelWidth - radius * 2;
        int innerHeight = pixelHeight - radius * 2;
        if (innerWidth > 0 && innerHeight > 0) {
            for (int y = radius; y < radius + innerHeight; y++) {
                int offset = y * pixelWidth;
                for (int x = radius; x < radius + innerWidth; x++) {
                    firstPass[offset + x] = 255;
                }
            }
        }

        float[] kernel = makeKernel(radius);
        int[] transposed = new int[firstPass.length];
        convolveAndTranspose(kernel, firstPass, transposed,
                pixelWidth, pixelHeight, null);
        boolean[] nonZeroRaw = new boolean[firstPass.length];
        convolveAndTranspose(kernel, transposed, firstPass,
                pixelHeight, pixelWidth, nonZeroRaw);

        NativeImageBackedTexture texture = new NativeImageBackedTexture(
                "Celestial legacy HUD shadow " + Integer.toUnsignedString(legacyKey),
                pixelWidth, pixelHeight, false);
        NativeImage image = texture.getImage();
        if (image == null) {
            throw new IllegalStateException("Legacy HUD shadow image was not allocated");
        }
        for (int y = 0; y < pixelHeight; y++) {
            int offset = y * pixelWidth;
            for (int x = 0; x < pixelWidth; x++) {
                int index = offset + x;
                int rgb = nonZeroRaw[index] ? 0x00FFFFFF : 0;
                image.setColorArgb(x, y, firstPass[index] << 24 | rgb);
            }
        }
        texture.upload();
        Identifier id = Identifier.of("celestial", "dynamic/legacy_hud_shadow/"
                + Integer.toUnsignedString(legacyKey, 16));
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, texture);
        TextureSetup textureSetup = TextureSetup.of(
                texture.getGlTextureView(),
                RenderSystem.getSamplerCache().getRepeated(FilterMode.LINEAR));
        cached = new CachedMask(texture, textureSetup);
        CACHE.put(legacyKey, cached);
        return cached;
    }

    private static float[] makeKernel(float radius) {
        int kernelRadius = (int) Math.ceil(radius);
        float[] matrix = new float[kernelRadius * 2 + 1];
        float sigma = radius / 3.0f;
        float sigma22 = 2.0f * sigma * sigma;
        float sigmaPi2 = 2.0f * (float) Math.PI * sigma;
        float sqrtSigmaPi2 = (float) Math.sqrt(sigmaPi2);
        float radius2 = radius * radius;
        float total = 0.0f;
        int index = 0;
        for (int row = -kernelRadius; row <= kernelRadius; row++) {
            float distance = row * row;
            matrix[index] = distance > radius2 ? 0.0f
                    : (float) Math.exp(-distance / sigma22) / sqrtSigmaPi2;
            total += matrix[index++];
        }
        for (int i = 0; i < matrix.length; i++) matrix[i] /= total;
        return matrix;
    }

    private static void convolveAndTranspose(
            float[] kernel, int[] input, int[] output,
            int width, int height, boolean[] nonZeroRaw
    ) {
        int radius = kernel.length / 2;
        for (int y = 0; y < height; y++) {
            int outputIndex = y;
            int inputOffset = y * width;
            for (int x = 0; x < width; x++) {
                float alpha = 0.0f;
                for (int column = -radius; column <= radius; column++) {
                    float weight = kernel[radius + column];
                    if (weight == 0.0f) continue;
                    int sampleX = x + column;
                    if (sampleX < 0) sampleX = 0;
                    else if (sampleX >= width) sampleX = width - 1;
                    alpha += weight * input[inputOffset + sampleX];
                }
                if (nonZeroRaw != null) nonZeroRaw[outputIndex] = alpha != 0.0f;
                output[outputIndex] = Math.max(0, Math.min(255,
                        (int) (alpha + 0.5f)));
                outputIndex += height;
            }
        }
    }

    private record CachedMask(
            NativeImageBackedTexture texture,
            TextureSetup textureSetup
    ) {
    }

    private record ShadowQuad(float x, float y, float width, float height, int color) {
    }

    private record ShadowBatchState(
            Matrix3x2f pose,
            List<ShadowQuad> quads,
            TextureSetup textureSetup,
            ScreenRect scissorArea,
            ScreenRect bounds
    ) implements SimpleGuiElementRenderState {
        @Override
        public void setupVertices(VertexConsumer vertices) {
            for (ShadowQuad quad : quads) {
                vertex(vertices, quad, quad.x, quad.y, 0.0f, 0.0f);
                vertex(vertices, quad, quad.x, quad.y + quad.height, 0.0f, 1.0f);
                vertex(vertices, quad, quad.x + quad.width,
                        quad.y + quad.height, 1.0f, 1.0f);
                vertex(vertices, quad, quad.x + quad.width, quad.y, 1.0f, 0.0f);
            }
        }

        private void vertex(
                VertexConsumer vertices, ShadowQuad quad,
                float pointX, float pointY, float u, float v
        ) {
            float transformedX = pose.m00() * pointX + pose.m10() * pointY + pose.m20();
            float transformedY = pose.m01() * pointX + pose.m11() * pointY + pose.m21();
            vertices.vertex(transformedX, transformedY, 0.0f)
                    .color(quad.color)
                    .texture(u, v);
        }

        @Override
        public RenderPipeline pipeline() {
            return PIPELINE;
        }
    }
}
