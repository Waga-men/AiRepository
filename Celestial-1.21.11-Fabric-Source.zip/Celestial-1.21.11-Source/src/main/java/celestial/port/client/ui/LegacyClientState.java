package celestial.port.client.ui;

import celestial.port.CelestialPortClient;
import net.minecraft.client.MinecraftClient;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;

public final class LegacyClientState {
    private static boolean shaders = true;
    private static boolean hideInformation;
    private static boolean changeLogPinned;
    private static boolean initialized;
    private static boolean saved;
    private static boolean preserveOriginalFile;

    private LegacyClientState() {
    }

    public static synchronized void initialize(MinecraftClient client) {
        if (initialized) return;
        initialized = true;

        Path file = file(client);
        if (!Files.exists(file)) {
            try {
                Files.createDirectories(file.getParent());
                write(file, client.getSession().getUsername());
            } catch (IOException exception) {
                CelestialPortClient.LOGGER.warn("Could not create legacy client.celka", exception);
                return;
            }
        }

        Parsed parsed;
        try {
            parsed = read(file);
        } catch (IOException exception) {
            CelestialPortClient.LOGGER.warn("Could not read legacy client.celka", exception);
            return;
        }

        if (parsed.hasAltName()
                && !LegacyOfflineSession.switchToAtStartup(client, parsed.altName())) {

            preserveOriginalFile = true;
            return;
        }

        shaders = parsed.shaders();
        hideInformation = parsed.hideInformation();
        changeLogPinned = parsed.changeLogPinned();
    }

    public static synchronized void save(MinecraftClient client) {
        if (saved || preserveOriginalFile) return;
        saved = true;
        Path file = file(client);
        try {
            Files.createDirectories(file.getParent());
            write(file, client.getSession().getUsername());
        } catch (IOException exception) {
            CelestialPortClient.LOGGER.warn("Could not save legacy client.celka", exception);
        }
    }

    public static boolean shaders() {
        return shaders;
    }

    public static void setShaders(boolean value) {
        shaders = value;
    }

    public static boolean hideInformation() {
        return hideInformation;
    }

    public static void setHideInformation(boolean value) {
        hideInformation = value;
    }

    public static boolean changeLogPinned() {
        return changeLogPinned;
    }

    public static void setChangeLogPinned(boolean value) {
        changeLogPinned = value;
    }

    private static Path file(MinecraftClient client) {
        return client.runDirectory.toPath().resolve("Celestial").resolve("client.celka");
    }

    private static Parsed read(Path file) throws IOException {
        boolean parsedShaders = shaders;
        boolean parsedHideInformation = hideInformation;
        boolean parsedChangeLogPinned = changeLogPinned;
        String parsedAltName = null;
        boolean hasAltName = false;

        try (BufferedReader reader = Files.newBufferedReader(file, Charset.defaultCharset())) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(":");
                try {
                    if (values[0].contains("Shaders")) {
                        parsedShaders = Boolean.parseBoolean(values[1]);
                        continue;
                    }
                    if (values[0].contains("HideInformation")) {
                        parsedHideInformation = Boolean.parseBoolean(values[1]);
                        continue;
                    }
                    if (values[0].contains("ChangeLogPinned")) {
                        parsedChangeLogPinned = Boolean.parseBoolean(values[1]);
                        continue;
                    }
                    if (values[0].contains("AltName")) {
                        parsedAltName = values.length == 1
                                ? "CelkaRandom" + (int) (Math.random() * 1000.0)
                                : values[1];
                        hasAltName = true;
                    }
                } catch (RuntimeException exception) {
                    CelestialPortClient.LOGGER.warn(
                            "Could not parse legacy client.celka line: {}", line, exception);
                }
            }
        }

        return new Parsed(parsedShaders, parsedHideInformation,
                parsedChangeLogPinned, parsedAltName, hasAltName);
    }

    private static void write(Path file, String username) throws IOException {
        try (BufferedWriter writer = Files.newBufferedWriter(
                file, Charset.defaultCharset(), StandardOpenOption.CREATE,
                StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE)) {
            writer.write("Shaders:" + shaders);
            writer.newLine();
            writer.write("HideInformation:" + hideInformation);
            writer.newLine();
            writer.write("ChangeLogPinned:" + changeLogPinned);
            writer.newLine();
            writer.write("AltName:" + username);
            writer.newLine();
        }
    }

    private record Parsed(
            boolean shaders,
            boolean hideInformation,
            boolean changeLogPinned,
            String altName,
            boolean hasAltName
    ) {
    }
}
