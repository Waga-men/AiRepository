package celestial.port.client.command.commands;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.modules.impl.DeathCoords;
import celestial.port.modules.legacyutility.AutoWay;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.util.math.BlockPos;

import java.util.Optional;

public final class TeleportCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "tp";
    }

    @Override
    public String description() {
        return "\u0422\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0435\u0442 \u0432\u0430\u0441 \u0432 \u0443\u043A\u0430\u0437\u0430\u043D\u043D\u0443\u044E \u0442\u043E\u0447\u043A\u0443";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length < 1) {
            usage();
            return;
        }

        boolean way = arguments[0].equalsIgnoreCase("way");
        boolean contract = arguments[0].equalsIgnoreCase("ct");
        boolean trader = arguments[0].equalsIgnoreCase("torg");
        boolean inventory = arguments[0].equalsIgnoreCase("inv");
        boolean death = arguments[0].equalsIgnoreCase("death");
        try {
            if (!(LegacyTeleportCoordinator.isLegacyNumber(arguments[0])
                    && arguments.length > 1
                    || way || contract || inventory || trader || death)) {
                teleportToPlayer(arguments[0]);
            } else if (way) {
                teleportToEvent();
            } else if (inventory) {
                showContractInventory();
            } else if (contract) {
                teleportToContract();
            } else if (trader) {
                teleportToTrader();
            } else if (death) {
                teleportToDeath();
            } else {
                teleportToCoordinates(arguments);
            }
        } catch (NumberFormatException exception) {
            LegacyCommandFeedback.send(
                    "\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u043A\u043E\u043C\u0430\u043D\u0434\u044B!");
        }
    }

    private static void teleportToPlayer(String requestedName) {
        MinecraftClient client = MinecraftClient.getInstance();
        AbstractClientPlayerEntity target = null;
        for (AbstractClientPlayerEntity candidate : client.world.getPlayers()) {
            if (candidate.getName().getString().equalsIgnoreCase(requestedName)) {
                target = candidate;
                break;
            }
        }
        if (target == null) {
            LegacyCommandFeedback.send(
                    "\u0418\u0433\u0440\u043E\u043A \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0432 \u0437\u043E\u043D\u0435 \u043F\u0440\u043E\u0433\u0440\u0443\u0437\u043A\u0438!");
            return;
        }
        float x = (float) target.getX();
        float y = (float) target.getY();
        float z = (float) target.getZ();
        LegacyTeleportCoordinator.teleport(
                LegacyTeleportCoordinator.TeleportType.PLAYER, x, y, z);
        LegacyCommandFeedback.send(
                "\u041F\u044B\u0442\u0430\u0435\u043C\u0441\u044F \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u043A \u00A7c"
                        + target.getName().getString());
    }

    private static void teleportToEvent() {
        AutoWay autoWay = (AutoWay) CelestialPortClient.MODULES.require("auto_way");
        if (!autoWay.enabled()) {
            LegacyCommandFeedback.send(
                    "\u0412\u043A\u043B\u044E\u0447\u0438\u0442\u0435 AutoWay \u0438 \u043F\u0435\u0440\u0435\u0437\u0430\u0439\u0434\u0438\u0442\u0435 \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440!");
            return;
        }
        Optional<AutoWay.Waypoint> active = autoWay.waypoint();
        long x = active.map(AutoWay.Waypoint::x).orElse(0L);
        long z = active.map(AutoWay.Waypoint::z).orElse(0L);
        if (!farEnough((int) x, (int) z)) {
            return;
        }
        if (active.isEmpty()) {
            LegacyCommandFeedback.send("\u041D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0433\u043E \u0441\u043E\u0431\u044B\u0442\u0438\u044F!");
            return;
        }
        AutoWay.Waypoint waypoint = active.get();
        LegacyTeleportCoordinator.teleport(
                LegacyTeleportCoordinator.TeleportType.NORMAL,
                waypoint.x(), waypoint.y(), waypoint.z());
        LegacyCommandFeedback.send(
                "\u041F\u044B\u0442\u0430\u0435\u043C\u0441\u044F \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u043A \u044D\u0432\u0435\u043D\u0442\u0443!");
    }

    private static void showContractInventory() {
        LegacyTeleportCoordinator.Contract current = LegacyTeleportCoordinator.contract();
        if (current == null) {
            noContract();
            return;
        }
        LegacyTeleportCoordinator.sendRawCommand("invsee " + current.targetName());
    }

    private static void teleportToContract() {
        LegacyTeleportCoordinator.Contract current = LegacyTeleportCoordinator.contract();
        if (current == null) {
            noContract();
            return;
        }
        if (!farEnough(current.x(), current.z())) {
            return;
        }
        LegacyTeleportCoordinator.sendRawCommand("contract info");
        sendDotWay(current.x(), current.z());

        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        boolean playerAtSpawn = player.getX() < 200.0 && player.getX() > -200.0
                && player.getZ() < 200.0 && player.getZ() > -200.0;
        boolean targetAtSpawn = current.x() < 200 && current.x() > -200
                && current.z() < 200 && current.z() > -200;
        if (targetAtSpawn || playerAtSpawn) {
            if (playerAtSpawn) {
                LegacyCommandFeedback.send("\u0423\u0439\u0434\u0438\u0442\u0435 \u0441\u043E \u0441\u043F\u0430\u0432\u043D\u0430!");
            } else {
                LegacyCommandFeedback.send(
                        "\u0412\u0430\u0448\u0430 \u0446\u0435\u043B\u044C \u0441\u0442\u043E\u0438\u0442 \u043D\u0430 \u0441\u043F\u0430\u0432\u043D\u0435! "
                                + "\u0422\u0435\u043B\u0435\u043F\u043E\u0440\u0442 \u043D\u0435 \u0443\u0434\u0430\u043B\u0441\u044F :(");
            }
            return;
        }
        LegacyTeleportCoordinator.teleport(
                LegacyTeleportCoordinator.TeleportType.NORMAL,
                current.x(), current.y(), current.z());
        LegacyCommandFeedback.send(
                "\u041F\u044B\u0442\u0430\u0435\u043C\u0441\u044F \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u043A \u0446\u0435\u043B\u0438!");
    }

    private static void teleportToTrader() {
        LegacyTeleportCoordinator.Trader current = LegacyTeleportCoordinator.trader();
        if (current == null) {
            LegacyCommandFeedback.send("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u0442\u043E\u0440\u0433\u043E\u0432\u0446\u0430!");
            return;
        }
        if (!farEnough(current.x(), current.z())) {
            return;
        }
        sendDotWay(current.x(), current.z());
        LegacyTeleportCoordinator.teleport(
                LegacyTeleportCoordinator.TeleportType.NORMAL,
                current.x(), 57.0F, current.z());
        LegacyCommandFeedback.send(
                "\u041F\u044B\u0442\u0430\u0435\u043C\u0441\u044F \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u043A \u0442\u043E\u0440\u0433\u043E\u0432\u0446\u0443!");
    }

    private static void teleportToDeath() {
        BlockPos position = DeathCoords.lastDeathPosition();
        if (position == null) {
            LegacyCommandFeedback.send("\u041D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u043E \u043C\u0435\u0441\u0442\u0430 \u0441\u043C\u0435\u0440\u0442\u0438!");
            return;
        }
        if (!farEnough(position.getX(), position.getZ())) {
            return;
        }
        LegacyTeleportCoordinator.teleport(
                LegacyTeleportCoordinator.TeleportType.NORMAL,
                position.getX(), position.getY(), position.getZ());
        LegacyCommandFeedback.send(
                "\u041F\u044B\u0442\u0430\u0435\u043C\u0441\u044F \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u043A \u043C\u0435\u0441\u0442\u0443 \u0441\u043C\u0435\u0440\u0442\u0438!");
    }

    private static void teleportToCoordinates(String[] arguments) {
        boolean withoutY = arguments.length < 3;
        float x = Float.parseFloat(arguments[0]);
        float y = withoutY ? 150.0F : Float.parseFloat(arguments[1]);
        float z = Float.parseFloat(arguments[withoutY ? 1 : 2]);
        if (!farEnough((int) x, (int) z)) {
            return;
        }
        LegacyTeleportCoordinator.teleport(
                LegacyTeleportCoordinator.TeleportType.NORMAL, x, y, z);
        LegacyCommandFeedback.send(
                "\u041F\u044B\u0442\u0430\u0435\u043C\u0441\u044F \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u043E\u0432\u0430\u0442\u044C\u0441\u044F \u043D\u0430: \u00A7c"
                        + (int) x + " " + (int) y + " " + (int) z);
    }

    private static boolean farEnough(int x, int z) {
        ClientPlayerEntity player = MinecraftClient.getInstance().player;
        if (Math.hypot(player.getX() - x, player.getZ() - z) < 10.0) {
            LegacyCommandFeedback.send(
                    "\u0412\u044B \u0443\u0436\u0435 \u0440\u044F\u0434\u043E\u043C \u0441 \u044D\u0442\u043E\u0439 \u0442\u043E\u0447\u043A\u043E\u0439!");
            return false;
        }
        return true;
    }

    private static void noContract() {
        LegacyCommandFeedback.send(
                "\u0423 \u0432\u0430\u0441 \u043D\u0435\u0442 \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u0433\u043E \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0430!");
    }

    private static void sendDotWay(int x, int z) {
        MinecraftClient.getInstance().getNetworkHandler()
                .sendChatMessage(".way " + x + " " + z);
    }

    private static void usage() {
        LegacyCommandFeedback.send(
                "\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430! \u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435:");
        LegacyCommandFeedback.send("tp \u00A7c<x, z> \u0438\u043B\u0438 \u0436\u0435 <x, y, z>");
        LegacyCommandFeedback.send(
                "tp \u00A7cway - \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0435\u0442 \u0432\u0430\u0441 \u043A \u0430\u0438\u0440-\u0434\u0440\u043E\u043F\u0443 \u0438\u043B\u0438 \u0442\u0430\u043B\u0438\u0441\u043C\u0430\u043D\u0443");
        LegacyCommandFeedback.send(
                "tp \u00A7cct - \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0435\u0442 \u0432\u0430\u0441 \u043A \u0430\u043A\u0442\u0438\u0432\u043D\u043E\u043C\u0443 \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442\u0443");
        LegacyCommandFeedback.send(
                "tp \u00A7cinv \u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0438\u043D\u0432\u0435\u043D\u0442\u0430\u0440\u044C \u0436\u0435\u0440\u0442\u0432\u044B (\u043D\u0443\u0436\u0435\u043D \u0434\u043E\u0441\u0442\u0443\u043F \u043A /invsee)");
        LegacyCommandFeedback.send(
                "tp \u00A7ctorg \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0435\u0442 \u043A \u0442\u0430\u0439\u043D\u043E\u043C\u0443 \u0442\u043E\u0440\u0433\u043E\u0432\u0446\u0443");
        LegacyCommandFeedback.send(
                "tp \u00A7cdeath \u0442\u0435\u043B\u0435\u043F\u043E\u0440\u0442\u0438\u0440\u0443\u0435\u0442 \u043A \u043F\u043E\u0441\u043B\u0435\u0434\u043D\u0435\u043C\u0443 \u043C\u0435\u0441\u0442\u0443 \u0441\u043C\u0435\u0440\u0442\u0438");
    }
}
