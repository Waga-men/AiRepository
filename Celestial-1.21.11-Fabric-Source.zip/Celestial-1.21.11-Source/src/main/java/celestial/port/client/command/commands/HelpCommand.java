package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;

public final class HelpCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "help";
    }

    @Override
    public String description() {
        return "\u041F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0434\u043E\u0441\u0442\u0443\u043F\u043D\u044B\u0435 "
                + "\u043A\u043E\u043C\u0430\u043D\u0434\u044B \u0432 \u043A\u043B\u0438\u0435\u043D\u0442\u0435";
    }

    @Override
    public void execute(String[] arguments) {
        LegacyCommandFeedback.send("\u00A77--- \u00A7cHelp Manager\u00A77 ---");
        for (LegacyDotCommandDispatcher.Command command : LegacyDotCommandDispatcher.commands()) {
            LegacyCommandFeedback.send(command.name() + "\u00A77 : \u00A7c" + command.description());
        }
    }
}
