package celestial.port.client.ui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import net.minecraft.util.Util;
import org.lwjgl.glfw.GLFW;

public final class LegacyAddAltScreen extends Screen {
    private final Screen parent;
    private String username = "";
    private String password = "";
    private String status = "";
    private Field focused = Field.USERNAME;
    private static boolean microsoft;
    private float loginHover;
    private float backHover;
    private float providerHover;
    private long blinkStarted = System.currentTimeMillis();
    private LegacyMicrosoftAuth.Operation authOperation;
    private long authGeneration;

    public LegacyAddAltScreen(Screen parent) {
        super(Text.literal("Add alt"));
        this.parent = parent;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        if (focused != Field.PASSWORD) focused = Field.USERNAME;
        LegacyMenuRender.wallpaper(context, width, height);
        int fieldX = width / 2 - 100;
        int nameY = height / 2 - 70;
        int passwordY = height / 2 - 35;

        renderStatus(context);
        LegacyMenuRender.draw(context, textRenderer, "Name",
                fieldX, height / 2.0f - 80, 0xFFAAAAAA, LegacyMenuRender.FONT_DX);
        LegacyMenuRender.draw(context, textRenderer, "Password",
                fieldX, height / 2.0f - 45, 0xFFAAAAAA, LegacyMenuRender.FONT_DX);
        LegacyMenuRender.textField(context, textRenderer, fieldX, nameY,
                200, 20, username, false, focused == Field.USERNAME, blinkStarted);
        LegacyMenuRender.textField(context, textRenderer, fieldX, passwordY,
                200, 20, password, true, focused == Field.PASSWORD, blinkStarted);

        boolean loginHovered = LegacyMenuRender.inside(mouseX, mouseY,
                fieldX, height / 2 + 5, 200, 20);
        boolean backHovered = LegacyMenuRender.inside(mouseX, mouseY,
                fieldX, height / 2 + 30, 200, 20);
        loginHover = LegacyMenuRender.approach(loginHover, loginHovered, deltaTicks, 15.0f);
        backHover = LegacyMenuRender.approach(backHover, backHovered, deltaTicks, 15.0f);
        LegacyMenuRender.button(context, textRenderer, fieldX, height / 2 + 5,
                200, 20, "Login alt", true, loginHovered, loginHover,
                LegacyMainMenuScreen.shadersEnabled());
        LegacyMenuRender.button(context, textRenderer, fieldX, height / 2 + 30,
                200, 20, "Back", true, backHovered, backHover,
                LegacyMainMenuScreen.shadersEnabled());

        int iconOffset = microsoft ? 36 : 32;
        int iconX = width - iconOffset;
        int iconY = height - iconOffset;
        boolean providerHovered = LegacyMenuRender.inside(mouseX, mouseY,
                iconX, iconY, 32, 32);
        providerHover = LegacyMenuRender.approach(providerHover,
                providerHovered, deltaTicks, 8.0f);
        int iconAlpha = (int) (255.0f - providerHover * 150.0f);
        LegacyMenuRender.texture(context,
                microsoft ? LegacyMenuRender.MICROSOFT : LegacyMenuRender.MOJANG,
                iconX, iconY, 32, 32,
                LegacyMenuRender.withAlpha(0xFFFFFFFF, iconAlpha));
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        int fieldX = width / 2 - 100;
        if (LegacyMenuRender.inside(click.x(), click.y(),
                fieldX, height / 2 - 70, 200, 20)) {
            focus(Field.USERNAME);
            return true;
        }
        if (LegacyMenuRender.inside(click.x(), click.y(),
                fieldX, height / 2 - 35, 200, 20)) {
            focus(Field.PASSWORD);
            return true;
        }
        if (LegacyMenuRender.inside(click.x(), click.y(),
                fieldX, height / 2 + 5, 200, 20)) {
            if (client != null) LegacyMenuRender.playClick(client);
            submit();
            return true;
        }
        if (LegacyMenuRender.inside(click.x(), click.y(),
                fieldX, height / 2 + 30, 200, 20)) {
            if (client != null) LegacyMenuRender.playClick(client);
            close();
            return true;
        }
        int iconOffset = microsoft ? 36 : 32;
        if (LegacyMenuRender.inside(click.x(), click.y(),
                width - iconOffset, height - iconOffset, 32, 32)) {
            if (authOperation == null) microsoft = !microsoft;
            return true;
        }
        focus(Field.USERNAME);
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (key == GLFW.GLFW_KEY_ENTER || key == GLFW.GLFW_KEY_KP_ENTER) {
            submit();
            return true;
        }
        if (focused != Field.NONE && key == GLFW.GLFW_KEY_BACKSPACE) {
            if (focused == Field.USERNAME) username = removeLast(username);
            else password = removeLast(password);
            status = "";
            blinkStarted = System.currentTimeMillis();
            return true;
        }
        if (focused != Field.NONE && key == GLFW.GLFW_KEY_V && controlDown() && client != null) {
            append(client.keyboard.getClipboard());
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (input.codepoint() == ' ') return true;
        if (focused == Field.NONE || !input.isValidChar()) return super.charTyped(input);
        append(input.asString());
        return true;
    }

    private void append(String typed) {
        if (focused == Field.USERNAME) {
            int room = Math.max(0, 32 - username.codePointCount(0, username.length()));
            String filtered = typed.codePoints()
                    .filter(codePoint -> codePoint >= 32 && codePoint != 127 && codePoint != '\u00a7')
                    .limit(room)
                    .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                    .toString();
            username += filtered;
        } else if (focused == Field.PASSWORD) {
            int room = Math.max(0, 32 - password.codePointCount(0, password.length()));
            String filtered = typed.codePoints()
                    .filter(codePoint -> !Character.isISOControl(codePoint))
                    .limit(room)
                    .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                    .toString();
            password += filtered;
        }
        status = "";
        blinkStarted = System.currentTimeMillis();
    }

    private void submit() {
        if (authOperation != null) return;
        String clean = username.strip();
        if (microsoft) {
            password = "";
            startMicrosoftAdd();
            return;
        }
        if (clean.isEmpty()) {
            status = "Login required!";
            return;
        }
        if (!password.isEmpty()) {
            status = "Mojang password login is no longer supported";
            password = "";
            focus(Field.PASSWORD);
            return;
        }
        try {
            LegacyAltStore.instance().addOffline(clean, true);
            status = "Alt " + clean + " was added";
            username = "";
            focus(Field.USERNAME);
        } catch (IllegalArgumentException ignored) {
            status = "Invalid login!";
        }
    }

    private void startMicrosoftAdd() {
        status = "Trying login...";
        long generation = ++authGeneration;
        authOperation = LegacyMicrosoftAuth.deviceCode(new LegacyMicrosoftAuth.Callback() {
            @Override
            public void onDeviceCode(LegacyMicrosoftAuth.DevicePrompt prompt) {
                onClientThread(generation, () -> {
                    status = "Microsoft code copied: " + prompt.userCode();
                    if (client != null) {
                        try {
                            client.keyboard.setClipboard(prompt.userCode());
                            Util.getOperatingSystem().open(prompt.directVerificationUri());
                        } catch (RuntimeException | LinkageError ignored) {
                            status = "Microsoft code: " + prompt.userCode();
                        }
                    }
                });
            }

            @Override
            public void onSuccess(LegacyMicrosoftAuth.Result result) {
                onClientThread(generation, () -> {
                    authOperation = null;
                    try {
                        LegacyAltStore.AltAccount account =
                                LegacyAltStore.instance().addMicrosoft(result, true);
                        status = "Alt " + account.profileName() + " was added";
                        username = "";
                        password = "";
                        focus(Field.USERNAME);
                    } catch (RuntimeException | LinkageError ignored) {
                        status = "Login failed!";
                    }
                });
            }

            @Override
            public void onFailure() {
                onClientThread(generation, () -> {
                    authOperation = null;
                    status = "Login failed!";
                });
            }
        });
    }

    private void onClientThread(long generation, Runnable action) {
        if (client == null) return;
        client.execute(() -> {
            if (generation != authGeneration || client.currentScreen != this) return;
            action.run();
        });
    }

    private void focus(Field field) {
        focused = field;
        blinkStarted = System.currentTimeMillis();
    }

    private void renderStatus(DrawContext context) {
        if (!status.startsWith("Alt ") || !status.endsWith(" was added")) {
            LegacyMenuRender.draw(context, textRenderer, status, 2, 3,
                    status.isEmpty() ? 0xFFFFFFFF : 0xFFFF5555,
                    LegacyMenuRender.FONT_DX);
            return;
        }
        String prefix = "Alt ";
        String suffix = " was added";
        String name = status.substring(prefix.length(), status.length() - suffix.length());
        LegacyMenuRender.draw(context, textRenderer, prefix, 2, 3,
                0xFFFFFFFF, LegacyMenuRender.FONT_DX);
        float nameX = 2 + LegacyMenuRender.width(textRenderer, prefix, LegacyMenuRender.FONT_DX);
        LegacyMenuRender.draw(context, textRenderer, name, nameX, 3,
                0xFF55FF55, LegacyMenuRender.FONT_DX);
        LegacyMenuRender.draw(context, textRenderer, suffix,
                nameX + LegacyMenuRender.width(textRenderer, name, LegacyMenuRender.FONT_DX),
                3, 0xFFFFFFFF, LegacyMenuRender.FONT_DX);
    }

    private boolean controlDown() {
        if (client == null) return false;
        long handle = client.getWindow().getHandle();
        return GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
    }

    private static String removeLast(String value) {
        if (value.isEmpty()) return value;
        return value.substring(0, value.offsetByCodePoints(value.length(), -1));
    }

    @Override
    public void close() {
        cancelAuthentication();
        password = "";
        if (client != null) client.setScreen(parent);
    }

    @Override
    public void removed() {
        cancelAuthentication();
        password = "";
        super.removed();
    }

    private void cancelAuthentication() {
        authGeneration++;
        if (authOperation == null) return;
        authOperation.cancel();
        authOperation = null;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private enum Field {
        NONE, USERNAME, PASSWORD
    }
}
