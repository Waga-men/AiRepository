package celestial.port.client.ui;

import celestial.port.CelestialPortClient;
import celestial.port.modules.render.ClickGuiModule;
import celestial.port.modules.visual.XRay;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.item.ItemStack;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Objects;

public final class XRayScreen extends Screen {
    private static final Identifier CLOSE = Identifier.of("celestial", "images/close.png");
    private static final int PANEL_WIDTH = 180;
    private static final int CELL_SIZE = 20;
    private static final int CELL_STEP = 25;
    private static final int COLUMNS = 7;
    private static final StyleSpriteSource FONT_DY = new StyleSpriteSource.Font(
            Identifier.of("celestial", "montserrat_21"));
    private static final int WHITE = 0xFFFFFFFF;
    private static final int INACTIVE_CELL = 0x96000000;

    private final Screen parent;
    private final XRay xray;

    private int panelX;
    private int panelY;
    private double closeHoverLinear;
    private long lastRenderNanos = System.nanoTime();

    public XRayScreen(Screen parent, XRay xray) {
        super(Text.literal("Xray UI"));
        this.parent = parent;
        this.xray = Objects.requireNonNull(xray, "xray");
    }

    @Override
    public void renderBackground(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        if (client == null || client.world == null) {
            super.renderBackground(context, mouseX, mouseY, deltaTicks);
            return;
        }
        if (legacyBlurEnabled()) {
            context.applyBlur();
        }
        client.inGameHud.renderDeferredSubtitles();
    }

    public boolean legacyBlurEnabled() {
        return CelestialPortClient.MODULES.find("click_gui")
                .filter(ClickGuiModule.class::isInstance)
                .map(ClickGuiModule.class::cast)
                .map(ClickGuiModule::blurEnabled)
                .orElse(false);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        int guiScale = legacyGuiScale();
        float fixedScale = 2.0f / guiScale;
        int legacyWidth = (int) (width * (guiScale / 2.0f));
        int legacyHeight = (int) (height * (guiScale / 2.0f));
        int legacyMouseX = toLegacyCoordinate(mouseX, guiScale);
        int legacyMouseY = toLegacyCoordinate(mouseY, guiScale);

        panelX = legacyWidth / 2 - 90;
        panelY = legacyHeight / 2 - 85;
        int headerY = panelY - 20;
        int first = primaryColor();
        int second = legacySecondaryColor(secondaryColor());

        context.getMatrices().pushMatrix();
        context.getMatrices().scale(fixedScale, fixedScale);

        SmoothRoundedGui.fillNoise(context, panelX - 5, headerY + 1,
                PANEL_WIDTH, 143, 5.5f, 10.0f, 0x96FFFFFF);
        SmoothRoundedGui.fill(context, panelX - 5, headerY + 3,
                PANEL_WIDTH, 145, 7.0f, WHITE);
        SmoothRoundedGui.fillFourCorners(context, panelX - 5, headerY,
                PANEL_WIDTH, 13, 4.0f, first, second, second, first);
        SmoothRoundedGui.fillFourCorners(context, panelX - 5, headerY + 5,
                PANEL_WIDTH, 8, 0.0f, first, second, second, first);

        String title = "Xray UI / Selected: " + xray.selectedCount();

        int closeX = panelX + PANEL_WIDTH - 17;
        int closeY = panelY - 18;
        boolean closeHovered = inside(legacyMouseX, legacyMouseY, closeX, closeY, 9, 9);
        LegacyMenuRender.texture(context, CLOSE, closeX, closeY, 9, 9,
                closeTint(updateCloseHover(closeHovered)));
        drawCenteredTitle(context, title, panelX + 85.0f, headerY + 2.5f);

        List<XRay.BlockSelection> blocks = xray.selections();
        for (int index = 0; index < blocks.size(); index++) {
            XRay.BlockSelection selection = blocks.get(index);
            int cellX = panelX + index % COLUMNS * CELL_STEP;
            int cellY = panelY + index / COLUMNS * CELL_STEP;
            int background = selection.selected() ? first : INACTIVE_CELL;
            int bottom = selection.selected() ? second : INACTIVE_CELL;
            SmoothRoundedGui.fillFourCorners(context, cellX, cellY,
                    CELL_SIZE, CELL_SIZE, 2.0f,
                    background, bottom, bottom, background);

            ItemStack stack = selection.block().asItem().getDefaultStack();
            if (!stack.isEmpty()) {
                context.getMatrices().pushMatrix();
                context.getMatrices().translate(cellX, cellY);
                context.getMatrices().scale(1.25f, 1.25f);
                context.drawItem(stack, 0, 0);
                context.getMatrices().popMatrix();
            }
        }

        context.getMatrices().popMatrix();

        super.render(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        int guiScale = legacyGuiScale();
        int mouseX = toLegacyCoordinate(click.x(), guiScale);
        int mouseY = toLegacyCoordinate(click.y(), guiScale);

        int closeX = panelX + PANEL_WIDTH - 17;
        int closeY = panelY - 18;
        if (click.button() == 0 && inside(mouseX, mouseY, closeX, closeY, 9, 9)) {
            returnToParent();
            return true;
        }

        List<XRay.BlockSelection> blocks = xray.selections();
        for (int index = 0; index < blocks.size(); index++) {
            int cellX = panelX + index % COLUMNS * CELL_STEP;
            int cellY = panelY + index / COLUMNS * CELL_STEP;
            if (inside(mouseX, mouseY, cellX, cellY, CELL_SIZE, CELL_SIZE)) {
                xray.toggleSelection(blocks.get(index));
                return true;
            }
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public void close() {
        if (client != null) {
            client.setScreen(null);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private static boolean inside(double x, double y, int left, int top, int width, int height) {
        return x >= left && y >= top && x < left + width && y < top + height;
    }

    private void returnToParent() {
        if (client != null) {
            client.setScreen(parent);
        }
    }

    private int legacyGuiScale() {
        return client == null ? 2 : Math.max(1, client.getWindow().getScaleFactor());
    }

    private static int toLegacyCoordinate(double coordinate, int guiScale) {
        return (int) (coordinate * (guiScale / 2.0));
    }

    private double updateCloseHover(boolean hovered) {
        long now = System.nanoTime();
        double frameMillis = Math.max(0.0, (now - lastRenderNanos) / 1_000_000.0);
        lastRenderNanos = now;
        double direction = hovered ? 1.0 : -1.0;
        closeHoverLinear = Math.max(0.0, Math.min(1.0,
                closeHoverLinear + direction * 0.45 * frameMillis * 0.01));
        return Math.sqrt(1.0 - Math.pow(closeHoverLinear - 1.0, 2.0));
    }

    private static int closeTint(double hoverProgress) {
        int channel = (int) (255.0 * (1.0 - 0.4 * hoverProgress));
        return 0xFF000000 | channel << 16 | channel << 8 | channel;
    }

    private void drawCenteredTitle(
            DrawContext context, String value, float centerX, float y
    ) {
        float x = centerX - LegacyMenuRender.width(textRenderer, value, FONT_DY) / 2.0f;
        int shadowColor = (WHITE & 0x00FCFCFC) >> 2 | WHITE & 0xC8141414;
        LegacyMenuRender.draw(context, textRenderer, value,
                x + 0.5f, y + 0.5f, shadowColor, FONT_DY);
        LegacyMenuRender.draw(context, textRenderer, value, x, y, WHITE, FONT_DY);
    }

    private static int primaryColor() {
        return CelestialPortClient.MODULES.find("click_gui")
                .filter(ClickGuiModule.class::isInstance)
                .map(ClickGuiModule.class::cast)
                .map(ClickGuiModule::primaryColor)
                .orElse(0xFFBF68FF);
    }

    private static int secondaryColor() {
        return CelestialPortClient.MODULES.find("click_gui")
                .filter(ClickGuiModule.class::isInstance)
                .map(ClickGuiModule.class::cast)
                .map(ClickGuiModule::secondaryColor)
                .orElse(0xFF110122);
    }

    private static int legacySecondaryColor(int color) {
        int red = (int) (((color >>> 16) & 0xFF) * 0.7f);
        int green = (int) (((color >>> 8) & 0xFF) * 0.7f);
        int blue = (int) ((color & 0xFF) * 0.7f);
        return 0xFF000000 | red << 16 | green << 8 | blue;
    }
}
