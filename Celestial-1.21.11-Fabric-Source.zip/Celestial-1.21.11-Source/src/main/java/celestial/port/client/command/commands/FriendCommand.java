package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.core.friend.FriendManager;

public final class FriendCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "friend";
    }

    @Override
    public String description() {
        return "\u0414\u043E\u0431\u0430\u0432\u043B\u044F\u0435\u0442 \u0434\u0440\u0443\u0433\u0430 \u043F\u043E \u043D\u0438\u043A\u0443";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length < 1) {
            usage();
            return;
        }

        try {
            if (arguments[0].equalsIgnoreCase("add")) {
                if (FriendManager.add(arguments[1])) {
                    LegacyCommandFeedback.send("\u0418\u0433\u0440\u043E\u043A " + arguments[1]
                            + " \u0431\u044B\u043B \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D \u0432 \u0441\u043F\u0438\u0441\u043E\u043A \u0434\u0440\u0443\u0437\u0435\u0439!");
                } else {
                    LegacyCommandFeedback.send("\u0418\u0433\u0440\u043E\u043A " + arguments[1]
                            + " \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u0432 \u0441\u043F\u0438\u0441\u043A\u0435 \u0434\u0440\u0443\u0437\u0435\u0439!");
                }
            }
            if (arguments[0].equalsIgnoreCase("delete")
                    || arguments[0].equalsIgnoreCase("remove")) {
                if (FriendManager.remove(arguments[1])) {
                    LegacyCommandFeedback.send("\u0418\u0433\u0440\u043E\u043A " + arguments[1]
                            + " \u0431\u044B\u043B \u0443\u0434\u0430\u043B\u0435\u043D \u0438\u0437 \u0441\u043F\u0438\u0441\u043A\u0430 \u0434\u0440\u0443\u0437\u0435\u0439!");
                    return;
                }
                LegacyCommandFeedback.send("\u0418\u0433\u0440\u043E\u043A " + arguments[1]
                        + " \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D \u0432 \u0441\u043F\u0438\u0441\u043A\u0435 \u0434\u0440\u0443\u0437\u0435\u0439!");
            }
        } catch (Exception exception) {
            LegacyCommandFeedback.send("\u041E\u0448\u0438\u0431\u043A\u0430 \u0430\u0440\u0433\u0443\u043C\u0435\u043D\u0442\u043E\u0432!");
        }

        if (arguments[0].equalsIgnoreCase("list")) {
            if (FriendManager.names().isEmpty()) {
                LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043F\u0438\u0441\u043E\u043A \u0434\u0440\u0443\u0437\u0435\u0439 \u043F\u0443\u0441\u0442\u043E\u0439!");
                return;
            }
            LegacyCommandFeedback.send("\u0421\u043F\u0438\u0441\u043E\u043A \u0434\u0440\u0443\u0437\u0435\u0439:");
            for (String friend : FriendManager.names()) {
                LegacyCommandFeedback.send(friend);
            }
        }
        if (arguments[0].equalsIgnoreCase("clear")) {
            if (FriendManager.names().isEmpty()) {
                LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043F\u0438\u0441\u043E\u043A \u0434\u0440\u0443\u0437\u0435\u0439 \u0443\u0436\u0435 \u043F\u0443\u0441\u0442\u043E\u0439!");
                return;
            }
            FriendManager.clear();
            LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043F\u0438\u0441\u043E\u043A \u0434\u0440\u0443\u0437\u0435\u0439 \u0431\u044B\u043B \u043E\u0447\u0438\u0449\u0435\u043D!");
        }
    }

    private static void usage() {
        LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430! "
                + "\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435:");
        LegacyCommandFeedback.send("friend \u00A7cadd \u00A77<name> (\u0447\u0442\u043E\u0431\u044B \u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0434\u0440\u0443\u0433\u0430)");
        LegacyCommandFeedback.send("friend \u00A7cdelete \u00A77<name> (\u0447\u0442\u043E\u0431\u044B \u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0434\u0440\u0443\u0433\u0430)");
        LegacyCommandFeedback.send("friend \u00A7clist \u00A77(\u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0441\u043F\u0438\u0441\u043E\u043A \u0432\u0441\u0435\u0445 \u0434\u0440\u0443\u0437\u0435\u0439)");
        LegacyCommandFeedback.send("friend \u00A7cclear \u00A77(\u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0432\u0441\u0435\u0445 \u0434\u0440\u0443\u0437\u0435\u0439)");
    }
}
