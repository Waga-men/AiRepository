package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.core.macro.LegacyMacroKeyCodec;
import celestial.port.core.macro.MacroManager;

public final class MacroCommand implements LegacyDotCommandDispatcher.Command {
    private static final String GRAY = "\u00A77";
    private static final String RED = "\u00A7c";
    private static final String WHITE = "\u00A7f";

    @Override
    public String name() {
        return "macro";
    }

    @Override
    public String description() {
        return "\u0423\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u043c\u0430\u043a\u0440\u043e\u0441\u0430\u043c\u0438 \u0432 \u043a\u043b\u0438\u0435\u043d\u0442\u0435";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length <= 0) {
            LegacyCommandFeedback.send("\u041d\u0435\u0432\u0435\u0440\u043d\u0430\u044f \u043a\u043e\u043c\u0430\u043d\u0434\u0430! \u041f\u043e\u0436\u0430\u043b\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435:");
            LegacyCommandFeedback.send("macro " + RED + "add " + GRAY + "<key> <text>");
            LegacyCommandFeedback.send("macro " + RED + "delete " + GRAY
                    + "<key> (\u0447\u0442\u043e\u0431\u044b \u0443\u0434\u0430\u043b\u0438\u0442\u044c \u043c\u0430\u043a\u0440\u043e\u0441)");
            LegacyCommandFeedback.send("macro " + RED + "list " + GRAY
                    + "(\u043f\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a \u0432\u0441\u0435\u0445 \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432)");
            LegacyCommandFeedback.send("macro " + RED + "clear " + GRAY
                    + "(\u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0432\u0441\u0435 \u043c\u0430\u043a\u0440\u043e\u0441\u044b)");
            LegacyCommandFeedback.send(".macro add mouse2 <text> (\u043a\u0430\u043a \u043f\u0440\u0438\u043c\u0435\u0440) - "
                    + "\u041c\u0430\u043a\u0440\u043e\u0441 \u043d\u0430 \u0431\u043e\u043a\u043e\u0432\u044b\u0435 \u043a\u043b\u0430\u0432\u0438\u0448\u0438 \u043c\u044b\u0448\u0438");
            return;
        }

        String operation = arguments[0];
        if (operation.equalsIgnoreCase("add")) {
            add(arguments);
            return;
        }
        if (operation.equalsIgnoreCase("delete") || operation.equalsIgnoreCase("remove")) {
            remove(arguments);
            return;
        }
        if (operation.equalsIgnoreCase("clear")) {
            if (MacroManager.entries().isEmpty()) {
                LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043f\u0438\u0441\u043e\u043a \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432 \u0443\u0436\u0435 \u043f\u0443\u0441\u0442\u043e\u0439!");
                return;
            }
            MacroManager.clear();
            LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043f\u0438\u0441\u043e\u043a \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432 \u0431\u044b\u043b \u043e\u0447\u0438\u0449\u0435\u043d!");
            return;
        }
        if (operation.equalsIgnoreCase("list")) {
            var entries = MacroManager.entries();
            if (entries.isEmpty()) {
                LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043f\u0438\u0441\u043e\u043a \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432 \u043f\u0443\u0441\u0442\u043e\u0439!");
                return;
            }
            LegacyCommandFeedback.send("\u0421\u043f\u0438\u0441\u043e\u043a \u043c\u0430\u043a\u0440\u043e\u0441\u043e\u0432:");
            for (MacroManager.Entry entry : entries) {
                LegacyCommandFeedback.send(WHITE + entry.text() + GRAY
                        + " : \u041a\u043b\u0430\u0432\u0438\u0448\u0430 " + RED + "'"
                        + LegacyMacroKeyCodec.name(entry.legacyKey()) + "'");
            }
        }
    }

    private static void add(String[] arguments) {
        if (arguments.length <= 2) {
            LegacyCommandFeedback.send("\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d\u0438\u0438 \u043c\u0430\u043a\u0440\u043e\u0441\u0430!");
            return;
        }
        StringBuilder text = new StringBuilder();
        for (int index = 2; index < arguments.length; index++) {
            text.append(arguments[index]);
            if (index != arguments.length - 1) text.append(' ');
        }

        int legacyKey;
        if (arguments[1].contains("mouse")) {

            legacyKey = -100 + Integer.parseInt(arguments[1].replaceAll("mouse", ""));
        } else {
            legacyKey = LegacyMacroKeyCodec.fromLegacy(arguments[1].toUpperCase());
        }
        String macro = text.toString();
        MacroManager.add(legacyKey, macro);
        LegacyCommandFeedback.send("\u041c\u0430\u043a\u0440\u043e\u0441 " + RED + "'" + macro + "'" + WHITE
                + " \u0431\u044b\u043b \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u043d\u0430 \u043a\u043b\u0430\u0432\u0438\u0448\u0443 " + RED + "'"
                + LegacyMacroKeyCodec.name(legacyKey) + "'");
    }

    private static void remove(String[] arguments) {
        if (arguments.length <= 1) {
            LegacyCommandFeedback.send("\u041e\u0448\u0438\u0431\u043a\u0430 \u043f\u0440\u0438 \u0443\u0434\u0430\u043b\u0435\u043d\u0438\u0438 \u043c\u0430\u043a\u0440\u043e\u0441\u0430!");
            return;
        }

        if (arguments[1].contains("mouse")) {

            int legacyKey = -100 + Integer.parseInt(arguments[1].replaceAll("mouse", ""));
            MacroManager.removeAll(legacyKey);
            LegacyCommandFeedback.send("\u041c\u0430\u043a\u0440\u043e\u0441 \u0431\u044b\u043b \u0443\u0434\u0430\u043b\u0435\u043d \u0441 \u043a\u043d\u043e\u043f\u043a\u0438 " + RED
                    + "'" + LegacyMacroKeyCodec.name(legacyKey) + "'");
            return;
        }

        int legacyKey = LegacyMacroKeyCodec.fromLegacy(arguments[1].toUpperCase());
        MacroManager.removeAll(legacyKey);
        LegacyCommandFeedback.send("\u041c\u0430\u043a\u0440\u043e\u0441 \u0431\u044b\u043b \u0443\u0434\u0430\u043b\u0435\u043d \u0441 \u043a\u043b\u0430\u0432\u0438\u0448\u0438 " + RED
                + "'" + LegacyMacroKeyCodec.name(legacyKey) + "'");
    }
}
