package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.core.staff.ManualStaffRegistry;

public final class StaffCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "staff";
    }

    @Override
    public String description() {
        return "\u0414\u043e\u0431\u0430\u0432\u043b\u044f\u0435\u0442 \u0430\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u044e \u043f\u043e \u043d\u0438\u043a\u0443 \u0432 \u0441\u043f\u0438\u0441\u043e\u043a";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length < 1) {
            LegacyCommandFeedback.send("\u041d\u0435\u0432\u0435\u0440\u043d\u0430\u044f \u043a\u043e\u043c\u0430\u043d\u0434\u0430! \u041f\u043e\u0436\u0430\u043b\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435:");
            LegacyCommandFeedback.send("staff \u00a7cadd \u00a77<name> (\u0447\u0442\u043e\u0431\u044b \u0434\u043e\u0431\u0430\u0432\u0438\u0442\u044c \u0438\u0433\u0440\u043e\u043a\u0430 \u0432 StaffList)");
            LegacyCommandFeedback.send("staff \u00a7cdelete \u00a77<name> (\u0447\u0442\u043e\u0431\u044b \u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0438\u0433\u0440\u043e\u043a\u0430 \u0438\u0437 StaffList)");
            LegacyCommandFeedback.send("staff \u00a7clist \u00a77(\u043f\u043e\u043a\u0430\u0437\u044b\u0432\u0430\u0435\u0442 \u0441\u043f\u0438\u0441\u043e\u043a \u0432\u0441\u0435\u0445 \u0438\u0433\u0440\u043e\u043a\u043e\u0432 \u0432 StaffList)");
            LegacyCommandFeedback.send("staff \u00a7cclear \u00a77(\u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0432\u0441\u0435\u0445 \u0438\u0433\u0440\u043e\u043a\u043e\u0432 \u0438\u0437 StaffList)");
            return;
        }

        try {
            if (arguments[0].equalsIgnoreCase("add")) {
                if (arguments[1].length() < 3) {
                    LegacyCommandFeedback.send("\u041d\u0438\u043a \u0438\u0433\u0440\u043e\u043a\u0430 \u0434\u043e\u043b\u0436\u0435\u043d \u0431\u044b\u0442\u044c \u043d\u0435 \u043c\u0435\u043d\u044c\u0448\u0435 3 \u0441\u0438\u043c\u0432\u043e\u043b\u043e\u0432!");
                    return;
                }
                if (ManualStaffRegistry.add(arguments[1])) {
                    LegacyCommandFeedback.send("\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440 " + arguments[1]
                            + " \u0431\u044b\u043b \u0434\u043e\u0431\u0430\u0432\u043b\u0435\u043d \u0432 \u0441\u043f\u0438\u0441\u043e\u043a!");
                } else {
                    LegacyCommandFeedback.send("\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440 " + arguments[1]
                            + " \u0443\u0436\u0435 \u0435\u0441\u0442\u044c \u0432 \u0441\u043f\u0438\u0441\u043a\u0435!");
                }
            }
            if (arguments[0].equalsIgnoreCase("delete")
                    || arguments[0].equalsIgnoreCase("remove")) {
                if (ManualStaffRegistry.remove(arguments[1])) {
                    LegacyCommandFeedback.send("\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440 " + arguments[1]
                            + " \u0431\u044b\u043b \u0443\u0434\u0430\u043b\u0435\u043d \u0438\u0437 \u0441\u043f\u0438\u0441\u043a\u0430!");
                } else {
                    LegacyCommandFeedback.send("\u0410\u0434\u043c\u0438\u043d\u0438\u0441\u0442\u0440\u0430\u0442\u043e\u0440 " + arguments[1]
                            + " \u043d\u0435 \u043d\u0430\u0439\u0434\u0435\u043d \u0432 \u0441\u043f\u0438\u0441\u043a\u0435!");
                }
            }
        } catch (Exception exception) {
            LegacyCommandFeedback.send("\u041e\u0448\u0438\u0431\u043a\u0430 \u0430\u0440\u0433\u0443\u043c\u0435\u043d\u0442\u043e\u0432!");
        }

        if (arguments[0].equalsIgnoreCase("list")) {
            if (ManualStaffRegistry.isEmpty()) {
                LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043f\u0438\u0441\u043e\u043a \u043f\u0443\u0441\u0442\u043e\u0439!");
                return;
            }
            LegacyCommandFeedback.send("\u0421\u043f\u0438\u0441\u043e\u043a \u043f\u0435\u0440\u0441\u043e\u043d\u0430\u043b\u0430:");
            ManualStaffRegistry.names().forEach(LegacyCommandFeedback::send);
        }
        if (arguments[0].equalsIgnoreCase("clear")) {
            if (ManualStaffRegistry.isEmpty()) {
                LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043f\u0438\u0441\u043e\u043a \u0443\u0436\u0435 \u043f\u0443\u0441\u0442\u043e\u0439!");
                return;
            }
            ManualStaffRegistry.clear();
            LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043f\u0438\u0441\u043e\u043a \u0431\u044b\u043b \u043e\u0447\u0438\u0449\u0435\u043d!");
        }
    }
}
