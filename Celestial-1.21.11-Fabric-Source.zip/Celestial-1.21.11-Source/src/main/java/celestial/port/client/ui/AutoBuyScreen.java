package celestial.port.client.ui;

import celestial.port.CelestialPortClient;
import celestial.port.modules.legacyutility.AutoBuy;
import celestial.port.modules.render.ClickGuiModule;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;

public final class AutoBuyScreen extends Screen {
    private static final Identifier CLOSE = Identifier.of("celestial", "images/close.png");
    private static final Identifier SETTINGS = Identifier.of("celestial", "images/setting.png");
    private static final Identifier DELETE = Identifier.of("celestial", "images/delete.png");
    private static final Identifier EDIT = Identifier.of("celestial", "images/edit.png");

    private static final int PANEL_WIDTH = 180;
    private static final int PANEL_BODY_HEIGHT = 145;
    private static final int LIST_HEIGHT = 113;
    private static final int ENTRY_HEIGHT = 55;
    private static final int POPUP_WIDTH = 140;

    private static final StyleSpriteSource FONT_DQ = LegacyHudFont.font(11);
    private static final StyleSpriteSource FONT_DR = LegacyHudFont.font(12);
    private static final StyleSpriteSource FONT_DT = LegacyHudFont.font(14);
    private static final StyleSpriteSource FONT_DU = LegacyHudFont.font(15);
    private static final StyleSpriteSource FONT_DY = font(21);
    private static final StyleSpriteSource FONT_MODE_ARROW = font(15);

    private static final int WHITE = 0xFFFFFFFF;
    private static final int BLACK = 0xFF000000;
    private static final int LEGACY_RED = 0xFFFF5555;
    private static final int CARD = 0x96000000;

    private final Screen parent;
    private final AutoBuy autoBuy;
    private final LinkedHashMap<Identifier, Integer> draftEnchantments = new LinkedHashMap<>();
    private final LinkedHashMap<Identifier, Integer> enchantDraft = new LinkedHashMap<>();
    private final List<EnchantChoice> enchantments = new ArrayList<>();
    private final IdentityHashMap<AutoBuy.Entry, PopupPosition> editPopupPositions =
            new IdentityHashMap<>();
    private final PopupPosition settingsPopup = new PopupPosition();
    private final PopupPosition addPopup = new PopupPosition();
    private final PopupPosition enchantPopup = new PopupPosition();

    private View view = View.MAIN;
    private View enchantReturnView = View.ADD;
    private Field focusedField = Field.NONE;
    private Drag drag = Drag.NONE;
    private AutoBuy.Entry editingEntry;

    private int panelX;
    private int panelY;
    private double listScroll;
    private double listScrollTarget;
    private double enchantScroll;
    private double enchantScrollTarget;
    private String itemText = "";
    private String priceText = "";
    private int draftCount = 1;
    private boolean draftEnchanted;
    private String error = "";
    private Field errorField = Field.NONE;
    private long cursorBlinkStarted = System.currentTimeMillis();
    private boolean enchantmentsLoaded;
    private boolean selectedAll;
    private boolean modeOpen;
    private int popupDragOffsetX;
    private int popupDragOffsetY;
    private Identifier draggedEnchantment;
    private View draggedPopupView = View.MAIN;

    public AutoBuyScreen(Screen parent, AutoBuy autoBuy) {
        super(Text.literal("AutoBuy UI"));
        this.parent = parent;
        this.autoBuy = Objects.requireNonNull(autoBuy, "autoBuy");
    }

    @Override
    protected void init() {
        loadEnchantments();
    }

    @Override
    public void renderBackground(
            DrawContext context, int mouseX, int mouseY, float deltaTicks
    ) {
        if (client == null || client.world == null) {
            super.renderBackground(context, mouseX, mouseY, deltaTicks);
            return;
        }
        if (legacyBlurEnabled()) {
            context.applyBlur();
        }
        client.inGameHud.renderDeferredSubtitles();
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        panelX = width / 2 - 90;
        panelY = height / 2 - 85;

        drawWindow(context, panelX - 5, panelY - 20, PANEL_WIDTH, PANEL_BODY_HEIGHT,
                "AutoBuy UI");
        renderMain(context, mouseX, mouseY, deltaTicks);
        renderChrome(context, mouseX, mouseY);

        if (view != View.MAIN) {
            switch (view) {
                case SETTINGS -> renderSettings(context, mouseX, mouseY);
                case ADD -> renderEditor(context, mouseX, mouseY, false);
                case EDIT -> renderEditor(context, mouseX, mouseY, true);
                case ENCHANTMENTS -> {
                    renderEditor(context, mouseX, mouseY,
                            enchantReturnView == View.EDIT);
                    renderEnchantments(context, mouseX, mouseY, deltaTicks);
                }
                default -> {
                }
            }
        }

        super.render(context, mouseX, mouseY, deltaTicks);
    }

    private void renderMain(
            DrawContext context, int mouseX, int mouseY, float deltaTicks
    ) {
        MainLayout layout = mainLayout();
        int maximumScroll = Math.max(0, autoBuy.entries().size() * ENTRY_HEIGHT - LIST_HEIGHT);
        listScrollTarget = clamp(listScrollTarget, 0.0, maximumScroll);
        listScroll = clamp(approachScroll(listScroll, listScrollTarget, deltaTicks),
                0.0, maximumScroll);

        context.enableScissor(layout.viewport.x, layout.viewport.y,
                layout.viewport.right(), layout.viewport.bottom());
        List<AutoBuy.Entry> entries = autoBuy.entries();
        for (int index = 0; index < entries.size(); index++) {
            AutoBuy.Entry entry = entries.get(index);
            int y = panelY + index * ENTRY_HEIGHT - (int) listScroll;
            if (y + ENTRY_HEIGHT <= layout.viewport.y || y >= layout.viewport.bottom()) {
                continue;
            }
            renderEntry(context, entry, y, mouseX, mouseY);
        }
        context.disableScissor();

        mainButton(context, layout.add, "Добавить предмет",
                layout.add.contains(mouseX, mouseY), true);
        mainButton(context, layout.clear, "Удалить предметы",
                layout.clear.contains(mouseX, mouseY), !entries.isEmpty());
    }

    private void renderEntry(
            DrawContext context, AutoBuy.Entry entry, int y, int mouseX, int mouseY
    ) {
        EntryLayout layout = entryLayout(y);
        SmoothRoundedGui.fill(context, layout.details.x, layout.details.y,
                layout.details.width, layout.details.height, 2.0f, CARD);
        SmoothRoundedGui.fill(context, layout.item.x, layout.item.y,
                layout.item.width, layout.item.height, 2.0f, CARD);
        SmoothRoundedGui.fill(context, layout.actions.x, layout.actions.y,
                layout.actions.width, layout.actions.height, 2.0f, 0x3C000000);

        ItemStack stack = entry.stack().copy();
        if (entry.enchantedWithoutNbt()) {
            stack.set(DataComponentTypes.ENCHANTMENT_GLINT_OVERRIDE, true);
        }
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(panelX + 5, y + 2);
        context.getMatrices().scale(1.5f, 1.5f);
        context.drawItem(stack, 0, 0);
        context.getMatrices().popMatrix();

        int textX = panelX + 36;
        drawEntryLine(context, "Предмет: ", stack.getName().getString(), false,
                textX, y + 3);
        drawEntryLine(context, "Количество: ", Long.toString(entry.minimumCount()), false,
                textX, y + 13);
        drawEntryLine(context, "Макс. цена: ", Long.toString(entry.maximumPrice()), true,
                textX, y + 23);
        drawEntryLine(context, "Зачарован: ",
                entry.enchantedWithoutNbt() ? "Да" : "Нет", true, textX, y + 33);
        drawEntryLine(context, "Зачарования: ",
                stripLegacyRed(entry.enchantmentSummary()), true, textX, y + 43);

        icon(context, DELETE, layout.delete,
                layout.delete.contains(mouseX, mouseY));
        icon(context, EDIT, layout.edit,
                layout.edit.contains(mouseX, mouseY));
    }

    private void renderChrome(DrawContext context, int mouseX, int mouseY) {
        MainLayout layout = mainLayout();
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(0.0f, -0.5f);
        icon(context, SETTINGS, layout.settings,
                layout.settings.contains(mouseX, mouseY));
        context.getMatrices().popMatrix();
        icon(context, CLOSE, layout.close,
                layout.close.contains(mouseX, mouseY));
    }

    private void renderSettings(DrawContext context, int mouseX, int mouseY) {
        Popup popup = popup(View.SETTINGS, 50);
        SettingsLayout layout = settingsLayout(popup);
        drawPopup(context, popup, "Настройка");
        drawLegacySlider(context, layout.delay, "Задержка",
                0, 1000, autoBuy.clickDelayMs(), mouseX, mouseY);
        drawPopupClose(context, popup, mouseX, mouseY);
    }

    private void renderEditor(
            DrawContext context, int mouseX, int mouseY, boolean editing
    ) {
        Popup popup = popup(editing ? View.EDIT : View.ADD, editing ? 120 : 170);
        EditorLayout layout = editorLayout(popup, editing);
        drawPopup(context, popup, editing ? "Редактирование" : "Добавление");

        if (!editing) {
            drawLegacyInput(context, layout.item,
                    itemText, autoBuy.addMode() == AutoBuy.AddMode.ID
                            ? "Введите ID предмета" : "Введите название предмета",
                    Field.ITEM);
        }

        drawLegacyInput(context, layout.price, priceText,
                "Введите максимальную цену", Field.PRICE);
        drawLegacySlider(context, layout.count,
                editing ? "Выберите количество" : "Выберите количество от",
                1, 64, draftCount, mouseX, mouseY);
        drawLegacyToggle(context, layout.enchanted, "Зачарован без NBT",
                draftEnchanted, mouseX, mouseY);

        String enchantLabel = editing ? "Изменить зачарования" : "Добавить зачарования";
        popupButton(context, layout.enchantButton, enchantLabel,
                layout.enchantButton.contains(mouseX, mouseY));
        String action = editing ? "Применить" : "Добавить";
        popupButton(context, layout.actionButton, action,
                layout.actionButton.contains(mouseX, mouseY));
        if (!editing) {
            drawModeDropdown(context, layout.mode, mouseX, mouseY);
        }
        drawPopupClose(context, popup, mouseX, mouseY);
    }

    private void renderEnchantments(
            DrawContext context, int mouseX, int mouseY, float deltaTicks
    ) {
        loadEnchantments();
        Popup popup = popup(View.ENCHANTMENTS, 126);
        drawPopup(context, popup, "Зачарования");
        Rect viewport = enchantViewport(popup);
        int maximumScroll = Math.max(0, enchantmentContentHeight() + 30 - popup.height);
        enchantScrollTarget = clamp(enchantScrollTarget, 0.0, maximumScroll);
        enchantScroll = clamp(approachScroll(enchantScroll, enchantScrollTarget, deltaTicks),
                0.0, maximumScroll);

        context.enableScissor(viewport.x, viewport.y, viewport.right(), viewport.bottom());
        int y = popup.y + 22 - (int) enchantScroll;
        for (EnchantChoice choice : enchantments) {
            ToggleLayout toggle = enchantToggleLayout(popup, y);
            if (toggle.bounds().bottom() > viewport.y && toggle.bounds().y < viewport.bottom()) {
                drawLegacyToggle(context, toggle, choice.name,
                        enchantDraft.containsKey(choice.id), mouseX, mouseY);
            }
            y += 20;
            if (enchantDraft.containsKey(choice.id) && choice.maximumLevel > 1) {
                SliderLayout level = sliderLayout(popup, y);
                if (level.bounds().bottom() > viewport.y && level.bounds().y < viewport.bottom()) {
                    drawLegacySlider(context, level, "Уровень", 1,
                            choice.maximumLevel,
                            enchantDraft.getOrDefault(choice.id, 1), mouseX, mouseY);
                }
                y += 35;
            }
        }
        context.disableScissor();

        Rect action = popup.actionButton();
        popupButton(context, action, "Применить", action.contains(mouseX, mouseY));
        drawPopupClose(context, popup, mouseX, mouseY);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() == 0 || click.button() == 1) {
            focusedField = Field.NONE;
            selectedAll = false;
            clearError();
        }
        boolean parentAddVisible = view == View.ENCHANTMENTS
                && enchantReturnView == View.ADD
                && !activePopup().bounds().contains(click.x(), click.y());
        if (click.button() == 1 && (view == View.ADD || parentAddVisible)) {
            Popup popup = popup(View.ADD, 170);
            EditorLayout layout = editorLayout(popup, false);
            if (layout.mode.collapsed.contains(click.x(), click.y())) {
                modeOpen = !modeOpen;
                focusedField = Field.NONE;
                selectedAll = false;
                return true;
            }
        }
        if (click.button() != 0) {
            return super.mouseClicked(click, doubled);
        }
        drag = Drag.NONE;
        draggedPopupView = View.MAIN;

        if (view == View.MAIN) {
            if (mainLayout().close.contains(click.x(), click.y())) {
                close();
                return true;
            }
            return clickMain(click) || super.mouseClicked(click, doubled);
        }
        Popup popup = activePopup();
        if (popup.closeButton().contains(click.x(), click.y())) {
            closePopup();
            return true;
        }
        if (popup.header().contains(click.x(), click.y())) {
            drag = Drag.POPUP;
            draggedPopupView = view;
            popupDragOffsetX = (int) Math.round(click.x()) - popup.x;
            popupDragOffsetY = (int) Math.round(click.y()) - popup.y;
            return true;
        }
        if (!popup.bounds().contains(click.x(), click.y())
                && mainLayout().close.contains(click.x(), click.y())) {
            close();
            return true;
        }
        if (view == View.ENCHANTMENTS && !popup.bounds().contains(click.x(), click.y())) {
            boolean editing = enchantReturnView == View.EDIT;
            Popup parentPopup = popup(enchantReturnView, editing ? 120 : 170);
            if (parentPopup.bounds().contains(click.x(), click.y())) {
                if (parentPopup.closeButton().contains(click.x(), click.y())) {
                    closeParentPopup();
                    return true;
                }
                if (parentPopup.header().contains(click.x(), click.y())) {
                    drag = Drag.POPUP;
                    draggedPopupView = enchantReturnView;
                    popupDragOffsetX = (int) Math.round(click.x()) - parentPopup.x;
                    popupDragOffsetY = (int) Math.round(click.y()) - parentPopup.y;
                    return true;
                }
                clickEditor(click, editing, true);
                return true;
            }
        }
        switch (view) {
            case SETTINGS -> clickSettings(click);
            case ADD -> clickEditor(click, false);
            case EDIT -> clickEditor(click, true);
            case ENCHANTMENTS -> clickEnchantments(click);
            default -> {
            }
        }
        return true;
    }

    private boolean clickMain(Click click) {
        MainLayout layout = mainLayout();
        if (layout.settings.contains(click.x(), click.y())) {
            view = View.SETTINGS;
            focusedField = Field.NONE;
            error = "";
            return true;
        }

        if (layout.add.contains(click.x(), click.y())) {
            beginAdd();
            return true;
        }
        if (layout.clear.contains(click.x(), click.y()) && !autoBuy.entries().isEmpty()) {
            autoBuy.clearEntries();
            editPopupPositions.clear();
            listScroll = 0.0;
            listScrollTarget = 0.0;
            return true;
        }

        List<AutoBuy.Entry> entries = autoBuy.entries();
        for (int index = 0; index < entries.size(); index++) {
            int y = panelY + index * ENTRY_HEIGHT - (int) listScroll;
            EntryLayout entryLayout = entryLayout(y);
            if (entryLayout.actions.y < panelY - 7
                    || entryLayout.actions.y > panelY + 108) {
                continue;
            }
            AutoBuy.Entry entry = entries.get(index);
            if (entryLayout.delete.contains(click.x(), click.y())) {
                autoBuy.removeEntry(entry);
                editPopupPositions.remove(entry);
                return true;
            }
            if (entryLayout.edit.contains(click.x(), click.y())) {
                beginEdit(entry);
                return true;
            }
        }
        return false;
    }

    private void clickSettings(Click click) {
        Popup popup = popup(View.SETTINGS, 50);
        SliderLayout slider = settingsLayout(popup).delay;
        if (slider.hit.contains(click.x(), click.y())) {
            drag = Drag.DELAY;
            updateDelay(click.x(), slider.track.x, slider.track.width);
        }
    }

    private void clickEditor(Click click, boolean editing) {
        clickEditor(click, editing, false);
    }

    private void clickEditor(Click click, boolean editing, boolean childOpen) {
        Popup popup = popup(editing ? View.EDIT : View.ADD, editing ? 120 : 170);
        EditorLayout layout = editorLayout(popup, editing);
        if (!editing) {
            if (modeOpen) {
                if (layout.mode.idOption.contains(click.x(), click.y())) {
                    autoBuy.setAddMode(AutoBuy.AddMode.ID);
                    modeOpen = false;
                    clearError();
                    return;
                }
                if (layout.mode.nameOption.contains(click.x(), click.y())) {
                    autoBuy.setAddMode(AutoBuy.AddMode.NAME);
                    modeOpen = false;
                    clearError();
                    return;
                }
                modeOpen = false;
            }
            if (layout.item.hit.contains(click.x(), click.y())) {
                focus(Field.ITEM);
                return;
            }
            if (layout.mode.collapsed.contains(click.x(), click.y())) {

                return;
            }
        }

        if (layout.price.hit.contains(click.x(), click.y())) {
            focus(Field.PRICE);
            return;
        }
        if (layout.count.hit.contains(click.x(), click.y())) {
            drag = Drag.COUNT;
            updateCount(click.x(), layout.count.track.x, layout.count.track.width);
            return;
        }
        if (layout.enchanted.hit.contains(click.x(), click.y())) {
            draftEnchanted = !draftEnchanted;
            return;
        }
        if (layout.enchantButton.contains(click.x(), click.y())) {
            if (!childOpen) {
                openEnchantments(editing ? View.EDIT : View.ADD, popup);
            }
            return;
        }

        if (layout.actionButton.contains(click.x(), click.y())) {
            submitEditor(editing);
            return;
        }
        focusedField = Field.NONE;
        selectedAll = false;
    }

    private void clickEnchantments(Click click) {
        Popup popup = popup(View.ENCHANTMENTS, 126);
        if (popup.actionButton().contains(click.x(), click.y())) {
            draftEnchantments.clear();
            draftEnchantments.putAll(enchantDraft);
            view = enchantReturnView;
            drag = Drag.NONE;
            draggedEnchantment = null;
            return;
        }
        Rect viewport = enchantViewport(popup);
        if (!viewport.contains(click.x(), click.y())) {
            return;
        }
        int y = popup.y + 22 - (int) enchantScroll;
        for (EnchantChoice choice : enchantments) {
            ToggleLayout toggle = enchantToggleLayout(popup, y);
            if (toggle.hit.contains(click.x(), click.y())) {
                if (enchantDraft.remove(choice.id) == null) {
                    enchantDraft.put(choice.id, 1);
                }
                return;
            }
            y += 20;
            if (enchantDraft.containsKey(choice.id) && choice.maximumLevel > 1) {
                SliderLayout slider = sliderLayout(popup, y);
                if (slider.hit.contains(click.x(), click.y())) {
                    drag = Drag.ENCHANT_LEVEL;
                    draggedEnchantment = choice.id;
                    updateEnchantmentLevel(choice, click.x(), slider);
                    return;
                }
                y += 35;
            }
        }
    }

    @Override
    public boolean mouseDragged(Click click, double deltaX, double deltaY) {
        if (click.button() == 0 && drag != Drag.NONE) {
            if (drag == Drag.POPUP) {
                moveActivePopup(click.x(), click.y());
                return true;
            }
            if (drag == Drag.DELAY && view == View.SETTINGS) {
                SliderLayout slider = settingsLayout(popup(View.SETTINGS, 50)).delay;
                updateDelay(click.x(), slider.track.x, slider.track.width);
                return true;
            }
            if (drag == Drag.COUNT && (view == View.ADD || view == View.EDIT
                    || view == View.ENCHANTMENTS)) {
                View editorView = view == View.ENCHANTMENTS ? enchantReturnView : view;
                boolean editing = editorView == View.EDIT;
                Popup popup = popup(editorView, editing ? 120 : 170);
                SliderLayout slider = editorLayout(popup, editing).count;
                updateCount(click.x(), slider.track.x, slider.track.width);
                return true;
            }
            if (drag == Drag.ENCHANT_LEVEL && view == View.ENCHANTMENTS
                    && draggedEnchantment != null) {
                EnchantSliderMatch match = findEnchantmentSlider(draggedEnchantment);
                if (match != null) {
                    updateEnchantmentLevel(match.choice, click.x(), match.slider);
                }
                return true;
            }
        }
        return super.mouseDragged(click, deltaX, deltaY);
    }

    @Override
    public boolean mouseReleased(Click click) {
        if (click.button() == 0 && drag != Drag.NONE) {
            drag = Drag.NONE;
            draggedEnchantment = null;
            draggedPopupView = View.MAIN;
            return true;
        }
        return super.mouseReleased(click);
    }

    @Override
    public boolean mouseScrolled(
            double mouseX, double mouseY, double horizontalAmount, double verticalAmount
    ) {
        MainLayout layout = mainLayout();
        if (view == View.MAIN && layout.scrollArea.contains(mouseX, mouseY)) {
            int maximum = Math.max(0, autoBuy.entries().size() * ENTRY_HEIGHT - LIST_HEIGHT);
            if (verticalAmount < 0.0) {
                listScrollTarget += 15.0;
            } else if (verticalAmount > 0.0) {
                listScrollTarget -= 15.0;
            }
            listScrollTarget = clamp(listScrollTarget, 0.0, maximum);
            return true;
        }
        if (view == View.ENCHANTMENTS) {
            Popup popup = popup(View.ENCHANTMENTS, 126);
            if (popup.bounds().contains(mouseX, mouseY)) {
                int maximum = Math.max(0,
                        enchantmentContentHeight() + 30 - popup.height);
                if (verticalAmount < 0.0) {
                    enchantScrollTarget += 15.0;
                } else if (verticalAmount > 0.0) {
                    enchantScrollTarget -= 15.0;
                }
                enchantScrollTarget = clamp(enchantScrollTarget, 0.0, maximum);
                return true;
            }
        }
        return super.mouseScrolled(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (view == View.MAIN) {
                close();
            } else {
                closePopup();
            }
            return true;
        }
        if (focusedField != Field.NONE) {
            if (key == GLFW.GLFW_KEY_A
                    && (input.modifiers() & GLFW.GLFW_MOD_CONTROL) != 0) {
                selectedAll = true;
                cursorBlinkStarted = System.currentTimeMillis();
                return true;
            }
            if (key == GLFW.GLFW_KEY_BACKSPACE) {
                if (selectedAll) {
                    if (focusedField == Field.ITEM) {
                        itemText = "";
                    } else {
                        priceText = "";
                    }
                } else {
                    if (focusedField == Field.ITEM) {
                        itemText = removeLastCodePoint(itemText);
                    } else {
                        priceText = removeLastCodePoint(priceText);
                    }
                }
                selectedAll = false;
                clearError();
                return true;
            }
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (focusedField == Field.NONE || !input.isValidChar()) {
            return super.charTyped(input);
        }
        String typed = input.asString();
        if (selectedAll) {
            if (focusedField == Field.ITEM) {
                itemText = "";
            } else {
                priceText = "";
            }
            selectedAll = false;
            clearError();
            return true;
        }
        if (focusedField == Field.PRICE) {
            boolean numericOnly = view == View.EDIT
                    || view == View.ENCHANTMENTS && enchantReturnView == View.EDIT;
            if (!numericOnly || typed.chars().allMatch(Character::isDigit)) {
                priceText += typed;
                clearError();
            } else {
                setError(Field.PRICE, "Цена должна быть числом!");
            }
            return true;
        }
        itemText += typed;
        clearError();
        return true;
    }

    private void beginAdd() {
        view = View.ADD;
        editingEntry = null;
        itemText = "";
        priceText = "";
        draftCount = autoBuy.editorCount();
        draftEnchanted = autoBuy.editorEnchantedWithoutNbt();
        draftEnchantments.clear();
        enchantDraft.clear();
        modeOpen = false;
        clearError();
        focus(Field.ITEM);
    }

    private void beginEdit(AutoBuy.Entry entry) {
        view = View.EDIT;
        editingEntry = entry;
        itemText = Registries.ITEM.getId(entry.item()).toString();
        priceText = Long.toString(entry.maximumPrice());
        draftCount = (int) entry.minimumCount();
        draftEnchanted = entry.enchantedWithoutNbt();
        draftEnchantments.clear();
        draftEnchantments.putAll(entry.enchantments());
        enchantDraft.clear();
        modeOpen = false;
        clearError();
        focus(Field.PRICE);
    }

    private void submitEditor(boolean editing) {
        if (editing) {
            if (editingEntry == null || !autoBuy.entries().contains(editingEntry)) {
                setSubmitError(Field.PRICE, "Предмет больше не существует");
                return;
            }
            Long price = validatedPrice(true);
            if (price == null) {
                return;
            }
            autoBuy.updateEntry(editingEntry, draftCount, price,
                    draftEnchanted, draftEnchantments);
            view = View.MAIN;
            focusedField = Field.NONE;
            selectedAll = false;
            clearError();
            return;
        }

        Item item = validatedAddItem();
        if (item == null) {
            return;
        }
        Long price = validatedPrice(false);
        if (price == null) {
            return;
        }
        boolean enchanted = draftEnchanted || !draftEnchantments.isEmpty();
        if (!autoBuy.addEntry(item, draftCount, price, enchanted, draftEnchantments)) {
            setSubmitError(Field.ITEM, "Предмет уже добавлен!");
            return;
        }
        autoBuy.setEditorCount(draftCount);
        autoBuy.setEditorEnchantedWithoutNbt(draftEnchanted);
        view = View.MAIN;
        focusedField = Field.NONE;
        selectedAll = false;
        clearError();
    }

    private Long validatedPrice(boolean editing) {
        long price;
        try {
            if (priceText.isBlank()) {
                if (editing && editingEntry != null) {
                    return editingEntry.maximumPrice();
                }
                setSubmitError(Field.PRICE, "Вы не ввели цену!");
                return null;
            }
            price = Long.parseLong(priceText);
            if (price <= 0L) {
                setSubmitError(Field.PRICE, "Цена не может быть меньше 1!");
                return null;
            }
            if (price > Integer.MAX_VALUE) {
                setSubmitError(Field.PRICE, "Слишком большая цена!");
                return null;
            }
        } catch (NumberFormatException exception) {
            setSubmitError(Field.PRICE, "Цена должна быть числом!");
            return null;
        }
        return price;
    }

    private Item validatedAddItem() {
        if (itemText == null || itemText.isBlank()) {
            setSubmitError(Field.ITEM, autoBuy.addMode() == AutoBuy.AddMode.ID
                    ? "Введите ID предмета!" : "Введите название предмета!");
            return null;
        }
        if (autoBuy.addMode() == AutoBuy.AddMode.ID
                && !itemText.matches("[0-9]+")) {
            setSubmitError(Field.ITEM, "ID должен быть числом!");
            return null;
        }
        Item item = resolveItem(itemText);
        if (item == null || item == Items.AIR || item instanceof BlockItem) {
            setSubmitError(Field.ITEM, autoBuy.addMode() == AutoBuy.AddMode.ID
                    ? "Такой ID не найден!" : "Такой предмет не найден!");
            return null;
        }
        if (autoBuy.entries().stream().anyMatch(entry -> entry.item() == item)) {
            setSubmitError(Field.ITEM, "Предмет уже добавлен!");
            return null;
        }
        return item;
    }

    private Item resolveItem(String input) {
        if (input == null || input.isBlank()) {
            return null;
        }
        if (autoBuy.addMode() == AutoBuy.AddMode.ID) {
            if (!input.matches("[0-9]+")) {
                return null;
            }
            try {
                long encoded = Long.parseLong(input);
                if (encoded > Integer.MAX_VALUE) {
                    return null;
                }
                int rawId = (int) encoded;
                return Registries.ITEM.getEntry(rawId)
                        .map(RegistryEntry.Reference::value).orElse(null);
            } catch (NumberFormatException ignored) {
                return null;
            }
        }
        String normalized = input.replaceAll("[^a-zA-Z0-9_]", "")
                .replaceAll("\\d", "").trim().toLowerCase(Locale.ROOT);
        Identifier id = Identifier.tryParse("minecraft:" + normalized);
        return id != null && Registries.ITEM.containsId(id) ? Registries.ITEM.get(id) : null;
    }

    private void loadEnchantments() {
        if (enchantmentsLoaded || client == null || client.world == null) {
            return;
        }
        try {
            var registry = client.world.getRegistryManager().getOrThrow(RegistryKeys.ENCHANTMENT);
            for (Map.Entry<net.minecraft.registry.RegistryKey<Enchantment>, Enchantment> entry
                    : registry.getEntrySet()) {
                Identifier id = entry.getKey().getValue();
                RegistryEntry<Enchantment> registryEntry = registry.getEntry(entry.getValue());
                String name = Enchantment.getName(registryEntry, 1).getString();
                enchantments.add(new EnchantChoice(id, name,
                        Math.max(1, entry.getValue().getMaxLevel()),
                        registry.getRawId(entry.getValue())));
            }
            enchantments.sort(Comparator.comparingInt(choice -> choice.registryOrder));
            enchantmentsLoaded = true;
        } catch (RuntimeException ignored) {

        }
    }

    private void updateDelay(double mouseX, int sliderX, int sliderWidth) {
        double ratio = clamp((mouseX - sliderX) / sliderWidth, 0.0, 1.0);
        int value = (int) Math.round(ratio * 100.0) * 10;
        autoBuy.setClickDelayMs(clamp(value, 0, 1000));
    }

    private void updateCount(double mouseX, int sliderX, int sliderWidth) {
        double ratio = clamp((mouseX - sliderX) / sliderWidth, 0.0, 1.0);
        draftCount = clamp(1 + (int) Math.round(ratio * 63.0), 1, 64);
    }

    private void focus(Field field) {
        focusedField = field;
        selectedAll = false;
        cursorBlinkStarted = System.currentTimeMillis();
    }

    private Popup popup(View target, int height) {
        PopupPosition position = popupPosition(target);
        if (!position.initialized) {
            position.x = panelX - 155;
            position.y = panelY - 20;
            position.initialized = true;
        }
        position.x = clamp(position.x, 3, Math.max(3, width - POPUP_WIDTH - 3));
        position.y = clamp(position.y, 3, Math.max(3, this.height - height - 3));
        return new Popup(position.x, position.y, POPUP_WIDTH, height);
    }

    private Popup activePopup() {
        return switch (view) {
            case SETTINGS -> popup(View.SETTINGS, 50);
            case ADD -> popup(View.ADD, 170);
            case EDIT -> popup(View.EDIT, 120);
            case ENCHANTMENTS -> popup(View.ENCHANTMENTS, 126);
            case MAIN -> throw new IllegalStateException("Main view has no popup");
        };
    }

    private PopupPosition popupPosition(View target) {
        return switch (target) {
            case SETTINGS -> settingsPopup;
            case ADD -> addPopup;
            case EDIT -> editingEntry == null
                    ? addPopup
                    : editPopupPositions.computeIfAbsent(
                            editingEntry, ignored -> new PopupPosition());
            case ENCHANTMENTS -> enchantPopup;
            case MAIN -> throw new IllegalArgumentException("Main view has no popup position");
        };
    }

    private void moveActivePopup(double mouseX, double mouseY) {
        View target = draggedPopupView == View.MAIN ? view : draggedPopupView;
        Popup popup = popup(target, popupHeight(target));
        PopupPosition position = popupPosition(target);
        position.x = clamp((int) Math.round(mouseX) - popupDragOffsetX,
                3, Math.max(3, width - popup.width - 3));
        position.y = clamp((int) Math.round(mouseY) - popupDragOffsetY,
                3, Math.max(3, height - popup.height - 3));
    }

    private static int popupHeight(View target) {
        return switch (target) {
            case SETTINGS -> 50;
            case ADD -> 170;
            case EDIT -> 120;
            case ENCHANTMENTS -> 126;
            case MAIN -> throw new IllegalArgumentException("Main view has no popup height");
        };
    }

    private void openEnchantments(View returnView, Popup parentPopup) {
        enchantReturnView = returnView;
        enchantDraft.clear();
        enchantDraft.putAll(draftEnchantments);
        enchantScroll = 0.0;
        enchantScrollTarget = 0.0;
        enchantPopup.x = parentPopup.x;
        enchantPopup.y = parentPopup.y;
        enchantPopup.initialized = true;
        view = View.ENCHANTMENTS;
        focusedField = Field.NONE;
        selectedAll = false;
        modeOpen = false;
        clearError();
    }

    private void closePopup() {
        if (view == View.ENCHANTMENTS) {
            enchantDraft.clear();
            view = enchantReturnView;
        } else {
            view = View.MAIN;
            editingEntry = null;
        }
        focusedField = Field.NONE;
        selectedAll = false;
        modeOpen = false;
        drag = Drag.NONE;
        draggedEnchantment = null;
        draggedPopupView = View.MAIN;
        clearError();
    }

    private void closeParentPopup() {
        enchantDraft.clear();
        view = View.MAIN;
        editingEntry = null;
        focusedField = Field.NONE;
        selectedAll = false;
        modeOpen = false;
        drag = Drag.NONE;
        draggedEnchantment = null;
        draggedPopupView = View.MAIN;
        clearError();
    }

    private void setError(Field field, String message) {
        errorField = field;
        error = message;
        focus(field);
    }

    private void setSubmitError(Field field, String message) {
        if (field == Field.ITEM) {
            itemText = "";
        } else if (field == Field.PRICE) {
            priceText = "";
        }
        setError(field, message);
    }

    private void clearError() {
        error = "";
        errorField = Field.NONE;
    }

    private SettingsLayout settingsLayout(Popup popup) {
        return new SettingsLayout(sliderLayout(popup, popup.y + 22));
    }

    private EditorLayout editorLayout(Popup popup, boolean editing) {
        if (editing) {
            return new EditorLayout(
                    null,
                    null,
                    inputLayout(popup, popup.y + 22),
                    sliderLayout(popup, popup.y + 47),
                    toggleLayout(popup, popup.y + 82),
                    new Rect(popup.x + 4, popup.y + popup.height - 25, 132, 10),
                    popup.actionButton()
            );
        }
        return new EditorLayout(
                modeLayout(popup, popup.y + 22),
                inputLayout(popup, popup.y + 47),
                inputLayout(popup, popup.y + 72),
                sliderLayout(popup, popup.y + 97),
                toggleLayout(popup, popup.y + 132),
                new Rect(popup.x + 4, popup.y + popup.height - 25, 132, 10),
                popup.actionButton()
        );
    }

    private InputLayout inputLayout(Popup popup, int componentY) {
        Rect bounds = new Rect(popup.x + 5, componentY, 131, 25);
        return new InputLayout(bounds,
                new Rect(bounds.x, componentY - 6, bounds.width, 18));
    }

    private ModeLayout modeLayout(Popup popup, int componentY) {
        int dropWidth = Math.max(fontWidth("ID", FONT_DU),
                fontWidth("Названию", FONT_DU)) + 10;
        int dropX = popup.x + 137 - dropWidth;
        Rect first = new Rect(dropX, componentY - 2, dropWidth, 10);
        Rect second = new Rect(dropX, componentY + 8, dropWidth, 10);
        boolean idSelected = autoBuy.addMode() == AutoBuy.AddMode.ID;
        return new ModeLayout(
                new Rect(dropX, componentY - 2, dropWidth, 20),
                first,
                idSelected ? first : second,
                idSelected ? second : first,
                popup.x + 5,
                componentY
        );
    }

    private SliderLayout sliderLayout(Popup popup, int componentY) {
        Rect track = new Rect(popup.x + 25, componentY + 10, 87, 1);
        return new SliderLayout(
                new Rect(popup.x + 5, componentY, 132, 35),
                track,
                new Rect(track.x - 4, componentY + 8, track.width + 4, 5)
        );
    }

    private ToggleLayout toggleLayout(Popup popup, int componentY) {
        Rect track = new Rect(popup.x + 119, componentY - 2, 18, 8);
        return new ToggleLayout(
                new Rect(popup.x + 5, componentY - 5, 133, 20),
                track,
                new Rect(popup.x + 117, componentY - 5, 21, 12)
        );
    }

    private ToggleLayout enchantToggleLayout(Popup popup, int componentY) {
        return toggleLayout(popup, componentY);
    }

    private Rect enchantViewport(Popup popup) {
        return new Rect(popup.x, popup.y + 14, popup.width, popup.height - 28);
    }

    private int enchantmentContentHeight() {
        int height = 0;
        for (EnchantChoice choice : enchantments) {
            height += 20;
            if (enchantDraft.containsKey(choice.id) && choice.maximumLevel > 1) {
                height += 35;
            }
        }
        return height;
    }

    private EnchantSliderMatch findEnchantmentSlider(Identifier enchantmentId) {
        Popup popup = popup(View.ENCHANTMENTS, 126);
        int y = popup.y + 22 - (int) enchantScroll;
        for (EnchantChoice choice : enchantments) {
            y += 20;
            if (enchantDraft.containsKey(choice.id) && choice.maximumLevel > 1) {
                SliderLayout slider = sliderLayout(popup, y);
                if (choice.id.equals(enchantmentId)) {
                    return new EnchantSliderMatch(choice, slider);
                }
                y += 35;
            }
        }
        return null;
    }

    private void updateEnchantmentLevel(
            EnchantChoice choice, double mouseX, SliderLayout slider
    ) {
        double ratio = clamp((mouseX - slider.track.x) / slider.track.width,
                0.0, 1.0);
        int level = 1 + (int) Math.round(ratio * (choice.maximumLevel - 1));
        enchantDraft.put(choice.id, clamp(level, 1, choice.maximumLevel));
    }

    private void drawWindow(
            DrawContext context, int x, int headerY, int width, int bodyHeight, String title
    ) {
        int first = primaryColor();
        int second = legacySecondaryColor();
        SmoothRoundedGui.fillNoise(context, x, headerY + 1, width, bodyHeight - 2,
                5.5f, 10.0f, 0x96FFFFFF);
        SmoothRoundedGui.fill(context, x, headerY + 3, width, bodyHeight,
                7.0f, WHITE);
        SmoothRoundedGui.fillFourCorners(context, x, headerY, width, 13,
                4.0f, first, second, second, first);
        SmoothRoundedGui.fillFourCorners(context, x, headerY + 5, width, 8,
                0.0f, first, second, second, first);
        drawCenteredFont(context, title, x + width / 2.0f, headerY + 2.5f,
                WHITE, FONT_DY, true);
    }

    private void drawPopup(DrawContext context, Popup popup, String title) {
        int first = primaryColor();
        int second = legacySecondaryColor();
        SmoothRoundedGui.fillNoise(context, popup.x, popup.y + 1,
                popup.width, popup.height - 2, 5.5f, 10.0f, 0x96FFFFFF);
        SmoothRoundedGui.fill(context, popup.x, popup.y + 3,
                popup.width, popup.height, 7.0f, WHITE);
        SmoothRoundedGui.fillFourCorners(context, popup.x, popup.y,
                popup.width, 13, 4.0f, first, second, second, first);
        SmoothRoundedGui.fillFourCorners(context, popup.x, popup.y + 5,
                popup.width, 8, 0.0f, first, second, second, first);
        drawCenteredFont(context, title, popup.x + popup.width / 2.0f,
                popup.y + 2.5f, WHITE, FONT_DY, true);
    }

    private void drawLegacySlider(
            DrawContext context, SliderLayout layout, String label,
            int minimum, int maximum, int value, int mouseX, int mouseY
    ) {
        int bounded = clamp(value, minimum, maximum);
        double ratio = maximum == minimum
                ? 0.0
                : (bounded - minimum) / (double) (maximum - minimum);
        int componentY = layout.bounds.y;
        int knobCenter = layout.track.x
                + (int) Math.round(layout.track.width * ratio);

        drawFont(context, label, layout.track.x - 20.0f, componentY,
                BLACK, FONT_DT, false);
        drawFont(context, Float.toString((float) minimum), layout.track.x - 20.0f,
                componentY + 10.0f, BLACK, FONT_DR, false);
        drawFont(context, Float.toString((float) maximum),
                layout.track.x + layout.track.width + 5.0f,
                componentY + 10.0f, BLACK, FONT_DR, false);
        drawCenteredFont(context, Float.toString((float) bounded), knobCenter,
                componentY + 18.0f, BLACK, FONT_DQ, false);

        context.fill(layout.track.x, layout.track.y,
                layout.track.right(), layout.track.bottom(), BLACK);
        int fillWidth = (int) Math.round(layout.track.width * ratio);
        if (fillWidth > 0) {
            context.fill(layout.track.x, layout.track.y,
                    layout.track.x + fillWidth, layout.track.bottom(), primaryColor());
        }
        ClickGuiModule clickGui = theme();
        if (clickGui != null && clickGui.shadowsEnabled()) {
            SmoothRoundedGui.fillGlow(context, knobCenter - 3, componentY + 7,
                    5, 5, 0.0f, 10.0f, primaryColor());
        }
        SmoothRoundedGui.fill(context, knobCenter - 3, layout.track.y - 3,
                7, 7, 3.5f, primaryColor());
        SmoothRoundedGui.fill(context, knobCenter - 2, layout.track.y - 2,
                5, 5, 2.5f, WHITE);
    }

    private void drawLegacyToggle(
            DrawContext context, ToggleLayout layout, String label,
            boolean enabled, int mouseX, int mouseY
    ) {
        drawFont(context, label, layout.bounds.x, layout.bounds.y + 5.0f,
                BLACK, FONT_DT, false);
        ClickGuiModule clickGui = theme();
        if (clickGui != null && clickGui.shadowsEnabled()) {
            SmoothRoundedGui.fillGlow(context, layout.track.x, layout.track.y,
                    layout.track.width, layout.track.height, 0.0f, 6.0f, 0xCD000000);
        }
        int first = enabled ? primaryColor() : 0xFF7C939B;
        int second = enabled ? legacySecondaryColor() : 0xFF7C939B;
        SmoothRoundedGui.fillFourCorners(context, layout.track.x, layout.track.y,
                layout.track.width, layout.track.height, 3.5f,
                first, second, second, first);
        int knobCenterX = layout.track.x + (enabled ? 14 : 4);
        int knobCenterY = layout.track.y + 4;
        SmoothRoundedGui.fill(context, knobCenterX - 4, knobCenterY - 4,
                8, 8, 4.0f, WHITE);
    }

    private void drawLegacyInput(
            DrawContext context, InputLayout layout, String value,
            String placeholder, Field field
    ) {
        boolean focused = focusedField == field;
        boolean activeError = errorField == field && !error.isEmpty();
        boolean showPlaceholder = !activeError && value.isBlank() && !focused;
        String display;
        if (activeError) {
            display = error;
        } else if (showPlaceholder) {
            display = placeholder;
        } else {
            boolean cursorVisible = focused
                    && (System.currentTimeMillis() - cursorBlinkStarted) / 500L % 2L == 0L;
            display = value + (cursorVisible ? "|" : "");
        }
        display = trimInput(display, layout.bounds.width - 25,
                focused && !activeError && !showPlaceholder);
        int color = activeError || focused && selectedAll ? primaryColor() : BLACK;
        drawFont(context, display, layout.bounds.x, layout.bounds.y,
                color, FONT_DT, false);
        context.fill(layout.bounds.x, layout.bounds.y + 10,
                layout.bounds.right(), layout.bounds.y + 11, BLACK);
    }

    private String trimInput(String value, int maximumWidth, boolean keepTail) {
        String result = value == null ? "" : value;
        while (!result.isEmpty() && fontWidth(result, FONT_DT) > maximumWidth) {
            result = keepTail ? removeFirstCodePoint(result) : removeLastCodePoint(result);
        }
        return result;
    }

    private void drawModeDropdown(
            DrawContext context, ModeLayout layout, int mouseX, int mouseY
    ) {
        drawFont(context, "Добавлять по", layout.labelX, layout.labelY,
                BLACK, FONT_DU, false);
        Rect box = modeOpen ? layout.bounds : layout.collapsed;
        SmoothRoundedGui.fillGlow(context, box.x, box.y, box.width, box.height,
                0.0f, 4.0f, 0xA5000000);
        SmoothRoundedGui.fill(context, box.x, box.y, box.width, box.height,
                2.0f, WHITE);

        boolean idSelected = autoBuy.addMode() == AutoBuy.AddMode.ID;
        String first = idSelected ? "ID" : "Названию";
        drawFont(context, first, layout.collapsed.x + 2.0f,
                layout.collapsed.y + 2.5f, BLACK, FONT_DU, false);
        if (modeOpen) {
            String second = idSelected ? "Названию" : "ID";
            drawFont(context, second, layout.collapsed.x + 2.0f,
                    layout.collapsed.y + 12.5f, BLACK, FONT_DU, false);
        }
        drawFont(context, modeOpen ? "▴" : "▾",
                layout.collapsed.right() - 7.0f, layout.collapsed.y + 2.0f,
                BLACK, FONT_MODE_ARROW, false);
    }

    private void popupButton(
            DrawContext context, Rect bounds, String label, boolean hovered
    ) {
        SmoothRoundedGui.fillGlow(context, bounds.x, bounds.y,
                bounds.width, bounds.height, 0.0f, 4.0f, 0xA5000000);
        SmoothRoundedGui.fill(context, bounds.x, bounds.y,
                bounds.width, bounds.height, 2.0f, WHITE);
        drawCenteredFont(context, label, bounds.x + bounds.width / 2.0f,
                bounds.y + 3.0f, BLACK, FONT_DT, false);
    }

    private void drawPopupClose(
            DrawContext context, Popup popup, int mouseX, int mouseY
    ) {
        Rect bounds = popup.closeButton();
        icon(context, CLOSE, bounds, bounds.contains(mouseX, mouseY));
    }

    private void mainButton(
            DrawContext context, Rect bounds, String label, boolean hovered, boolean enabled
    ) {
        SmoothRoundedGui.fill(context, bounds.x, bounds.y, bounds.width, bounds.height,
                2.0f, CARD);
        int color = enabled ? (hovered ? 0xFFCCCCCC : WHITE) : 0xFFCCCCCC;
        drawCenteredFont(context, label, bounds.x + bounds.width / 2.0f,
                bounds.y + 3.0f, color, FONT_DT, false);
    }

    private void icon(
            DrawContext context, Identifier texture, Rect bounds, boolean hovered
    ) {
        LegacyMenuRender.texture(context, texture, bounds.x, bounds.y,
                bounds.width, bounds.height, hovered ? 0xCCFFFFFF : WHITE);
    }

    private void drawEntryLine(
            DrawContext context, String label, String value, boolean accent,
            float x, float y
    ) {
        drawFont(context, label, x, y, WHITE, FONT_DT, true);
        drawFont(context, value,
                x + LegacyHudFont.widthFloat(textRenderer, label, FONT_DT), y,
                accent ? LEGACY_RED : WHITE, FONT_DT, true);
    }

    private static String stripLegacyRed(String value) {
        return value == null ? "" : value.replace("\u00A7c", "");
    }

    private MainLayout mainLayout() {
        return new MainLayout(
                new Rect(panelX - 2, panelY - 2, PANEL_WIDTH - 7, LIST_HEIGHT),
                new Rect(panelX - 2, panelY - 2, PANEL_WIDTH, LIST_HEIGHT),
                new Rect(panelX - 1, panelY + 116, 83, 10),
                new Rect(panelX + 87, panelY + 116, 83, 10),
                new Rect(panelX - 2, panelY - 19, 12, 12),
                new Rect(panelX + PANEL_WIDTH - 17, panelY - 18, 9, 9)
        );
    }

    private EntryLayout entryLayout(int y) {
        return new EntryLayout(
                new Rect(panelX + 35, y, PANEL_WIDTH - 45, 50),
                new Rect(panelX, y, 30, 40),
                new Rect(panelX, y + 30, 30, 10),
                new Rect(panelX, y + 30, 10, 10),
                new Rect(panelX + 20, y + 30, 10, 10)
        );
    }

    private static String enchantmentSummary(Map<Identifier, Integer> values) {
        return values.entrySet().stream()
                .map(entry -> {
                    String path = entry.getKey().getPath();
                    String prefix = path.substring(0, Math.min(2, path.length()))
                            .toUpperCase(Locale.ROOT);
                    return prefix + (entry.getValue() == 1 ? "" : entry.getValue());
                })
                .sorted()
                .reduce((left, right) -> left + ", " + right)
                .orElse("Пусто");
    }

    @Override
    public void close() {
        autoBuy.saveEntries();
        if (client != null) {
            client.setScreen(parent);
        }
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private ClickGuiModule theme() {
        return CelestialPortClient.MODULES.find("click_gui")
                .filter(ClickGuiModule.class::isInstance)
                .map(ClickGuiModule.class::cast)
                .orElse(null);
    }

    public boolean legacyBlurEnabled() {
        ClickGuiModule clickGui = theme();
        return clickGui != null && clickGui.blurEnabled();
    }

    private static int primaryColor() {
        return CelestialPortClient.MODULES.find("click_gui")
                .filter(ClickGuiModule.class::isInstance)
                .map(ClickGuiModule.class::cast)
                .map(ClickGuiModule::primaryColor)
                .orElse(0xFFBF68FF);
    }

    private static int secondaryColor() {
        return CelestialPortClient.MODULES.find("click_gui")
                .filter(ClickGuiModule.class::isInstance)
                .map(ClickGuiModule.class::cast)
                .map(ClickGuiModule::secondaryColor)
                .orElse(0xFF110122);
    }

    private static int legacySecondaryColor() {
        int color = secondaryColor();
        int red = (int) (((color >>> 16) & 0xFF) * 0.7f);
        int green = (int) (((color >>> 8) & 0xFF) * 0.7f);
        int blue = (int) ((color & 0xFF) * 0.7f);
        return 0xFF000000 | red << 16 | green << 8 | blue;
    }

    private static StyleSpriteSource font(int legacySize) {
        return new StyleSpriteSource.Font(
                Identifier.of("celestial", "montserrat_" + legacySize));
    }

    private static Text fontText(String value, StyleSpriteSource font) {
        return Text.literal(value).styled(style -> style.withFont(font));
    }

    private int fontWidth(String value, StyleSpriteSource font) {
        if (isLegacyFont(font)) {
            return LegacyHudFont.width(textRenderer, value, font);
        }
        return textRenderer.getWidth(fontText(value, font));
    }

    private static boolean isLegacyFont(StyleSpriteSource font) {
        return font == FONT_DQ || font == FONT_DR || font == FONT_DT || font == FONT_DU;
    }

    private void drawCenteredFont(
            DrawContext context, String value, float centerX, float y,
            int color, StyleSpriteSource font, boolean shadow
    ) {
        drawFont(context, value, centerX - fontWidth(value, font) / 2.0f,
                y, color, font, shadow);
    }

    private void drawFont(
            DrawContext context, String value, float x, float y,
            int color, StyleSpriteSource font, boolean shadow
    ) {
        if (isLegacyFont(font)) {
            LegacyHudFont.draw(context, textRenderer, value, x, y,
                    color, font, shadow);
            return;
        }
        if (shadow) {
            int shadowColor = (color & 0x00FCFCFC) >> 2 | color & 0xC8141414;
            drawFont(context, value, x + 0.5f, y + 0.5f, shadowColor, font);
        }
        drawFont(context, value, x, y, color, font);
    }

    private void drawFont(
            DrawContext context, String value, float x, float y,
            int color, StyleSpriteSource font
    ) {
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(
                x - (float) Math.floor(x), y - (float) Math.floor(y));
        context.drawText(textRenderer, fontText(value, font),
                (int) Math.floor(x), (int) Math.floor(y), color, false);
        context.getMatrices().popMatrix();
    }

    private static double approachScroll(double current, double target, float deltaTicks) {
        if (Math.abs(target - current) < 0.01) {
            return target;
        }
        double step = Math.min(1.0, Math.max(0.08, Math.max(0.0f, deltaTicks) * 0.3));
        return current + (target - current) * step;
    }

    private static String removeLastCodePoint(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return value.substring(0, value.offsetByCodePoints(value.length(), -1));
    }

    private static String removeFirstCodePoint(String value) {
        if (value == null || value.isEmpty()) {
            return "";
        }
        return value.substring(value.offsetByCodePoints(0, 1));
    }

    private static int clamp(int value, int minimum, int maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private enum View {
        MAIN, SETTINGS, ADD, EDIT, ENCHANTMENTS
    }

    private enum Field {
        NONE, ITEM, PRICE
    }

    private enum Drag {
        NONE, DELAY, COUNT, ENCHANT_LEVEL, POPUP
    }

    private static final class PopupPosition {
        private int x;
        private int y;
        private boolean initialized;
    }

    private record Rect(int x, int y, int width, int height) {
        private int right() {
            return x + width;
        }

        private int bottom() {
            return y + height;
        }

        private boolean contains(double mouseX, double mouseY) {
            return mouseX > x && mouseX < right() && mouseY > y && mouseY < bottom();
        }
    }

    private record MainLayout(
            Rect viewport, Rect scrollArea, Rect add, Rect clear, Rect settings, Rect close
    ) {
    }

    private record EntryLayout(
            Rect details, Rect item, Rect actions, Rect delete, Rect edit
    ) {
    }

    private record Popup(int x, int y, int width, int height) {
        private Rect bounds() {
            return new Rect(x, y, width, height);
        }

        private Rect header() {
            return new Rect(x, y, width, 13);
        }

        private Rect closeButton() {
            return new Rect(x + width - 12, y + 2, 9, 9);
        }

        private Rect actionButton() {
            return new Rect(x + 4, y + height - 10, 132, 10);
        }
    }

    private record SettingsLayout(SliderLayout delay) {
    }

    private record EditorLayout(
            ModeLayout mode,
            InputLayout item,
            InputLayout price,
            SliderLayout count,
            ToggleLayout enchanted,
            Rect enchantButton,
            Rect actionButton
    ) {
    }

    private record InputLayout(Rect bounds, Rect hit) {
    }

    private record ModeLayout(
            Rect bounds,
            Rect collapsed,
            Rect idOption,
            Rect nameOption,
            int labelX,
            int labelY
    ) {
    }

    private record SliderLayout(Rect bounds, Rect track, Rect hit) {
    }

    private record ToggleLayout(Rect bounds, Rect track, Rect hit) {
    }

    private record EnchantSliderMatch(EnchantChoice choice, SliderLayout slider) {
    }

    private record EnchantChoice(
            Identifier id, String name, int maximumLevel, int registryOrder
    ) {
    }
}
