package celestial.port.client.chat;

import java.util.Objects;

public final class LegacyOutgoingChatEvent {
    private String message;
    private boolean cancelled;

    public LegacyOutgoingChatEvent(String message) {
        this.message = Objects.requireNonNull(message, "message");
    }

    public String message() {
        return message;
    }

    public void setMessage(String message) {
        this.message = Objects.requireNonNull(message, "message");
    }

    public boolean cancelled() {
        return cancelled;
    }

    public void cancel() {
        cancelled = true;
    }
}
