package celestial.port.client.ui;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyModuleResolver;
import celestial.port.core.Category;
import celestial.port.core.Module;
import celestial.port.core.ModuleManager;
import celestial.port.core.setting.BindSetting;
import celestial.port.modules.render.ArrayListModule;
import celestial.port.modules.render.ClickGuiModule;
import celestial.port.modules.render.HudModule;
import celestial.port.modules.movement.TimerModule;
import celestial.port.modules.legacyutility.RWHelper;
import celestial.port.modules.legacyutility.StaffStatistics;
import celestial.port.mixin.accessor.RenderTickCounterDynamicAccessor;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.hud.InGameHud;
import net.minecraft.client.gui.screen.ChatScreen;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffectUtil;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.awt.Color;
import java.io.IOException;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;

public final class CelestialHud {
    private static final int TEXT = 0xFFEBEBEB;
    private static final int MUTED = 0xFFAAAAAA;
    private static final int CARD_BACKGROUND = 0xFF0A0A0A;
    private static final int EMPTY_TEXT = 0xFFEBEBEB;

    private static final Identifier ATOM = Identifier.of("celestial", "images/atomwhite.png");
    private static final Identifier KEYBOARD = Identifier.of("celestial", "images/keyboard.png");
    private static final Identifier SWORDS = Identifier.of("celestial", "images/swords.png");
    private static final Identifier STAFF = Identifier.of("celestial", "images/staff.png");
    private static final Identifier GRAB = Identifier.of("celestial", "images/grab.png");
    private static final Identifier LEGACY_EFFECTS = Identifier.of(
            "celestial", "images/inventory_1_12_2.png");
    private static final Identifier PING_1 = Identifier.of("minecraft", "icon/ping_1");
    private static final Identifier PING_2 = Identifier.of("minecraft", "icon/ping_2");
    private static final Identifier PING_3 = Identifier.of("minecraft", "icon/ping_3");
    private static final Identifier PING_4 = Identifier.of("minecraft", "icon/ping_4");
    private static final Identifier PING_5 = Identifier.of("minecraft", "icon/ping_5");
    private static final Identifier PING_UNKNOWN = Identifier.of("minecraft", "icon/ping_unknown");
    private static final StyleSpriteSource FONT_DP = fontSource(10);
    private static final StyleSpriteSource FONT_DS = fontSource(13);
    private static final StyleSpriteSource FONT_DT = fontSource(14);
    private static final StyleSpriteSource FONT_DU = fontSource(15);
    private static final StyleSpriteSource FONT_DV = fontSource(16);
    private static final StyleSpriteSource FONT_DW = fontSource(17);
    private static final StyleSpriteSource FONT_DX = fontSource(18);
    private static final EquipmentSlot[] ARMOR_ORDER = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    private static final Map<String, ArrayAnimation> ARRAY_ANIMATIONS = new HashMap<>();
    private static final Map<String, KeybindAnimation> KEYBIND_ANIMATIONS = new HashMap<>();
    private static final CardAnimation KEYBIND_CARD = new CardAnimation();
    private static final CardAnimation KILL_FEED_CARD = new CardAnimation();
    private static final Set<KillEntry> KILLS = new HashSet<>();
    private static final Map<String, HudPosition> POSITIONS = new LinkedHashMap<>();
    private static final Map<String, HudBounds> BOUNDS = new LinkedHashMap<>();
    private static final Map<String, HudBounds> GRAB_HANDLES = new LinkedHashMap<>();
    private static final UiLayoutStore LAYOUT = new UiLayoutStore(
            FabricLoader.getInstance().getConfigDir().resolve("celestial"));
    private static final ZoneId MOSCOW = ZoneId.of("Europe/Moscow");
    private static final List<HudSchedule> SCHEDULES = List.of(
            new HudSchedule("Тайный торговец",
                    new int[]{240, 300, 480, 660, 840, 1020, 1200, 1380}),
            new HudSchedule("Аир дроп",
                    new int[]{540, 660, 780, 900, 1020, 1140, 1260, 1380, 1500}),
            new HudSchedule("Талисман", new int[]{1170}),
            new HudSchedule("Скрудж", new int[]{930})
    );

    private static boolean layoutLoaded;
    private static long lastFrameNanos;
    private static float chatOffset;
    private static float timerIndicatorProgress;
    private static String draggedHud;
    private static double dragOffsetX;
    private static double dragOffsetY;
    private static boolean lastLeftDown;

    private final ModuleManager moduleManager;

    public CelestialHud(ModuleManager moduleManager) {
        this.moduleManager = Objects.requireNonNull(moduleManager, "moduleManager");
    }

    public void render(DrawContext context) {
        render(context, moduleManager);
    }

    public static float legacyHotbarOffset() {
        MinecraftClient client = MinecraftClient.getInstance();
        boolean hudEnabled = CelestialPortClient.MODULES.find("hud")
                .filter(HudModule.class::isInstance)
                .map(HudModule.class::cast)
                .map(Module::enabled)
                .orElse(false);
        return chatOffset + (hudEnabled && client.currentScreen instanceof ChatScreen
                ? 2.0f : 0.0f);
    }

    public static void render(DrawContext context, ModuleManager moduleManager) {
        Objects.requireNonNull(context, "context");
        Objects.requireNonNull(moduleManager, "moduleManager");
        ensureLayoutLoaded();

        MinecraftClient client = MinecraftClient.getInstance();
        long nowNanos = System.nanoTime();
        int frameMillis = lastFrameNanos == 0L ? 16
                : Math.max(0, (int) ((nowNanos - lastFrameNanos) / 1_000_000L));
        lastFrameNanos = nowNanos;
        if (client.options.hudHidden) return;

        long nowMillis = System.currentTimeMillis();
        HudModule hud = moduleManager.find("hud")
                .filter(HudModule.class::isInstance).map(HudModule.class::cast).orElse(null);
        ArrayListModule arrayList = moduleManager.find("array_list")
                .filter(ArrayListModule.class::isInstance).map(ArrayListModule.class::cast).orElse(null);
        ClickGuiModule theme = moduleManager.find("click_gui")
                .filter(ClickGuiModule.class::isInstance).map(ClickGuiModule.class::cast).orElse(null);

        boolean editor = client.currentScreen instanceof ChatScreen;
        updateActiveDrag(client, context, editor);
        BOUNDS.clear();
        GRAB_HANDLES.clear();

        if (hud != null && hud.enabled()) {
            drawBottomInformation(context, client, hud, frameMillis);
            if (hud.shows("Armor")) drawArmor(context, client);
            if (hud.shows("Watermark")) {
                drawWatermark(context, client, arrayList, theme);
            }
            if (hud.shows("Kill Feed")) {
                drawKillFeed(context, client, arrayList, theme, nowMillis, frameMillis);
            }
            if (hud.shows("Keybinds")) {
                drawKeybinds(context, moduleManager, arrayList, theme, frameMillis);
            }
            if (hud.shows("Potions")) drawPotions(context, client, hud, arrayList, theme);
        }

        if (arrayList != null && arrayList.enabled()) {
            drawArrayList(context, moduleManager, arrayList, frameMillis);
        }

        if (TimerModule.indicatorVisible()) {
            drawTimerIndicator(context, client, arrayList, theme);
        }

        RWHelper rwHelper = moduleManager.find("rw_helper")
                .filter(RWHelper.class::isInstance).map(RWHelper.class::cast).orElse(null);
        if (rwHelper != null && rwHelper.hasScheduleGraphics()
                && !(client.currentScreen instanceof CelestialScreen)) {
            drawSchedules(context, rwHelper, arrayList, theme);
        }

        StaffStatistics staffStatistics = moduleManager.find("staff_statistics")
                .filter(StaffStatistics.class::isInstance).map(StaffStatistics.class::cast).orElse(null);
        if (staffStatistics != null && staffStatistics.enabled()) {
            drawStaffStatistics(context, staffStatistics, arrayList, theme);
        }

        if (editor) drawHudEditor(context, client, arrayList, theme);
        else finishDragIfNeeded();
        ClientFeedback.render(context, frameMillis, chatOffset);
    }

    private static void drawTimerIndicator(
            DrawContext context, MinecraftClient client,
            ArrayListModule array, ClickGuiModule theme
    ) {
        float target = Math.max(0.0f, Math.min(1.0f, TimerModule.indicatorProgress()));
        timerIndicatorProgress += (target - timerIndicatorProgress) * 0.03f;
        if (Math.abs(target - timerIndicatorProgress) < 0.001f) {
            timerIndicatorProgress = target;
        }

        int baseX = context.getScaledWindowWidth() / 2 - 30;
        int y = context.getScaledWindowHeight() - 100;
        int outerX = baseX + 1;
        int first = withAlpha(hudColor(array, theme, 0), 195);
        int second = withAlpha(hudColor(array, theme, 90), 195);
        int third = withAlpha(hudColor(array, theme, 180), 195);
        int fourth = withAlpha(hudColor(array, theme, 270), 195);

        drawLegacyGlow(context, outerX, y, 58, 16, 3, 5,
                first, second, third, fourth);
        fillRounded(context, baseX + 1, y + 3, 58, 10, 0, 0xFF1E1E1E);
        int fillWidth = Math.round(timerIndicatorProgress * 56.0f);
        if (fillWidth > 0) {
            fillFourCornerRounded(context, baseX + 2, y + 4, fillWidth, 8, 0,
                    fourth, third, second, first);
        }

        String percentage = (int) Math.floor(timerIndicatorProgress * 100.0f) + "%";
        drawFont(context, client.textRenderer, percentage,
                baseX + 30.0f - fontWidth(client.textRenderer, percentage, FONT_DS) / 2.0f,
                y + 6.5f, 0xFFEBEBEB, FONT_DS);
    }

    public static void recordAuraKill(LivingEntity entity, PlayerEntity attacker) {
        if (!(entity instanceof PlayerEntity victim) || victim == attacker
                || attacker.age <= 5 || !attacker.isAlive()
                || victim.isAlive() || victim.isRemoved()) {
            return;
        }
        HudModule hud = CelestialPortClient.MODULES.find("hud")
                .filter(HudModule.class::isInstance)
                .map(HudModule.class::cast)
                .orElse(null);
        if (hud == null || !hud.enabled() || !hud.shows("Kill Feed")) return;

        String name = victim.getName().getString();
        KILLS.add(new KillEntry(
                name,
                attacker.getMainHandStack().copy(),
                (long) victim.getX(),
                (long) victim.getY(),
                (long) victim.getZ(),
                System.currentTimeMillis()));
    }

    private static void ensureLayoutLoaded() {
        if (layoutLoaded) return;
        layoutLoaded = true;
        POSITIONS.put("logo", new HudPosition(8, 7));
        POSITIONS.put("array_list", new HudPosition(4, 34));
        POSITIONS.put("kill_feed", new HudPosition(250, 120));
        POSITIONS.put("keybinds", new HudPosition(250, 180));
        POSITIONS.put("schedules", new HudPosition(350, 120));
        POSITIONS.put("staff_statistics", new HudPosition(250, 80));
        Map<String, UiLayoutStore.Position> stored = LAYOUT.loadSectionMigratingLegacy(
                "hud", "hud.celka", Map.of(
                        "LogoComponent", "logo",
                        "ArrayListComponent", "array_list",
                        "StaffComponent", "staff_statistics",
                        "KillFeedComponent", "kill_feed",
                        "KeyBindsComponent", "keybinds",
                        "SchedulesComponent", "schedules"));
        stored.forEach((name, point) -> {
            HudPosition position = POSITIONS.get(name);
            if (position != null) {

                if (name.equals("array_list") && point.x() == 3 && point.y() == 41) return;
                if (name.equals("keybinds") && point.x() == 709 && point.y() == 99) return;
                position.x = point.x();
                position.y = point.y();
            }
        });
    }

    private static void drawWatermark(
            DrawContext context, MinecraftClient client, ArrayListModule array, ClickGuiModule theme
    ) {
        HudPosition position = position("logo");
        TextRenderer renderer = client.textRenderer;
        String title = "Celestial";
        String uidLabel = "UID: ";
        String uidValue = "1";
        int titleWidth = fontWidth(renderer, title, FONT_DX);
        int visualWidth = titleWidth + 35;
        int x = position.x;
        int y = position.y;
        boolean right = x > context.getScaledWindowWidth() / 2;
        int first = hudColor(array, theme, 0);
        int rightTop = 0xFFFAFFFF;
        int rightBottom = 0xFFFFFFFF;
        int shadow = withAlpha(first, 195);
        int shadowX = x + (right ? 57 : -5);
        int atomX = x + (right ? 58 : -4);
        int textX = x + (right ? 14 : 22);

        LegacyHudShadow.Batch shadowBatch = LegacyHudShadow.batch();
        shadowBatch.add(shadowX, y - 3, 25, 25, 15, shadow);
        shadowBatch.add(x + (right ? 0 : 22), y,
                titleWidth + 15, 20, 25, shadow);
        shadowBatch.submit(context);
        fillFourCornerRounded(context, x + (right ? 0 : 6), y,
                titleWidth + 30, 21, 3,
                first, rightTop, rightBottom, first);
        fillFourCornerRounded(context, x, y, visualWidth, 21, 10,
                first, rightTop, rightBottom, first);
        fillFourCornerRounded(context, shadowX, y - 3, 25, 25, 12,
                first, rightTop, rightBottom, first);
        drawTintedTexture(context, ATOM, atomX, y - 1.5f, 23, 23, 0xFF000000);
        drawTintedTexture(context, ATOM, atomX, y - 2.0f, 23, 23,
                darkenRgb(first, 0.9f));
        drawFont(context, renderer, title, textX, y + 3, TEXT, FONT_DX, true);
        drawFont(context, renderer, uidLabel, textX, y + 13, TEXT, FONT_DU, true);
        drawFont(context, renderer, uidValue,
                textX + fontWidth(renderer, uidLabel, FONT_DU), y + 13,
                MUTED, FONT_DU, true);
        BOUNDS.put("logo", new HudBounds(x - 3, y - 4, 80, 28));
        GRAB_HANDLES.put("logo", new HudBounds(x + 27, y - 1, 24, 24));
    }

    private static void drawSchedules(
            DrawContext context, RWHelper helper,
            ArrayListModule array, ClickGuiModule theme
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer renderer = client.textRenderer;
        List<HudSchedule> visible = SCHEDULES.stream()
                .filter(schedule -> helper.graphics().selected(schedule.label))
                .sorted(Comparator.comparingInt((HudSchedule schedule) ->
                        fontWidth(renderer, schedule.label, FONT_DT)).reversed())
                .toList();
        if (visible.isEmpty()) return;
        int width = Math.max(100, visible.stream().mapToInt(schedule ->
                        fontWidth(renderer, schedule.label, FONT_DT) + 60)
                .max().orElse(100));
        int height = Math.max(27, visible.size() * 10 + 15);
        HudPosition position = position("schedules");
        int x = position.x;
        int y = position.y;
        drawCardFrame(context, x, y, width, height, array, theme);
        String title = "Schedules";
        drawFont(context, renderer, title,
                x + width / 2.0f - fontWidth(renderer, title, FONT_DX) / 2.0f - 1,
                y + 3, TEXT, FONT_DX);
        ZonedDateTime now = ZonedDateTime.now(MOSCOW);
        int rowY = y + 15;
        for (HudSchedule schedule : visible) {
            String countdown = scheduleCountdown(schedule.minutes, now);
            drawFont(context, renderer, schedule.label, x + 3, rowY, TEXT, FONT_DT);
            drawFont(context, renderer, countdown,
                    x + width - fontWidth(renderer, countdown, FONT_DT) - 7,
                    rowY, TEXT, FONT_DT);
            rowY += 10;
        }
        BOUNDS.put("schedules", new HudBounds(x - 3, y - 4, width, height));
        GRAB_HANDLES.put("schedules", new HudBounds(
                x + width / 2 - 15, y + visible.size() * 10 / 4, 28, 28));
    }

    private static String scheduleCountdown(int[] schedule, ZonedDateTime now) {
        int current = now.getHour() * 60 + now.getMinute();
        int remaining = schedule[0] + 1440 - current;
        for (int minute : schedule) {
            if (minute >= current) {
                remaining = minute - current;
                break;
            }
        }
        int hours = remaining / 60;
        int minutes = remaining % 60;
        if (minutes > 0) minutes--;
        return hours + "h " + minutes + "m " + (59 - now.getSecond()) + "s";
    }

    private static void drawStaffStatistics(
            DrawContext context, StaffStatistics statistics,
            ArrayListModule array, ClickGuiModule theme
    ) {
        if (!statistics.drawTable().enabled()) return;
        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer renderer = client.textRenderer;
        List<StaffStatistics.StaffEntry> entries = statistics.entries();
        int width = Math.max(100, entries.stream().mapToInt(entry ->
                        fontWidth(renderer, staffRow(entry), FONT_DT) + 10)
                .max().orElse(100));
        int height = entries.isEmpty() ? 30 : Math.max(27, entries.size() * 10 + 15);
        HudPosition position = position("staff_statistics");
        int x = position.x;
        int y = position.y;
        drawCardFrame(context, x, y, width, height, array, theme);

        String title = "Staff Statistics";
        drawFont(context, renderer, title,
                x + width / 2.0f - fontWidth(renderer, title, FONT_DX) / 2.0f,
                y + 3, TEXT, FONT_DX);
        if (entries.isEmpty()) {
            context.drawTexturedQuad(STAFF, x + 2, y + 11, x + 18, y + 27,
                    0.0f, 1.0f, 0.0f, 1.0f);
            drawFont(context, renderer, "Список пуст", x + 20, y + 12,
                    EMPTY_TEXT, FONT_DW);
            drawFont(context, renderer, "Персонал ещё не зашел!", x + 20.5f, y + 22,
                    EMPTY_TEXT, FONT_DP);
        } else {
            int rowY = y + 15;
            for (StaffStatistics.StaffEntry entry : entries) {
                String status = entry.status().label();
                int statusColor = entry.status() == StaffStatistics.Status.OFFLINE
                        ? 0xFFFF5555 : 0xFF55FF55;
                if (!status.isEmpty()) {
                    drawFont(context, renderer, status, x + 1, rowY, statusColor, FONT_DT);
                }
                String remainder = " " + entry.rank() + " " + entry.name();
                drawFont(context, renderer, remainder,
                        x + 1 + fontWidth(renderer, status, FONT_DT), rowY, TEXT, FONT_DT);
                rowY += 10;
            }
        }
        BOUNDS.put("staff_statistics", new HudBounds(x - 3, y - 4, width, height));
        GRAB_HANDLES.put("staff_statistics", new HudBounds(
                x + width / 2 - 15, y + entries.size() * 10 / 4, 28, 28));
    }

    private static String staffRow(StaffStatistics.StaffEntry entry) {
        return entry.status().label() + " " + entry.rank() + " " + entry.name();
    }

    private static void drawArrayList(
            DrawContext context, ModuleManager moduleManager,
            ArrayListModule settings, int frameMillis
    ) {
        TextRenderer renderer = MinecraftClient.getInstance().textRenderer;
        List<Module> modules = new ArrayList<>(moduleManager.modules());
        float layoutStep = frameMillis * 0.06f;
        float alphaStep = frameMillis * 0.03f;
        for (Module module : modules) {
            if (excludedFromArrayList(module, settings)) continue;
            ArrayAnimation animation = ARRAY_ANIMATIONS.computeIfAbsent(
                    module.id(), ignored -> new ArrayAnimation());
            float target = module.enabled() ? 10.0f : 0.0f;
            animation.layout = moveTowards(animation.layout, target, layoutStep);
            animation.alpha = moveTowards(animation.alpha, target, alphaStep);
        }

        modules.sort(Comparator.comparingInt(module ->
                -fontWidth(renderer, arrayName(module, settings), FONT_DS)));

        HudPosition position = position("array_list");
        int screenWidth = context.getScaledWindowWidth();
        int startY = position.y;
        boolean right = position.x > screenWidth / 2;
        float anchorX = position.x + (right ? 52.0f : 0.0f);
        float handleX = position.x + (right ? 15.0f : 0.0f);
        float yOffset = (float) Math.max(0.5, Math.min(0.8, settings.yOffset()));
        long time = System.currentTimeMillis();

        LegacyHudShadow.Batch shadowBatch = LegacyHudShadow.batch();
        int rowY = 0;
        int colorOffset = 0;
        for (Module module : modules) {
            if (excludedFromArrayList(module, settings)) continue;
            ArrayAnimation animation = ARRAY_ANIMATIONS.get(module.id());
            if (animation == null) continue;
            if (module.enabled()) {
                String name = arrayName(module, settings);
                int textWidth = fontWidth(renderer, name, FONT_DS);
                int color = arrayColor(settings, -colorOffset, modules.size(), time);
                float x = anchorX - (right ? textWidth : 0.0f) - 5.0f;
                shadowBatch.add(x, startY + 1.0f + rowY,
                        textWidth + yOffset + 16.0f, 10.0f, 20, color);
                colorOffset = (int) (colorOffset
                        + 15.0f * (animation.layout / 10.0f) * yOffset);
            }
            rowY = (int) (rowY + animation.layout * yOffset);
        }
        shadowBatch.submit(context);

        rowY = 0;
        colorOffset = 0;
        int previousColor = arrayColor(settings, 0, modules.size(), time);
        float lineHeight = 0.0f;
        boolean drewBackground = false;
        for (Module module : modules) {
            if (excludedFromArrayList(module, settings)) continue;
            ArrayAnimation animation = ARRAY_ANIMATIONS.get(module.id());
            if (animation == null) continue;
            if (module.enabled()) {
                String name = arrayName(module, settings);
                int textWidth = fontWidth(renderer, name, FONT_DS);
                int color = arrayColor(settings, -colorOffset, modules.size(), time);
                float x = anchorX - (right ? textWidth : 0.0f);
                fillVerticalFractional(context, x, startY + rowY,
                        textWidth + 7.0f, yOffset + 10.0f,
                        previousColor, color);
                previousColor = color;
                colorOffset = (int) (colorOffset
                        + 15.0f * (animation.layout / 10.0f) * yOffset);
                lineHeight = rowY + yOffset + 10.0f;
                drewBackground = true;
            }
            rowY = (int) (rowY + animation.layout * yOffset);
        }
        if (drewBackground) {
            fillFractional(context, anchorX + (right ? 7.0f : 0.0f), startY,
                    2.0f, lineHeight, 0xFFFFFFFF);
        }

        rowY = 0;
        boolean afterFirstRegistryRow = false;
        int componentHeight = 14;
        for (Module module : modules) {
            if (excludedFromArrayList(module, settings)) continue;
            ArrayAnimation animation = ARRAY_ANIMATIONS.get(module.id());
            if (animation == null) continue;
            String name = arrayName(module, settings);
            if (module.enabled()) {
                int textWidth = fontWidth(renderer, name, FONT_DS);
                float textX = anchorX + (right ? 3.0f : 4.0f)
                        - (right ? textWidth : 0.0f);
                int alpha = (int) (animation.alpha * 25.0f);
                drawFont(context, renderer, name, textX,
                        startY + 4.0f + rowY + (afterFirstRegistryRow ? 1.1f : 0.0f),
                        withAlpha(TEXT, alpha), FONT_DS, true);
            }
            rowY = (int) (rowY + animation.layout * yOffset);
            afterFirstRegistryRow = true;
            componentHeight = (int) (rowY
                    + 8.0f * (animation.layout / 10.0f) * yOffset + 10.0f);
        }
        componentHeight = Math.max(14, componentHeight);
        BOUNDS.put("array_list", new HudBounds(
                position.x - 3, startY - 4, 63, componentHeight));
        GRAB_HANDLES.put("array_list", new HudBounds(
                Math.round(handleX + 5.0f), startY + componentHeight / 4, 32, 32));
    }

    private static boolean excludedFromArrayList(Module module, ArrayListModule settings) {
        if (module.id().equals("click_gui")) return true;
        return !settings.renderFunctions()
                && !module.id().equals("hud")
                && module.category() == Category.RENDER;
    }

    private static String arrayName(Module module, ArrayListModule settings) {
        String legacyName = LegacyModuleResolver.legacyName(module);
        return settings.lowercase()
                ? legacyName.toLowerCase(Locale.ROOT)
                : legacyName;
    }

    private static int arrayColor(ArrayListModule settings, int index, int total, long timeMillis) {
        int period = Math.max(1, 10 - (int) settings.colorSpeed());
        int phase = (int) Math.floorMod(timeMillis / period + index, 360L);
        int color = switch (settings.colorMode().toLowerCase(Locale.ROOT)) {
            case "static" -> settings.staticColor();
            case "rainbow" -> 0xFF000000 | (Color.HSBtoRGB(
                    phase / 360.0f, 0.7f, 1.0f) & 0xFFFFFF);
            case "astolfo" -> {
                float hue = phase / 360.0f;
                if (hue < 0.5f) hue = -hue;
                yield 0xFF000000 | (Color.HSBtoRGB(hue, 0.7f, 1.0f) & 0xFFFFFF);
            }
            default -> {
                int triangle = (phase >= 180 ? 360 - phase : phase) * 2;
                yield blend(settings.fadeFirstColor(), settings.fadeSecondColor(),
                        triangle / 360.0f);
            }
        };
        return withAlpha(color, 255);
    }

    private static void drawBottomInformation(
            DrawContext context, MinecraftClient client, HudModule settings, int frameMillis
    ) {
        if (client.player == null) return;
        TextRenderer renderer = client.textRenderer;
        int screenHeight = context.getScaledWindowHeight();
        float targetOffset = client.currentScreen instanceof ChatScreen
                ? chatHudOffset(client) : 0.0f;
        chatOffset = (float) legacyEaseOut(chatOffset, targetOffset,
                frameMillis * 0.02);
        double bps = currentBps(client);
        String movementValue = Double.toString(Math.round(bps * 100.0) / 100.0);
        if (!(client.currentScreen instanceof ChatScreen)) {
            if (settings.shows("Coordinates")) {
                drawLegacyStat(context, renderer, "BPS: ", movementValue,
                        2.0f, screenHeight - 15.0f, FONT_DU);
                String coordinates = (int) client.player.getX() + " "
                        + (int) client.player.getY() + " " + (int) client.player.getZ();
                drawLegacyStat(context, renderer, "XYZ: ", coordinates,
                        2.0f, screenHeight - 7.0f, FONT_DU);
            } else {
                drawLegacyStat(context, renderer, "BPS: ", movementValue,
                        2.0f, screenHeight - 7.0f, FONT_DU);
            }
        }

        int ping = -1;
        if (client.getNetworkHandler() != null) {
            PlayerListEntry entry = client.getNetworkHandler().getPlayerListEntry(client.player.getUuid());
            if (entry != null) ping = entry.getLatency();
        }
        String fpsValue = Integer.toString(client.getCurrentFps());
        String fps = "FPS: " + fpsValue;
        boolean singleplayer = client.isInSingleplayer();
        float fpsX = context.getScaledWindowWidth() - fontWidth(renderer, fps, FONT_DU) - 2.0f;
        drawLegacyStat(context, renderer, "FPS: ", fpsValue, fpsX,
                screenHeight - (singleplayer ? 7.0f : 15.0f) - chatOffset, FONT_DU);
        if (!singleplayer) {
            String latencyValue = ping < 0 ? "?" : Integer.toString(ping);
            String latency = "Ping: " + latencyValue;
            float latencyX = (int) (context.getScaledWindowWidth()
                    - fontWidth(renderer, latency, FONT_DU) - 15.0f);
            drawLegacyStat(context, renderer, "Ping: ", latencyValue, latencyX,
                    screenHeight - 7.0f - chatOffset, FONT_DU);
            drawLatencyIcon(context, context.getScaledWindowWidth() - 12,
                    screenHeight - 10.0f - chatOffset, ping);
        }
    }

    private static int chatHudOffset(MinecraftClient client) {
        int guiScale = client.options.getGuiScale().getValue();
        return switch (guiScale) {
            case 1 -> 8;
            case 3 -> 22;
            case 0 -> 29;
            default -> 15;
        };
    }

    private static void drawLatencyIcon(DrawContext context, int x, float y, int ping) {
        Identifier texture = ping < 0 ? PING_UNKNOWN
                : ping < 150 ? PING_5
                : ping < 300 ? PING_4
                : ping < 600 ? PING_3
                : ping < 1000 ? PING_2 : PING_1;
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.drawGuiTexture(RenderPipelines.GUI_TEXTURED,
                texture, 0, 0, 10, 8, 0xFFFFFFFF);
        context.getMatrices().popMatrix();
    }

    private static double currentBps(MinecraftClient client) {
        double timerSpeed = 1.0;
        if (client.getRenderTickCounter() instanceof RenderTickCounterDynamicAccessor accessor) {
            float tickTime = accessor.celestial$getTickTime();
            if (tickTime > 0.0f) timerSpeed = 50.0 / tickTime;
        }
        return Math.hypot(client.player.getX() - client.player.lastX,
                client.player.getZ() - client.player.lastZ) * timerSpeed * 20.0;
    }

    private static void drawArmor(DrawContext context, MinecraftClient client) {
        if (client.player == null) return;
        int guiScale = client.options.getGuiScale().getValue();
        int verticalOffset = switch (guiScale) {
            case 3 -> 73;
            case 0 -> 93;
            default -> 56;
        };
        if (client.player.isSubmergedInWater() && client.player.getAir() > 0) {
            verticalOffset += 10;
        } else if (client.player.getVehicle() instanceof LivingEntity mount) {
            if (mount.getMaxHealth() > 40.0f) verticalOffset += 20;
            else if (mount.getMaxHealth() > 20.0f) verticalOffset += 10;
        }
        int horizontalOffset = switch (guiScale) {
            case 3 -> 15;
            case 0 -> 20;
            default -> 10;
        };
        int x = context.getScaledWindowWidth() / 2 + horizontalOffset;
        float editorOffset = chatOffset
                + (client.currentScreen instanceof ChatScreen ? 2.0f : 0.0f);
        int y = (int) (context.getScaledWindowHeight() + 3.0f
                - verticalOffset - editorOffset);
        for (EquipmentSlot slot : ARMOR_ORDER) {
            ItemStack stack = client.player.getEquippedStack(slot);
            if (!stack.isEmpty()) {
                context.drawItem(stack, x, y);
                context.drawStackOverlay(client.textRenderer, stack, x, y);
            }
            x += 16;
        }
    }

    private static void drawPotions(
            DrawContext context, MinecraftClient client, HudModule settings,
            ArrayListModule array, ClickGuiModule theme
    ) {
        if (client.player == null || client.player.getStatusEffects().isEmpty()) return;
        List<StatusEffectInstance> effects = client.player.getStatusEffects().stream()
                .sorted()
                .toList();
        boolean right = settings.potionPosition().startsWith("Right");
        boolean top = settings.potionPosition().endsWith("Top");
        boolean background = settings.potionBackground();
        int spacing = background ? 30 : 22;
        int x = right ? context.getScaledWindowWidth() - (background ? 76 : 72)
                : (background ? -6 : -10);
        int y = top ? (background ? 6 : 0)
                : context.getScaledWindowHeight() / 2 - effects.size() * spacing / 2;

        List<PotionLayout> rows = new ArrayList<>();
        for (StatusEffectInstance effect : effects) {
            String name = effect.getEffectType().value().getName().getString()
                    + " " + romanAmplifier(effect.getAmplifier());
            String duration = StatusEffectUtil.getDurationText(effect, 1.0f, 20.0f).getString();
            int textWidth = Math.max(fontWidth(client.textRenderer, name, FONT_DT),
                    fontWidth(client.textRenderer, duration, FONT_DT));
            int cardX = right ? x + 74 - (textWidth + 32) : x + 9;
            int iconX = x + (right ? 53 : 13);
            int textX = right ? x + 50 - fontWidth(client.textRenderer, name, FONT_DT) : x + 34;
            int durationX = right
                    ? x + 50 - fontWidth(client.textRenderer, duration, FONT_DT) : x + 34;
            rows.add(new PotionLayout(effect, name, duration, cardX, iconX,
                    textX, durationX, y, textWidth));
            y += spacing;
        }

        for (PotionLayout row : rows) {
            if (background) {
                drawLegacyInsetCard(context, row.cardX, row.y - 5,
                        row.textWidth + 32, 31, 1, array, theme);
            }
            drawEffectIcon(context, row.effect, row.iconX, row.y + 1);
        }
        for (PotionLayout row : rows) {
            drawFont(context, client.textRenderer, row.name,
                    row.textX, row.y + 4, TEXT, FONT_DT, true);
            if (row.effect.getDuration() >= 200 || client.player.age % 20 <= 10) {
                drawFont(context, client.textRenderer, row.duration,
                        row.durationX, row.y + 13, MUTED, FONT_DT, true);
            }
        }
    }

    private static void drawEffectIcon(
            DrawContext context, StatusEffectInstance effect, int x, int y
    ) {
        int legacyIndex = legacyEffectIconIndex(
                effect.getEffectType().value().getTranslationKey());
        if (legacyIndex >= 0) {
            int u = legacyIndex % 8 * 18;
            int v = 198 + legacyIndex / 8 * 18;
            context.drawTexture(RenderPipelines.GUI_TEXTURED, LEGACY_EFFECTS,
                    x, y, (float) u, (float) v,
                    18, 18, 18, 18, 256, 256, 0xFFFFFFFF);
        } else if (legacyIndex == Integer.MIN_VALUE) {

            context.drawGuiTexture(RenderPipelines.GUI_TEXTURED,
                    InGameHud.getEffectTexture(effect.getEffectType()),
                    x, y, 18, 18, 0xFFFFFFFF);
        }
    }

    private static int legacyEffectIconIndex(String translationKey) {
        return switch (translationKey) {
            case "effect.minecraft.speed" -> 0;
            case "effect.minecraft.slowness" -> 1;
            case "effect.minecraft.haste" -> 2;
            case "effect.minecraft.mining_fatigue" -> 3;
            case "effect.minecraft.strength" -> 4;
            case "effect.minecraft.weakness" -> 5;
            case "effect.minecraft.poison" -> 6;
            case "effect.minecraft.regeneration" -> 7;
            case "effect.minecraft.invisibility" -> 8;
            case "effect.minecraft.hunger" -> 9;
            case "effect.minecraft.jump_boost" -> 10;
            case "effect.minecraft.nausea" -> 11;
            case "effect.minecraft.night_vision" -> 12;
            case "effect.minecraft.blindness" -> 13;
            case "effect.minecraft.resistance" -> 14;
            case "effect.minecraft.fire_resistance" -> 15;
            case "effect.minecraft.water_breathing" -> 16;
            case "effect.minecraft.wither" -> 17;
            case "effect.minecraft.absorption" -> 18;
            case "effect.minecraft.levitation" -> 19;
            case "effect.minecraft.glowing" -> 20;
            case "effect.minecraft.luck" -> 21;
            case "effect.minecraft.unluck" -> 22;
            case "effect.minecraft.health_boost" -> 23;

            case "effect.minecraft.instant_health",
                    "effect.minecraft.instant_damage",
                    "effect.minecraft.saturation" -> -1;
            default -> Integer.MIN_VALUE;
        };
    }

    private static String romanAmplifier(int amplifier) {
        return switch (amplifier) {
            case 0 -> "I";
            case 1 -> "II";
            case 2 -> "III";
            case 3 -> "IV";
            case 4 -> "V";
            default -> "";
        };
    }

    private static void drawKillFeed(
            DrawContext context, MinecraftClient client,
            ArrayListModule array, ClickGuiModule theme, long now, int frameMillis
    ) {
        if (client.player == null) return;
        TextRenderer renderer = client.textRenderer;
        KILLS.removeIf(entry -> now - entry.createdAt > 100L
                && entry.opacity <= 0.01 && entry.height == 0.0f);
        float targetWidth = Math.max(100, KILLS.stream()
                .mapToInt(entry -> fontWidth(renderer, entry.text(client.player), FONT_DT) + 25)
                .max().orElse(100));
        float targetHeight = KILLS.isEmpty()
                ? 30.0f : Math.max(27, KILLS.size() * 10 + 15);
        KILL_FEED_CARD.animate(targetWidth, targetHeight, frameMillis);
        float frameWidth = Math.max(1.0f, KILL_FEED_CARD.width);
        float frameHeight = Math.max(1.0f, KILL_FEED_CARD.height);
        int width = Math.max(1, (int) Math.ceil(frameWidth));
        int height = Math.max(1, (int) Math.ceil(frameHeight));
        HudPosition position = position("kill_feed");
        int x = position.x;
        int y = position.y;
        drawCardFrame(context, x, y, frameWidth, frameHeight, array, theme);

        String title = "Kill Feed";
        drawFont(context, renderer, title,
                x + KILL_FEED_CARD.width / 2.0f
                        - fontWidth(renderer, title, FONT_DX) / 2.0f - 3.0f,
                y + 3, TEXT, FONT_DX);
        int rowOffset = 0;
        for (KillEntry entry : KILLS) {
            boolean active = now - entry.createdAt < 60_000L;
            entry.opacity = legacyEaseOut(entry.opacity, active ? 1.0 : -0.03,
                    frameMillis * (active ? 0.004 : 0.005));
            entry.height = moveTowards(entry.height,
                    entry.opacity > 0.0 ? 1.0f : 0.0f, frameMillis * 0.01f);
            int alpha = (int) (entry.opacity * 255.0);
            if (!entry.weapon.isEmpty()) {
                context.getMatrices().pushMatrix();
                context.getMatrices().translate(x + 1, y + 13 + rowOffset);
                context.getMatrices().scale(0.5f, 0.5f);
                context.drawItem(entry.weapon, 0, 0);
                context.getMatrices().popMatrix();
            }
            drawFont(context, renderer, entry.text(client.player),
                    x + (entry.weapon.isEmpty() ? 3 : 11), y + 15 + rowOffset,
                    withAlpha(TEXT, alpha), FONT_DT);
            rowOffset = (int) (rowOffset + 10.0f * entry.height);
        }

        KILL_FEED_CARD.animateEmpty(KILLS.isEmpty(), frameMillis);
        if (KILLS.isEmpty()) {
            int emptyColor = withAlpha(EMPTY_TEXT, (int) KILL_FEED_CARD.emptyAlpha);
            drawTintedTexture(context, SWORDS, x + 2, y + 11, 16, 15, emptyColor);
            drawFont(context, renderer, "Список пуст", x + 20, y + 12,
                    emptyColor, FONT_DW);
            drawFont(context, renderer, "Вы ещё никого не убили!", x + 20.5f, y + 22,
                    emptyColor, FONT_DP);
        }
        BOUNDS.put("kill_feed", new HudBounds(x - 3, y - 4, width, height));
        GRAB_HANDLES.put("kill_feed", new HudBounds(
                x + width / 2 - 15, y + rowOffset / 4, 28, 28));
    }

    private static void drawKeybinds(
            DrawContext context, ModuleManager modules,
            ArrayListModule array, ClickGuiModule theme, int frameMillis
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        TextRenderer renderer = client.textRenderer;
        List<Module> entries = new ArrayList<>(modules.modules());
        entries.sort(Comparator.comparingInt(module ->
                -fontWidth(renderer, LegacyModuleResolver.legacyName(module), FONT_DT)));
        boolean empty = true;
        int activeCount = 0;
        float targetWidth = 100.0f;
        for (Module module : entries) {
            if (module.key() == BindSetting.UNBOUND) continue;
            KeybindAnimation animation = KEYBIND_ANIMATIONS.computeIfAbsent(
                    module.id(), ignored -> new KeybindAnimation());
            if (!animation.hidden(module)) {
                empty = false;
                activeCount++;
                String measured = LegacyModuleResolver.legacyName(module)
                        + "[" + keyName(module.key()) + "]";
                targetWidth = Math.max(targetWidth,
                        fontWidthFloat(renderer, measured, FONT_DT) + 15.0f);
            }
        }
        float targetHeight = empty ? 30.0f : Math.max(27, activeCount * 10 + 15);
        KEYBIND_CARD.animate(targetWidth, targetHeight, frameMillis);
        float frameWidth = Math.max(1.0f, KEYBIND_CARD.width);
        float frameHeight = Math.max(1.0f, KEYBIND_CARD.height);
        int width = Math.max(1, (int) Math.ceil(frameWidth));
        int height = Math.max(1, (int) Math.ceil(frameHeight));
        HudPosition position = position("keybinds");
        int x = position.x;
        int y = position.y;
        drawCardFrame(context, x, y, frameWidth, frameHeight, array, theme);

        String title = "Keybinds";
        drawFont(context, renderer, title,
                x + KEYBIND_CARD.width / 2.0f
                        - fontWidth(renderer, title, FONT_DX) / 2.0f - 3.0f,
                y + 3, TEXT, FONT_DX);
        int rowOffset = 0;
        for (Module module : entries) {
            if (module.key() == BindSetting.UNBOUND) continue;
            KeybindAnimation animation = KEYBIND_ANIMATIONS.get(module.id());
            animation.update(module, frameMillis);
            int alpha = (int) (animation.opacity * 255.0);
            drawFont(context, renderer, LegacyModuleResolver.legacyName(module), x + 3,
                    y + 15 + rowOffset, withAlpha(TEXT, alpha), FONT_DT,
                    false, false);
            String key = "[" + keyName(module.key()) + "]";
            drawFont(context, renderer, key,
                    x + KEYBIND_CARD.width - fontWidthFloat(renderer, key, FONT_DT) - 7.0f,
                    y + 15 + rowOffset, withAlpha(TEXT, alpha), FONT_DT,
                    false, false);
            rowOffset = (int) (rowOffset + 10.0f * animation.height);
        }

        KEYBIND_CARD.animateEmpty(empty, frameMillis);
        if (empty) {
            int emptyColor = withAlpha(EMPTY_TEXT, (int) KEYBIND_CARD.emptyAlpha);
            drawTintedTexture(context, KEYBOARD, x + 2, y + 11, 16, 15, emptyColor);
            drawFont(context, renderer, "Список пуст", x + 20, y + 12,
                    emptyColor, FONT_DW, false, false);
            drawFont(context, renderer, "Нет активных биндов!", x + 20.5f, y + 22,
                    emptyColor, FONT_DP, false, false);
        }
        BOUNDS.put("keybinds", new HudBounds(x - 3, y - 4, width, height));
        GRAB_HANDLES.put("keybinds", new HudBounds(
                x + width / 2 - 15, y + rowOffset / 4, 28, 28));
    }

    private static void drawCardFrame(
            DrawContext context, float x, float y, float width, float height,
            ArrayListModule array, ClickGuiModule theme
    ) {
        int first = hudColor(array, theme, 0);
        int second = hudColor(array, theme, 90);
        int third = hudColor(array, theme, 180);
        int fourth = hudColor(array, theme, 270);
        LegacyHudFloatGui.fillGlowFourCorners(context,
                x - 4.0f, y - 6.0f, width + 4.0f, height + 9.0f,
                3.0f, 8.0f, first, third, fourth, second);
        LegacyHudFloatGui.fillGlowFourCorners(context,
                x - 3.0f, y - 4.0f, width + 2.0f, height + 6.0f,
                3.0f, 5.0f, CARD_BACKGROUND, CARD_BACKGROUND,
                CARD_BACKGROUND, CARD_BACKGROUND);
        LegacyHudFloatGui.fillFourCorners(context,
                x - 2.0f, y - 3.0f, width, 2.0f, 0.0f,
                second, fourth, fourth, second);
        LegacyHudFloatGui.fillGlowFourCorners(context,
                x - 2.0f, y - 4.0f, width, 4.0f,
                2.0f, 2.0f, second, fourth, fourth, second);
    }

    private static void drawLegacyInsetCard(
            DrawContext context, int x, int y, int width, int height, int inset,
            ArrayListModule array, ClickGuiModule theme
    ) {
        int first = hudColor(array, theme, 0);
        int second = hudColor(array, theme, 90);
        int third = hudColor(array, theme, 180);
        int fourth = hudColor(array, theme, 270);
        int expandedWidth = width + inset * 2;
        int expandedHeight = height + inset * 2;
        int top = y - inset;
        drawLegacyGlow(context, x - inset, top, expandedWidth, expandedHeight,
                3, 8, first, second, third, fourth);
        drawLegacyGlow(context, x, top + 2, expandedWidth - 2, expandedHeight - 4,
                3, 5, CARD_BACKGROUND, CARD_BACKGROUND, CARD_BACKGROUND, CARD_BACKGROUND);
    }

    private static int hudColor(ArrayListModule array, ClickGuiModule theme, int offset) {
        if (array != null) return arrayColor(array, offset, 360, System.currentTimeMillis());
        return offset == 0
                ? (theme == null ? 0xFFBF68FF : theme.primaryColor())
                : (theme == null ? 0xFF110122 : theme.secondaryColor());
    }

    private static void updateActiveDrag(MinecraftClient client, DrawContext context, boolean editor) {
        boolean leftDown = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT)
                == GLFW.GLFW_PRESS;
        if (!editor || draggedHud == null || !leftDown) return;
        double mouseX = client.mouse.getX() * context.getScaledWindowWidth()
                / client.getWindow().getWidth();
        double mouseY = client.mouse.getY() * context.getScaledWindowHeight()
                / client.getWindow().getHeight();
        HudPosition position = POSITIONS.get(draggedHud);
        HudBounds bounds = BOUNDS.get(draggedHud);
        if (position == null || bounds == null) return;
        int nextX = (int) Math.round(mouseX - dragOffsetX - (bounds.x - position.x));
        int nextY = (int) Math.round(mouseY - dragOffsetY - (bounds.y - position.y));
        position.x = clampedX(nextX, bounds.width, context.getScaledWindowWidth());
        position.y = clampedY(nextY, bounds.height, context.getScaledWindowHeight());
    }

    private static void drawHudEditor(
            DrawContext context, MinecraftClient client,
            ArrayListModule array, ClickGuiModule theme
    ) {
        boolean leftDown = GLFW.glfwGetMouseButton(client.getWindow().getHandle(), GLFW.GLFW_MOUSE_BUTTON_LEFT)
                == GLFW.GLFW_PRESS;
        double mouseX = client.mouse.getX() * context.getScaledWindowWidth()
                / client.getWindow().getWidth();
        double mouseY = client.mouse.getY() * context.getScaledWindowHeight()
                / client.getWindow().getHeight();
        HudBounds reset = new HudBounds(context.getScaledWindowWidth() / 2 - 50, 2, 100, 15);

        if (leftDown && !lastLeftDown) {
            if (reset.contains(mouseX, mouseY)) {
                resetHudPositions(context);
            } else {
                List<Map.Entry<String, HudBounds>> entries = new ArrayList<>(BOUNDS.entrySet());
                for (int index = entries.size() - 1; index >= 0; index--) {
                    Map.Entry<String, HudBounds> entry = entries.get(index);
                    if (!entry.getValue().contains(mouseX, mouseY)) continue;
                    draggedHud = entry.getKey();
                    dragOffsetX = mouseX - entry.getValue().x;
                    dragOffsetY = mouseY - entry.getValue().y;
                    break;
                }
            }
        }
        if (!leftDown && lastLeftDown && draggedHud != null) {
            draggedHud = null;
            saveHudPositions();
        }
        lastLeftDown = leftDown;

        context.fill(reset.x, reset.y, reset.x + reset.width, reset.y + reset.height,
                0x7D0F0F0F);
        String resetText = "Reset draggables";
        drawFont(context, client.textRenderer, resetText,
                reset.x + (reset.width - fontWidth(client.textRenderer, resetText, FONT_DV)) / 2,
                reset.y + 5,
                reset.contains(mouseX, mouseY) ? 0xFFFFFFA0 : 0xFFE0E0E0, FONT_DV);

        GRAB_HANDLES.forEach((name, handle) ->
                context.drawTexturedQuad(GRAB, handle.x, handle.y,
                        handle.x + handle.width, handle.y + handle.height,
                        0.0f, 1.0f, 0.0f, 1.0f));
    }

    private static void finishDragIfNeeded() {
        if (draggedHud != null) {
            draggedHud = null;
            saveHudPositions();
        }
        lastLeftDown = false;
    }

    private static void resetHudPositions(DrawContext context) {
        int resetX = context.getScaledWindowWidth() / 2;
        int resetY = context.getScaledWindowHeight() / 2;
        POSITIONS.values().forEach(position -> position.set(resetX, resetY));
        LegacyTargetHud.resetPosition(resetX, resetY);
        saveHudPositions();
    }

    private static void saveHudPositions() {
        Map<String, UiLayoutStore.Position> stored = new LinkedHashMap<>();
        POSITIONS.forEach((name, position) -> stored.put(name,
                new UiLayoutStore.Position(position.x, position.y)));
        try {
            LAYOUT.saveSection("hud", stored);
        } catch (IOException ignored) {

        }
    }

    private static HudPosition position(String name) {
        return POSITIONS.get(name);
    }

    private static int clampedX(int x, int width, int screenWidth) {
        return Math.max(0, Math.min(x, Math.max(0, screenWidth - width)));
    }

    private static int clampedY(int y, int height, int screenHeight) {
        return Math.max(0, Math.min(y, Math.max(0, screenHeight - height)));
    }

    private static StyleSpriteSource fontSource(int legacySize) {
        return LegacyHudFont.font(legacySize);
    }

    private static int fontWidth(TextRenderer renderer, String text) {
        return fontWidth(renderer, text, FONT_DX);
    }

    private static int fontWidth(
            TextRenderer renderer, String text, StyleSpriteSource font
    ) {
        return LegacyHudFont.width(renderer, text, font);
    }

    private static float fontWidthFloat(
            TextRenderer renderer, String text, StyleSpriteSource font
    ) {
        return LegacyHudFont.widthFloat(renderer, text, font);
    }

    private static void drawLegacyStat(
            DrawContext context, TextRenderer renderer,
            String label, String value, float x, float y, StyleSpriteSource font
    ) {
        drawFont(context, renderer, label, x, y, TEXT, font, true);
        drawFont(context, renderer, value,
                x + fontWidth(renderer, label, font), y, MUTED, font, true);
    }

    private static void drawFont(
            DrawContext context, TextRenderer renderer, String text, int x, int y, int color
    ) {
        drawFont(context, renderer, text, (float) x, (float) y, color, FONT_DX);
    }

    private static void drawFont(
            DrawContext context, TextRenderer renderer, String text,
            float x, float y, int color, StyleSpriteSource font
    ) {
        drawFont(context, renderer, text, x, y, color, font, false);
    }

    private static void drawFont(
            DrawContext context, TextRenderer renderer, String text,
            float x, float y, int color, StyleSpriteSource font, boolean shadow
    ) {
        LegacyHudFont.draw(context, renderer, text, x, y, color, font, shadow);
    }

    private static void drawFont(
            DrawContext context, TextRenderer renderer, String text,
            float x, float y, int color, StyleSpriteSource font,
            boolean shadow, boolean normalize
    ) {
        LegacyHudFont.draw(context, renderer, text, x, y, color, font,
                shadow, normalize);
    }

    private static void drawTintedTexture(
            DrawContext context, Identifier texture,
            float x, float y, int width, int height, int color
    ) {
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.drawTexture(RenderPipelines.GUI_TEXTURED, texture,
                0, 0, 0.0f, 0.0f, width, height, width, height, color);
        context.getMatrices().popMatrix();
    }

    private static void fillVerticalFractional(
            DrawContext context, float x, float y, float width, float height,
            int top, int bottom
    ) {
        int baseWidth = Math.max(1, (int) Math.ceil(width));
        int baseHeight = Math.max(1, (int) Math.ceil(height));
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(width / baseWidth, height / baseHeight);

        context.fillGradient(0, 0, baseWidth, baseHeight, top, bottom);
        context.getMatrices().popMatrix();
    }

    private static void fillFractional(
            DrawContext context, float x, float y, float width, float height, int color
    ) {
        int baseWidth = Math.max(1, (int) Math.ceil(width));
        int baseHeight = Math.max(1, (int) Math.ceil(height));
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.getMatrices().scale(width / baseWidth, height / baseHeight);
        context.fill(0, 0, baseWidth, baseHeight, color);
        context.getMatrices().popMatrix();
    }

    private static float moveTowards(float current, float target, float step) {
        if (current < target) return Math.min(current + step, target);
        return Math.max(current - step, target);
    }

    private static double legacyEaseOut(double current, double target, double fraction) {
        if (fraction <= 0.0) return current;
        if (fraction >= 1.0) return target;

        double low = 0.0;
        double high = 1.0;
        for (int iteration = 0; iteration < 14; iteration++) {
            double parameter = (low + high) * 0.5;
            double inverse = 1.0 - parameter;
            double x = 3.0 * inverse * parameter * parameter * 0.58
                    + parameter * parameter * parameter;
            if (x < fraction) low = parameter;
            else high = parameter;
        }
        double parameter = (low + high) * 0.5;
        double inverse = 1.0 - parameter;
        double eased = 3.0 * inverse * parameter * parameter
                + parameter * parameter * parameter;
        return current + (target - current) * eased;
    }

    private static int darkenRgb(int color, float multiplier) {
        int red = (int) (((color >>> 16) & 0xFF) * multiplier);
        int green = (int) (((color >>> 8) & 0xFF) * multiplier);
        int blue = (int) ((color & 0xFF) * multiplier);
        return 0xFF000000 | red << 16 | green << 8 | blue;
    }

    private static String keyName(int key) {
        if (BindSetting.isMouseButton(key)) {
            return switch (BindSetting.mouseButton(key)) {
                case GLFW.GLFW_MOUSE_BUTTON_LEFT -> "LEFT";
                case GLFW.GLFW_MOUSE_BUTTON_RIGHT -> "RIGHT";
                case GLFW.GLFW_MOUSE_BUTTON_MIDDLE -> "MIDDLE";
                default -> "MOUSE" + (BindSetting.mouseButton(key) + 1);
            };
        }
        if (key >= GLFW.GLFW_KEY_A && key <= GLFW.GLFW_KEY_Z) {
            return Character.toString((char) key);
        }
        if (key >= GLFW.GLFW_KEY_0 && key <= GLFW.GLFW_KEY_9) {
            return Character.toString((char) key);
        }
        if (key >= GLFW.GLFW_KEY_F1 && key <= GLFW.GLFW_KEY_F25) {
            return "F" + (key - GLFW.GLFW_KEY_F1 + 1);
        }
        if (key >= GLFW.GLFW_KEY_KP_0 && key <= GLFW.GLFW_KEY_KP_9) {
            return "NUMPAD" + (key - GLFW.GLFW_KEY_KP_0);
        }
        return switch (key) {
            case GLFW.GLFW_KEY_APOSTROPHE -> "APOSTROPHE";
            case GLFW.GLFW_KEY_COMMA -> "COMMA";
            case GLFW.GLFW_KEY_MINUS -> "MINUS";
            case GLFW.GLFW_KEY_PERIOD -> "PERIOD";
            case GLFW.GLFW_KEY_SLASH -> "SLASH";
            case GLFW.GLFW_KEY_SEMICOLON -> "SEMICOLON";
            case GLFW.GLFW_KEY_EQUAL -> "EQUALS";
            case GLFW.GLFW_KEY_LEFT_BRACKET -> "LBRACKET";
            case GLFW.GLFW_KEY_BACKSLASH -> "BACKSLASH";
            case GLFW.GLFW_KEY_RIGHT_BRACKET -> "RBRACKET";
            case GLFW.GLFW_KEY_GRAVE_ACCENT -> "GRAVE";
            case GLFW.GLFW_KEY_SPACE -> "SPACE";
            case GLFW.GLFW_KEY_ESCAPE -> "ESCAPE";
            case GLFW.GLFW_KEY_ENTER -> "RETURN";
            case GLFW.GLFW_KEY_TAB -> "TAB";
            case GLFW.GLFW_KEY_BACKSPACE -> "BACK";
            case GLFW.GLFW_KEY_INSERT -> "INSERT";
            case GLFW.GLFW_KEY_DELETE -> "DELETE";
            case GLFW.GLFW_KEY_RIGHT -> "RIGHT";
            case GLFW.GLFW_KEY_LEFT -> "LEFT";
            case GLFW.GLFW_KEY_DOWN -> "DOWN";
            case GLFW.GLFW_KEY_UP -> "UP";
            case GLFW.GLFW_KEY_PAGE_UP -> "PRIOR";
            case GLFW.GLFW_KEY_PAGE_DOWN -> "NEXT";
            case GLFW.GLFW_KEY_HOME -> "HOME";
            case GLFW.GLFW_KEY_END -> "END";
            case GLFW.GLFW_KEY_CAPS_LOCK -> "CAPITAL";
            case GLFW.GLFW_KEY_SCROLL_LOCK -> "SCROLL";
            case GLFW.GLFW_KEY_NUM_LOCK -> "NUMLOCK";
            case GLFW.GLFW_KEY_PRINT_SCREEN -> "SYSRQ";
            case GLFW.GLFW_KEY_PAUSE -> "PAUSE";
            case GLFW.GLFW_KEY_LEFT_SHIFT -> "LSHIFT";
            case GLFW.GLFW_KEY_RIGHT_SHIFT -> "RSHIFT";
            case GLFW.GLFW_KEY_LEFT_CONTROL -> "LCONTROL";
            case GLFW.GLFW_KEY_RIGHT_CONTROL -> "RCONTROL";
            case GLFW.GLFW_KEY_LEFT_ALT -> "LMENU";
            case GLFW.GLFW_KEY_RIGHT_ALT -> "RMENU";
            case GLFW.GLFW_KEY_LEFT_SUPER -> "LMETA";
            case GLFW.GLFW_KEY_RIGHT_SUPER -> "RMETA";
            case GLFW.GLFW_KEY_MENU -> "APPS";
            case GLFW.GLFW_KEY_KP_DECIMAL -> "DECIMAL";
            case GLFW.GLFW_KEY_KP_DIVIDE -> "DIVIDE";
            case GLFW.GLFW_KEY_KP_MULTIPLY -> "MULTIPLY";
            case GLFW.GLFW_KEY_KP_SUBTRACT -> "SUBTRACT";
            case GLFW.GLFW_KEY_KP_ADD -> "ADD";
            case GLFW.GLFW_KEY_KP_ENTER -> "NUMPADENTER";
            case GLFW.GLFW_KEY_KP_EQUAL -> "NUMPADEQUALS";
            default -> Integer.toString(key);
        };
    }

    private static int blend(int first, int second, float amount) {
        float t = Math.max(0, Math.min(1, amount));
        int a = (int) (((first >>> 24) & 0xFF) * (1 - t) + ((second >>> 24) & 0xFF) * t);
        int r = (int) (((first >>> 16) & 0xFF) * (1 - t) + ((second >>> 16) & 0xFF) * t);
        int g = (int) (((first >>> 8) & 0xFF) * (1 - t) + ((second >>> 8) & 0xFF) * t);
        int b = (int) ((first & 0xFF) * (1 - t) + (second & 0xFF) * t);
        return a << 24 | r << 16 | g << 8 | b;
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0xFFFFFF);
    }

    private static void fillRounded(
            DrawContext context, int x, int y, int width, int height, int radius, int color
    ) {
        SmoothRoundedGui.fill(context, x, y, width, height, radius, color);
    }

    private static void drawLegacyGlow(
            DrawContext context, int x, int y, int width, int height,
            int radius, int glowRadius,
            int topLeft, int bottomLeft, int topRight, int bottomRight
    ) {
        SmoothRoundedGui.fillGlowFourCorners(context, x, y, width, height,
                radius, glowRadius, topLeft, topRight, bottomRight, bottomLeft);
    }

    private static void drawSoftShadow(
            DrawContext context, int x, int y, int width, int height,
            int radius, int blurRadius, int color
    ) {
        drawLegacyGlow(context, x, y, width, height, radius, blurRadius,
                color, color, color, color);
    }

    private static void fillFourCornerRounded(
            DrawContext context, int x, int y, int width, int height, int radius,
            int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        SmoothRoundedGui.fillFourCorners(context, x, y, width, height, radius,
                topLeft, topRight, bottomRight, bottomLeft);
    }

    private static final class ArrayAnimation {
        private float layout;
        private float alpha;
    }

    private static final class KeybindAnimation {
        private double phase;
        private double opacity;
        private float height;

        private boolean hidden(Module module) {
            return !module.enabled() && opacity <= 0.01;
        }

        private void update(Module module, int frameMillis) {
            double speed = module.enabled() ? 0.15 : 10.0;
            phase = Math.max(0.0, Math.min(1.0,
                    phase + (module.enabled() ? speed : -speed)
                            * frameMillis * 0.01));
            opacity = Math.sqrt(Math.max(0.0,
                    1.0 - (phase - 1.0) * (phase - 1.0)));
            height = moveTowards(height, module.enabled() ? 1.0f : 0.0f,
                    frameMillis * 0.007f);
        }
    }

    private static final class CardAnimation {
        private float width;
        private float height;
        private float emptyAlpha;

        private void animate(float targetWidth, float targetHeight, int frameMillis) {
            double fraction = frameMillis * 0.015;
            width = (float) legacyEaseOut(width, targetWidth, fraction);
            height = (float) legacyEaseOut(height, targetHeight, fraction);
        }

        private void animateEmpty(boolean empty, int frameMillis) {
            if (empty) {
                emptyAlpha = (float) legacyEaseOut(
                        emptyAlpha, 256.0, frameMillis * 0.015 * 0.3);
            } else {
                emptyAlpha = 0.0f;
            }
        }
    }

    private record PotionLayout(
            StatusEffectInstance effect,
            String name,
            String duration,
            int cardX,
            int iconX,
            int textX,
            int durationX,
            int y,
            int textWidth
    ) {
    }

    private static final class KillEntry {
        private final String name;
        private final ItemStack weapon;
        private final long victimX;
        private final long victimY;
        private final long victimZ;
        private final long createdAt;
        private double opacity;
        private float height;

        private KillEntry(
                String name, ItemStack weapon,
                long victimX, long victimY, long victimZ, long createdAt
        ) {
            this.name = name;
            this.weapon = weapon;
            this.victimX = victimX;
            this.victimY = victimY;
            this.victimZ = victimZ;
            this.createdAt = createdAt;
        }

        private String text(PlayerEntity player) {
            float deltaX = (float) (player.getX() - victimX);
            float deltaY = (float) (player.getY() - victimY);
            float deltaZ = (float) (player.getZ() - victimZ);
            int distance = (int) (float) Math.sqrt(
                    deltaX * deltaX + deltaY * deltaY + deltaZ * deltaZ);
            return "Убит " + name + " (" + distance + "м)";
        }

        @Override
        public boolean equals(Object other) {
            return this == other || other instanceof KillEntry entry
                    && Objects.equals(name, entry.name);
        }

        @Override
        public int hashCode() {
            return Objects.hash(name);
        }
    }

    private record HudSchedule(String label, int[] minutes) {
    }

    private static final class HudPosition {
        private int x;
        private int y;

        private HudPosition(int x, int y) {
            this.x = x;
            this.y = y;
        }

        private void set(int x, int y) {
            this.x = x;
            this.y = y;
        }
    }

    private record HudBounds(int x, int y, int width, int height) {
        private boolean contains(double pointX, double pointY) {
            return pointX >= x && pointX < x + width && pointY >= y && pointY < y + height;
        }
    }
}
