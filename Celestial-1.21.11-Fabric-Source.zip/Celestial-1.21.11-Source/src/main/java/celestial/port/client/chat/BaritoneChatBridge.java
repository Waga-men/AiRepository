package celestial.port.client.chat;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.network.ClientPlayerEntity;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

public final class BaritoneChatBridge {
    private static Resolution resolution;
    private static String lastError = "";

    private BaritoneChatBridge() {
    }

    public static boolean isCancelled(ClientPlayerEntity player, String message) {
        Resolution current = resolve();
        if (current == null || player == null) {
            return false;
        }
        try {
            Object provider = current.getProvider.invoke(null);
            Object baritone = current.getBaritoneForPlayer.invoke(provider, player);
            if (baritone == null) {
                return false;
            }
            Object event = current.chatEventConstructor.newInstance(message);
            Object eventBus = current.getGameEventHandler.invoke(baritone);
            current.onSendChatMessage.invoke(eventBus, event);
            lastError = "";
            return Boolean.TRUE.equals(current.isCancelled.invoke(event));
        } catch (InvocationTargetException exception) {
            throw propagate(exception.getCause());
        } catch (ReflectiveOperationException | RuntimeException exception) {
            lastError = readable(exception);
            return false;
        }
    }

    public static String lastError() {
        return lastError;
    }

    private static synchronized Resolution resolve() {
        if (resolution != null) {
            return resolution.available ? resolution : null;
        }
        if (!FabricLoader.getInstance().isModLoaded("baritone")) {
            resolution = Resolution.unavailable();
            return null;
        }
        try {
            ClassLoader loader = BaritoneChatBridge.class.getClassLoader();
            Class<?> apiType = Class.forName("baritone.api.BaritoneAPI", false, loader);
            Class<?> providerType = Class.forName("baritone.api.IBaritoneProvider", false, loader);
            Class<?> baritoneType = Class.forName("baritone.api.IBaritone", false, loader);
            Class<?> eventBusType = Class.forName("baritone.api.event.listener.IEventBus", false, loader);
            Class<?> chatEventType = Class.forName("baritone.api.event.events.ChatEvent", false, loader);

            resolution = new Resolution(
                    true,
                    apiType.getMethod("getProvider"),
                    providerType.getMethod("getBaritoneForPlayer", ClientPlayerEntity.class),
                    baritoneType.getMethod("getGameEventHandler"),
                    chatEventType.getConstructor(String.class),
                    eventBusType.getMethod("onSendChatMessage", chatEventType),
                    chatEventType.getMethod("isCancelled")
            );
            lastError = "";
            return resolution;
        } catch (ReflectiveOperationException | LinkageError | RuntimeException exception) {
            lastError = readable(exception);
            resolution = Resolution.unavailable();
            return null;
        }
    }

    private static RuntimeException propagate(Throwable cause) {
        if (cause instanceof RuntimeException runtime) {
            return runtime;
        }
        if (cause instanceof Error error) {
            throw error;
        }
        return new IllegalStateException("Baritone chat listener failed", cause);
    }

    private static String readable(Throwable throwable) {
        String message = throwable.getMessage();
        return throwable.getClass().getSimpleName()
                + (message == null || message.isBlank() ? "" : ": " + message);
    }

    private record Resolution(
            boolean available,
            Method getProvider,
            Method getBaritoneForPlayer,
            Method getGameEventHandler,
            Constructor<?> chatEventConstructor,
            Method onSendChatMessage,
            Method isCancelled
    ) {
        private static Resolution unavailable() {
            return new Resolution(false, null, null, null, null, null, null);
        }
    }
}
