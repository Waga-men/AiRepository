package celestial.port.client.chat;

import celestial.port.client.command.LegacyDotCommandDispatcher;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.Objects;
import java.util.concurrent.CopyOnWriteArrayList;

public final class LegacyOutgoingChatDispatcher {
    private static final CopyOnWriteArrayList<Listener> LISTENERS = new CopyOnWriteArrayList<>();

    private LegacyOutgoingChatDispatcher() {
    }

    public static Subscription listen(Listener listener) {
        Listener checked = Objects.requireNonNull(listener, "listener");
        LISTENERS.add(checked);
        return () -> LISTENERS.remove(checked);
    }

    public static boolean afterExternalBaritone(String originalMessage) {
        if (LegacyDotCommandDispatcher.dispatch(originalMessage)) {
            return true;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || client.world == null) {
            return false;
        }
        LegacyOutgoingChatEvent event = new LegacyOutgoingChatEvent(originalMessage);
        for (Listener listener : LISTENERS) {
            listener.onOutgoingChat(event);
        }

        return event.cancelled();
    }

    public static boolean includingBaritone(ClientPlayerEntity player, String originalMessage) {
        return BaritoneChatBridge.isCancelled(player, originalMessage)
                || afterExternalBaritone(originalMessage);
    }

    @FunctionalInterface
    public interface Listener {
        void onOutgoingChat(LegacyOutgoingChatEvent event);
    }

    @FunctionalInterface
    public interface Subscription {
        void unsubscribe();
    }
}
