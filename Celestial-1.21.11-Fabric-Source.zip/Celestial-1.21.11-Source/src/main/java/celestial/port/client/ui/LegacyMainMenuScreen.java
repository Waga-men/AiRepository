package celestial.port.client.ui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.screen.multiplayer.MultiplayerScreen;
import net.minecraft.client.gui.screen.option.OptionsScreen;
import net.minecraft.client.gui.screen.world.SelectWorldScreen;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;

import java.util.EnumMap;
import java.util.List;
import java.util.Map;

public final class LegacyMainMenuScreen extends Screen {
    private static final String VERSION = "#0.6.7";
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 20;
    private final Map<Action, Float> hoverRaw = new EnumMap<>(Action.class);

    private static final List<ChangeLine> CHANGELOG = List.of(
            new ChangeLine(Kind.HEADER, "Версия #0.6.7 (19 Мая, 2023)"),
            new ChangeLine(Kind.ADDED, "новый режим \"Sunrise\" в Jesus (фулл обход Sunrise)"),
            new ChangeLine(Kind.ADDED, "настройка \"Длительность буста\" в Strafe", "а"),
            new ChangeLine(Kind.ADDED, "KTLeave обратно (все еще обходит Vulcan)"),
            new ChangeLine(Kind.ADDED, "поисковик в ресурспаки"),
            new ChangeLine(Kind.ADDED, "чекбокс \"Задний фон зелий\" в HUD"),
            new ChangeLine(Kind.CHANGED, "режим \"Sunrise Elytra\" в Flight"),
            new ChangeLine(Kind.CHANGED, "чекбокс \"Закрытие меню\" в RWHelper"),
            new ChangeLine(Kind.FIXED, "небольшой баг в .rct"),
            new ChangeLine(Kind.FIXED, "некоторые баги", "ы"),
            new ChangeLine(Kind.INFO_HEADER, "Дополнительная информация"),
            new ChangeLine(Kind.INFO, "RWHelper: чекбокс \"Закрытие меню\" теперь вообще не открывает меню"),
            new ChangeLine(Kind.INFO, "Strafe: слайдер \"Длительность буста\" сделан специально для Sunrise"),
            new ChangeLine(Kind.INFO, "ставьте на Sunrise 25, а на ReallyWorld 10"),
            new ChangeLine(Kind.INFO, "Flight: теперь мод \"Sunrise Elytra\" может разгоняться до ~60 БПС"),
            new ChangeLine(Kind.INFO, "ShieldBreaker: теперь может ломать из инвентаря"),
            new ChangeLine(Kind.INFO, "AutoExplosion: теперь может брать и взрывать кристаллы из инвентаря"),
            new ChangeLine(Kind.INFO, "HUD: вы можете выключить чекбокс \"Задний фон зелий\" если у вас слабый ПК")
    );

    private float changelogProgress;
    private int changelogWidth;
    private long lastRenderNanos = System.nanoTime();

    public LegacyMainMenuScreen() {
        super(Text.literal("Celestial"));
        for (Action action : Action.values()) hoverRaw.put(action, 0.0f);
    }

    static boolean shadersEnabled() {
        return LegacyClientState.shaders();
    }

    @Override
    public void renderBackground(
            DrawContext context, int mouseX, int mouseY, float deltaTicks
    ) {
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        long now = System.nanoTime();
        float frameSeconds = Math.min(0.1f,
                Math.max(0.0f, (now - lastRenderNanos) / 1_000_000_000.0f));
        lastRenderNanos = now;

        LegacyMenuRender.wallpaper(context, width, height);
        int baseY = height / 4 + 48;
        int buttonX = width / 2 - 100;

        if (shadersEnabled()) {
            LegacyMenuBackdropBlur.apply(context, width, height, buttonX, baseY);
        }

        LegacyMenuRender.texture(context, LegacyMenuRender.ATOM,
                width / 2 - 20, height / 4 - 6, 32, 32, 0x4B000000);
        LegacyMenuRender.texture(context, LegacyMenuRender.ATOM,
                width / 2 - 20, height / 4 - 8, 32, 32, 0xFFFFFFFF);

        String welcome = "Welcome, " + (client == null ? "Player" : client.getSession().getUsername()) + "!";
        drawLegacyText(context, welcome,
                2, height - 10.5f, 0xFFFFFFFF, LegacyMenuRender.FONT_DX);
        String version = "Version: " + VERSION;
        drawLegacyText(context, version,
                width - LegacyMenuRender.width(textRenderer, version, LegacyMenuRender.FONT_DX) - 2,
                height - 10.5f, 0xFFFFFFFF, LegacyMenuRender.FONT_DX);

        renderChangelog(context, mouseX, mouseY, deltaTicks);

        drawButton(context, Action.SINGLEPLAYER, buttonX, baseY + 24,
                Text.translatable("menu.singleplayer").getString(), mouseX, mouseY, frameSeconds);
        drawButton(context, Action.MULTIPLAYER, buttonX, baseY + 48,
                Text.translatable("menu.multiplayer").getString(), mouseX, mouseY, frameSeconds);
        drawButton(context, Action.OPTIONS, buttonX, baseY + 105, 98,
                Text.translatable("menu.options").getString(), mouseX, mouseY, frameSeconds);
        drawButton(context, Action.QUIT, buttonX + 102, baseY + 105, 98,
                Text.translatable("menu.quit").getString(), mouseX, mouseY, frameSeconds);
        drawButton(context, Action.ALTS, buttonX, baseY + 72,
                "Alt Manager", mouseX, mouseY, frameSeconds);
        drawButton(context, Action.SHADERS, buttonX, baseY,
                "Shaders: " + shadersEnabled(), mouseX, mouseY, frameSeconds);
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    private void drawButton(
            DrawContext context, Action action, int x, int y,
            String label, int mouseX, int mouseY, float frameSeconds
    ) {
        drawButton(context, action, x, y, BUTTON_WIDTH, label, mouseX, mouseY, frameSeconds);
    }

    private void drawButton(
            DrawContext context, Action action, int x, int y, int buttonWidth,
            String label, int mouseX, int mouseY, float frameSeconds
    ) {
        boolean hovered = LegacyMenuRender.inside(mouseX, mouseY,
                x, y, buttonWidth, BUTTON_HEIGHT);
        float raw = Math.max(0.0f, Math.min(1.0f,
                hoverRaw.get(action) + (hovered ? 1.0f : -1.0f)
                        * frameSeconds * 3.0f));
        hoverRaw.put(action, raw);
        float progress = (float) Math.sqrt(Math.max(0.0f,
                1.0f - (raw - 1.0f) * (raw - 1.0f)));
        LegacyMenuRender.button(context, textRenderer, x, y, buttonWidth, BUTTON_HEIGHT,
                label, true, hovered, progress, shadersEnabled());
    }

    private void renderChangelog(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        int panelWidth = CHANGELOG.stream().mapToInt(line ->
                LegacyMenuRender.width(textRenderer, line.measureText(),
                        LegacyMenuRender.FONT_DU)).max().orElse(0) + 27;
        int panelHeight = 25 + CHANGELOG.size() * 10;
        boolean edgeHover = mouseX >= 0 && mouseX < changelogWidth + 15
                && mouseY >= 0 && mouseY < 26 + CHANGELOG.size() * 10;
        changelogProgress = LegacyClientState.changeLogPinned() ? 1.0f
                : LegacyMenuRender.approach(changelogProgress,
                edgeHover, deltaTicks, 5.0f);
        if (width <= 460 || changelogProgress <= 0.002f) return;
        changelogWidth = panelWidth;

        int panelX = Math.round(-panelWidth * (1.0f - changelogProgress)) + 6;
        int panelY = 5;
        if (shadersEnabled()) {
            LegacyMenuRender.softShadow(context, panelX, panelY, panelWidth, panelHeight,
                    0, 10, 0xFF000000);
            LegacyMenuRender.softShadow(context, panelX, panelY, panelWidth, panelHeight,
                    0, 15, 0x64050505);
        } else {
            LegacyMenuRender.rounded(context, panelX, panelY, panelWidth, panelHeight,
                    0, 0x64050505);
        }
        drawLegacyText(context, "ChangeLog",
                panelX + 9, panelY + 7, 0xFFFFFFFF, LegacyMenuRender.FONT_DZ);

        int rowY = panelY + 21;
        for (ChangeLine line : CHANGELOG) {
            if (line.kind == Kind.HEADER || line.kind == Kind.INFO_HEADER) {
                drawLegacyText(context,
                        "----- " + line.text + " -----", panelX + 10, rowY - 2,
                        0xFFAAAAAA, LegacyMenuRender.FONT_DU);
            } else if (line.kind == Kind.INFO) {
                drawInfoLine(context, line.text, panelX + 8, rowY - 2);
            } else {
                int dotColor = line.kind.color;
                LegacyMenuRender.rounded(context, panelX + 7, rowY, 8, 8,
                        4.0f, 0xFF000000);
                LegacyMenuRender.rounded(context, panelX + 8, rowY + 1, 6, 6,
                        3.0f, dotColor);
                if (shadersEnabled()) {
                    drawCachedLegacyShadow(context, panelX + 8.0f, rowY,
                            6.5f, 6.5f, 8,
                            LegacyMenuRender.withAlpha(dotColor, 125));
                }
                drawLegacyText(context, line.displayText(),
                        panelX + 17, rowY - 2, 0xFFFFFFFF, LegacyMenuRender.FONT_DU);
            }
            rowY += 10;
        }
        int pinCenterX = panelX + panelWidth - 6;
        int pinCenterY = panelY + 6;
        LegacyMenuRender.rounded(context, pinCenterX - 4, pinCenterY - 4,
                8, 8, 4, 0xFF000000);
        LegacyMenuRender.rounded(context, pinCenterX - 3, pinCenterY - 3,
                6, 6, 3, LegacyClientState.changeLogPinned() ? 0xFFD85AD8 : 0xFFFFFFFF);
        if (shadersEnabled()) {
            drawCachedLegacyShadow(context, pinCenterX - 3.0f, pinCenterY - 3.5f,
                    6.5f, 6.5f, 10,
                    LegacyClientState.changeLogPinned() ? 0xFFD85AD8 : 0xFFFFFFFF);
        }
    }

    private static void drawCachedLegacyShadow(
            DrawContext context, float x, float y, float width, float height,
            int blurRadius, int color
    ) {
        LegacyHudShadow.Batch batch = LegacyHudShadow.batch();
        batch.add(x, y, width, height, blurRadius, color);
        batch.submit(context);
    }

    private void drawInfoLine(DrawContext context, String value, int x, int y) {
        int colon = value.indexOf(':');
        if (colon < 0) {
            drawLegacyText(context, value, x, y,
                    0xFFAAAAAA, LegacyMenuRender.FONT_DU);
            return;
        }
        String label = value.substring(0, colon + 1);
        String detail = value.substring(colon + 1);
        drawLegacyText(context, label, x, y,
                0xFFFFFFFF, LegacyMenuRender.FONT_DU);
        drawLegacyText(context, detail,
                x + LegacyMenuRender.width(textRenderer, label, LegacyMenuRender.FONT_DU), y,
                0xFFAAAAAA, LegacyMenuRender.FONT_DU);
    }

    private void drawLegacyText(
            DrawContext context, String value, float x, float y,
            int color, StyleSpriteSource font
    ) {
        int shadow = (color & 0x00FCFCFC) >> 2 | color & 0xC8141414;
        drawDenseText(context, value, x + 0.5f, y + 0.5f, shadow, font);
        drawDenseText(context, value, x, y, color, font);
    }

    private void drawDenseText(
            DrawContext context, String value, float x, float y,
            int color, StyleSpriteSource font
    ) {
        LegacyMenuRender.draw(context, textRenderer, value, x, y, color, font);
        LegacyMenuRender.draw(context, textRenderer, value,
                x + 0.25f, y, color, font);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        int baseY = height / 4 + 48;
        int buttonX = width / 2 - 100;

        if (width > 460 && changelogProgress > 0.01f) {
            int panelWidth = CHANGELOG.stream().mapToInt(line ->
                    LegacyMenuRender.width(textRenderer, line.measureText(),
                            LegacyMenuRender.FONT_DU)).max().orElse(0) + 27;
            int panelX = Math.round(-panelWidth * (1.0f - changelogProgress)) + 6;
            if (LegacyMenuRender.inside(click.x(), click.y(),
                    panelX + panelWidth - 13, 8, 10, 10)) {
                LegacyClientState.setChangeLogPinned(!LegacyClientState.changeLogPinned());
                return true;
            }
        }
        if (activate(click, Action.SHADERS, buttonX, baseY, 200)) return true;
        if (activate(click, Action.SINGLEPLAYER, buttonX, baseY + 24, 200)) return true;
        if (activate(click, Action.MULTIPLAYER, buttonX, baseY + 48, 200)) return true;
        if (activate(click, Action.ALTS, buttonX, baseY + 72, 200)) return true;
        if (activate(click, Action.OPTIONS, buttonX, baseY + 105, 98)) return true;
        if (activate(click, Action.QUIT, buttonX + 102, baseY + 105, 98)) return true;
        return super.mouseClicked(click, doubled);
    }

    private boolean activate(Click click, Action action, int x, int y, int buttonWidth) {
        if (!LegacyMenuRender.inside(click.x(), click.y(), x, y, buttonWidth, BUTTON_HEIGHT)) {
            return false;
        }
        if (client == null) return true;
        LegacyMenuRender.playClick(client);
        switch (action) {
            case SHADERS -> LegacyClientState.setShaders(!LegacyClientState.shaders());
            case SINGLEPLAYER -> client.setScreen(new SelectWorldScreen(this));
            case MULTIPLAYER -> client.setScreen(new MultiplayerScreen(this));
            case ALTS -> client.setScreen(new LegacyAltManagerScreen(this));
            case OPTIONS -> client.setScreen(new OptionsScreen(this, client.options));
            case QUIT -> client.scheduleStop();
        }
        return true;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private enum Action {
        SHADERS, SINGLEPLAYER, MULTIPLAYER, ALTS, OPTIONS, QUIT
    }

    private enum Kind {
        HEADER(0xFFFFFFFF, "Версия"),
        ADDED(0xFF00D800, "Добавлен"),
        CHANGED(0xFF00D8D8, "Улучшен"),
        FIXED(0xFFD85AD8, "Исправлен"),
        INFO_HEADER(0xFFFFFFFF, "Информация"),
        INFO(0xFFFFFFFF, "");

        private final int color;
        private final String prefix;

        Kind(int color, String prefix) {
            this.color = color;
            this.prefix = prefix;
        }
    }

    private record ChangeLine(Kind kind, String text, String suffix) {
        private ChangeLine(Kind kind, String text) {
            this(kind, text, "");
        }

        private String displayText() {
            return kind.prefix + suffix + " " + text;
        }

        private String measureText() {
            return displayText();
        }
    }
}
