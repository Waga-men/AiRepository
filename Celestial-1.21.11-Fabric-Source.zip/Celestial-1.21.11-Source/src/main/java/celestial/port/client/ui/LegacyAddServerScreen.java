package celestial.port.client.ui;

import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.CharInput;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

final class LegacyAddServerScreen extends Screen {
    private final Screen parent;
    private String serverName = "";
    private String serverAddress = "";
    private String status = "";
    private Field focused = Field.NAME;
    private float addHover;
    private float backHover;
    private long blinkStarted = System.currentTimeMillis();

    LegacyAddServerScreen(Screen parent) {
        super(Text.literal("Add QuickJoin server"));
        this.parent = parent;
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float deltaTicks) {
        if (focused != Field.ADDRESS) focused = Field.NAME;
        LegacyMenuRender.wallpaper(context, width, height);
        int x = width / 2 - 100;
        int nameY = height / 2 - 70;
        int addressY = height / 2 - 35;
        renderStatus(context);
        LegacyMenuRender.draw(context, textRenderer, "Server Name",
                x, height / 2.0f - 80, 0xFFAAAAAA, LegacyMenuRender.FONT_DX);
        LegacyMenuRender.draw(context, textRenderer, "Server IP",
                x, height / 2.0f - 45, 0xFFAAAAAA, LegacyMenuRender.FONT_DX);
        LegacyMenuRender.textField(context, textRenderer, x, nameY, 200, 20,
                serverName, false, focused == Field.NAME, blinkStarted);
        LegacyMenuRender.textField(context, textRenderer, x, addressY, 200, 20,
                serverAddress, false, focused == Field.ADDRESS, blinkStarted);

        boolean addHovered = LegacyMenuRender.inside(mouseX, mouseY,
                x, height / 2 + 5, 200, 20);
        boolean backHovered = LegacyMenuRender.inside(mouseX, mouseY,
                x, height / 2 + 30, 200, 20);
        addHover = LegacyMenuRender.approach(addHover, addHovered, deltaTicks, 15.0f);
        backHover = LegacyMenuRender.approach(backHover, backHovered, deltaTicks, 15.0f);
        LegacyMenuRender.button(context, textRenderer, x, height / 2 + 5, 200, 20,
                "Add server", true, addHovered, addHover,
                LegacyMainMenuScreen.shadersEnabled());
        LegacyMenuRender.button(context, textRenderer, x, height / 2 + 30, 200, 20,
                "Back", true, backHovered, backHover,
                LegacyMainMenuScreen.shadersEnabled());
        super.render(context, mouseX, mouseY, deltaTicks);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        if (click.button() != 0) return super.mouseClicked(click, doubled);
        int x = width / 2 - 100;
        if (LegacyMenuRender.inside(click.x(), click.y(),
                x, height / 2 - 70, 200, 20)) {
            focus(Field.NAME);
            return true;
        }
        if (LegacyMenuRender.inside(click.x(), click.y(),
                x, height / 2 - 35, 200, 20)) {
            focus(Field.ADDRESS);
            return true;
        }
        if (LegacyMenuRender.inside(click.x(), click.y(),
                x, height / 2 + 5, 200, 20)) {
            if (client != null) LegacyMenuRender.playClick(client);
            submit();
            return true;
        }
        if (LegacyMenuRender.inside(click.x(), click.y(),
                x, height / 2 + 30, 200, 20)) {
            if (client != null) LegacyMenuRender.playClick(client);
            close();
            return true;
        }
        focused = Field.NONE;
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            close();
            return true;
        }
        if (key == GLFW.GLFW_KEY_BACKSPACE && focused != Field.NONE) {
            if (focused == Field.NAME) serverName = removeLast(serverName);
            else serverAddress = removeLast(serverAddress);
            status = "";
            blinkStarted = System.currentTimeMillis();
            return true;
        }
        if (key == GLFW.GLFW_KEY_V && focused != Field.NONE && controlDown() && client != null) {
            append(client.keyboard.getClipboard());
            return true;
        }
        return super.keyPressed(input);
    }

    @Override
    public boolean charTyped(CharInput input) {
        if (focused == Field.NONE || !input.isValidChar()) return super.charTyped(input);
        append(input.asString());
        return true;
    }

    private void append(String typed) {
        String filtered = typed.codePoints()
                .filter(codePoint -> codePoint >= 32 && codePoint != 127)
                .limit(128)
                .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
                .toString();
        if (focused == Field.NAME) {
            int room = Math.max(0, 32 - serverName.codePointCount(0, serverName.length()));
            serverName += filtered.codePoints().limit(room)
                    .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append);
        } else {
            int room = Math.max(0, 32 - serverAddress.codePointCount(0, serverAddress.length()));
            serverAddress += filtered.codePoints().limit(room)
                    .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append);
        }
        status = "";
        blinkStarted = System.currentTimeMillis();
    }

    private void submit() {
        String name = serverName.strip();
        String address = serverAddress.strip();
        if (name.isEmpty() && address.isEmpty()) {
            status = "Name and IP required!";
        } else if (name.isEmpty()) {
            status = "Name required!";
        } else if (address.isEmpty()) {
            status = "IP required!";
        } else {
            LegacyAltStore.instance().addServer(name, address);
            LegacyAltStore.instance().sortServers(value ->
                    LegacyMenuRender.width(textRenderer, value, LegacyMenuRender.FONT_DX));
            status = "Server " + name + " was added";
        }
    }

    private void focus(Field field) {
        focused = field;
        blinkStarted = System.currentTimeMillis();
    }

    private void renderStatus(DrawContext context) {
        if (!status.startsWith("Server ") || !status.endsWith(" was added")) {
            LegacyMenuRender.draw(context, textRenderer, status, 2, 3,
                    status.isEmpty() ? 0xFFFFFFFF : 0xFFFF5555,
                    LegacyMenuRender.FONT_DX);
            return;
        }
        String prefix = "Server ";
        String suffix = " was added";
        String name = status.substring(prefix.length(), status.length() - suffix.length());
        LegacyMenuRender.draw(context, textRenderer, prefix, 2, 3,
                0xFFFFFFFF, LegacyMenuRender.FONT_DX);
        float nameX = 2 + LegacyMenuRender.width(textRenderer, prefix, LegacyMenuRender.FONT_DX);
        LegacyMenuRender.draw(context, textRenderer, name, nameX, 3,
                0xFF55FF55, LegacyMenuRender.FONT_DX);
        LegacyMenuRender.draw(context, textRenderer, suffix,
                nameX + LegacyMenuRender.width(textRenderer, name, LegacyMenuRender.FONT_DX),
                3, 0xFFFFFFFF, LegacyMenuRender.FONT_DX);
    }

    private boolean controlDown() {
        if (client == null) return false;
        long handle = client.getWindow().getHandle();
        return GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_LEFT_CONTROL) == GLFW.GLFW_PRESS
                || GLFW.glfwGetKey(handle, GLFW.GLFW_KEY_RIGHT_CONTROL) == GLFW.GLFW_PRESS;
    }

    private static String removeLast(String value) {
        if (value.isEmpty()) return value;
        return value.substring(0, value.offsetByCodePoints(value.length(), -1));
    }

    @Override
    public void close() {
        status = "";
        if (client != null) client.setScreen(parent);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    private enum Field {
        NONE, NAME, ADDRESS
    }
}
