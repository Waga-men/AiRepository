package celestial.port.client.command.commands;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.client.command.LegacyModuleResolver;
import celestial.port.core.Module;
import celestial.port.core.macro.LegacyMacroKeyCodec;
import celestial.port.core.setting.BindSetting;
import org.lwjgl.glfw.GLFW;

public final class BindCommand implements LegacyDotCommandDispatcher.Command {
    private static final String GRAY = "\u00A77";
    private static final String RED = "\u00A7c";
    private static final String WHITE = "\u00A7f";

    @Override
    public String name() {
        return "bind";
    }

    @Override
    public String description() {
        return "\u0423\u043f\u0440\u0430\u0432\u043b\u044f\u0435\u0442 \u0431\u0438\u043d\u0434\u0430\u043c\u0438 \u0432 \u043a\u043b\u0438\u0435\u043d\u0442\u0435";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length == 0) {
            LegacyCommandFeedback.send("\u041d\u0435\u0432\u0435\u0440\u043d\u0430\u044f \u043a\u043e\u043c\u0430\u043d\u0434\u0430! \u041f\u043e\u0436\u0430\u043b\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043f\u043e\u043b\u044c\u0437\u0443\u0439\u0442\u0435:");
            LegacyCommandFeedback.send("bind " + GRAY
                    + "<module> <key> (\u0447\u0442\u043e\u0431\u044b \u0437\u0430\u0431\u0438\u043d\u0434\u0438\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u044c)");
            LegacyCommandFeedback.send("bind " + GRAY + "<module>" + RED + " none" + GRAY
                    + " (\u0447\u0442\u043e\u0431\u044b \u0440\u0430\u0437\u0431\u0438\u043d\u0434\u0438\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u044c)");
            LegacyCommandFeedback.send("bind " + RED + "list " + GRAY
                    + "(\u043f\u043e\u0441\u043c\u043e\u0442\u0440\u0435\u0442\u044c \u0441\u043f\u0438\u0441\u043e\u043a \u0432\u0441\u0435\u0445 \u0431\u0438\u043d\u0434\u043e\u0432)");
            LegacyCommandFeedback.send("bind " + RED + "clear " + GRAY
                    + "(\u0443\u0434\u0430\u043b\u0438\u0442\u044c \u0432\u0441\u0435 \u0431\u0438\u043d\u0434\u044b)");
            LegacyCommandFeedback.send("\u0411\u0438\u043d\u0434\u0438\u0442\u044c \u043c\u043e\u0434\u0443\u043b\u0438 \u0442\u0430\u043a\u0436\u0435 \u043c\u043e\u0436\u043d\u043e \u0447\u0435\u0440\u0435\u0437 \u043a\u043e\u043b\u0435\u0441\u0438\u043a\u043e \u043c\u044b\u0448\u043a\u0438 \u0432 \u043a\u043b\u0438\u043a\u0433\u0443\u0438 :)");
            return;
        }

        try {
            if (arguments[0].equalsIgnoreCase("clear")) {
                for (Module module : CelestialPortClient.MODULES.modules()) {
                    if (isClickGui(module) || module.key() == BindSetting.UNBOUND) continue;
                    module.setKey(BindSetting.UNBOUND);
                }
                LegacyCommandFeedback.send("\u0412\u0430\u0448 \u043b\u0438\u0441\u0442 \u0431\u0438\u043d\u0434\u043e\u0432 \u0431\u044b\u043b \u043e\u0447\u0438\u0449\u0435\u043d!");
                return;
            }
            if (arguments[0].equalsIgnoreCase("list")) {
                LegacyCommandFeedback.send("\u0421\u043f\u0438\u0441\u043e\u043a \u0431\u0438\u043d\u0434\u043e\u0432:");
                for (Module module : CelestialPortClient.MODULES.modules()) {
                    if (module.key() == BindSetting.UNBOUND) continue;
                    LegacyCommandFeedback.send(WHITE + LegacyModuleResolver.legacyName(module) + GRAY
                            + " : \u041a\u043b\u0430\u0432\u0438\u0448\u0430 " + RED + "'" + legacyKeyName(module.key()) + "'");
                }
                return;
            }

            Module module = LegacyModuleResolver.module(arguments[0]).orElse(null);
            if (module == null) {
                LegacyCommandFeedback.send("\u041c\u043e\u0434\u0443\u043b\u044c " + RED + "'" + arguments[0] + "'" + WHITE
                        + " \u043d\u0435 \u0441\u0443\u0449\u0435\u0441\u0442\u0432\u0443\u0435\u0442!");
                return;
            }

            String moduleName = LegacyModuleResolver.legacyName(module);
            if (arguments[1].equalsIgnoreCase("none")) {
                module.setKey(isClickGui(module) ? GLFW.GLFW_KEY_RIGHT_SHIFT : BindSetting.UNBOUND);
                LegacyCommandFeedback.send("\u041c\u043e\u0434\u0443\u043b\u044c " + RED + "'" + moduleName + "'" + WHITE
                        + " \u0431\u044b\u043b \u0440\u0430\u0437\u0431\u0438\u043d\u0436\u0435\u043d!");
                return;
            }

            int legacyKey = LegacyMacroKeyCodec.fromLegacy(arguments[1].toUpperCase());
            int glfwKey = LegacyMacroKeyCodec.toGlfw(legacyKey);
            module.setKey(glfwKey == GLFW.GLFW_KEY_UNKNOWN ? BindSetting.UNBOUND : glfwKey);
            LegacyCommandFeedback.send("\u041c\u043e\u0434\u0443\u043b\u044c " + RED + "'" + moduleName + "'" + WHITE
                    + " \u0431\u044b\u043b \u0437\u0430\u0431\u0438\u043d\u0436\u0435\u043d \u043d\u0430 \u043a\u043b\u0430\u0432\u0438\u0448\u0443 " + RED
                    + arguments[1].toUpperCase());
        } catch (ArrayIndexOutOfBoundsException exception) {
            LegacyCommandFeedback.send("\u041d\u0435 \u0443\u043a\u0430\u0437\u0430\u043d\u0430 \u043a\u043b\u0430\u0432\u0438\u0448\u0430!");
        }
    }

    private static boolean isClickGui(Module module) {
        return module.id().equals("click_gui");
    }

    private static String legacyKeyName(int currentKey) {
        if (BindSetting.isMouseButton(currentKey)) {
            return LegacyMacroKeyCodec.name(currentKey);
        }
        return LegacyMacroKeyCodec.name(LegacyMacroKeyCodec.fromGlfw(currentKey));
    }
}
