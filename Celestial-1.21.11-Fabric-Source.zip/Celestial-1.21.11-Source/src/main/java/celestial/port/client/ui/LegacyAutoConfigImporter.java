package celestial.port.client.ui;

import celestial.port.core.LegacyString;
import celestial.port.core.Module;
import celestial.port.core.ModuleManager;
import celestial.port.core.macro.LegacyMacroKeyCodec;
import celestial.port.core.setting.ActionSetting;
import celestial.port.core.setting.BindSetting;
import celestial.port.core.setting.BooleanSetting;
import celestial.port.core.setting.ColorSetting;
import celestial.port.core.setting.ModeSetting;
import celestial.port.core.setting.MultiSelectSetting;
import celestial.port.core.setting.NumberSetting;
import celestial.port.core.setting.Setting;
import celestial.port.core.setting.TextSetting;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HexFormat;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.zip.InflaterInputStream;

final class LegacyAutoConfigImporter {
    private static final Logger LOGGER = LoggerFactory.getLogger("celestial/legacy-config");
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting()
            .disableHtmlEscaping()
            .create();
    private static final int MAX_COMPRESSED_BYTES = 4 * 1024 * 1024;
    private static final int MAX_INFLATED_BYTES = 16 * 1024 * 1024;
    private static final Map<String, String> LEGACY_SETTING_ALIASES = Map.of(
            "attack_aura.obstruction_check", "Проверка на обсу",
            "elytra_flight.firework_slot", "Слот с фейрверком",
            "elytra_flight.firework_delay", "Задержка фейрверка"
    );

    private LegacyAutoConfigImporter() {
    }

    static void ensureImported(ModuleManager modules, Path profileDirectory) {
        List<Path> sources;
        try {
            sources = legacyConfigsNewestFirst();
        } catch (RuntimeException exception) {

            LOGGER.warn("Unable to discover legacy autocfg.celka", exception);
            return;
        }

        for (Path source : sources) {
            try {
                importCandidate(modules, profileDirectory, source);
                return;
            } catch (IOException | RuntimeException exception) {

                LOGGER.warn("Unable to import legacy autocfg candidate '{}'", source, exception);
            }
        }
    }

    private static void importCandidate(
            ModuleManager modules, Path profileDirectory, Path source
    ) throws IOException {
        byte[] compressed = readStoredBytes(source);
        String digest = sha256(compressed);
        String importedName = "autocfg-1.12.2-" + digest.substring(0, 12);
        Path target = profileDirectory.resolve(importedName + ".celka");
        if (Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) return;

        Path priorJson = profileDirectory.resolve(importedName + ".json");
        if (isPriorImportedProfile(priorJson, digest)
                && migratePriorImportedProfile(priorJson, target)) {
            LOGGER.info("Migrated imported legacy profile '{}' to '{}'",
                    priorJson.getFileName(), target.getFileName());
            return;
        }

        ImportResult imported = convert(modules, inflate(compressed), source, digest);
        writeNewProfile(target, imported.root());
        LOGGER.info("Imported legacy autocfg as profile '{}' ({} modules, {} settings)",
                target.getFileName(), imported.moduleCount(), imported.settingCount());
    }

    static JsonObject readProfile(ModuleManager modules, Path source) throws IOException {
        byte[] stored = readStoredBytes(source);
        String digest = sha256(stored);

        IOException plainFailure;
        try {
            JsonObject plain = parseObject(stored, "profile JSON");
            if (isModernProfile(plain)) {
                return plain;
            }
            return convert(modules, stored, source, digest).root();
        } catch (IOException exception) {
            plainFailure = exception;
        }

        try {
            byte[] inflated = inflate(stored);
            JsonObject decoded = parseObject(inflated, "inflated legacy profile JSON");
            if (isModernProfile(decoded)) {
                return decoded;
            }
            return convert(modules, inflated, source, digest).root();
        } catch (IOException exception) {
            exception.addSuppressed(plainFailure);
            throw exception;
        }
    }

    private static byte[] readStoredBytes(Path source) throws IOException {
        if (!Files.isRegularFile(source, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("Profile is not a regular file: " + source);
        }
        long storedSize = Files.size(source);
        if (storedSize <= 0 || storedSize > MAX_COMPRESSED_BYTES) {
            throw new IOException("Profile has an invalid stored size: " + storedSize);
        }
        byte[] stored = Files.readAllBytes(source);
        if (stored.length == 0 || stored.length > MAX_COMPRESSED_BYTES) {
            throw new IOException("Profile changed to an invalid size while reading: "
                    + stored.length);
        }
        return stored;
    }

    private static JsonObject parseObject(byte[] bytes, String description) throws IOException {
        JsonElement parsed;
        try {
            parsed = JsonParser.parseString(new String(bytes, StandardCharsets.UTF_8));
        } catch (JsonParseException exception) {
            throw new IOException("Invalid " + description, exception);
        }
        if (!parsed.isJsonObject()) {
            throw new IOException(description + " root must be an object");
        }
        return parsed.getAsJsonObject();
    }

    private static boolean isModernProfile(JsonObject root) {
        JsonElement schemaVersion = root.get("schemaVersion");
        JsonElement moduleStates = root.get("modules");
        return schemaVersion != null
                && schemaVersion.isJsonPrimitive()
                && schemaVersion.getAsJsonPrimitive().isNumber()
                && moduleStates != null
                && moduleStates.isJsonObject();
    }

    private static boolean isPriorImportedProfile(Path source, String digest) {
        try {
            JsonObject root = parseObject(readStoredBytes(source), "prior imported profile");
            JsonObject provenance = object(root, "legacyImport");
            JsonElement importedDigest = provenance == null ? null : provenance.get("sha256");
            return isModernProfile(root)
                    && importedDigest != null
                    && importedDigest.isJsonPrimitive()
                    && digest.equalsIgnoreCase(importedDigest.getAsString());
        } catch (IOException | RuntimeException ignored) {
            return false;
        }
    }

    private static boolean migratePriorImportedProfile(Path source, Path target)
            throws IOException {
        Files.createDirectories(target.getParent());
        Path temporary = Files.createTempFile(target.getParent(),
                target.getFileName().toString() + ".", ".migrating");
        try {
            Files.copy(source, temporary, StandardCopyOption.REPLACE_EXISTING);
            try {

                Files.move(temporary, target);
            } catch (FileAlreadyExistsException raceWonElsewhere) {
                return Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS);
            }
            try {
                Files.deleteIfExists(source);
            } catch (IOException exception) {

                LOGGER.warn("Migrated '{}' but could not remove the JSON fallback",
                        source.getFileName(), exception);
            }
            return true;
        } finally {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {

            }
        }
    }

    private static List<Path> legacyConfigsNewestFirst() {
        Path gameDirectory = FabricLoader.getInstance().getGameDir()
                .toAbsolutePath().normalize();
        List<Path> roots = new ArrayList<>();
        roots.add(gameDirectory);
        Path parent = gameDirectory.getParent();
        if (parent != null) roots.add(parent);

        Set<Path> candidates = new LinkedHashSet<>();
        for (Path root : roots) {
            candidates.add(root.resolve("configs").resolve("autocfg.celka").normalize());
            candidates.add(root.resolve("Celestial").resolve("configs")
                    .resolve("autocfg.celka").normalize());
            candidates.add(root.resolve("autocfg.celka").normalize());
        }
        return candidates.stream()
                .filter(Files::isRegularFile)
                .sorted(Comparator.comparingLong(
                        LegacyAutoConfigImporter::lastModifiedQuietly).reversed())
                .toList();
    }

    private static long lastModifiedQuietly(Path path) {
        try {
            return Files.getLastModifiedTime(path).toMillis();
        } catch (IOException ignored) {
            return Long.MIN_VALUE;
        }
    }

    private static byte[] inflate(byte[] compressed) throws IOException {
        try (InputStream input = new InflaterInputStream(new ByteArrayInputStream(compressed));
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192];
            int total = 0;
            int read;
            while ((read = input.read(buffer)) >= 0) {
                total += read;
                if (total > MAX_INFLATED_BYTES) {
                    throw new IOException("Inflated legacy autocfg exceeds safety limit");
                }
                output.write(buffer, 0, read);
            }
            return output.toByteArray();
        }
    }

    private static ImportResult convert(
            ModuleManager modules, byte[] jsonBytes, Path source, String digest
    ) throws IOException {
        JsonElement parsed;
        try {
            parsed = JsonParser.parseString(new String(jsonBytes, StandardCharsets.UTF_8));
        } catch (JsonParseException exception) {
            throw new IOException("Invalid legacy autocfg JSON", exception);
        }
        if (!parsed.isJsonObject()) {
            throw new IOException("Legacy autocfg root must be an object");
        }
        JsonObject legacyModules = object(parsed.getAsJsonObject(), "modules");
        if (legacyModules == null) {
            throw new IOException("Legacy autocfg has no modules object");
        }

        Map<String, Module> currentModules = new HashMap<>();
        for (Module module : modules.modules()) {
            currentModules.putIfAbsent(canonical(module.id()), module);
            currentModules.putIfAbsent(canonical(module.displayName()), module);
        }

        JsonObject convertedModules = new JsonObject();
        int importedModuleCount = 0;
        int importedSettingCount = 0;
        for (Map.Entry<String, JsonElement> entry : legacyModules.entrySet()) {
            if (!entry.getValue().isJsonObject()) continue;
            Module module = currentModules.get(canonical(entry.getKey()));
            if (module == null) continue;

            JsonObject legacyState = entry.getValue().getAsJsonObject();
            JsonObject state = new JsonObject();
            copyBoolean(legacyState, state, "enabled");
            Integer legacyKey = integer(legacyState, "key");
            if (legacyKey != null) state.addProperty("key", modernBind(legacyKey));
            copyBoolean(legacyState, state, "flag");
            copyBoolean(legacyState, state, "disabler");

            JsonObject convertedSettings = new JsonObject();
            JsonObject legacySettings = object(legacyState, "settings");
            if (legacySettings != null) {
                Map<String, JsonElement> valuesByName = new HashMap<>();
                for (Map.Entry<String, JsonElement> setting : legacySettings.entrySet()) {
                    valuesByName.putIfAbsent(canonical(setting.getKey()), setting.getValue());
                }
                for (Setting<?> setting : module.settings()) {
                    if (setting instanceof ActionSetting) continue;
                    JsonElement legacyValue = valuesByName.get(canonical(setting.displayName()));
                    if (legacyValue == null) {
                        String alias = LEGACY_SETTING_ALIASES.get(
                                module.id() + "." + setting.id());
                        if (alias != null) legacyValue = valuesByName.get(canonical(alias));
                    }
                    if (legacyValue == null || legacyValue.isJsonNull()) continue;
                    JsonElement converted = convertSetting(setting, legacyValue);
                    if (converted != null) {
                        convertedSettings.add(setting.id(), converted);
                        importedSettingCount++;
                    }
                }
            }
            state.add("settings", convertedSettings);
            convertedModules.add(module.id(), state);
            importedModuleCount++;
        }

        if (importedModuleCount == 0) {
            throw new IOException("Legacy config contains no recognized modules");
        }

        JsonObject root = new JsonObject();
        root.addProperty("schemaVersion", 1);
        root.add("modules", convertedModules);
        JsonObject provenance = new JsonObject();
        provenance.addProperty("format", "Celestial 1.12.2 config.celka");
        provenance.addProperty("source", source.getFileName().toString());
        provenance.addProperty("sha256", digest);
        provenance.addProperty("modules", importedModuleCount);
        provenance.addProperty("settings", importedSettingCount);
        root.add("legacyImport", provenance);

        return new ImportResult(root, importedModuleCount, importedSettingCount);
    }

    private static JsonElement convertSetting(Setting<?> setting, JsonElement value) {
        try {
            if (setting instanceof MultiSelectSetting multiSelect) {
                return convertMultiSelect(multiSelect, value);
            }
            if (setting instanceof ModeSetting mode) {
                if (!value.isJsonPrimitive()) return null;
                String wanted = LegacyString.repair(value.getAsString());
                return mode.options().stream()
                        .filter(option -> canonical(option).equals(canonical(wanted)))
                        .findFirst()
                        .map(GSON::toJsonTree)
                        .orElse(null);
            }
            if (setting instanceof BindSetting) {
                return value.isJsonPrimitive()
                        ? GSON.toJsonTree(modernBind(value.getAsInt())) : null;
            }
            if (setting instanceof BooleanSetting) {
                return value.isJsonPrimitive() ? GSON.toJsonTree(value.getAsBoolean()) : null;
            }
            if (setting instanceof NumberSetting) {
                return value.isJsonPrimitive() ? GSON.toJsonTree(value.getAsDouble()) : null;
            }
            if (setting instanceof ColorSetting) {
                return value.isJsonPrimitive() ? GSON.toJsonTree(value.getAsInt()) : null;
            }
            if (setting instanceof TextSetting) {
                return value.isJsonPrimitive()
                        ? GSON.toJsonTree(LegacyString.repair(value.getAsString())) : null;
            }
        } catch (RuntimeException ignored) {

        }
        return null;
    }

    private static JsonArray convertMultiSelect(MultiSelectSetting setting, JsonElement value) {
        Set<String> selectedNames = new LinkedHashSet<>();
        if (value.isJsonObject()) {
            for (Map.Entry<String, JsonElement> option : value.getAsJsonObject().entrySet()) {
                try {
                    if (option.getValue().getAsBoolean()) selectedNames.add(canonical(option.getKey()));
                } catch (RuntimeException ignored) {

                }
            }
        } else if (value.isJsonArray()) {
            for (JsonElement option : value.getAsJsonArray()) {
                if (option.isJsonPrimitive()) selectedNames.add(canonical(option.getAsString()));
            }
        } else {
            return null;
        }

        JsonArray converted = new JsonArray();
        setting.options().stream()
                .filter(option -> selectedNames.contains(canonical(option)))
                .forEach(converted::add);
        return converted;
    }

    private static int modernBind(int legacyCode) {
        if (legacyCode == 0) return BindSetting.UNBOUND;
        if (LegacyMacroKeyCodec.isMouse(legacyCode)) return legacyCode;
        int glfw = LegacyMacroKeyCodec.toGlfw(legacyCode);
        return glfw >= 0 ? glfw : BindSetting.UNBOUND;
    }

    private static String canonical(String value) {
        String repaired = LegacyString.repair(value).toLowerCase(Locale.ROOT);
        StringBuilder normalized = new StringBuilder(repaired.length());
        repaired.codePoints()
                .filter(Character::isLetterOrDigit)
                .forEach(normalized::appendCodePoint);
        return normalized.toString();
    }

    private static void copyBoolean(JsonObject source, JsonObject target, String key) {
        JsonElement value = source.get(key);
        if (value == null || !value.isJsonPrimitive()) return;
        try {
            target.addProperty(key, value.getAsBoolean());
        } catch (RuntimeException ignored) {

        }
    }

    private static Integer integer(JsonObject source, String key) {
        JsonElement value = source.get(key);
        if (value == null || !value.isJsonPrimitive()) return null;
        try {
            return value.getAsInt();
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static JsonObject object(JsonObject source, String key) {
        JsonElement value = source.get(key);
        return value != null && value.isJsonObject() ? value.getAsJsonObject() : null;
    }

    private static String sha256(byte[] bytes) throws IOException {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(bytes));
        } catch (NoSuchAlgorithmException impossible) {
            throw new IOException("SHA-256 is unavailable", impossible);
        }
    }

    private static void writeNewProfile(Path target, JsonObject root) throws IOException {
        Files.createDirectories(target.getParent());
        Path temporary = Files.createTempFile(target.getParent(),
                target.getFileName().toString() + ".", ".tmp");
        try {
            try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }
            try {

                Files.move(temporary, target);
            } catch (FileAlreadyExistsException ignored) {

            }
        } finally {
            try {
                Files.deleteIfExists(temporary);
            } catch (IOException ignored) {

            }
        }
    }

    private record ImportResult(JsonObject root, int moduleCount, int settingCount) {
    }
}
