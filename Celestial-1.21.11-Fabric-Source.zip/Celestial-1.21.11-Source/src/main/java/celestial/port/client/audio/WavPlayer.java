package celestial.port.client.audio;

import celestial.port.CelestialPortClient;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineEvent;
import java.io.BufferedInputStream;
import java.io.InputStream;

public final class WavPlayer {
    private WavPlayer() {
    }

    public static synchronized void play(String resourcePath, float volume) {
        try {
            InputStream raw = WavPlayer.class.getResourceAsStream(resourcePath);
            if (raw == null) {
                CelestialPortClient.LOGGER.warn("Missing bundled sound {}", resourcePath);
                return;
            }

            Clip clip = AudioSystem.getClip();
            try (InputStream input = raw;
                 BufferedInputStream buffered = new BufferedInputStream(input);
                 AudioInputStream audio = AudioSystem.getAudioInputStream(buffered)) {
                clip.open(audio);
            }

            if (clip.isControlSupported(FloatControl.Type.MASTER_GAIN)) {
                FloatControl gain = (FloatControl) clip.getControl(FloatControl.Type.MASTER_GAIN);
                float legacyGain = -40.0F * (1.0F - Math.clamp(volume, 0.0F, 1.0F));
                gain.setValue(Math.clamp(legacyGain, gain.getMinimum(), gain.getMaximum()));
            }
            clip.addLineListener(event -> {
                if (event.getType() == LineEvent.Type.STOP) {
                    event.getLine().close();
                }
            });
            clip.start();
        } catch (Exception exception) {
            CelestialPortClient.LOGGER.warn("Unable to play bundled sound {}", resourcePath, exception);
        }
    }
}
