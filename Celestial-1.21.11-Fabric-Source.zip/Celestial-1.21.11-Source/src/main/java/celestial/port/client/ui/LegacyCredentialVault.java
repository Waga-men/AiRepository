package celestial.port.client.ui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.sun.jna.Platform;
import com.sun.jna.platform.win32.Crypt32Util;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

final class LegacyCredentialVault {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final int MAX_FILE_BYTES = 4 * 1024 * 1024;
    private static final int MAX_STATE_BYTES = 1024 * 1024;
    private static final LegacyCredentialVault INSTANCE = new LegacyCredentialVault();

    private final Path file = FabricLoader.getInstance().getConfigDir()
            .resolve("celestial").resolve("alt-auth.dat").toAbsolutePath().normalize();

    private LegacyCredentialVault() {
    }

    static LegacyCredentialVault instance() {
        return INSTANCE;
    }

    synchronized boolean put(UUID accountId, String state) {
        if (!windowsDpapiAvailable()) return false;
        byte[] clear = state.getBytes(StandardCharsets.UTF_8);
        try {
            if (clear.length == 0 || clear.length > MAX_STATE_BYTES) return false;
            byte[] protectedBytes = Crypt32Util.cryptProtectData(clear);
            Map<String, String> values = readProtectedValues();
            values.put(accountId.toString(), Base64.getEncoder().encodeToString(protectedBytes));
            writeProtectedValues(values);
            return true;
        } catch (RuntimeException | LinkageError | IOException ignored) {
            return false;
        } finally {
            java.util.Arrays.fill(clear, (byte) 0);
        }
    }

    synchronized Optional<String> get(UUID accountId) {
        if (!windowsDpapiAvailable()) return Optional.empty();
        byte[] clear = null;
        try {
            String encoded = readProtectedValues().get(accountId.toString());
            if (encoded == null || encoded.isBlank()) return Optional.empty();
            byte[] protectedBytes = Base64.getDecoder().decode(encoded);
            clear = Crypt32Util.cryptUnprotectData(protectedBytes);
            if (clear.length == 0 || clear.length > MAX_STATE_BYTES) return Optional.empty();
            return Optional.of(new String(clear, StandardCharsets.UTF_8));
        } catch (RuntimeException | LinkageError | IOException ignored) {
            return Optional.empty();
        } finally {
            if (clear != null) java.util.Arrays.fill(clear, (byte) 0);
        }
    }

    synchronized void remove(UUID accountId) {
        if (!windowsDpapiAvailable()) return;
        try {
            Map<String, String> values = readProtectedValues();
            if (values.remove(accountId.toString()) != null) writeProtectedValues(values);
        } catch (RuntimeException | LinkageError | IOException ignored) {

        }
    }

    private static boolean windowsDpapiAvailable() {
        try {
            return Platform.isWindows();
        } catch (RuntimeException | LinkageError ignored) {
            return false;
        }
    }

    private Map<String, String> readProtectedValues() throws IOException {
        Map<String, String> result = new LinkedHashMap<>();
        if (!Files.isRegularFile(file)) return result;
        long size = Files.size(file);
        if (size <= 0 || size > MAX_FILE_BYTES) throw new IOException("Invalid vault size");
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (!parsed.isJsonObject()) throw new IOException("Invalid vault root");
            JsonElement rawCredentials = parsed.getAsJsonObject().get("credentials");
            if (rawCredentials == null || !rawCredentials.isJsonObject()) return result;
            for (Map.Entry<String, JsonElement> entry
                    : rawCredentials.getAsJsonObject().entrySet()) {
                try {
                    UUID.fromString(entry.getKey());
                    if (entry.getValue().isJsonPrimitive()) {
                        result.put(entry.getKey(), entry.getValue().getAsString());
                    }
                } catch (RuntimeException ignored) {

                }
            }
        }
        return result;
    }

    private void writeProtectedValues(Map<String, String> values) throws IOException {
        JsonObject root = new JsonObject();
        root.addProperty("schemaVersion", 1);
        JsonObject credentials = new JsonObject();
        values.forEach(credentials::addProperty);
        root.add("credentials", credentials);

        Files.createDirectories(file.getParent());
        Path temporary = Files.createTempFile(file.getParent(), "alt-auth.", ".tmp");
        try {
            try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                GSON.toJson(root, writer);
            }
            try {
                Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING,
                        StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException ignored) {
                Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(temporary);
        }
    }
}
