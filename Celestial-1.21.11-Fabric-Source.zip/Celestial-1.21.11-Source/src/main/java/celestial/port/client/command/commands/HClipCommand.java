package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;

public final class HClipCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "hclip";
    }

    @Override
    public String description() {
        return "\u041A\u043B\u0438\u043F\u0430\u0435\u0442 \u0432\u0430\u0441 \u043D\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u0443\u044E \u0432\u0430\u043C\u0438 "
                + "\u043F\u043E\u0437\u0438\u0446\u0438\u044E \u043F\u043E \u0433\u043E\u0440\u0438\u0437\u043E\u043D\u0442\u0430\u043B\u0438";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length == 0) {
            usage();
            return;
        }
        try {
            ClientPlayerEntity player = MinecraftClient.getInstance().player;
            float yaw = player.getYaw() * ((float) Math.PI / 180.0F);
            double distance = arguments[0].equalsIgnoreCase("s")
                    ? 0.8D : Double.parseDouble(arguments[0]);
            double x = player.getX() - Math.sin(yaw) * distance;
            double y = player.getY();
            double z = player.getZ() + Math.cos(yaw) * distance;
            for (int index = 0; index < 5; index++) {
                player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                        x, y, z, false, false));
            }
            player.setPosition(x, y, z);
            for (int index = 0; index < 5; index++) {
                player.networkHandler.sendPacket(new PlayerMoveC2SPacket.PositionAndOnGround(
                        x, y, z, false, false));
            }
        } catch (Exception exception) {
            LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0430\u0440\u0433\u0443\u043C\u0435\u043D\u0442 \u0447\u0438\u0441\u043B\u0430!");
        }
    }

    private static void usage() {
        LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430! "
                + "\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435:");
        LegacyCommandFeedback.send("hclip \u00A7c\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u00A77(\u043A\u043B\u0438\u043F\u0430\u0435\u0442 \u0432\u0430\u0441 \u0432\u043F\u0435\u0440\u0435\u0434 "
                + "\u043D\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435)");
        LegacyCommandFeedback.send("hclip \u00A7c-\u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435 \u00A77(\u043A\u043B\u0438\u043F\u0430\u0435\u0442 \u0432\u0430\u0441 \u043D\u0430\u0437\u0430\u0434 "
                + "\u043D\u0430 \u0432\u044B\u0431\u0440\u0430\u043D\u043D\u043E\u0435 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435)");
        LegacyCommandFeedback.send("hclip \u00A7cs \u00A77(hclip \u0434\u043B\u044F \u0434\u0432\u0435\u0440\u0435\u0439 \u0438 \u0442.\u0434 \u043F\u043E\u0434 Sunrise)");
    }
}
