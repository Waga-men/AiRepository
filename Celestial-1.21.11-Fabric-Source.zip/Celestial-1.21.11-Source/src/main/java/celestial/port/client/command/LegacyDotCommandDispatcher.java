package celestial.port.client.command;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class LegacyDotCommandDispatcher {
    private static final Map<String, Command> COMMANDS = new HashMap<>();
    private static final List<Initializer> INITIALIZERS = new ArrayList<>();
    private static boolean initialized;

    private LegacyDotCommandDispatcher() {
    }

    public static synchronized void register(Command command) {
        Command checked = Objects.requireNonNull(command, "command");
        COMMANDS.put(Objects.requireNonNull(checked.name(), "command.name"), checked);
    }

    public static synchronized List<Command> commands() {
        return List.copyOf(COMMANDS.values());
    }

    public static synchronized void registerInitializer(Initializer initializer) throws Exception {
        Initializer checked = Objects.requireNonNull(initializer, "initializer");
        if (initialized) {
            checked.initialize();
        } else {
            INITIALIZERS.add(checked);
        }
    }

    public static boolean dispatch(String message) {
        try {
            initializeIfNeeded();
            if (message.startsWith(".") && message.length() > 1) {
                String commandLine = message.substring(1);
                String[] split = commandLine.split(" ");
                String[] arguments = Arrays.copyOfRange(split, 1, split.length);
                boolean matched = false;
                for (Command command : COMMANDS.values()) {
                    if (!command.name().equalsIgnoreCase(split[0])) {
                        continue;
                    }
                    command.execute(arguments);
                    matched = true;
                }
                if (!matched) {
                    reportUnknown(commandLine.toLowerCase());
                }
                return true;
            }
        } catch (Exception exception) {
            exception.printStackTrace();
        }
        return false;
    }

    private static synchronized void initializeIfNeeded() throws Exception {
        if (initialized) {
            return;
        }
        for (Initializer initializer : INITIALIZERS) {
            initializer.initialize();
        }
        initialized = true;
    }

    private static void reportUnknown(String commandLine) {
        LegacyCommandFeedback.send("\u041A\u043E\u043C\u0430\u043D\u0434\u0430 \u00A7c\""
                + commandLine.toLowerCase()
                + "\"\u00A7r \u043D\u0435 \u043D\u0430\u0439\u0434\u0435\u043D\u0430!");
        LegacyCommandFeedback.send("\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 "
                + "\u043D\u0430\u043F\u0438\u0448\u0438\u0442\u0435 \u00A7c.help\u00A7r "
                + "\u0434\u043B\u044F \u043F\u043E\u043B\u0443\u0447\u0435\u043D\u0438\u044F "
                + "\u0441\u043F\u0438\u0441\u043A\u0430 \u0432\u0441\u0435\u0445 "
                + "\u043A\u043E\u043C\u0430\u043D\u0434!");
    }

    @FunctionalInterface
    public interface Initializer {
        void initialize() throws Exception;
    }

    public interface Command {
        String name();

        String description();

        void execute(String[] arguments) throws Exception;
    }
}
