package celestial.port.client.ui;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.PlayerSkinTextureDownloader;
import net.minecraft.util.Identifier;

import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

final class LegacyAltHeadCache {
    private static final String HOST = "minotar.net";
    private static final Map<String, Entry> ENTRIES = new ConcurrentHashMap<>();

    private LegacyAltHeadCache() {
    }

    static Identifier request(MinecraftClient client, String username) {
        if (username == null || username.isBlank()) return null;
        String shownName = username.strip();
        String key = shownName.toLowerCase(Locale.ROOT);
        Entry entry = ENTRIES.computeIfAbsent(key,
                ignored -> beginDownload(client, shownName));
        return entry.ready() ? entry.texture() : null;
    }

    private static Entry beginDownload(MinecraftClient client, String username) {
        String cacheId = UUID.nameUUIDFromBytes(
                ("CelestialMinotarBust:" + username.toLowerCase(Locale.ROOT))
                        .getBytes(StandardCharsets.UTF_8))
                .toString().replace("-", "");
        Identifier texture = Identifier.of(
                "celestial", "alt_heads/" + cacheId);
        Path cacheFile = client.runDirectory.toPath()
                .resolve("celestial-cache")
                .resolve("alt-heads")
                .resolve(cacheId + ".png");

        CompletableFuture<?> download;
        try {
            PlayerSkinTextureDownloader downloader =
                    new PlayerSkinTextureDownloader(
                            client.getNetworkProxy(), client.getTextureManager(), client);
            download = downloader.downloadAndRegisterTexture(
                    texture, cacheFile, minotarUrl(username), false);
        } catch (RuntimeException | LinkageError exception) {
            download = CompletableFuture.failedFuture(exception);
        }
        return new Entry(texture, download);
    }

    private static String minotarUrl(String username) {
        String segment = URLEncoder.encode(username, StandardCharsets.UTF_8)
                .replace("+", "%20");
        URI uri = URI.create("https://" + HOST + "/bust/" + segment);
        if (!"https".equalsIgnoreCase(uri.getScheme())
                || !HOST.equalsIgnoreCase(uri.getHost())) {
            throw new IllegalArgumentException("Unexpected Alt head host");
        }
        return uri.toASCIIString();
    }

    private record Entry(Identifier texture, CompletableFuture<?> download) {
        private boolean ready() {
            return download.isDone()
                    && !download.isCancelled()
                    && !download.isCompletedExceptionally();
        }
    }
}
