package celestial.port.client.ui;

import celestial.port.modules.inventory.AutoTotem;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

public final class AutoTotemCounterHud {
    private static final Identifier ELEMENT = Identifier.of("celestial", "auto_totem_counter");
    private static final StyleSpriteSource FONT = new StyleSpriteSource.Font(
            Identifier.of("celestial", "montserrat_12"));
    private static final ItemStack TOTEM = new ItemStack(Items.TOTEM_OF_UNDYING);
    private static boolean registered;

    private AutoTotemCounterHud() {
    }

    public static void register(AutoTotem module) {
        if (registered) {
            return;
        }
        registered = true;
        HudElementRegistry.attachElementAfter(
                VanillaHudElements.CROSSHAIR, ELEMENT,
                (context, tickCounter) -> render(context, module));
    }

    private static void render(DrawContext context, AutoTotem module) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null || !module.enabled() || !module.counterEnabled()) {
            return;
        }
        int count = module.totemCount();
        if (count <= 0) {
            return;
        }

        float guiScale = (float) client.getWindow().getScaleFactor();
        int centerX = (int) (context.getScaledWindowWidth() * guiScale / 4.0F);
        int centerY = (int) (context.getScaledWindowHeight() * guiScale / 4.0F);
        float fixedScale = 2.0F / guiScale;

        TextRenderer renderer = client.textRenderer;
        Text label = Text.literal(Integer.toString(count)).styled(style -> style.withFont(FONT));
        float textX = centerX - renderer.getWidth(label) / 2.0F;

        context.getMatrices().pushMatrix();
        context.getMatrices().scale(fixedScale, fixedScale);
        context.drawItem(TOTEM, centerX - 8, centerY + 12);
        drawShadowedText(context, renderer, label, textX, centerY + 32, 0xFFEBEBEB);
        context.getMatrices().popMatrix();
    }

    private static void drawShadowedText(
            DrawContext context, TextRenderer renderer, Text text, float x, float y, int color
    ) {
        int shadow = (color & 0x00FCFCFC) >> 2 | color & 0xC8141414;
        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x + 0.5F, y + 0.5F);
        context.drawText(renderer, text, 0, 0, shadow, false);
        context.getMatrices().popMatrix();

        context.getMatrices().pushMatrix();
        context.getMatrices().translate(x, y);
        context.drawText(renderer, text, 0, 0, color, false);
        context.getMatrices().popMatrix();
    }
}
