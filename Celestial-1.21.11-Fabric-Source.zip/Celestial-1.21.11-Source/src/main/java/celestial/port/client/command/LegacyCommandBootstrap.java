package celestial.port.client.command;

import celestial.port.client.command.commands.AutoBuyCommand;
import celestial.port.client.command.commands.BindCommand;
import celestial.port.client.command.commands.ConfigCommand;
import celestial.port.client.command.commands.FriendCommand;
import celestial.port.client.command.commands.HClipCommand;
import celestial.port.client.command.commands.HelpCommand;
import celestial.port.client.command.commands.MacroCommand;
import celestial.port.client.command.commands.ParseCommand;
import celestial.port.client.command.commands.PvpBlacklistCommand;
import celestial.port.client.command.commands.RctCommand;
import celestial.port.client.command.commands.SetCommand;
import celestial.port.client.command.commands.StaffCommand;
import celestial.port.client.command.commands.TeleportCommand;
import celestial.port.client.command.commands.VClipCommand;
import celestial.port.client.command.commands.WayCommand;

public final class LegacyCommandBootstrap {
    private static boolean installed;
    private static boolean initialized;

    private LegacyCommandBootstrap() {
    }

    public static synchronized void install() {
        if (installed) {
            return;
        }
        try {

            LegacyTeleportCoordinator.install();
            LegacyDotCommandDispatcher.registerInitializer(
                    LegacyCommandBootstrap::initialize);
            installed = true;
        } catch (Exception exception) {
            throw new IllegalStateException("Unable to install legacy command catalog", exception);
        }
    }

    private static synchronized void initialize() {
        if (initialized) {
            return;
        }

        LegacyDotCommandDispatcher.register(new WayCommand());
        LegacyDotCommandDispatcher.register(new HelpCommand());
        LegacyDotCommandDispatcher.register(new SetCommand());
        LegacyDotCommandDispatcher.register(new BindCommand());
        LegacyDotCommandDispatcher.register(new ConfigCommand());
        LegacyDotCommandDispatcher.register(new MacroCommand());
        LegacyDotCommandDispatcher.register(new FriendCommand());
        LegacyDotCommandDispatcher.register(new VClipCommand());
        LegacyDotCommandDispatcher.register(new HClipCommand());
        LegacyDotCommandDispatcher.register(new StaffCommand());
        LegacyDotCommandDispatcher.register(new TeleportCommand());
        LegacyDotCommandDispatcher.register(new AutoBuyCommand());
        LegacyDotCommandDispatcher.register(new ParseCommand());
        LegacyDotCommandDispatcher.register(new RctCommand());
        LegacyDotCommandDispatcher.register(new PvpBlacklistCommand());
        initialized = true;
    }
}
