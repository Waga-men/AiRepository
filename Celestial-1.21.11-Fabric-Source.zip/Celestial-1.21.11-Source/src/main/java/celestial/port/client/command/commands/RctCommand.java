package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.client.command.LegacyTeleportCoordinator;
import celestial.port.core.PvpContext;
import celestial.port.mixin.accessor.PlayerListHudAccessor;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

public final class RctCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "rct";
    }

    @Override
    public String description() {
        return "\u0410\u0432\u0442\u043E\u043C\u0430\u0442\u0438\u0447\u0435\u0441\u043A\u0438 \u043F\u0435\u0440\u0435\u0437\u0430\u0445\u043E\u0434\u0438\u0442 \u043D\u0430 \u0441\u0435\u0440\u0432\u0435\u0440";
    }

    @Override
    public void execute(String[] arguments) {
        try {
            if (PvpContext.active()) {
                LegacyCommandFeedback.send(
                        "\u0412\u044B \u043D\u0430\u0445\u043E\u0434\u0438\u0442\u0435\u0441\u044C \u0432 PVP \u0440\u0435\u0436\u0438\u043C\u0435!");
                LegacyTeleportCoordinator.resetRetryState();
                return;
            }
            MinecraftClient client = MinecraftClient.getInstance();
            boolean reallyWorld = LegacyTeleportCoordinator.isReallyWorld(client);
            boolean sunrise = LegacyTeleportCoordinator.isSunrise(client);
            String requested = arguments.length > 0 ? normalize(arguments) : "";
            if (reallyWorld) {
                reconnectReallyWorld(requested);
            } else if (sunrise) {
                reconnectSunrise(requested);
            } else {
                LegacyCommandFeedback.send(
                        "\u042D\u0442\u0430 \u043A\u043E\u043C\u0430\u043D\u0434\u0430 \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \u0442\u043E\u043B\u044C\u043A\u043E \u043D\u0430 ReallyWorld \u0438\u043B\u0438 Sunrise!");
            }
        } catch (Exception exception) {
            LegacyCommandFeedback.send(
                    "\u041E\u0448\u0438\u0431\u043A\u0430! \u041D\u0435 \u043F\u043E\u0434\u043A\u043B\u044E\u0447\u0430\u0439\u0442\u0435\u0441\u044C \u0442\u0430\u043A \u0447\u0430\u0441\u0442\u043E, "
                            + "\u043B\u0438\u0431\u043E \u0443\u043A\u0430\u0436\u0438\u0442\u0435 \u0441\u0435\u0440\u0432\u0435\u0440 \u0432 .rct");
            exception.printStackTrace();
        }
    }

    private static void reconnectSunrise(String requested) {
        boolean defaultServer = requested.isEmpty() || requested.isBlank();
        if (!defaultServer && !requested.matches("[a-zA-Z\u0430-\u044F\u0410-\u042F]+")) {
            LegacyCommandFeedback.send("\u0412\u0432\u0435\u0434\u0438\u0442\u0435 \u0442\u043E\u043B\u044C\u043A\u043E \u0431\u0443\u043A\u0432\u044B!");
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        Text header = ((PlayerListHudAccessor) client.inGameHud.getPlayerListHud())
                .celestial$getHeader();
        String plainHeader = header.getString();
        String currentServer = plainHeader.substring(
                plainHeader.indexOf("\u0421\u0435\u0440\u0432\u0435\u0440: ") + 8,
                plainHeader.indexOf("\u041E\u043D\u043B\u0430\u0439\u043D: ") - 1
        );
        sendHub();
        LegacyTeleportCoordinator.setHubSelector(defaultServer ? currentServer : requested);
    }

    private static void reconnectReallyWorld(String requested) {
        String currentServer = LegacyTeleportCoordinator.currentReallyWorldGrief();
        boolean defaultServer = requested.isEmpty() || requested.isBlank();
        if (currentServer.isEmpty() && defaultServer) {
            LegacyCommandFeedback.send(
                    "\u041F\u043E\u0434\u043E\u0436\u0434\u0438\u0442\u0435 \u0435\u0449\u0435 \u0447\u0443\u0442\u044C-\u0447\u0443\u0442\u044C!");
            return;
        }
        sendHub();
        LegacyTeleportCoordinator.setHubSelector(defaultServer ? currentServer : requested);
    }

    private static String normalize(String[] arguments) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (LegacyTeleportCoordinator.isSunrise(client)) {
            return arguments[0];
        }
        if (LegacyTeleportCoordinator.isReallyWorld(client)
                && arguments[0].equalsIgnoreCase("mega")) {
            return arguments[0];
        }
        return arguments[0].replaceAll("\\D", "");
    }

    private static void sendHub() {
        MinecraftClient.getInstance().getNetworkHandler().sendChatCommand("hub");
    }
}
