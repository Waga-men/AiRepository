package celestial.port.client.command.commands;

import celestial.port.CelestialPortClient;
import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.client.ui.ConfigProfiles;
import net.fabricmc.loader.api.FabricLoader;

import java.util.List;
import java.util.stream.Collectors;

public final class ConfigCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "cfg";
    }

    @Override
    public String description() {
        return "\u0423\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u0442 \u043A\u043E\u043D\u0444\u0438\u0433\u0430\u043C\u0438 \u0432 \u043A\u043B\u0438\u0435\u043D\u0442\u0435";
    }

    @Override
    public void execute(String[] arguments) throws Exception {
        if (arguments.length == 0) {
            usage();
            return;
        }

        ConfigProfiles profiles = profiles();

        List<String> names = profiles.names();
        String action = arguments[0];
        if (action.equalsIgnoreCase("save")) {
            if (arguments.length > 1) {
                profiles.save(arguments[1]);
                LegacyCommandFeedback.send("\u041A\u043E\u043D\u0444\u0438\u0433 \u00A7c'" + arguments[1]
                        + "'\u00A7f \u0431\u044B\u043B \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D!");
            } else {
                LegacyCommandFeedback.send("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0441\u043E\u0445\u0440\u0430\u043D\u0435\u043D\u0438\u0438 \u043A\u043E\u043D\u0444\u0438\u0433\u0430!");
            }
        } else if (action.equalsIgnoreCase("load")) {
            if (arguments.length > 1 && load(profiles, arguments[1])) {
                LegacyCommandFeedback.send("\u041A\u043E\u043D\u0444\u0438\u0433 \u00A7c'" + arguments[1]
                        + "'\u00A7f \u0431\u044B\u043B \u0437\u0430\u0433\u0440\u0443\u0436\u0435\u043D!");
            } else {
                LegacyCommandFeedback.send("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0437\u0430\u0433\u0440\u0443\u0437\u043A\u0435 \u043A\u043E\u043D\u0444\u0438\u0433\u0430!");
            }
        } else if (action.equalsIgnoreCase("delete") || action.equalsIgnoreCase("remove")) {
            if (arguments.length > 1 && delete(profiles, arguments[1])) {
                LegacyCommandFeedback.send("\u041A\u043E\u043D\u0444\u0438\u0433 \u00A7c'" + arguments[1]
                        + "'\u00A7f \u0431\u044B\u043B \u0443\u0434\u0430\u043B\u0435\u043D!");
            } else {
                LegacyCommandFeedback.send("\u041E\u0448\u0438\u0431\u043A\u0430 \u043F\u0440\u0438 \u0443\u0434\u0430\u043B\u0435\u043D\u0438\u0438 \u043A\u043E\u043D\u0444\u0438\u0433\u0430!");
            }
        } else if (action.equalsIgnoreCase("list")) {
            List<String> visible = names.stream()
                    .filter(profile -> !profile.equals("autocfg"))
                    .toList();
            if (visible.isEmpty()) {
                LegacyCommandFeedback.send("\u0412\u0430\u0448 \u0441\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u043D\u0444\u0438\u0433\u043E\u0432 \u043F\u0443\u0441\u0442\u043E\u0439!");
                return;
            }
            LegacyCommandFeedback.send("\u0421\u043F\u0438\u0441\u043E\u043A \u043A\u043E\u043D\u0444\u0438\u0433\u043E\u0432:");
            LegacyCommandFeedback.send(visible.stream().collect(Collectors.joining(", ")));
        } else if (action.equalsIgnoreCase("dir")) {
            profiles.openDirectory();
        }
    }

    private static ConfigProfiles profiles() {
        return new ConfigProfiles(CelestialPortClient.MODULES,
                FabricLoader.getInstance().getConfigDir()
                        .resolve("celestial").resolve("profiles"));
    }

    private static boolean load(ConfigProfiles profiles, String name) {
        try {
            return profiles.load(name);
        } catch (Exception exception) {
            return false;
        }
    }

    private static boolean delete(ConfigProfiles profiles, String name) {
        try {
            return profiles.delete(name);
        } catch (Exception exception) {
            return false;
        }
    }

    private static void usage() {
        LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430! "
                + "\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435:");
        LegacyCommandFeedback.send("cfg \u00A7csave \u00A77<name> (\u0447\u0442\u043E\u0431\u044B \u0441\u043E\u0445\u0440\u0430\u043D\u0438\u0442\u044C \u043A\u043E\u043D\u0444\u0438\u0433)");
        LegacyCommandFeedback.send("cfg \u00A7cload \u00A77<name> (\u0447\u0442\u043E\u0431\u044B \u0437\u0430\u0433\u0440\u0443\u0437\u0438\u0442\u044C \u043A\u043E\u043D\u0444\u0438\u0433)");
        LegacyCommandFeedback.send("cfg \u00A7cdelete \u00A77<name> (\u0447\u0442\u043E\u0431\u044B \u0443\u0434\u0430\u043B\u0438\u0442\u044C \u043A\u043E\u043D\u0444\u0438\u0433)");
        LegacyCommandFeedback.send("cfg \u00A7clist \u00A77(\u043F\u043E\u043A\u0430\u0437\u044B\u0432\u0430\u0435\u0442 \u0441\u043F\u0438\u0441\u043E\u043A \u0432\u0441\u0435\u0445 \u043A\u043E\u043D\u0444\u0438\u0433\u043E\u0432)");
        LegacyCommandFeedback.send("cfg \u00A7cdir \u00A77(\u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u0442 \u0434\u0438\u0440\u0435\u043A\u0442\u043E\u0440\u0438\u044E \u0441 \u043A\u043E\u043D\u0444\u0438\u0433\u0430\u043C\u0438)");
    }
}
