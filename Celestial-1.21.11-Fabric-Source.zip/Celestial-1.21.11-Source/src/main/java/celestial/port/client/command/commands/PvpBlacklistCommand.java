package celestial.port.client.command.commands;

import celestial.port.client.command.LegacyCommandFeedback;
import celestial.port.client.command.LegacyDotCommandDispatcher;
import celestial.port.core.pvp.PvpBlacklistManager;
import net.minecraft.client.MinecraftClient;

public final class PvpBlacklistCommand implements LegacyDotCommandDispatcher.Command {
    @Override
    public String name() {
        return "pvpbl";
    }

    @Override
    public String description() {
        return "\u0421\u043A\u0438\u043F\u0430\u0435\u0442 \u043D\u0443\u0436\u043D\u044B\u0445 \u0438\u0433\u0440\u043E\u043A\u043E\u0432 \u0432 /pvp";
    }

    @Override
    public void execute(String[] arguments) {
        if (arguments.length == 0) {
            LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u0430\u044F \u043A\u043E\u043C\u0430\u043D\u0434\u0430! "
                    + "\u041F\u043E\u0436\u0430\u043B\u0443\u0439\u0441\u0442\u0430 \u0438\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435:");
            LegacyCommandFeedback.send("pvpbl \u00A7cadd \u00A77<name> \u00A77(\u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0438\u0433\u0440\u043E\u043A\u0430 \u0432 \u0431\u043B\u0435\u043A\u043B\u0438\u0441\u0442)");
            LegacyCommandFeedback.send("pvpbl \u00A7cremove \u00A77<name> \u00A77(\u0443\u0434\u0430\u043B\u0438\u0442\u044C \u0438\u0433\u0440\u043E\u043A\u0430 \u0438\u0437 \u0431\u043B\u0435\u043A\u043B\u0438\u0441\u0442\u0430)");
            LegacyCommandFeedback.send("pvpbl \u00A7cclear\u00A77 (\u043E\u0447\u0438\u0441\u0442\u0438\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u0432\u0441\u0435\u0445 \u0438\u0433\u0440\u043E\u043A\u043E\u0432)");
            LegacyCommandFeedback.send("pvpbl \u00A7clist\u00A77 (\u043F\u0440\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u0441\u043F\u0438\u0441\u043E\u043A \u0432\u0441\u0435\u0445 \u0438\u0433\u0440\u043E\u043A\u043E\u0432)");
            return;
        }
        try {
            switch (arguments[0].toLowerCase()) {
                case "add" -> add(arguments[1]);
                case "remove", "delete" -> remove(arguments[1]);
                case "clear" -> clear();
                case "list" -> list();
                default -> usage();
            }
        } catch (ArrayIndexOutOfBoundsException exception) {
            LegacyCommandFeedback.send("\u041D\u0435\u0432\u0435\u0440\u043D\u044B\u0439 \u0444\u043E\u0440\u043C\u0430\u0442 \u0430\u0440\u0433\u0443\u043C\u0435\u043D\u0442\u043E\u0432!");
        }
    }

    private static void add(String name) {
        String self = MinecraftClient.getInstance().getGameProfile().name();
        if (name.equalsIgnoreCase(self)) {
            LegacyCommandFeedback.send("\u0412\u044B \u043D\u0435 \u043C\u043E\u0436\u0435\u0442\u0435 \u0434\u043E\u0431\u0430\u0432\u0438\u0442\u044C \u0441\u0430\u043C\u043E\u0433\u043E \u0441\u0435\u0431\u044F!");
        } else if (PvpBlacklistManager.add(name)) {
            LegacyCommandFeedback.send("\u0418\u0433\u0440\u043E\u043A \u00A7c" + name + "\u00A7r \u0434\u043E\u0431\u0430\u0432\u043B\u0435\u043D \u0441 \u0441\u043F\u0438\u0441\u043E\u043A!");
        } else {
            LegacyCommandFeedback.send("\u042D\u0442\u043E\u0442 \u0438\u0433\u0440\u043E\u043A \u0443\u0436\u0435 \u0435\u0441\u0442\u044C \u0432 \u0441\u043F\u0438\u0441\u043A\u0435!");
        }
    }

    private static void remove(String name) {
        if (PvpBlacklistManager.removeIgnoreCase(name)) {
            LegacyCommandFeedback.send("\u0418\u0433\u0440\u043E\u043A \u00A7c" + name + "\u00A7r \u0431\u044B\u043B \u0443\u0434\u0430\u043B\u0435\u043D \u0438\u0437 \u0441\u043F\u0438\u0441\u043A\u0430!");
        } else {
            LegacyCommandFeedback.send("\u042D\u0442\u043E\u0433\u043E \u0438\u0433\u0440\u043E\u043A\u0430 \u043D\u0435\u0442 \u0432 \u0441\u043F\u0438\u0441\u043A\u0435!");
        }
    }

    private static void clear() {
        LegacyCommandFeedback.send(PvpBlacklistManager.clear()
                ? "\u0421\u043F\u0438\u0441\u043E\u043A \u0438\u0433\u0440\u043E\u043A\u043E\u0432 \u0431\u044B\u043B \u043E\u0447\u0438\u0449\u0435\u043D!"
                : "\u0421\u043F\u0438\u0441\u043E\u043A \u0438\u0433\u0440\u043E\u043A\u043E\u0432 \u043F\u0443\u0441\u0442\u043E\u0439!");
    }

    private static void list() {
        var names = PvpBlacklistManager.names();
        if (names.isEmpty()) {
            LegacyCommandFeedback.send("\u0421\u043F\u0438\u0441\u043E\u043A \u0438\u0433\u0440\u043E\u043A\u043E\u0432 \u043F\u0443\u0441\u0442\u043E\u0439!");
            return;
        }
        LegacyCommandFeedback.send("\u0421\u043F\u0438\u0441\u043E\u043A \u0438\u0433\u0440\u043E\u043A\u043E\u0432:");
        LegacyCommandFeedback.send(String.join(", ", names));
    }

    private static void usage() {
        LegacyCommandFeedback.send("\u0418\u0441\u043F\u043E\u043B\u044C\u0437\u0443\u0439\u0442\u0435 - add | remove | clear | list");
    }
}
