package celestial.port.client.ui;

import com.mojang.blaze3d.pipeline.BlendFunction;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import com.mojang.blaze3d.vertex.VertexFormatElement;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gl.UniformType;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.ScreenRect;
import net.minecraft.client.gui.render.state.SimpleGuiElementRenderState;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.texture.TextureSetup;
import net.minecraft.util.Identifier;
import org.joml.Matrix3x2f;

final class LegacyHudFloatGui {
    private static final int MODE_GRADIENT = 0;
    private static final int MODE_GLOW = 2;
    private static final float PARAMETER_SCALE = 16.0f;

    private static final VertexFormat VERTEX_FORMAT = VertexFormat.builder()
            .add("Position", VertexFormatElement.POSITION)
            .add("Color", VertexFormatElement.COLOR)
            .add("UV0", VertexFormatElement.UV0)
            .add("UV1", VertexFormatElement.UV1)
            .add("UV2", VertexFormatElement.UV2)
            .add("LineWidth", VertexFormatElement.LINE_WIDTH)
            .add("Normal", VertexFormatElement.NORMAL)
            .padding(1)
            .build();

    private static final RenderPipeline PIPELINE = RenderPipeline.builder()
            .withLocation(Identifier.of("celestial", "pipeline/legacy_hud_float_gui"))
            .withVertexShader(Identifier.of("celestial", "core/legacy_hud_float_gui"))
            .withFragmentShader(Identifier.of("celestial", "core/legacy_sdf_gui"))
            .withUniform("DynamicTransforms", UniformType.UNIFORM_BUFFER)
            .withUniform("Projection", UniformType.UNIFORM_BUFFER)
            .withBlend(BlendFunction.TRANSLUCENT)
            .withCull(false)
            .withDepthWrite(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .withVertexFormat(VERTEX_FORMAT, VertexFormat.DrawMode.QUADS)
            .build();

    private LegacyHudFloatGui() {
    }

    static void fillFourCorners(
            DrawContext context, float x, float y, float width, float height,
            float radius, int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        add(context, MODE_GRADIENT, x, y, width, height, radius, 0.5f,
                topLeft, topRight, bottomRight, bottomLeft);
    }

    static void fillGlowFourCorners(
            DrawContext context, float x, float y, float width, float height,
            float radius, float glowRadius,
            int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        add(context, MODE_GLOW, x, y, width, height, radius, glowRadius,
                topLeft, topRight, bottomRight, bottomLeft);
    }

    private static void add(
            DrawContext context, int mode,
            float x, float y, float width, float height, float radius, float extra,
            int topLeft, int topRight, int bottomRight, int bottomLeft
    ) {
        if (width <= 0.0f || height <= 0.0f) return;

        float effectiveRadius = Math.max(0.0f,
                Math.min(radius, Math.min(width, height) * 0.5f));
        float effectiveExtra = Math.max(0.0f, extra);
        float geometryPadding = mode == MODE_GLOW ? 1.0f + effectiveExtra : 1.0f;

        Matrix3x2f pose = new Matrix3x2f(context.getMatrices());
        ScreenRect scissor = context.scissorStack.peekLast();
        int left = (int) Math.floor(x - geometryPadding);
        int top = (int) Math.floor(y - geometryPadding);
        int right = (int) Math.ceil(x + width + geometryPadding);
        int bottom = (int) Math.ceil(y + height + geometryPadding);
        ScreenRect transformed = new ScreenRect(left, top, right - left, bottom - top)
                .transformEachVertex(pose);
        ScreenRect bounds = scissor == null ? transformed : scissor.intersection(transformed);

        int radiusUnits = fixedParameter(effectiveRadius);
        int extraUnits = fixedParameter(effectiveExtra);
        int guiScaleUnits = Math.max(1, Math.min(255,
                Math.round((float) MinecraftClient.getInstance().getWindow().getScaleFactor()
                        * PARAMETER_SCALE)));
        int packedModeAndScale = mode | guiScaleUnits << 2;

        context.state.addSimpleElement(new FloatSdfState(
                pose, x, y, width, height, geometryPadding,
                radiusUnits, extraUnits, packedModeAndScale,
                topLeft, topRight, bottomRight, bottomLeft,
                scissor, bounds));
    }

    private static int fixedParameter(float value) {
        return Math.max(0, Math.min(255, Math.round(value * PARAMETER_SCALE)));
    }

    private record FloatSdfState(
            Matrix3x2f pose,
            float x,
            float y,
            float width,
            float height,
            float geometryPadding,
            int radiusUnits,
            int extraUnits,
            int packedModeAndScale,
            int topLeft,
            int topRight,
            int bottomRight,
            int bottomLeft,
            ScreenRect scissorArea,
            ScreenRect bounds
    ) implements SimpleGuiElementRenderState {
        @Override
        public void setupVertices(VertexConsumer vertices) {
            float left = x - geometryPadding;
            float top = y - geometryPadding;
            float right = x + width + geometryPadding;
            float bottom = y + height + geometryPadding;
            vertex(vertices, left, top);
            vertex(vertices, left, bottom);
            vertex(vertices, right, bottom);
            vertex(vertices, right, top);
        }

        private void vertex(VertexConsumer vertices, float pointX, float pointY) {
            float transformedX = pose.m00() * pointX + pose.m10() * pointY + pose.m20();
            float transformedY = pose.m01() * pointX + pose.m11() * pointY + pose.m21();
            int packedBottomLeft = bottomLeft & 0x00FFFFFF | radiusUnits << 24;
            int packedTopRight = topRight & 0x00FFFFFF | extraUnits << 24;
            vertices.vertex(transformedX, transformedY, bottomRight & 0x00FFFFFF)
                    .color(topLeft)

                    .texture(width, height)
                    .overlay(packedBottomLeft & 0xFFFF, packedBottomLeft >>> 16)
                    .light(packedTopRight & 0xFFFF, packedTopRight >>> 16)
                    .lineWidth(packedModeAndScale)
                    .normal(0.0f, 0.0f, 0.0f);
        }

        @Override
        public RenderPipeline pipeline() {
            return PIPELINE;
        }

        @Override
        public TextureSetup textureSetup() {
            return TextureSetup.empty();
        }
    }
}
