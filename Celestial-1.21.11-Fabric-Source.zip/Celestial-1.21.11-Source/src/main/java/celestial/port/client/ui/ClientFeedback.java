package celestial.port.client.ui;

import celestial.port.CelestialPortClient;
import celestial.port.core.Module;
import celestial.port.core.ModuleFeedback;
import celestial.port.modules.render.NotificationsModule;
import celestial.port.modules.visual.VisualColors;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Style;
import net.minecraft.text.StyleSpriteSource;
import net.minecraft.text.Text;
import net.minecraft.text.TextColor;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Optional;

public final class ClientFeedback {
    private static final Deque<Entry> ENTRIES = new ArrayDeque<>();
    private static final StyleSpriteSource TITLE_FONT = LegacyHudFont.font(18);
    private static final StyleSpriteSource BODY_FONT = LegacyHudFont.font(14);
    private static final Identifier SUCCESS = Identifier.of("celestial", "images/notification/success.png");
    private static final Identifier ERROR = Identifier.of("celestial", "images/notification/error.png");
    private static final Identifier INFO = Identifier.of("celestial", "images/notification/info.png");
    private static final Identifier SHIELD = Identifier.of("celestial", "images/notification/shield.png");
    private static boolean initialized;

    private ClientFeedback() {
    }

    public static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        ModuleFeedback.listen(ClientFeedback::onModuleStateChanged);
    }

    private static void onModuleStateChanged(Module module, boolean enabled) {
        if (module.id().equals("click_gui") || module.id().equals("baritone")) return;
        Module candidate = CelestialPortClient.MODULES.find("notifications").orElse(null);
        if (candidate instanceof NotificationsModule notifications
                && notifications.enabled() && notifications.moduleToggleNotifications()) {
            push("Module Debug", module.displayName() + (enabled ? " включен" : " выключен"),
                    enabled ? SUCCESS : ERROR, 3);
        }
    }

    public static void shieldBreak(String description) {
        Module candidate = CelestialPortClient.MODULES.find("notifications").orElse(null);
        if (candidate instanceof NotificationsModule notifications
                && notifications.enabled() && notifications.shieldBreakNotifications()) {
            push("Shield Debug", description, SHIELD, 5);
        }
    }

    public static void staffLeave(String description) {
        Module candidate = CelestialPortClient.MODULES.find("notifications").orElse(null);
        if (candidate instanceof NotificationsModule notifications
                && notifications.enabled() && notifications.staffLeaveNotifications()) {
            push("Staff Alert Debug", description, INFO, 15);
        }
    }

    public static synchronized void info(String title, String description, int lifetimeSeconds) {
        push(title, description, INFO, lifetimeSeconds);
    }

    public static synchronized void info(String title, Text description, int lifetimeSeconds) {
        push(title, description, INFO, lifetimeSeconds);
    }

    public static synchronized void flagDetector(String legacyModuleName, boolean inWater) {
        String suffix = inWater ? " зафлагался в воде!" : " зафлагался!";
        push("Flag Detector Debug", "Модуль " + legacyModuleName + suffix, ERROR, 5);
    }

    private static synchronized void push(
            String title, String description, Identifier icon, int lifetimeSeconds
    ) {
        push(title, Text.literal(description), icon, lifetimeSeconds);
    }

    private static synchronized void push(
            String title, Text description, Identifier icon, int lifetimeSeconds
    ) {

        ENTRIES.addLast(new Entry(Text.literal(title), description.copy(), icon, System.nanoTime(),
                Math.max(0, lifetimeSeconds) * 1_000_000_000L));
    }

    public static synchronized void render(
            DrawContext context, int frameMillis, float chatOffset
    ) {
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player == null) {
            return;
        }
        long now = System.nanoTime();

        ENTRIES.removeIf(entry -> now - entry.createdNanos > entry.expirationNanos());
        TextRenderer renderer = client.textRenderer;
        int stack = 0;
        for (Entry entry : ENTRIES) {
            long age = now - entry.createdNanos;
            float layoutAlpha = entry.advanceAlpha(age, frameMillis);
            entry.layoutHeight = clamp(entry.layoutHeight
                    + (layoutAlpha >= 185.0f ? 0.12f : -0.20f) * frameMillis,
                    0.0f, 35.0f);
            if (entry.advanceAlpha(age, frameMillis) < 60.0f) {
                continue;
            }

            LegacyText title = legacyText(entry.title, 0xEBEBEB);
            LegacyText body = legacyText(entry.description, 0xC8C8C8);
            int cardWidth = Math.max(
                    LegacyHudFont.width(renderer, title.measurement, TITLE_FONT),
                    LegacyHudFont.width(renderer, body.measurement, BODY_FONT)) + 50;
            float x = context.getScaledWindowWidth() - cardWidth;
            float y = context.getScaledWindowHeight() - chatOffset - 48.0f - stack;
            float backgroundWidth = cardWidth - 10.0f;

            int backgroundAlpha = (int) entry.advanceAlpha(age, frameMillis);
            int color0 = withAlpha(VisualColors.clientColor(0.0f), backgroundAlpha);
            int color180 = withAlpha(VisualColors.clientColor(180.0f), backgroundAlpha);
            int color270 = withAlpha(VisualColors.clientColor(270.0f), backgroundAlpha);
            int color90 = withAlpha(VisualColors.clientColor(90.0f), backgroundAlpha);
            LegacyHudFloatGui.fillGlowFourCorners(context,
                    x - 1.0f, y - 1.0f, backgroundWidth + 2.0f, 32.0f,
                    3.0f, 8.0f, color0, color180, color270, color90);

            int innerAlpha = Math.min((int) (backgroundAlpha * 1.4f), 255);
            int innerColor = withAlpha(0xFF0A0A0A, innerAlpha);
            LegacyHudFloatGui.fillGlowFourCorners(context,
                    x, y + 1.0f, backgroundWidth, 28.0f,
                    3.0f, 5.0f, innerColor, innerColor, innerColor, innerColor);

            int titleAlpha = (int) entry.advanceAlpha(age, frameMillis);
            drawLegacyText(context, renderer, title, x + 25.0f, y + 8.0f,
                    titleAlpha, TITLE_FONT);
            int bodyAlpha = (int) entry.advanceAlpha(age, frameMillis);
            drawLegacyText(context, renderer, body, x + 25.0f, y + 18.0f,
                    bodyAlpha, BODY_FONT);

            int iconAlpha = (int) entry.advanceAlpha(age, frameMillis);
            context.getMatrices().pushMatrix();
            context.getMatrices().translate(x + 5.0f, y + 7.0f);
            context.drawTexture(RenderPipelines.GUI_TEXTURED, entry.icon,
                    0, 0, 0.0f, 0.0f, 16, 16, 16, 16,
                    withAlpha(0xFFFFFFFF, iconAlpha));
            context.getMatrices().popMatrix();

            stack = (int) (stack + entry.layoutHeight);
        }
    }

    private static LegacyText legacyText(Text text, int baseColor) {
        StringBuilder measurement = new StringBuilder();
        List<StyledRun> runs = new ArrayList<>();
        text.visit((style, value) -> {
            TextColor textColor = style.getColor();
            measurement.append(legacyColorPrefix(textColor)).append(value);
            runs.add(new StyledRun(value,
                    textColor == null ? baseColor : textColor.getRgb()));
            return Optional.empty();
        }, Style.EMPTY);
        return new LegacyText(measurement.toString(), List.copyOf(runs));
    }

    private static String legacyColorPrefix(TextColor color) {
        if (color != null) {
            int rgb = color.getRgb();
            for (Formatting formatting : Formatting.values()) {
                Integer value = formatting.getColorValue();
                if (formatting.isColor() && value != null && value == rgb) {
                    return "\u00a7" + formatting.getCode();
                }
            }
        }
        return "\u00a7r";
    }

    private static void drawLegacyText(
            DrawContext context, TextRenderer renderer, LegacyText text,
            float x, float y, int alpha, StyleSpriteSource font
    ) {
        float cursor = x;
        for (StyledRun run : text.runs) {
            LegacyHudFont.draw(context, renderer, run.value, cursor, y,
                    withAlpha(run.color, alpha), font, false, false);
            cursor += LegacyHudFont.widthFloat(renderer, run.value, font);
        }
    }

    private static int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0xFFFFFF);
    }

    private static double clamp(double value, double minimum, double maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private static float clamp(float value, float minimum, float maximum) {
        return Math.max(minimum, Math.min(maximum, value));
    }

    private record LegacyText(String measurement, List<StyledRun> runs) {
    }

    private record StyledRun(String value, int color) {
    }

    private static final class Entry {
        private final Text title;
        private final Text description;
        private final Identifier icon;
        private final long createdNanos;
        private final long lifetimeNanos;
        private double phase;
        private float layoutHeight;

        private Entry(
                Text title, Text description, Identifier icon,
                long createdNanos, long lifetimeNanos
        ) {
            this.title = title;
            this.description = description;
            this.icon = icon;
            this.createdNanos = createdNanos;
            this.lifetimeNanos = lifetimeNanos;
        }

        private float advanceAlpha(long ageNanos, int frameMillis) {
            boolean appearing = ageNanos < lifetimeNanos / 2L - 700_000_000L;
            phase = clamp(phase + (appearing ? 1.0 : -1.0)
                    * 0.0003 * frameMillis, 0.0, 1.0);
            return (float) clamp(255.0 * Math.sqrt(
                    1.0 - Math.pow(phase - 1.0, 2.0)), 0.0, 255.0);
        }

        private long expirationNanos() {
            return lifetimeNanos - lifetimeNanos / 4L;
        }
    }
}
