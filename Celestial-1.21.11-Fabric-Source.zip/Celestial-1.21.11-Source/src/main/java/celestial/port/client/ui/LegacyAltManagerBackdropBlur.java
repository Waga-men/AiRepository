package celestial.port.client.ui;

import celestial.port.modules.visual.BlurVisuals;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;

final class LegacyAltManagerBackdropBlur {
    private static PendingPlan pendingPlan;

    private LegacyAltManagerBackdropBlur() {
    }

    static void apply(
            DrawContext context, int screenWidth, int screenHeight,
            List<Region> toolbarRegions,
            int accountCount, int scrollOffset,
            int panelX, int panelY, int panelHeight
    ) {
        List<Pass> passes = new ArrayList<>(toolbarRegions.size() + accountCount + 2);
        passes.add(new Pass(new Region(0, 0, screenWidth, 40, 0.0f), 5));
        for (Region toolbarRegion : toolbarRegions) {
            passes.add(new Pass(toolbarRegion, 10));
        }
        for (int index = 0; index < accountCount; index++) {
            int rowY = 50 + index * 45 + scrollOffset;
            int top = Math.max(41, rowY);
            int bottom = Math.min(screenHeight, rowY + 32);
            if (bottom > top) {
                passes.add(new Pass(
                        new Region(15, top, 200, bottom - top, 0.0f), 10));
            }
        }
        passes.add(new Pass(
                new Region(panelX, panelY, 140, panelHeight, 0.0f), 10));

        context.createNewRootLayer();
        context.applyBlur();
        pendingPlan = new PendingPlan(List.copyOf(passes));
    }

    static boolean consumePendingPlan() {
        PendingPlan plan = pendingPlan;
        pendingPlan = null;
        if (plan == null) return false;

        for (Pass pass : plan.passes()) {
            Region region = pass.region();
            BlurVisuals.renderLegacyMenuBlurRegion(
                    region.x(), region.y(), region.x() + region.width(),
                    region.y() + region.height(), region.cornerRadius(),
                    pass.framebufferRadius());
        }
        return true;
    }

    static void externalShadow(
            DrawContext context, int x, int y, int width, int height,
            int framebufferBlur
    ) {
        float scale = Math.max(1.0f,
                (float) MinecraftClient.getInstance().getWindow().getScaleFactor());
        float blur = framebufferBlur / scale;
        int padding = Math.max(2, (int) Math.ceil(blur + 1.0f));

        shadowPart(context, x, y, width, height, blur,
                x - padding, y - padding, x + width + padding, y);
        shadowPart(context, x, y, width, height, blur,
                x - padding, y + height, x + width + padding, y + height + padding);
        shadowPart(context, x, y, width, height, blur,
                x - padding, y, x, y + height);
        shadowPart(context, x, y, width, height, blur,
                x + width, y, x + width + padding, y + height);
    }

    private static void shadowPart(
            DrawContext context, int x, int y, int width, int height, float blur,
            int clipLeft, int clipTop, int clipRight, int clipBottom
    ) {
        if (clipRight <= clipLeft || clipBottom <= clipTop) return;
        context.enableScissor(clipLeft, clipTop, clipRight, clipBottom);
        try {
            SmoothRoundedGui.fillGlow(context, x, y, width, height,
                    0.0f, blur, 0xFF000000);
        } finally {
            context.disableScissor();
        }
    }

    record Region(int x, int y, int width, int height, float cornerRadius) {
    }

    private record Pass(Region region, int framebufferRadius) {
    }

    private record PendingPlan(List<Pass> passes) {
    }
}
