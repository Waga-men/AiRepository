package celestial.port.client.ui;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.function.ToIntFunction;

final class LegacyAltStore {
    private static final Gson GSON = new GsonBuilder()
            .setPrettyPrinting().disableHtmlEscaping().create();
    private static final List<QuickServer> BUILTIN_SERVERS = List.of(
            new QuickServer("Infinity HVH", "mc.infinityhvh.com"),
            new QuickServer("Night HVH", "mc.nighthvh.space"),
            new QuickServer("Favery HVH", "mc.FaveryHvH.fun"),
            new QuickServer("Really World", "mc.reallyworld.ru"),
            new QuickServer("MST Network", "mstnw.net"),
            new QuickServer("Nexus Grief", "ngrief.su"),
            new QuickServer("SunRise", "play.sunmc.ru")
    );
    private static final LegacyAltStore INSTANCE = new LegacyAltStore();

    private final Path file = FabricLoader.getInstance().getConfigDir()
            .resolve("celestial").resolve("alts.json").toAbsolutePath().normalize();
    private final LegacyCredentialVault vault = LegacyCredentialVault.instance();
    private final List<AltAccount> accounts = new ArrayList<>();
    private final List<QuickServer> servers = new ArrayList<>();
    private boolean loaded;
    private boolean legacyImported;
    private int panelX = 226;
    private int panelY = 50;

    private LegacyAltStore() {
    }

    static LegacyAltStore instance() {
        INSTANCE.ensureLoaded();
        return INSTANCE;
    }

    synchronized List<AltAccount> accounts() {
        ensureLoaded();
        return List.copyOf(accounts);
    }

    synchronized List<QuickServer> servers() {
        ensureLoaded();
        return List.copyOf(servers);
    }

    synchronized AltAccount addOffline(String username, boolean manual) {
        ensureLoaded();
        String clean = sanitizeUsername(username);
        AltAccount account = new AltAccount(
                UUID.randomUUID(), clean, clean, null,
                System.currentTimeMillis(), manual ? 1 : 0, Provider.OFFLINE);
        accounts.add(account);
        saveQuietly();
        return account;
    }

    synchronized AltAccount addMicrosoft(
            LegacyMicrosoftAuth.Result authenticated, boolean manual
    ) {
        ensureLoaded();
        UUID id = UUID.randomUUID();
        boolean persisted = vault.put(id, authenticated.persistedState());
        String profileName = sanitizeUsername(authenticated.profileName());
        AltAccount account = new AltAccount(
                id, profileName, profileName, authenticated.profileUuid(),
                System.currentTimeMillis(), manual ? 1 : 0,
                persisted ? Provider.MICROSOFT : Provider.MICROSOFT_RELINK);
        accounts.add(account);
        saveQuietly();
        return account;
    }

    synchronized AltAccount updateMicrosoft(
            AltAccount account, LegacyMicrosoftAuth.Result authenticated
    ) {
        ensureLoaded();
        int index = accounts.indexOf(account);
        if (index < 0) return account;
        boolean persisted = vault.put(account.id(), authenticated.persistedState());
        String profileName = sanitizeUsername(authenticated.profileName());
        AltAccount updated = new AltAccount(
                account.id(), profileName, profileName, authenticated.profileUuid(),
                account.addedAt(), account.type(),
                persisted ? Provider.MICROSOFT : Provider.MICROSOFT_RELINK);
        accounts.set(index, updated);
        saveQuietly();
        return updated;
    }

    synchronized Optional<String> credentialState(AltAccount account) {
        ensureLoaded();
        if (account.provider() != Provider.MICROSOFT) return Optional.empty();
        return vault.get(account.id());
    }

    synchronized boolean needsRelink(AltAccount account) {
        ensureLoaded();
        return account.provider() == Provider.MICROSOFT_RELINK
                || account.provider() == Provider.MICROSOFT
                && vault.get(account.id()).isEmpty();
    }

    synchronized void remove(AltAccount account) {
        ensureLoaded();
        if (accounts.remove(account)) vault.remove(account.id());
        saveQuietly();
    }

    synchronized void clearRandom() {
        ensureLoaded();
        List<AltAccount> removed = accounts.stream()
                .filter(account -> account.type() != 1).toList();
        accounts.removeAll(removed);
        removed.forEach(account -> vault.remove(account.id()));
        saveQuietly();
    }

    synchronized void addServer(String name, String address) {
        ensureLoaded();
        String cleanName = Objects.requireNonNull(name, "name").strip();
        String cleanAddress = Objects.requireNonNull(address, "address").strip();
        if (cleanName.isEmpty() || cleanAddress.isEmpty()) {
            throw new IllegalArgumentException("Name and IP are required");
        }
        servers.add(new QuickServer(cleanName, cleanAddress));
        saveQuietly();
    }

    synchronized void sortServers(ToIntFunction<String> width) {
        ensureLoaded();
        servers.sort(Comparator.comparingInt(
                (QuickServer server) -> width.applyAsInt(server.name())).reversed());
        saveQuietly();
    }

    synchronized void removeServer(QuickServer server) {
        ensureLoaded();
        servers.remove(server);
        saveQuietly();
    }

    synchronized int panelX() {
        ensureLoaded();
        return panelX;
    }

    synchronized int panelY() {
        ensureLoaded();
        return panelY;
    }

    synchronized void setPanelPosition(int x, int y) {
        ensureLoaded();
        panelX = x;
        panelY = y;
        saveQuietly();
    }

    private synchronized void ensureLoaded() {
        if (loaded) return;
        loaded = true;
        boolean modernLoaded = readJson();
        if (!legacyImported) importLegacyMetadata(!modernLoaded);
        restoreBuiltinServers();
        saveQuietly();
    }

    private void restoreBuiltinServers() {
        List<QuickServer> saved = new ArrayList<>(servers);
        servers.clear();
        servers.addAll(BUILTIN_SERVERS);
        for (QuickServer server : saved) {
            if (servers.stream().noneMatch(existing ->
                    existing.address().equalsIgnoreCase(server.address()))) {
                servers.add(server);
            }
        }
    }

    private boolean readJson() {
        if (!Files.isRegularFile(file)) return false;
        try (Reader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            JsonElement parsed = JsonParser.parseReader(reader);
            if (!parsed.isJsonObject()) return false;
            JsonObject root = parsed.getAsJsonObject();
            panelX = integer(root, "panelX", 226);
            panelY = integer(root, "panelY", 50);
            legacyImported = bool(root, "legacyImported", false);
            JsonElement rawAccounts = root.get("accounts");
            if (rawAccounts != null && rawAccounts.isJsonArray()) {
                int index = 0;
                for (JsonElement raw : rawAccounts.getAsJsonArray()) {
                    if (!raw.isJsonObject()) continue;
                    JsonObject value = raw.getAsJsonObject();
                    try {
                        String username = sanitizeUsername(value.get("username").getAsString());
                        String profile = value.has("profileName")
                                ? value.get("profileName").getAsString() : username;
                        if (profile == null || profile.isBlank()
                                || profile.equalsIgnoreCase("null")) {
                            profile = username;
                        } else {
                            profile = sanitizeUsername(profile);
                        }
                        long addedAt = value.has("addedAt")
                                ? value.get("addedAt").getAsLong() : System.currentTimeMillis();
                        int type = value.has("type") ? value.get("type").getAsInt() : 1;
                        UUID id = value.has("id")
                                ? UUID.fromString(value.get("id").getAsString())
                                : migratedId(username, addedAt, index);
                        UUID profileUuid = value.has("profileUuid")
                                ? parseUuid(value.get("profileUuid").getAsString()) : null;
                        Provider provider = value.has("provider")
                                ? Provider.parse(value.get("provider").getAsString())
                                : Provider.OFFLINE;
                        accounts.add(new AltAccount(
                                id, username, profile, profileUuid, addedAt, type, provider));
                        index++;
                    } catch (RuntimeException ignored) {

                    }
                }
            }
            JsonElement rawServers = root.get("quickServers");
            if (rawServers != null && rawServers.isJsonArray()) {
                servers.clear();
                for (JsonElement raw : rawServers.getAsJsonArray()) {
                    if (!raw.isJsonObject()) continue;
                    JsonObject value = raw.getAsJsonObject();
                    try {
                        String name = value.get("name").getAsString().strip();
                        String address = value.get("address").getAsString().strip();
                        if (!name.isEmpty() && !address.isEmpty()) {
                            servers.add(new QuickServer(name, address));
                        }
                    } catch (RuntimeException ignored) {
                    }
                }
            }
            return true;
        } catch (IOException | RuntimeException ignored) {
            accounts.clear();
            servers.clear();
            return false;
        }
    }

    private void importLegacyMetadata(boolean importPanelPosition) {
        Path legacyFile = legacyFile();
        if (legacyFile == null) return;

        Map<AccountSignature, Integer> existing = new HashMap<>();
        for (AltAccount account : accounts) {
            existing.merge(AccountSignature.of(account), 1, Integer::sum);
        }
        try (BufferedReader reader = Files.newBufferedReader(
                legacyFile, StandardCharsets.UTF_8)) {
            String value;
            int index = 0;
            while ((value = reader.readLine()) != null) {
                value = value.strip();
                if (value.isEmpty()) continue;
                if (value.startsWith("AltHelper:")) {
                    if (importPanelPosition) importPanel(value);
                    continue;
                }
                AltAccount imported = parseLegacyAccount(value, index++);
                if (imported == null) continue;
                AccountSignature signature = AccountSignature.of(imported);
                int available = existing.getOrDefault(signature, 0);
                if (available > 0) {
                    existing.put(signature, available - 1);
                } else {
                    accounts.add(imported);
                }
            }
            legacyImported = true;
        } catch (IOException ignored) {

        }
    }

    private AltAccount parseLegacyAccount(String value, int index) {
        try {
            String[] parts = value.split("-", -1);
            if (parts.length < 5) {
                String clean = sanitizeUsername(value);
                return new AltAccount(migratedId(clean, 0L, index), clean, clean,
                        null, System.currentTimeMillis(), 1, Provider.OFFLINE);
            }
            String legacyLogin = parts[0];
            String profile = parts[parts.length - 3];
            String publicName = profile.isBlank() || profile.equalsIgnoreCase("null")
                    ? legacyLogin : profile;
            String clean = sanitizeUsername(publicName);
            long addedAt = System.currentTimeMillis();
            try {
                addedAt = DateFormat.getDateTimeInstance(
                                DateFormat.DEFAULT, DateFormat.DEFAULT, Locale.ROOT)
                        .parse(parts[parts.length - 2]).getTime();
            } catch (ParseException ignored) {
            }
            int type = 1;
            try {
                type = Integer.parseInt(parts[parts.length - 1]);
            } catch (NumberFormatException ignored) {
            }
            boolean hadPassword = false;
            for (int part = 1; part < parts.length - 3; part++) {
                if (!parts[part].isEmpty()) {
                    hadPassword = true;
                    break;
                }
            }
            return new AltAccount(
                    migratedId(clean, addedAt, index), clean, clean, null,
                    addedAt, type,
                    hadPassword ? Provider.MICROSOFT_RELINK : Provider.OFFLINE);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private void importPanel(String value) {
        String[] coordinates = value.split(":");
        if (coordinates.length < 3) return;
        try {
            panelX = Integer.parseInt(coordinates[1]);
            panelY = Integer.parseInt(coordinates[2]);
        } catch (NumberFormatException ignored) {
        }
    }

    private static Path legacyFile() {
        Path gameDirectory = FabricLoader.getInstance().getGameDir()
                .toAbsolutePath().normalize();
        List<Path> roots = new ArrayList<>();
        roots.add(gameDirectory);
        if (gameDirectory.getParent() != null) roots.add(gameDirectory.getParent());
        Set<Path> candidates = new LinkedHashSet<>();
        for (Path root : roots) {
            candidates.add(root.resolve("Celestial").resolve("alt.celka").normalize());
            candidates.add(root.resolve("alt.celka").normalize());
        }
        return candidates.stream().filter(Files::isRegularFile).findFirst().orElse(null);
    }

    private void saveQuietly() {
        JsonObject root = new JsonObject();
        root.addProperty("schemaVersion", 2);
        root.addProperty("panelX", panelX);
        root.addProperty("panelY", panelY);
        root.addProperty("passwordsStored", false);
        root.addProperty("legacyImported", legacyImported);
        JsonArray encodedAccounts = new JsonArray();
        for (AltAccount account : accounts) {
            JsonObject value = new JsonObject();
            value.addProperty("id", account.id().toString());
            value.addProperty("username", account.username());
            value.addProperty("profileName", account.profileName());
            if (account.profileUuid() != null) {
                value.addProperty("profileUuid", account.profileUuid().toString());
            }
            value.addProperty("addedAt", account.addedAt());
            value.addProperty("type", account.type());
            value.addProperty("provider", account.provider().serialized());
            encodedAccounts.add(value);
        }
        root.add("accounts", encodedAccounts);
        JsonArray encodedServers = new JsonArray();
        for (QuickServer server : servers) {
            JsonObject value = new JsonObject();
            value.addProperty("name", server.name());
            value.addProperty("address", server.address());
            encodedServers.add(value);
        }
        root.add("quickServers", encodedServers);

        try {
            Files.createDirectories(file.getParent());
            Path temporary = Files.createTempFile(file.getParent(), "alts.", ".tmp");
            try {
                try (Writer writer = Files.newBufferedWriter(temporary, StandardCharsets.UTF_8)) {
                    GSON.toJson(root, writer);
                }
                try {
                    Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING,
                            StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException ignored) {
                    Files.move(temporary, file, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(temporary);
            }
        } catch (IOException ignored) {

        }
    }

    private static int integer(JsonObject object, String name, int fallback) {
        try {
            return object.has(name) ? object.get(name).getAsInt() : fallback;
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static boolean bool(JsonObject object, String name, boolean fallback) {
        try {
            return object.has(name) ? object.get(name).getAsBoolean() : fallback;
        } catch (RuntimeException ignored) {
            return fallback;
        }
    }

    private static UUID parseUuid(String value) {
        try {
            return UUID.fromString(value);
        } catch (RuntimeException ignored) {
            return null;
        }
    }

    private static UUID migratedId(String username, long addedAt, int index) {
        String value = "CelestialAlt:" + username.toLowerCase(Locale.ROOT)
                + ':' + addedAt + ':' + index;
        return UUID.nameUUIDFromBytes(value.getBytes(StandardCharsets.UTF_8));
    }

    private static String sanitizeUsername(String username) {
        String clean = Objects.requireNonNull(username, "username").strip();
        int length = clean.codePointCount(0, clean.length());
        boolean invalid = clean.codePoints().anyMatch(codePoint ->
                codePoint < 32 || codePoint == 127 || codePoint == '\u00a7');
        if (length < 1 || length > 32 || invalid) {
            throw new IllegalArgumentException("Username must contain 1-32 printable characters");
        }
        return clean;
    }

    enum Provider {
        OFFLINE,
        MICROSOFT,
        MICROSOFT_RELINK;

        String serialized() {
            return name().toLowerCase(Locale.ROOT);
        }

        static Provider parse(String value) {
            try {
                return valueOf(value.toUpperCase(Locale.ROOT));
            } catch (RuntimeException ignored) {
                return OFFLINE;
            }
        }
    }

    record AltAccount(
            UUID id, String username, String profileName, UUID profileUuid,
            long addedAt, int type, Provider provider
    ) {
        String addedText() {
            String formatted = DateFormat.getDateTimeInstance(
                            DateFormat.DEFAULT, DateFormat.DEFAULT, Locale.ROOT)
                    .format(new Date(addedAt))
                    .replace('\u202F', ' ')
                    .replace('\u00A0', ' ');
            return "Added " + formatted;
        }

        boolean microsoft() {
            return provider != Provider.OFFLINE;
        }
    }

    private record AccountSignature(String name, long addedAt, int type) {
        static AccountSignature of(AltAccount account) {
            return new AccountSignature(
                    account.profileName().toLowerCase(Locale.ROOT),
                    account.addedAt(), account.type());
        }
    }

    record QuickServer(String name, String address) {
    }
}
