package celestial.port.client.ui;

import celestial.port.mixin.accessor.MinecraftClientSessionAccessor;
import celestial.port.mixin.accessor.RealmsClientInstanceAccessor;
import com.mojang.authlib.GameProfile;
import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.minecraft.UserApiService;
import com.mojang.authlib.yggdrasil.ProfileResult;
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.SocialInteractionsManager;
import net.minecraft.client.realms.RealmsClient;
import net.minecraft.client.realms.RealmsPeriodicCheckers;
import net.minecraft.client.session.ProfileKeys;
import net.minecraft.client.session.Session;
import net.minecraft.client.session.report.AbuseReportContext;
import net.minecraft.client.session.report.ReporterEnvironment;
import net.minecraft.client.session.telemetry.TelemetryManager;

import java.nio.charset.StandardCharsets;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class LegacyOfflineSession {
    private LegacyOfflineSession() {
    }

    static String switchTo(MinecraftClient client, String username) {
        String blocked = blockedReason(client, true);
        if (blocked != null) return blocked;
        UUID uuid = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + username).getBytes(StandardCharsets.UTF_8));
        Session session = new Session(username, uuid, "", Optional.empty(), Optional.empty());
        return apply(client, session, UserApiService.OFFLINE, true)
                ? "Logged as " + username : "Login failed!";
    }

    static String switchTo(MinecraftClient client, LegacyMicrosoftAuth.Result authenticated) {
        String blocked = blockedReason(client, true);
        if (blocked != null) return blocked;
        Session session = new Session(
                authenticated.profileName(), authenticated.profileUuid(),
                authenticated.accessToken(), Optional.empty(), Optional.empty());
        try {
            UserApiService userApiService = new YggdrasilAuthenticationService(
                    client.getNetworkProxy()).createUserApiService(authenticated.accessToken());
            return apply(client, session, userApiService, false)
                    ? "Logged as " + authenticated.profileName() : "Login failed!";
        } catch (RuntimeException | LinkageError ignored) {
            return "Login failed!";
        }
    }

    public static boolean switchToAtStartup(MinecraftClient client, String username) {
        if (client == null || !validUsername(username) || blockedReason(client, false) != null) {
            return false;
        }
        String clean = username.strip();
        UUID uuid = UUID.nameUUIDFromBytes(
                ("OfflinePlayer:" + clean).getBytes(StandardCharsets.UTF_8));
        Session session = new Session(clean, uuid, "", Optional.empty(), Optional.empty());
        return apply(client, session, UserApiService.OFFLINE, true);
    }

    private static boolean apply(
            MinecraftClient client, Session session,
            UserApiService userApiService, boolean offline
    ) {
        MinecraftClientSessionAccessor accessor = (MinecraftClientSessionAccessor) client;
        OldState old = new OldState(
                accessor.celestial$getGameProfileFuture(), accessor.celestial$getSession(),
                accessor.celestial$getUserApiService(),
                accessor.celestial$getUserPropertiesFuture(),
                client.getSocialInteractionsManager(), client.getTelemetryManager(),
                client.getProfileKeys(), client.getRealmsPeriodicCheckers(),
                client.getAbuseReportContext(),
                RealmsClientInstanceAccessor.celestial$getInstance());

        CompletableFuture<ProfileResult> profile = CompletableFuture.completedFuture(
                new ProfileResult(new GameProfile(session.getUuidOrNull(), session.getUsername())));
        CompletableFuture<UserApiService.UserProperties> properties = offline
                ? CompletableFuture.completedFuture(UserApiService.OFFLINE_PROPERTIES)
                : CompletableFuture.supplyAsync(() -> fetchProperties(userApiService));

        SocialInteractionsManager social;
        TelemetryManager telemetry = null;
        ProfileKeys keys;
        AbuseReportContext reports;
        try {
            social = new SocialInteractionsManager(client, userApiService);
            keys = offline ? ProfileKeys.MISSING
                    : ProfileKeys.create(userApiService, session, client.runDirectory.toPath());
            telemetry = new TelemetryManager(client, userApiService, session);
            reports = AbuseReportContext.create(
                    ReporterEnvironment.ofIntegratedServer(), userApiService);
        } catch (RuntimeException | LinkageError failure) {
            closeQuietly(telemetry);
            return false;
        }

        try {
            accessor.celestial$setGameProfileFuture(profile);
            accessor.celestial$setSession(session);
            accessor.celestial$setUserApiService(userApiService);
            accessor.celestial$setUserPropertiesFuture(properties);
            accessor.celestial$setSocialInteractionsManager(social);
            accessor.celestial$setTelemetryManager(telemetry);
            accessor.celestial$setProfileKeys(keys);
            accessor.celestial$setAbuseReportContext(reports);
            RealmsClientInstanceAccessor.celestial$setInstance(null);
            accessor.celestial$setRealmsPeriodicCheckers(new RealmsPeriodicCheckers(
                    RealmsClient.createRealmsClient(client)));
        } catch (RuntimeException | LinkageError failure) {
            restore(accessor, old);
            RealmsClientInstanceAccessor.celestial$setInstance(old.realmsClient());
            closeQuietly(telemetry);
            return false;
        }

        try {
            old.socialInteractionsManager().unloadBlockList();
        } catch (RuntimeException ignored) {
        }
        closeQuietly(old.telemetryManager());
        return true;
    }

    private static String blockedReason(MinecraftClient client, boolean requireAccountScreen) {
        if (client == null || client.world != null || client.getNetworkHandler() != null
                || client.getServer() != null) {
            return "Disconnect before changing account";
        }
        if (requireAccountScreen && !(client.currentScreen instanceof LegacyAltManagerScreen)) {
            return "Account screen is no longer active";
        }
        return null;
    }

    private static boolean validUsername(String username) {
        if (username == null) return false;
        String clean = username.strip();
        int length = clean.codePointCount(0, clean.length());
        return length >= 1 && length <= 32 && clean.codePoints().noneMatch(codePoint ->
                codePoint < 32 || codePoint == 127 || codePoint == '\u00a7');
    }

    private static UserApiService.UserProperties fetchProperties(UserApiService service) {
        try {
            return service.fetchProperties();
        } catch (AuthenticationException | RuntimeException ignored) {
            return UserApiService.OFFLINE_PROPERTIES;
        }
    }

    private static void restore(MinecraftClientSessionAccessor accessor, OldState old) {
        accessor.celestial$setGameProfileFuture(old.gameProfileFuture());
        accessor.celestial$setSession(old.session());
        accessor.celestial$setUserApiService(old.userApiService());
        accessor.celestial$setUserPropertiesFuture(old.userPropertiesFuture());
        accessor.celestial$setSocialInteractionsManager(old.socialInteractionsManager());
        accessor.celestial$setTelemetryManager(old.telemetryManager());
        accessor.celestial$setProfileKeys(old.profileKeys());
        accessor.celestial$setRealmsPeriodicCheckers(old.realmsPeriodicCheckers());
        accessor.celestial$setAbuseReportContext(old.abuseReportContext());
    }

    private static void closeQuietly(TelemetryManager telemetry) {
        if (telemetry == null) return;
        try {
            telemetry.close();
        } catch (RuntimeException ignored) {
        }
    }

    private record OldState(
            CompletableFuture<ProfileResult> gameProfileFuture,
            Session session,
            UserApiService userApiService,
            CompletableFuture<UserApiService.UserProperties> userPropertiesFuture,
            SocialInteractionsManager socialInteractionsManager,
            TelemetryManager telemetryManager,
            ProfileKeys profileKeys,
            RealmsPeriodicCheckers realmsPeriodicCheckers,
            AbuseReportContext abuseReportContext,
            RealmsClient realmsClient
    ) {
    }
}
