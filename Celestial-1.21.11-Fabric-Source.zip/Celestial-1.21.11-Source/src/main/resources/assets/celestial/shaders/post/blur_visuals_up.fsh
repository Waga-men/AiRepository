#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform KawaseConfig {
    float Offset;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 halfpixel = 0.5 / InSize;
    vec4 sum = texture(InSampler, texCoord
            + vec2(-halfpixel.x * 2.0, 0.0) * Offset);
    sum += texture(InSampler, texCoord
            + vec2(-halfpixel.x, halfpixel.y) * Offset) * 2.0;
    sum += texture(InSampler, texCoord
            + vec2(0.0, halfpixel.y * 2.0) * Offset);
    sum += texture(InSampler, texCoord
            + vec2(halfpixel.x, halfpixel.y) * Offset) * 2.0;
    sum += texture(InSampler, texCoord
            + vec2(halfpixel.x * 2.0, 0.0) * Offset);
    sum += texture(InSampler, texCoord
            + vec2(halfpixel.x, -halfpixel.y) * Offset) * 2.0;
    sum += texture(InSampler, texCoord
            + vec2(0.0, -halfpixel.y * 2.0) * Offset);
    sum += texture(InSampler, texCoord
            + vec2(-halfpixel.x, -halfpixel.y) * Offset) * 2.0;
    fragColor = vec4(sum.rgb / 12.0, 1.0);
}
