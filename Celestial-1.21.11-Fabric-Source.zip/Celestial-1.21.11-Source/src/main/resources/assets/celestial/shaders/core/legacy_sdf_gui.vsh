#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in float LineWidth;
in vec3 Normal;

out vec2 texCoord0;
flat out vec4 rectColor1;
flat out vec4 rectColor2;
flat out vec4 rectColor3;
flat out vec4 rectColor4;
flat out vec2 rectSize;
flat out float rectRadius;
flat out float extraParameter;
flat out float guiScale;
flat out int rectMode;

uint unpackShortPair(ivec2 value) {
    return (uint(value.x) & 0xFFFFu) | ((uint(value.y) & 0xFFFFu) << 16u);
}

vec3 unpackArgbRgb(uint value) {
    return vec3(
        float((value >> 16u) & 0xFFu),
        float((value >> 8u) & 0xFFu),
        float(value & 0xFFu)
    ) / 255.0;
}

void main() {

    gl_Position = ProjMat * ModelViewMat * vec4(Position.xy, 0.0, 1.0);
    texCoord0 = UV0;

    rectColor1 = Color;
    rectColor2 = vec4(unpackArgbRgb(unpackShortPair(UV1)), 1.0);
    rectColor3 = vec4(unpackArgbRgb(unpackShortPair(UV2)), 1.0);
    rectColor4 = vec4(unpackArgbRgb(uint(round(Position.z))), 1.0);

    uint packedSize = uint(round(LineWidth));
    rectSize = vec2(
        float(packedSize & 0xFFFu),
        float((packedSize >> 12u) & 0xFFFu)
    ) * 0.5;
    rectRadius = round(Normal.x * 127.0) * 0.5;
    extraParameter = round(Normal.y * 127.0) * 0.5;

    int packedModeAndScale = int(round(Normal.z * 127.0));
    rectMode = packedModeAndScale & 3;
    guiScale = float(packedModeAndScale >> 2) * 0.5;
}
