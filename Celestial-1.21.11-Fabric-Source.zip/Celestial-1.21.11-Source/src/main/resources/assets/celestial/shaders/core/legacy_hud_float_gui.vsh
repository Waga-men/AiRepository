#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};
layout(std140) uniform Projection {
    mat4 ProjMat;
};

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in float LineWidth;
in vec3 Normal;

out vec2 texCoord0;
flat out vec4 rectColor1;
flat out vec4 rectColor2;
flat out vec4 rectColor3;
flat out vec4 rectColor4;
flat out vec2 rectSize;
flat out float rectRadius;
flat out float extraParameter;
flat out float guiScale;
flat out int rectMode;

uint unpackShortPair(ivec2 value) {
    return (uint(value.x) & 0xFFFFu) | ((uint(value.y) & 0xFFFFu) << 16u);
}

vec3 unpackRgb(uint value) {
    return vec3(
        float((value >> 16u) & 0xFFu),
        float((value >> 8u) & 0xFFu),
        float(value & 0xFFu)
    ) / 255.0;
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position.xy, 0.0, 1.0);

    int corner = gl_VertexID & 3;
    texCoord0 = vec2(
        corner >= 2 ? 1.0 : 0.0,
        (corner == 1 || corner == 2) ? 1.0 : 0.0
    );

    uint packedBottomLeft = unpackShortPair(UV1);
    uint packedTopRight = unpackShortPair(UV2);
    rectColor1 = Color;
    rectColor2 = vec4(unpackRgb(packedBottomLeft), 1.0);
    rectColor3 = vec4(unpackRgb(packedTopRight), 1.0);
    rectColor4 = vec4(unpackRgb(uint(round(Position.z))), 1.0);
    rectSize = UV0;
    rectRadius = float((packedBottomLeft >> 24u) & 0xFFu) / 16.0;
    extraParameter = float((packedTopRight >> 24u) & 0xFFu) / 16.0;

    int packedModeAndScale = int(round(LineWidth));
    rectMode = packedModeAndScale & 3;
    guiScale = float(packedModeAndScale >> 2) / 16.0;
}
