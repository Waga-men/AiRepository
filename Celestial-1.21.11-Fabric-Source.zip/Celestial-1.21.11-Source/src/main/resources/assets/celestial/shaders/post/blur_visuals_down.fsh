#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform KawaseConfig {
    float Offset;
};

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec2 halfpixel = 0.5 / InSize;
    vec4 sum = texture(InSampler, texCoord) * 4.0;
    sum += texture(InSampler, texCoord - halfpixel.xy * Offset);
    sum += texture(InSampler, texCoord + halfpixel.xy * Offset);
    sum += texture(InSampler, texCoord + vec2(halfpixel.x, -halfpixel.y) * Offset);
    sum += texture(InSampler, texCoord - vec2(halfpixel.x, -halfpixel.y) * Offset);
    fragColor = vec4(sum.rgb / 8.0, 1.0);
}
