#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform LegacyChatBlurConfig {
    vec2 Direction;
};

in vec2 texCoord;
out vec4 fragColor;

const float SIGMA = 6.5;
const float NORMALIZER = 0.0613757354521355;

float gaussianWeight(float distance) {
    return NORMALIZER * exp(-(distance * distance) / (2.0 * SIGMA * SIGMA));
}

void main() {
    vec2 stepSize = Direction / InSize;
    vec3 blurred = texture(InSampler, texCoord).rgb * gaussianWeight(0.0);
    for (int sampleIndex = 1; sampleIndex <= 13; ++sampleIndex) {
        vec2 offset = stepSize * float(sampleIndex);
        float weight = gaussianWeight(float(sampleIndex));
        blurred += texture(InSampler, texCoord + offset).rgb * weight;
        blurred += texture(InSampler, texCoord - offset).rgb * weight;
    }
    fragColor = vec4(blurred, 1.0);
}
