#version 330

uniform sampler2D InSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 InSize;
};

layout(std140) uniform CelestialGlowConfig {
    vec4 Color1;
    vec4 Color2;
    vec4 Color3;
    vec4 Color4;
    vec4 Color5;
    vec4 Params;
};

in vec2 texCoord;
out vec4 fragColor;

const float PI = 3.14159265358979323846;

float gaussian(float distance, float sigma) {
    return exp(-(distance * distance) / (2.0 * sigma * sigma))
        / sqrt(2.0 * PI * sigma * sigma);
}

void main() {
    float radius = clamp(Params.x, 3.0, 50.0);
    float sigma = radius * 0.5;
    vec2 texel = vec2(1.0 / InSize.x, 0.0);

    float alpha = texture(InSampler, texCoord).a * gaussian(1.0, sigma);
    for (int sampleIndex = 1; sampleIndex <= 50; ++sampleIndex) {

        if (float(sampleIndex) >= radius) {
            break;
        }
        float weight = gaussian(float(sampleIndex + 1), sigma);
        vec2 offset = texel * float(sampleIndex);
        alpha += texture(InSampler, texCoord + offset).a * weight;
        alpha += texture(InSampler, texCoord - offset).a * weight;
    }

    float exposedAlpha = 1.0 - exp(-alpha * clamp(Params.y, 1.0, 3.0));
    fragColor = vec4(1.0, 1.0, 1.0, exposedAlpha);
}
