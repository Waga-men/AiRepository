#version 330

uniform sampler2D BlurredSampler;
uniform sampler2D MaskSampler;

layout(std140) uniform SamplerInfo {
    vec2 OutSize;
    vec2 BlurredSize;
    vec2 MaskSize;
};

layout(std140) uniform CelestialGlowConfig {
    vec4 Color1;
    vec4 Color2;
    vec4 Color3;
    vec4 Color4;
    vec4 Color5;
    vec4 Params;
};

in vec2 texCoord;
out vec4 fragColor;

const float PI = 3.14159265358979323846;
const float TAU = PI * 2.0;

float gaussian(float distance, float sigma) {
    return exp(-(distance * distance) / (2.0 * sigma * sigma))
        / sqrt(2.0 * PI * sigma * sigma);
}

vec3 animatedColor(float time) {
    vec2 centered = texCoord - vec2(0.5);
    float theta = atan(centered.y, centered.x);
    float progress = mod(theta + time, TAU) / TAU;
    if (progress < 0.2) {
        return mix(Color1.rgb, Color2.rgb, smoothstep(0.0, 0.2, progress));
    }
    if (progress < 0.4) {
        return mix(Color2.rgb, Color3.rgb, smoothstep(0.2, 0.4, progress));
    }
    if (progress < 0.6) {
        return mix(Color3.rgb, Color4.rgb, smoothstep(0.4, 0.6, progress));
    }
    if (progress < 0.8) {
        return mix(Color4.rgb, Color5.rgb, smoothstep(0.6, 0.8, progress));
    }
    return mix(Color5.rgb, Color1.rgb, smoothstep(0.8, 1.0, progress));
}

void main() {

    if (texture(MaskSampler, texCoord).a > 0.0001) {
        fragColor = vec4(0.0);
        return;
    }

    float radius = clamp(Params.x, 3.0, 50.0);
    float sigma = radius * 0.5;
    vec2 texel = vec2(0.0, 1.0 / BlurredSize.y);

    float alpha = texture(BlurredSampler, texCoord).a * gaussian(1.0, sigma);
    for (int sampleIndex = 1; sampleIndex <= 50; ++sampleIndex) {
        if (float(sampleIndex) >= radius) {
            break;
        }
        float weight = gaussian(float(sampleIndex + 1), sigma);
        vec2 offset = texel * float(sampleIndex);
        alpha += texture(BlurredSampler, texCoord + offset).a * weight;
        alpha += texture(BlurredSampler, texCoord - offset).a * weight;
    }

    float exposedAlpha = 1.0 - exp(-alpha * clamp(Params.y, 1.0, 3.0));
    fragColor = vec4(animatedColor(Params.z), exposedAlpha);
}
