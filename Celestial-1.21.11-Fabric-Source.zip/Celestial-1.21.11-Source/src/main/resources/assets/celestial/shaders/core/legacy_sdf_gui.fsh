#version 330

layout(std140) uniform DynamicTransforms {
    mat4 ModelViewMat;
    vec4 ColorModulator;
    vec3 ModelOffset;
    mat4 TextureMat;
};

in vec2 texCoord0;
flat in vec4 rectColor1;
flat in vec4 rectColor2;
flat in vec4 rectColor3;
flat in vec4 rectColor4;
flat in vec2 rectSize;
flat in float rectRadius;
flat in float extraParameter;
flat in float guiScale;
flat in int rectMode;

out vec4 fragColor;

const int MODE_GRADIENT = 0;
const int MODE_NOISE = 1;
const int MODE_GLOW = 2;

float roundSDF(vec2 point, vec2 bounds, float radius) {
    return length(max(abs(point) - bounds, 0.0)) - radius;
}

vec3 createGradient(
        vec2 coordinates, vec3 color1, vec3 color2, vec3 color3, vec3 color4
) {
    return mix(
        mix(color1, color2, coordinates.y),
        mix(color3, color4, coordinates.y),
        coordinates.x
    );
}

float legacyNoise(vec2 coordinates, float strength) {
    return mix(
        strength / 255.0,
        -strength / 255.0,
        fract(sin(dot(coordinates, vec2(12.9898, 78.233))) * 43758.5453)
    );
}

void main() {
    vec2 shaderSize = rectSize;
    float shaderRadius = rectRadius;

    if (rectMode == MODE_GRADIENT) {
        shaderSize *= guiScale;
        shaderRadius *= guiScale;
    }

    vec2 halfSize = shaderSize * 0.5;
    vec2 point = halfSize - texCoord0 * shaderSize;
    vec3 color = createGradient(
        texCoord0,
        rectColor1.rgb,
        rectColor2.rgb,
        rectColor3.rgb,
        rectColor4.rgb
    );
    float alpha;

    if (rectMode == MODE_GLOW) {
        float glowRadius = max(extraParameter, 0.0001);
        float distance = roundSDF(
            point,
            halfSize - (glowRadius + shaderRadius * 0.75),
            shaderRadius
        );
        float smoothedAlpha = (1.0 - smoothstep(
            -glowRadius, glowRadius, distance
        )) * rectColor1.a;

        alpha = smoothedAlpha * smoothedAlpha;
    } else {
        float distance = roundSDF(
            point,
            halfSize - shaderRadius - 1.0,
            shaderRadius
        );
        alpha = (1.0 - smoothstep(0.0, 2.0, distance)) * rectColor1.a;
        float noiseStrength = rectMode == MODE_NOISE ? extraParameter : 0.5;
        color += vec3(legacyNoise(texCoord0, noiseStrength));
    }

    vec4 outputColor = vec4(color, alpha) * ColorModulator;
    if (outputColor.a <= 0.0) {
        discard;
    }
    fragColor = outputColor;
}
