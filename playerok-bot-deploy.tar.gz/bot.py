"""Telegram-бот «Playerok Tools» — порт расширения для playerok.com."""
from __future__ import annotations

import asyncio
import json
import time
import uuid
from typing import Optional

from aiogram import Bot, Dispatcher, F, Router, BaseMiddleware
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BotCommand,
    BotCommandScopeChat,
    BufferedInputFile,
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    LabeledPrice,
    MenuButtonCommands,
    Message,
    PreCheckoutQuery,
)

import config
import storage
from client import PlayerokClient, AuthError, parse_cookies
from fmt import esc, money, status_label, dt_str, time_str, now_ms
import analytics
import automation

bot = None  # создаётся в make_bot()


def make_bot():
    """Создаёт Bot с учётом прокси/локального Bot API (обход блокировки)."""
    from aiogram.client.session.aiohttp import AiohttpSession
    from aiogram.client.telegram import TelegramAPIServer

    kwargs = {}
    if config.BOT_API_URL:
        kwargs["session"] = AiohttpSession(
            api=TelegramAPIServer.from_base(config.BOT_API_URL)
        )
    elif config.PROXY:
        kwargs["session"] = AiohttpSession(proxy=config.PROXY)

    return Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
        **kwargs,
    )
dp = Dispatcher(storage=MemoryStorage())
router = Router()

# Небольшой кэш списков, чтобы не дёргать API на каждый клик.
_cache: dict = {}


def cache_get(key: str, ttl: float = 30.0):
    item = _cache.get(key)
    if item and time.time() - item[0] < ttl:
        return item[1]
    return None


def cache_set(key: str, value) -> None:
    _cache[key] = (time.time(), value)
    if len(_cache) > 500:
        for k in list(_cache)[:100]:
            _cache.pop(k, None)


# ================= FSM =================

class Form(StatesGroup):
    login = State()
    reply = State()
    add_template = State()
    add_command = State()
    set_value = State()
    grant = State()          # ввод @username/ID для выдачи доступа
    card_amount = State()    # ввод суммы перевода на карту
    set_price = State()      # владелец: ввод новой цены


# ================= доступ =================

# Команды, доступные без покупки (публичные).
PUBLIC_COMMANDS = {"start", "help", "buy", "login", "logout"}


class AccessMiddleware(BaseMiddleware):
    """Пропускает только владельца и пользователей с активным доступом.

    Публичные команды и диалог /login доступны всем.
    """

    async def __call__(self, handler, event, data):
        user_id = event.from_user.id if event.from_user else None
        if user_id is None:
            return await handler(event, data)

        if await storage.is_allowed(user_id):
            return await handler(event, data)

        # подтверждение оплаты звёздами должно пройти всегда
        if getattr(event, "successful_payment", None):
            return await handler(event, data)

        # публичные команды
        text = getattr(event, "text", None) or getattr(event, "data", None) or ""
        if isinstance(text, str) and text.startswith("/"):
            cmd = text.split()[0].lstrip("/").split("@")[0].lower()
            if cmd in PUBLIC_COMMANDS:
                return await handler(event, data)

        # публичные кнопки покупки (callback_data)
        if isinstance(event, CallbackQuery) and event.data in ("buy", "pay_stars", "pay_card"):
            return await handler(event, data)

        # диалоги, доступные без подписки: ввод cookies и суммы перевода
        state: FSMContext = data.get("state")
        if state is not None:
            cur = await state.get_state()
            if cur in ("Form:login", "Form:card_amount"):
                return await handler(event, data)

        # отказ
        deny = (
            "⛔ <b>Доступ ограничен.</b>\n\n"
            "Бот платный. Чтобы получить доступ, оплатите подписку:\n"
            "/buy — оплата звёздами Telegram или переводом на карту.\n\n"
            "После оплаты доступ активируется автоматически (звёзды) "
            "или владельцем (карта)."
        )
        if isinstance(event, CallbackQuery):
            await event.answer("⛔ Доступ ограничен. Оплатите: /buy", show_alert=True)
            try:
                await event.message.answer(deny)
            except Exception:
                pass
        else:
            await event.answer(deny)
        return


async def _get_client(user_id: int) -> Optional[PlayerokClient]:
    cookies = await storage.get_cookies(user_id)
    if not cookies:
        return None
    return PlayerokClient(cookies)


# ================= утилиты клавиатур =================

def kb(rows):
    return InlineKeyboardMarkup(inline_keyboard=rows)


def btn(text, data):
    return InlineKeyboardButton(text=text, callback_data=data)


def menu_kb():
    return kb([
        [btn("🏠 Дашборд", "dashboard"), btn("💬 Чаты", "chats")],
        [btn("📦 Лоты", "lots"), btn("⚙️ Авто", "auto")],
        [btn("📈 Аналитика", "stats"), btn("🔧 Настройки", "settings")],
    ])


def owner_menu_kb():
    return kb([
        [btn("🏠 Дашборд", "dashboard"), btn("💬 Чаты", "chats")],
        [btn("📦 Лоты", "lots"), btn("⚙️ Авто", "auto")],
        [btn("📈 Аналитика", "stats"), btn("🔧 Настройки", "settings")],
        [btn("👑 Админ-панель", "admin")],
    ])


def back_kb(to: str = "menu"):
    return kb([[btn("‹ Назад", to)]])


def yesno_kb(data_yes: str):
    return kb([
        [btn("✅ Да", data_yes), btn("❌ Нет", "menu")],
    ])


# ================= /start и меню =================

@router.message(CommandStart())
async def start(message: Message, state: FSMContext):
    await state.clear()
    await storage.register_user(message.from_user.id, message.from_user.username or "")

    if await storage.is_owner(message.from_user.id):
        await message.answer(
            "👑 Вы — <b>владелец</b> бота. Доступ постоянный.\n\n"
            "Меню ниже, а в <b>Админ-панели</b> — выдача доступа и настройка цен.",
            reply_markup=owner_menu_kb(),
        )
        return

    if await storage.is_allowed(message.from_user.id):
        await message.answer(
            "👋 Добро пожаловать! Подключите аккаунт Playerok: /login",
            reply_markup=menu_kb(),
        )
        return

    await message.answer(
        "👋 <b>Playerok Tools</b> — бот-помощник продавца Playerok.\n\n"
        "Бот <b>платный</b>. Чтобы получить доступ:\n"
        "/buy — оплата звёздами Telegram или переводом на карту.\n\n"
        "После оплаты откроются дашборд, чаты, лоты, авто-поднятие, "
        "перевыставление, команды, возвраты и аналитика.",
        reply_markup=kb([[btn("💳 Купить доступ", "buy")]]),
    )


@router.message(Command("menu"))
async def menu_cmd(message: Message, state: FSMContext):
    await state.clear()
    if await storage.is_owner(message.from_user.id):
        await message.answer("📋 Меню", reply_markup=owner_menu_kb())
    else:
        await message.answer("📋 Меню", reply_markup=menu_kb())


@router.message(Command("help"))
async def help_cmd(message: Message):
    common = (
        "/start — приветствие и меню\n"
        "/login — подключить аккаунт Playerok (cookies)\n"
        "/logout — отключить аккаунт\n"
        "/menu — главное меню\n"
        "/buy — купить доступ\n"
    )
    if await storage.is_owner(message.from_user.id):
        common += (
            "\n👑 <b>Владелец:</b>\n"
            "/admin — админ-панель\n"
            "/grant <i>@user или ID</i> — выдать доступ\n"
            "/revoke <i>@user или ID</i> — забрать доступ\n"
            "/prices — цены и реквизиты\n"
        )
    await message.answer("<b>Команды</b>\n" + common)


@router.message(Command("login"))
async def login_cmd(message: Message, state: FSMContext):
    await state.set_state(Form.login)
    await message.answer(
        "🔑 <b>Подключение аккаунта Playerok</b>\n\n"
        "1. Откройте <code>playerok.com</code> в браузере и войдите в аккаунт.\n"
        "2. Откройте расширение <b>EditThisCookie</b>.\n"
        "3. Нажмите <b>Export</b> (стрелка) и скопируйте JSON, либо скопируйте значение куки сессии.\n"
        "4. Вставьте сюда полученный текст.\n\n"
        "Подойдёт также команда <b>Copy as cURL</b> из DevTools (Network → правый клик по запросу /graphql), "
        "или строка вида <code>name=value; name2=value2</code>.\n\n"
        "<i>Бот хранит cookies локально и использует их только для запросов к Playerok.</i>",
        disable_web_page_preview=True,
    )


@router.message(Command("logout"))
async def logout_cmd(message: Message, state: FSMContext):
    await state.clear()
    await storage.set_cookies(message.from_user.id, None)
    _cache.clear()
    await message.answer("🔓 Аккаунт отключён. Cookies удалены.", reply_markup=menu_kb())


# ================= login: приём cookies =================

@router.message(Form.login)
async def login_receive(message: Message, state: FSMContext):
    raw = message.text or ""
    cookie_header = parse_cookies(raw)
    if not cookie_header:
        await message.answer(
            "⚠️ Не удалось распознать cookies. Пришлите JSON-экспорт EditThisCookie, "
            "cURL-команду или строку cookie."
        )
        return
    await message.answer("⏳ Проверяю сессию в Playerok…")
    client = PlayerokClient(cookie_header)
    try:
        viewer = await client.get_viewer()
    except AuthError as exc:
        await message.answer(f"❌ Сессия недействительна: {esc(exc)}\nПопробуйте ещё раз /login.")
        await state.clear()
        return
    except Exception as exc:
        await message.answer(f"❌ Ошибка подключения: {esc(exc)}\nПопробуйте ещё раз /login.")
        await state.clear()
        return
    finally:
        await client.close()

    await storage.set_cookies(message.from_user.id, cookie_header)
    await storage.update(
        message.from_user.id,
        lambda r: r.update(username=message.from_user.username or ""),
    )
    await state.clear()
    await message.answer(
        f"✅ Подключено!\n\n"
        f"Аккаунт: <b>{esc(viewer['username'] or '—')}</b>\n"
        f"Баланс: <b>{money(viewer['balance'])}</b>\n"
        f"Непрочитанных: <b>{viewer['unread_chats_counter']}</b>",
        reply_markup=menu_kb(),
    )


# ================= Дашборд =================

async def render_dashboard(message: Message, edit: bool = False):
    client = await _get_client(message.from_user.id)
    if not client:
        await message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        viewer = await client.get_viewer()
    except AuthError as exc:
        await message.answer(f"⚠️ {esc(exc)}\nОбновите сессию: /login")
        return
    except Exception as exc:
        await message.answer(f"⚠️ Ошибка: {esc(exc)}")
        return
    finally:
        await client.close()

    rec = await storage.load(message.from_user.id)
    s = rec["settings"]
    auto_on = s["automation"]["enabled"]
    relist_on = s["relist"]["enabled"]

    text = (
        f"🏠 <b>Дашборд</b>\n\n"
        f"Аккаунт: <b>{esc(viewer['username'] or '—')}</b>\n"
        f"Баланс: <b>{money(viewer['balance'])}</b>\n"
        f"Непрочитанных сообщений: <b>{viewer['unread_chats_counter']}</b>\n"
        f"Отзывов: {viewer['testimonial_counter']}\n\n"
        f"Чат-автоматизация: {'✅ вкл' if auto_on else '⏸ выкл'}\n"
        f"Перевыставление: {'✅ вкл' if relist_on else '⏸ выкл'}"
    )
    kbd = kb([
        [btn("💬 Чаты", "chats"), btn("📦 Лоты", "lots")],
        [btn("✅ Прочитать все", "readall")],
        [btn("♻️ Перевыставить лоты", "runrelist_confirm")],
        [btn("📈 Статистика", "stats")],
        [btn("‹ Меню", "menu")],
    ])
    if edit:
        await message.edit_text(text, reply_markup=kbd)
    else:
        await message.answer(text, reply_markup=kbd)


@router.callback_query(F.data == "dashboard")
async def dashboard_cb(cq: CallbackQuery):
    await cq.answer()
    await render_dashboard(cq.message, edit=True)


# ================= Чаты =================

async def fetch_chats(user_id: int, max_pages: int = 5):
    key = f"chats:{user_id}:{max_pages}"
    cached = cache_get(key)
    if cached:
        return cached
    client = await _get_client(user_id)
    if not client:
        return None
    try:
        data = await client.get_chats(max_pages=max_pages)
    finally:
        await client.close()
    cache_set(key, data)
    return data


async def render_chats(message: Message, page: int = 0, edit: bool = False):
    data = await fetch_chats(message.from_user.id)
    if data is None:
        await message.answer("Сначала подключите аккаунт: /login")
        return
    viewer = data["viewer"]
    chats = data["chats"]
    per_page = 8
    total_pages = max(1, (len(chats) + per_page - 1) // per_page)
    page = max(0, min(page, total_pages - 1))
    chunk = chats[page * per_page:(page + 1) * per_page]

    if not chats:
        await message.answer("💬 Чатов нет.")
        return

    unread_total = sum(1 for c in chats if c["unread_counter"] > 0)
    lines = [f"💬 <b>Чаты</b> · непрочитанных: {unread_total}\n"]
    for c in chunk:
        other = automation.other_participant(c, viewer)
        name = other["username"] if other and other.get("username") else "—"
        unread = c["unread_counter"]
        badge = f"🔵{unread} " if unread else ""
        last = c["last_message"]
        preview = (last["text"] if last else "")[:28]
        lines.append(f"{badge}<b>{esc(name)}</b> · {esc(preview) if preview else '…'}")

    nav = []
    if total_pages > 1:
        nav.append(btn(f"‹", f"chats_p:{page-1}" if page > 0 else f"chats_p:0"))
        nav.append(btn(f"{page+1}/{total_pages}", "noop"))
        nav.append(btn(f"›", f"chats_p:{page+1}" if page < total_pages - 1 else f"chats_p:{page}"))

    rows = []
    for c in chunk:
        other = automation.other_participant(c, viewer)
        name = other["username"] if other and other.get("username") else "чат"
        rows.append([btn(f"💬 {name[:24]}", f"chat:{c['id']}")])
    if nav:
        rows.append(nav)
    rows.append([btn("✅ Прочитать все", "readall"), btn("‹ Меню", "menu")])

    text = "\n".join(lines)
    if edit:
        await message.edit_text(text, reply_markup=kb(rows))
    else:
        await message.answer(text, reply_markup=kb(rows))


@router.callback_query(F.data == "chats")
async def chats_cb(cq: CallbackQuery):
    await cq.answer()
    await render_chats(cq.message, edit=True)


@router.callback_query(F.data.startswith("chats_p:"))
async def chats_page_cb(cq: CallbackQuery):
    await cq.answer()
    page = int(cq.data.split(":")[1])
    await render_chats(cq.message, page=page, edit=True)


# ================= Чат (сообщения) =================

async def render_chat(cq: CallbackQuery, chat_id: str):
    await cq.answer()
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        viewer = await client.get_viewer()
        res = await client.get_messages(chat_id, 24)
    except AuthError as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}\nОбновите сессию: /login")
        return
    except Exception as exc:
        await cq.message.answer(f"⚠️ Ошибка: {esc(exc)}")
        return
    finally:
        await client.close()

    msgs = res["messages"]
    msgs.sort(key=lambda m: m["created_at"] or "")
    shown = msgs[-12:]
    lines = [f"💬 <b>Сообщения</b> ({res['total_count']})\n"]
    for m in shown:
        who = (m["user"] or {})
        name = who.get("username") or "—"
        mine = who.get("id") == viewer["id"]
        prefix = "Вы" if mine else name
        body = m["text"] or (f"(событие: {m['event']})" if m.get("event") else "…")
        lines.append(f"[{time_str(m['created_at'])}] <b>{esc(prefix)}</b>: {esc(body[:120])}")

    kbd = kb([
        [btn("✍️ Ответить", f"reply:{chat_id}"), btn("📋 Шаблоны", f"tpl_send_list:{chat_id}")],
        [btn("✅ Прочитан", f"read:{chat_id}")],
        [btn("‹ Чаты", "chats")],
    ])
    await cq.message.edit_text("\n".join(lines)[:4000], reply_markup=kbd)


@router.callback_query(F.data.startswith("chat:"))
async def chat_cb(cq: CallbackQuery):
    chat_id = cq.data.split(":", 1)[1]
    await render_chat(cq, chat_id)


# ================= Ответить (FSM) =================

@router.callback_query(F.data.startswith("reply:"))
async def reply_cb(cq: CallbackQuery, state: FSMContext):
    chat_id = cq.data.split(":", 1)[1]
    await state.set_state(Form.reply)
    await state.update_data(chat_id=chat_id)
    await cq.answer()
    await cq.message.answer(
        "✍️ Введите текст сообщения (поддерживаются переменные <code>{{username}}</code> и <code>{{time}}</code>):"
    )


@router.message(Form.reply)
async def reply_receive(message: Message, state: FSMContext):
    data = await state.get_data()
    chat_id = data.get("chat_id")
    await state.clear()
    if not chat_id:
        await message.answer("Ошибка: не выбран чат.")
        return

    client = await _get_client(message.from_user.id)
    if not client:
        await message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        viewer = await client.get_viewer()
        chats_data = await client.get_chats(max_pages=5)
        chat = next((c for c in chats_data["chats"] if c["id"] == chat_id), None)
        user = automation.other_participant(chat, viewer) if chat else None
        name = user["username"] if user and user.get("username") else "покупатель"
        text = (message.text or "").replace("{{username}}", name).replace(
            "{{time}}", time.strftime("%H:%M")
        )
        await client.send_message(chat_id, text)
    except AuthError as exc:
        await message.answer(f"⚠️ {esc(exc)}\nОбновите сессию: /login")
        return
    except Exception as exc:
        await message.answer(f"⚠️ Ошибка: {esc(exc)}")
        return
    finally:
        await client.close()

    await message.answer("✅ Сообщение отправлено.", reply_markup=back_kb("chats"))


# ================= Прочитать =================

@router.callback_query(F.data.startswith("read:"))
async def read_one_cb(cq: CallbackQuery):
    chat_id = cq.data.split(":", 1)[1]
    await cq.answer("Отмечаю прочитанным…")
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        await client.mark_chat_read(chat_id)
    except Exception as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}")
        return
    finally:
        await client.close()
    await cq.answer("Прочитан ✅")


@router.callback_query(F.data == "readall")
async def read_all_cb(cq: CallbackQuery):
    await cq.answer("Обрабатываю…")
    data = await fetch_chats(cq.from_user.id, max_pages=40)
    if data is None:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    unread = [c for c in data["chats"] if c["unread_counter"] > 0]
    if not unread:
        await cq.message.answer("Непрочитанных чатов нет.")
        return

    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    done = 0
    failed = 0
    try:
        for c in unread:
            try:
                await client.mark_chat_read(c["id"])
                done += 1
            except Exception:
                failed += 1
            await asyncio.sleep(0.1)
    finally:
        await client.close()
    _cache.pop(f"chats:{cq.from_user.id}:5", None)
    _cache.pop(f"chats:{cq.from_user.id}:40", None)
    await cq.message.answer(
        f"✅ Все чаты отмечены: {done}" + (f", ошибок: {failed}" if failed else ""),
        reply_markup=back_kb("chats"),
    )


# ================= Лоты =================

STATUS_FILTERS = [
    ("APPROVED", "Активные"),
    ("EXPIRED", "Истёкшие"),
    ("DRAFT", "Черновики"),
    ("SOLD", "Проданные"),
    ("ALL", "Все"),
]


async def fetch_items(user_id: int, statuses=None):
    key = f"items:{user_id}:{','.join(statuses or [])}"
    cached = cache_get(key)
    if cached:
        return cached
    client = await _get_client(user_id)
    if not client:
        return None
    try:
        data = await client.get_items(statuses=statuses, max_pages=30)
    finally:
        await client.close()
    cache_set(key, data)
    return data


async def render_lots(cq: CallbackQuery, filter_status: str = "ALL", page: int = 0, edit: bool = True):
    await cq.answer()
    statuses = None if filter_status == "ALL" else [filter_status]
    data = await fetch_items(cq.from_user.id, statuses)
    if data is None:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    items = data["items"]
    per_page = 6
    total_pages = max(1, (len(items) + per_page - 1) // per_page)
    page = max(0, min(page, total_pages - 1))
    chunk = items[page * per_page:(page + 1) * per_page]

    if not items:
        await cq.message.answer("📦 Лотов нет.", reply_markup=back_kb())
        return

    lines = [f"📦 <b>Лоты</b> · {len(items)} шт.\n"]
    for it in chunk:
        p = money(it["price"])
        extra = []
        if it.get("priority") == "PREMIUM":
            extra.append("⭐премиум")
        if it.get("views_counter"):
            extra.append(f"👁{it['views_counter']}")
        suffix = " · " + " ".join(extra) if extra else ""
        lines.append(f"• <b>{esc(it['name'][:40])}</b> — {p} [{status_label(it['status'])}]{suffix}")

    filter_btns = [
        btn(("✓" if filter_status == fs else "") + label, f"lots_f:{fs}")
        for fs, label in STATUS_FILTERS
    ]

    rows = []
    for it in chunk:
        if it["status"] == "APPROVED":
            rows.append([btn(f"⬆️ Поднять: {esc(it['name'][:18])}", f"lot_bump:{it['id']}")])
        elif it["status"] in ("EXPIRED", "DRAFT"):
            rows.append([btn(f"♻️ Выставить: {esc(it['name'][:18])}", f"lot_relist:{it['id']}")])

    nav = []
    if total_pages > 1:
        nav = [
            btn("‹", f"lots_p:{filter_status}:{page-1}" if page > 0 else f"lots_p:{filter_status}:0"),
            btn(f"{page+1}/{total_pages}", "noop"),
            btn("›", f"lots_p:{filter_status}:{page+1}" if page < total_pages-1 else f"lots_p:{filter_status}:{page}"),
        ]
    rows.append(filter_btns)
    if nav:
        rows.append(nav)
    rows.append([btn("⬇️ Экспорт CSV", "lots_csv"), btn("‹ Меню", "menu")])

    text = "\n".join(lines)[:4000]
    if edit:
        await cq.message.edit_text(text, reply_markup=kb(rows))
    else:
        await cq.message.answer(text, reply_markup=kb(rows))


@router.callback_query(F.data == "lots")
async def lots_cb(cq: CallbackQuery):
    await render_lots(cq, "ALL")


@router.callback_query(F.data.startswith("lots_f:"))
async def lots_filter_cb(cq: CallbackQuery):
    await render_lots(cq, cq.data.split(":", 1)[1])


@router.callback_query(F.data.startswith("lots_p:"))
async def lots_page_cb(cq: CallbackQuery):
    _, fs, page = cq.data.split(":")
    await render_lots(cq, fs, int(page))


@router.callback_query(F.data == "lots_csv")
async def lots_csv_cb(cq: CallbackQuery):
    await cq.answer()
    data = await fetch_items(cq.from_user.id)
    if not data:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    csv_text = analytics.items_to_csv(data["items"])
    await cq.message.answer_document(
        BufferedInputFile(csv_text.encode("utf-8-sig"), filename="lots.csv"),
        caption=f"Каталог лотов ({len(data['items'])} шт.)",
    )


# ================= Ручные поднять/выставить =================

async def pick_priority(client: PlayerokClient, item_id: str, price: float, mode: str):
    statuses = await client.get_priority_statuses(item_id, price)
    free = automation.free_status(statuses)
    paid = sorted([s for s in statuses if s["price"] > 0], key=lambda s: s["price"])
    return statuses, free, paid


def fmt_statuses(statuses, free, paid):
    lines = []
    if free:
        lines.append(f"0 ₽ — бесплатно")
    for s in paid[:8]:
        lines.append(f"{money(s['price'])} — {s['name'] or 'тариф'}")
    return lines


@router.callback_query(F.data.startswith("lot_bump:"))
async def lot_bump_cb(cq: CallbackQuery):
    item_id = cq.data.split(":", 1)[1]
    await cq.answer("Загружаю тарифы…")
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        items = (await fetch_items(cq.from_user.id, ["APPROVED"])) or {"items": []}
        item = next((i for i in items["items"] if i["id"] == item_id), None)
        if not item:
            await cq.message.answer("Лот не найден (обновите список).")
            return
        statuses, free, paid = await pick_priority(client, item_id, item["price"], "bump")
        lines = fmt_statuses(statuses, free, paid)
        # для поднятия расширение берёт только бесплатный тариф; платный — опционально
        buttons = []
        if free:
            buttons.append([btn(f"Бесплатно — поднять", f"bump_do:{item_id}:{free['id']}")])
        for s in paid[:6]:
            buttons.append([btn(f"{money(s['price'])} — поднять", f"bump_do:{item_id}:{s['id']}")])
        buttons.append([btn("‹ Лоты", "lots")])
        await cq.message.answer(
            f"⬆️ <b>Поднять «{esc(item['name'])}»</b>\n\nТарифы:\n" + "\n".join(lines),
            reply_markup=kb(buttons),
        )
    except Exception as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}")
    finally:
        await client.close()


@router.callback_query(F.data.startswith("lot_relist:"))
async def lot_relist_cb(cq: CallbackQuery):
    item_id = cq.data.split(":", 1)[1]
    await cq.answer("Загружаю тарифы…")
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        items = (await fetch_items(cq.from_user.id)) or {"items": []}
        item = next((i for i in items["items"] if i["id"] == item_id), None)
        if not item:
            await cq.message.answer("Лот не найден (обновите список).")
            return
        statuses, free, paid = await pick_priority(client, item_id, item["price"], "relist")
        lines = fmt_statuses(statuses, free, paid)
        buttons = []
        if free:
            buttons.append([btn(f"Бесплатно — выставить", f"relist_do:{item_id}:{free['id']}")])
        for s in paid[:6]:
            buttons.append([btn(f"{money(s['price'])} — выставить", f"relist_do:{item_id}:{s['id']}")])
        buttons.append([btn("‹ Лоты", "lots")])
        await cq.message.answer(
            f"♻️ <b>Выставить «{esc(item['name'])}»</b>\n\nТарифы:\n" + "\n".join(lines),
            reply_markup=kb(buttons),
        )
    except Exception as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}")
    finally:
        await client.close()


@router.callback_query(F.data.startswith("bump_do:"))
async def bump_do_cb(cq: CallbackQuery):
    _, item_id, sid = cq.data.split(":")
    await cq.answer("Поднимаю…")
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        res = await client.increase_item_priority(item_id, sid)
        await cq.message.answer(f"✅ Лот «{esc(res['item']['name'])}» поднят.", reply_markup=back_kb("lots"))
    except Exception as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}")
    finally:
        await client.close()


@router.callback_query(F.data.startswith("relist_do:"))
async def relist_do_cb(cq: CallbackQuery):
    _, item_id, sid = cq.data.split(":")
    await cq.answer("Выставляю…")
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        res = await client.publish_item(item_id, sid)
        await cq.message.answer(f"✅ Лот «{esc(res['item']['name'])}» выставлен.", reply_markup=back_kb("lots"))
    except Exception as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}")
    finally:
        await client.close()


# ================= Авто =================

def switch_row(key: str, checked: bool, label: str, description: str):
    return [
        btn(f"{'✅' if checked else '☐'} {label}", f"toggle:{key}"),
        btn("ℹ️", f"info:{key}"),
    ], description


def settings_desc(rec: dict) -> dict:
    """Возвращает {key: (label, checked, description)} для тумблеров."""
    s = rec["settings"]
    return {
        "automation.enabled": (
            "Чат-автоматизация", s["automation"]["enabled"],
            "Автоответы по командам + уведомления о новых сообщениях",
        ),
        "automation.keyword_enabled": (
            "Ответы по командам", s["automation"]["keyword_enabled"],
            "Отвечать, когда сообщение начинается с ключевой команды",
        ),
        "automation.auto_read": (
            "Авто-прочтение", s["automation"]["auto_read"],
            "Отмечать чаты прочитанными после обработки",
        ),
        "bump.enabled": (
            "Авто-поднятие", s["bump"]["enabled"],
            "Бесплатно поднимать активные лоты",
        ),
        "relist.enabled": (
            "Авто-перевыставление", s["relist"]["enabled"],
            "Выставлять истёкшие лоты заново",
        ),
        "relist.paid_enabled": (
            "Платное перевыставление", s["relist"]["paid_enabled"],
            "Разрешить платный тариф (списание с баланса)",
        ),
        "return_message.enabled": (
            "Сообщение при возврате", s["return_message"]["enabled"],
            "Слать сообщение покупателю при возврате сделки",
        ),
    }


@router.callback_query(F.data == "auto")
async def auto_cb(cq: CallbackQuery):
    await cq.answer()
    rec = await storage.load(cq.from_user.id)
    s = rec["settings"]

    text_lines = ["⚙️ <b>Авто</b>\n"]
    descs = settings_desc(rec)
    rows = []
    for key, (label, checked, desc) in descs.items():
        text_lines.append(f"{'✅' if checked else '☐'} <b>{esc(label)}</b> — {esc(desc)}")
        rows.append([btn(f"{'✅' if checked else '☐'} {label}", f"toggle:{key}")])

    # числовые настройки
    text_lines.append("")
    text_lines.append(
        f"Задержка автоответа: <b>{s['automation']['delay_seconds']}с</b> · "
        f"лимит: <b>{s['automation']['hourly_limit']}/час</b> · опрос: <b>{s['automation']['poll_seconds']}с</b>"
    )
    text_lines.append(
        f"Перевыставление: макс. <b>{money(s['relist']['max_price_per_item'])}</b> · "
        f"мин.баланс <b>{money(s['relist']['min_balance'])}</b> · задержка <b>{s['relist']['delay_minutes']} мин</b>"
    )

    rows.append([
        btn("⚙️ Параметры автоответа", "setparams"),
        btn("⚙️ Параметры перевыставления", "setrelistparams"),
    ])
    rows.append([
        btn("⬆️ Поднять сейчас", "runbump"),
        btn("♻️ Перевыставить сейчас", "runrelist_confirm"),
    ])
    rows.append([
        btn("💬 Команды", "commands"),
        btn("📜 Журнал", "auto_log"),
    ])
    rows.append([btn("‹ Меню", "menu")])

    await cq.message.edit_text("\n".join(text_lines)[:4000], reply_markup=kb(rows))


# тумблер
@router.callback_query(F.data.startswith("toggle:"))
async def toggle_cb(cq: CallbackQuery):
    key = cq.data.split(":", 1)[1]
    parts = key.split(".")
    if len(parts) == 2:
        section, field = parts
    else:
        await cq.answer()
        return

    def mutate(rec):
        rec["settings"][section][field] = not rec["settings"][section][field]
        # флаг accepted при первом включении
        if rec["settings"][section][field]:
            rec["settings"][section]["accepted"] = True

    await storage.update(cq.from_user.id, mutate)
    await cq.answer("Сохранено ✅")
    await auto_cb(cq)


@router.callback_query(F.data == "info:automation.enabled")
async def _noop(cq: CallbackQuery):
    await cq.answer()


@router.callback_query(F.data.startswith("info:"))
async def info_cb(cq: CallbackQuery):
    key = cq.data.split(":", 1)[1]
    descs = settings_desc(await storage.load(cq.from_user.id))
    if key in descs:
        await cq.answer(descs[key][2], show_alert=True)
    else:
        await cq.answer()


@router.callback_query(F.data == "runbump")
async def runbump_cb(cq: CallbackQuery):
    await cq.answer("Запускаю цикл поднятия…")
    await cq.message.answer("⬆️ Запускаю ручной цикл поднятия…")
    await automation.bump_cycle(cq.from_user.id, manual=True)
    await cq.message.answer("Готово. См. /menu → Авто → Журнал.", reply_markup=back_kb("auto"))


@router.callback_query(F.data == "runrelist_confirm")
async def runrelist_confirm_cb(cq: CallbackQuery):
    rec = await storage.load(cq.from_user.id)
    paid = rec["settings"]["relist"]["paid_enabled"]
    await cq.answer()
    if paid:
        await cq.message.answer(
            "♻️ Запустить перевыставление? Включён платный тариф — деньги спишутся с баланса.",
            reply_markup=yesno_kb("runrelist"),
        )
    else:
        await cq.message.answer("♻️ Запускаю перевыставление (только бесплатный тариф)…")
        await automation.relist_cycle(cq.from_user.id, manual=True, force_paid_ok=True)
        await cq.message.answer("Готово. См. Журнал.", reply_markup=back_kb("auto"))


@router.callback_query(F.data == "runrelist")
async def runrelist_cb(cq: CallbackQuery):
    await cq.answer()
    await cq.message.answer("♻️ Запускаю перевыставление…")
    await automation.relist_cycle(cq.from_user.id, manual=True, force_paid_ok=True)
    await cq.message.answer("Готово. См. Журнал.", reply_markup=back_kb("auto"))


@router.callback_query(F.data == "auto_log")
async def auto_log_cb(cq: CallbackQuery):
    await cq.answer()
    rec = await storage.load(cq.from_user.id)
    log = rec["runtime"].get("automation_log", [])
    if not log:
        await cq.message.answer("Журнал пуст.", reply_markup=back_kb("auto"))
        return
    lines = ["📜 <b>Журнал автоматизации</b>\n"]
    for e in log[-30:]:
        t = time.strftime("%H:%M", time.localtime(e["at"] / 1000))
        icon = {"error": "❌", "warn": "⚠️"}.get(e.get("kind"), "•")
        lines.append(f"{t} {icon} {esc(e['message'])[:140]}")
    await cq.message.edit_text("\n".join(lines)[:4000], reply_markup=back_kb("auto"))


# ================= Настройки (шаблоны, команды, бэкап) =================

@router.callback_query(F.data == "settings")
async def settings_cb(cq: CallbackQuery):
    await cq.answer()
    rec = await storage.load(cq.from_user.id)
    tpl_count = len(rec["settings"]["templates"])
    cmd_count = len(rec["settings"]["automation"]["rules"])
    text = (
        "🔧 <b>Настройки</b>\n\n"
        f"📋 Шаблоны: <b>{tpl_count}</b>\n"
        f"💬 Команды: <b>{cmd_count}</b>\n\n"
        "Выберите раздел:"
    )
    kbd = kb([
        [btn("📋 Шаблоны", "templates"), btn("💬 Команды", "commands")],
        [btn("💾 Резервная копия", "backup")],
        [btn("🔓 Отключить аккаунт", "logout")],
        [btn("‹ Меню", "menu")],
    ])
    await cq.message.edit_text(text, reply_markup=kbd)


@router.callback_query(F.data == "logout")
async def logout_cb(cq: CallbackQuery):
    await cq.answer()
    await storage.set_cookies(cq.from_user.id, None)
    _cache.clear()
    await cq.message.edit_text("🔓 Аккаунт отключён.", reply_markup=menu_kb())


# ---- Шаблоны ----

@router.callback_query(F.data == "templates")
async def templates_cb(cq: CallbackQuery):
    await cq.answer()
    rec = await storage.load(cq.from_user.id)
    tpls = rec["settings"]["templates"]
    lines = ["📋 <b>Шаблоны</b>\n"]
    rows = []
    for t in tpls:
        lines.append(f"• <b>{esc(t['title'])}</b>: {esc(t['text'][:60])}")
        rows.append([btn(f"🗑 {esc(t['title'][:24])}", f"tpl_del:{t['id']}")])
    if not tpls:
        lines.append("(пусто)")
    rows.append([btn("➕ Добавить", "tpl_add"), btn("‹ Настройки", "settings")])
    await cq.message.edit_text("\n".join(lines)[:4000], reply_markup=kb(rows))


@router.callback_query(F.data == "tpl_add")
async def tpl_add_cb(cq: CallbackQuery, state: FSMContext):
    await state.set_state(Form.add_template)
    await cq.answer()
    await cq.message.answer(
        "➕ Введите шаблон в формате:\n<code>Название | текст сообщения</code>\n\n"
        "Пример:\n<code>Доставка | Отправим в течение {{time}}</code>"
    )


@router.message(Form.add_template)
async def tpl_add_receive(message: Message, state: FSMContext):
    await state.clear()
    raw = message.text or ""
    if "|" not in raw:
        await message.answer("Неверный формат. Нужно: <code>Название | текст</code>")
        return
    title, text = raw.split("|", 1)
    title = title.strip()
    text = text.strip()
    if not title or not text:
        await message.answer("Название и текст не должны быть пустыми.")
        return
    tpl = {"id": f"t{uuid.uuid4().hex[:8]}", "title": title[:40], "text": text[:4000]}
    await storage.update(message.from_user.id, lambda r: r["settings"]["templates"].append(tpl))
    await message.answer(f"✅ Шаблон «{esc(title)}» добавлен.", reply_markup=back_kb("templates"))


@router.callback_query(F.data.startswith("tpl_del:"))
async def tpl_del_cb(cq: CallbackQuery):
    tpl_id = cq.data.split(":", 1)[1]
    await storage.update(
        cq.from_user.id,
        lambda r: r["settings"].update(
            templates=[t for t in r["settings"]["templates"] if t["id"] != tpl_id]
        ),
    )
    await cq.answer("Удалён 🗑")
    await templates_cb(cq)


# ---- Отправка шаблона в чат ----

@router.callback_query(F.data.startswith("tpl_send_list:"))
async def tpl_send_list_cb(cq: CallbackQuery):
    chat_id = cq.data.split(":", 1)[1]
    await cq.answer()
    rec = await storage.load(cq.from_user.id)
    tpls = rec["settings"]["templates"]
    rows = [
        [btn(f"📋 {t['title'][:26]}", f"tpl_send:{t['id']}:{chat_id}")]
        for t in tpls
    ]
    rows.append([btn("‹ Чат", f"chat:{chat_id}")])
    await cq.message.answer("Выберите шаблон для отправки:", reply_markup=kb(rows))


@router.callback_query(F.data.startswith("tpl_send:"))
async def tpl_send_cb(cq: CallbackQuery):
    _, tpl_id, chat_id = cq.data.split(":", 2)
    await cq.answer()
    rec = await storage.load(cq.from_user.id)
    tpl = next((t for t in rec["settings"]["templates"] if t["id"] == tpl_id), None)
    if not tpl:
        await cq.message.answer("Шаблон не найден.")
        return
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        viewer = await client.get_viewer()
        chats_data = await client.get_chats(max_pages=5)
        chat = next((c for c in chats_data["chats"] if c["id"] == chat_id), None)
        user = automation.other_participant(chat, viewer) if chat else None
        name = user["username"] if user and user.get("username") else "покупатель"
        text = (tpl["text"] or "").replace("{{username}}", name).replace(
            "{{time}}", time.strftime("%H:%M")
        )
        await client.send_message(chat_id, text)
    except AuthError as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}\nОбновите сессию: /login")
        return
    except Exception as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}")
        return
    finally:
        await client.close()
    await cq.message.answer("✅ Шаблон отправлен.", reply_markup=back_kb(f"chat:{chat_id}"))


# ---- Команды ----

@router.callback_query(F.data == "commands")
async def commands_cb(cq: CallbackQuery):
    await cq.answer()
    rec = await storage.load(cq.from_user.id)
    rules = rec["settings"]["automation"]["rules"]
    lines = ["💬 <b>Команды</b> (ответ при начале сообщения с команды)\n"]
    rows = []
    for i, r in enumerate(rules):
        on = "✅" if r.get("enabled") is not False else "☐"
        lines.append(f"{on} <b>{esc(r.get('keyword',''))}</b> → {esc(r.get('response','')[:50])}")
        rows.append([
            btn(f"{on} {esc(r.get('keyword','')[:20])}", f"cmd_toggle:{i}"),
            btn("🗑", f"cmd_del:{i}"),
        ])
    if not rules:
        lines.append("(пусто)")
    rows.append([btn("➕ Добавить", "cmd_add"), btn("‹ Настройки", "settings")])
    await cq.message.edit_text("\n".join(lines)[:4000], reply_markup=kb(rows))


@router.callback_query(F.data == "cmd_add")
async def cmd_add_cb(cq: CallbackQuery, state: FSMContext):
    await state.set_state(Form.add_command)
    await cq.answer()
    await cq.message.answer(
        "➕ Введите команду в формате:\n<code>ключевое слово | ответ</code>\n\n"
        "Пример:\n<code>как купить | Напишите в чат, и я вышлю инструкцию</code>\n\n"
        "В ответе можно использовать {{username}} и {{time}}."
    )


@router.message(Form.add_command)
async def cmd_add_receive(message: Message, state: FSMContext):
    await state.clear()
    raw = message.text or ""
    if "|" not in raw:
        await message.answer("Неверный формат. Нужно: <code>команда | ответ</code>")
        return
    keyword, response = raw.split("|", 1)
    keyword = keyword.strip()
    response = response.strip()
    if not keyword or not response:
        await message.answer("Команда и ответ не должны быть пустыми.")
        return
    await storage.update(
        message.from_user.id,
        lambda r: r["settings"]["automation"]["rules"].append(
            {"keyword": keyword[:80], "response": response[:4000], "enabled": True}
        ),
    )
    await message.answer(f"✅ Команда «{esc(keyword)}» добавлена.", reply_markup=back_kb("commands"))


@router.callback_query(F.data.startswith("cmd_del:"))
async def cmd_del_cb(cq: CallbackQuery):
    idx = int(cq.data.split(":", 1)[1])
    await storage.update(
        cq.from_user.id,
        lambda r: (r["settings"]["automation"]["rules"].pop(idx)
                   if idx < len(r["settings"]["automation"]["rules"]) else None),
    )
    await cq.answer("Удалена 🗑")
    await commands_cb(cq)


@router.callback_query(F.data.startswith("cmd_toggle:"))
async def cmd_toggle_cb(cq: CallbackQuery):
    idx = int(cq.data.split(":", 1)[1])
    def mutate(rec):
        rules = rec["settings"]["automation"]["rules"]
        if idx < len(rules):
            rules[idx]["enabled"] = rules[idx].get("enabled") is False
    await storage.update(cq.from_user.id, mutate)
    await cq.answer()
    await commands_cb(cq)


# ---- Параметры (числовые) ----

PARAM_KEYS = {
    "delay_seconds": ("automation", "delay_seconds", "Задержка автоответа, сек (2–60)"),
    "hourly_limit": ("automation", "hourly_limit", "Лимит автоответов в час (1–60)"),
    "poll_seconds": ("automation", "poll_seconds", "Период опроса чатов, сек (10–300)"),
    "max_price_per_item": ("relist", "max_price_per_item", "Макс. сумма за перевыставление, ₽ (0 = без лимита)"),
    "min_balance": ("relist", "min_balance", "Мин. баланс, ₽"),
    "delay_minutes": ("relist", "delay_minutes", "Задержка перевыставления, минут (1–120)"),
}


@router.callback_query(F.data == "setparams")
async def setparams_cb(cq: CallbackQuery):
    await cq.answer()
    kbd = kb([
        [btn("Задержка автоответа", "set:delay_seconds")],
        [btn("Лимит в час", "set:hourly_limit")],
        [btn("Период опроса", "set:poll_seconds")],
        [btn("‹ Авто", "auto")],
    ])
    await cq.message.edit_text("⚙️ <b>Параметры автоответа</b>", reply_markup=kbd)


@router.callback_query(F.data == "setrelistparams")
async def setrelistparams_cb(cq: CallbackQuery):
    await cq.answer()
    kbd = kb([
        [btn("Макс. сумма", "set:max_price_per_item")],
        [btn("Мин. баланс", "set:min_balance")],
        [btn("Задержка, мин", "set:delay_minutes")],
        [btn("Текст при возврате", "set:return_text")],
        [btn("‹ Авто", "auto")],
    ])
    await cq.message.edit_text("⚙️ <b>Параметры перевыставления и возврата</b>", reply_markup=kbd)


@router.callback_query(F.data.startswith("set:"))
async def set_cb(cq: CallbackQuery, state: FSMContext):
    key = cq.data.split(":", 1)[1]
    await cq.answer()
    if key == "return_text":
        await state.set_state(Form.set_value)
        await state.update_data(set_key=key)
        rec = await storage.load(cq.from_user.id)
        cur = rec["settings"]["return_message"]["text"]
        await cq.message.answer(
            "↩️ Текст сообщения при возврате ({{username}}, {{item}}, {{time}}):\n\n"
            f"Текущий:\n<code>{esc(cur)}</code>\n\nОтправьте новый текст:"
        )
        return
    if key not in PARAM_KEYS:
        return
    section, field, desc = PARAM_KEYS[key]
    await state.set_state(Form.set_value)
    await state.update_data(set_key=key)
    rec = await storage.load(cq.from_user.id)
    cur = rec["settings"][section][field]
    await cq.message.answer(f"⚙️ {esc(desc)}\nТекущее значение: <b>{esc(cur)}</b>\nОтправьте новое число:")


@router.message(Form.set_value)
async def set_value_receive(message: Message, state: FSMContext):
    data = await state.get_data()
    key = data.get("set_key")
    await state.clear()
    raw = (message.text or "").strip()

    if key == "return_text":
        if not raw:
            await message.answer("Текст не может быть пустым.")
            return
        await storage.update(
            message.from_user.id,
            lambda r: r["settings"]["return_message"].update(text=raw[:4000]),
        )
        await message.answer("✅ Текст сохранён.", reply_markup=back_kb("auto"))
        return

    if key not in PARAM_KEYS:
        return
    section, field, desc = PARAM_KEYS[key]
    try:
        val = float(raw.replace(",", "."))
    except ValueError:
        await message.answer("Введите число.")
        return
    val = int(val)
    limits = {
        "delay_seconds": (2, 60),
        "hourly_limit": (1, 60),
        "poll_seconds": (10, 300),
        "max_price_per_item": (0, 100000),
        "min_balance": (0, 1000000),
        "delay_minutes": (1, 120),
    }
    lo, hi = limits.get(key, (0, 10**9))
    val = max(lo, min(hi, val))
    await storage.update(
        message.from_user.id,
        lambda r: r["settings"][section].update({field: val}),
    )
    await message.answer(f"✅ {esc(desc)}: <b>{val}</b>", reply_markup=back_kb("auto"))


# ---- Резервная копия ----

@router.callback_query(F.data == "backup")
async def backup_cb(cq: CallbackQuery):
    await cq.answer()
    rec = await storage.load(cq.from_user.id)
    payload = {
        "settings": rec["settings"],
        "exported_at": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    # cookies не экспортируем
    data = json.dumps(payload, ensure_ascii=False, indent=2)
    await cq.message.answer_document(
        BufferedInputFile(data.encode("utf-8"), filename="playerok-tools-backup.json"),
        caption="💾 Резервная копия настроек (без cookies).",
    )


# ================= Аналитика =================

@router.callback_query(F.data == "stats")
async def stats_cb(cq: CallbackQuery):
    await cq.answer()
    kbd = kb([
        [btn("7 дней", "stats:7"), btn("30 дней", "stats:30"),
         btn("90 дней", "stats:90"), btn("Вся история", "stats:0")],
        [btn("⬇️ Экспорт CSV", "stats_csv")],
        [btn("‹ Меню", "menu")],
    ])
    await cq.message.edit_text("📈 <b>Аналитика</b>\nВыберите период:", reply_markup=kbd)


@router.callback_query(F.data.startswith("stats:"))
async def stats_period_cb(cq: CallbackQuery):
    days = int(cq.data.split(":", 1)[1])
    await cq.answer("Считаю…")
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        data = await client.get_deals(max_pages=60)
    except AuthError as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}\nОбновите сессию: /login")
        return
    except Exception as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}")
        return
    finally:
        await client.close()

    period = None if days == 0 else days
    r = analytics.compute(data["deals"], period)
    label = "вся история" if days == 0 else f"{days} дней"

    lines = [
        f"📈 <b>Аналитика</b> · {esc(label)}",
        "",
        f"Продажи: <b>{r['sales_count']}</b>",
        f"Оборот: <b>{money(r['revenue'])}</b>",
        f"Средний чек: <b>{money(r['avg_check'])}</b>",
        f"Проблемные сделки: <b>{r['problem_count']}</b>",
    ]
    if r["top_items"]:
        lines.append("")
        lines.append("<b>Топ товаров по обороту:</b>")
        for it in r["top_items"][:7]:
            lines.append(f"• {esc(it['name'][:30])} — {money(it['revenue'])} ({it['count']} шт.)")

    kbd = kb([
        [btn("‹ Периоды", "stats")],
    ])
    await cq.message.edit_text("\n".join(lines)[:4000], reply_markup=kbd)


@router.callback_query(F.data == "stats_csv")
async def stats_csv_cb(cq: CallbackQuery):
    await cq.answer("Собираю…")
    client = await _get_client(cq.from_user.id)
    if not client:
        await cq.message.answer("Сначала подключите аккаунт: /login")
        return
    try:
        data = await client.get_deals(max_pages=60)
    except Exception as exc:
        await cq.message.answer(f"⚠️ {esc(exc)}")
        return
    finally:
        await client.close()
    csv_text = analytics.to_csv(data["deals"])
    await cq.message.answer_document(
        BufferedInputFile(csv_text.encode("utf-8-sig"), filename="deals.csv"),
        caption=f"Сделки ({len(data['deals'])} шт.)",
    )


# ================= Админ-панель (владелец) =================

async def _require_owner(message: Message) -> bool:
    if not await storage.is_owner(message.from_user.id):
        await message.answer("⛔ Только для владельца.")
        return False
    return True


def status_icon(u: dict) -> str:
    st = u.get("status")
    if st == "owner":
        return "👑"
    if st == "active":
        until = u.get("until")
        if until and int(until) < int(time.time()):
            return "⏰"
        return "✅"
    if st == "revoked":
        return "🚫"
    return "—"


@router.message(Command("admin"))
async def admin_cmd(message: Message, state: FSMContext):
    if not await _require_owner(message):
        return
    await state.clear()
    await render_admin(message, edit=False)


@router.callback_query(F.data == "admin")
async def admin_cb(cq: CallbackQuery):
    if not await storage.is_owner(cq.from_user.id):
        await cq.answer("⛔ Только для владельца.", show_alert=True)
        return
    await cq.answer()
    await render_admin(cq.message, edit=True)


async def render_admin(message: Message, edit: bool):
    data = await storage.load_admin()
    users = data["users"]
    active = sum(1 for u in users.values() if u.get("status") == "active")
    owner_id = data["owner_id"]

    lines = [f"👑 <b>Админ-панель</b>\n", f"Владелец: <code>{owner_id}</code>", f"Пользователей: {len(users)} · активных: {active}\n"]

    kbd = kb([
        [btn("➕ Выдать доступ", "grant_start"), btn("🚫 Забрать доступ", "revoke_list")],
        [btn("👥 Список пользователей", "user_list")],
        [btn("💰 Цены и реквизиты", "prices")],
        [btn("🧾 Последние платежи", "payments")],
        [btn("‹ Меню", "menu")],
    ])
    text = "\n".join(lines)
    if edit:
        await message.edit_text(text, reply_markup=kbd)
    else:
        await message.answer(text, reply_markup=kbd)


# ---- выдача доступа ----

@router.callback_query(F.data == "grant_start")
async def grant_start_cb(cq: CallbackQuery, state: FSMContext):
    if not await storage.is_owner(cq.from_user.id):
        await cq.answer("⛔", show_alert=True)
        return
    await cq.answer()
    await state.set_state(Form.grant)
    await cq.message.answer(
        "➕ Отправьте <b>@username</b> или числовой <b>ID</b> пользователя, "
        "которому выдаём доступ.\n\n"
        "Доступ выдаётся <b>навсегда</b> (пока не отзовёте)."
    )


@router.message(Command("grant"))
async def grant_cmd(message: Message, state: FSMContext):
    if not await _require_owner(message):
        return
    arg = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else ""
    if not arg:
        await state.set_state(Form.grant)
        await message.answer("Отправьте @username или ID для выдачи доступа.")
        return
    await state.set_state(Form.grant)
    await _grant_receive(message, state)


@router.message(Form.grant)
async def _grant_receive(message: Message, state: FSMContext):
    await state.clear()
    ref = (message.text or "").strip()
    user_id, err = await storage.resolve_user(ref)
    if user_id is None:
        await message.answer(f"❌ {esc(err)}")
        return
    owner_id = (await storage.load_admin())["owner_id"]
    if user_id == int(owner_id):
        await message.answer("Это владелец — ему и так всё доступно.")
        return
    await storage.grant_access(user_id, None, message.from_user.id)
    uname = f"@{ref[1:]}" if ref.startswith("@") else f"ID {user_id}"
    await message.answer(f"✅ Доступ выдан пользователю {esc(uname)} (навсегда).")
    try:
        await bot.send_message(user_id, "✅ Вам выдан доступ к Playerok Tools!\nПодключите аккаунт: /login")
    except Exception:
        pass


# ---- отзыв доступа ----

@router.message(Command("revoke"))
async def revoke_cmd(message: Message):
    if not await _require_owner(message):
        return
    arg = message.text.split(maxsplit=1)[1] if len(message.text.split()) > 1 else ""
    if not arg:
        await render_revoke_list(message, edit=False)
        return
    user_id, err = await storage.resolve_user(arg)
    if user_id is None:
        await message.answer(f"❌ {esc(err)}")
        return
    await storage.revoke_access(user_id)
    await message.answer(f"🚫 Доступ отозван у {esc(arg)}.")


@router.callback_query(F.data == "revoke_list")
async def revoke_list_cb(cq: CallbackQuery):
    if not await storage.is_owner(cq.from_user.id):
        await cq.answer("⛔", show_alert=True)
        return
    await cq.answer()
    await render_revoke_list(cq.message, edit=True)


async def render_revoke_list(message: Message, edit: bool):
    data = await storage.load_admin()
    users = data["users"]
    rows = []
    lines = ["🚫 <b>Отозвать доступ</b>\n"]
    for uid, u in users.items():
        if u.get("status") in ("active",) :
            name = data["known"].get(uid) or ""
            label = f"@{name}" if name else f"ID {uid}"
            rows.append([btn(f"🚫 {label[:24]}", f"revoke:{uid}")])
    if not rows:
        lines.append("Активных пользователей нет.")
    rows.append([btn("‹ Админ", "admin")])
    text = "\n".join(lines)
    if edit:
        await message.edit_text(text, reply_markup=kb(rows))
    else:
        await message.answer(text, reply_markup=kb(rows))


@router.callback_query(F.data.startswith("revoke:"))
async def revoke_one_cb(cq: CallbackQuery):
    if not await storage.is_owner(cq.from_user.id):
        await cq.answer("⛔", show_alert=True)
        return
    uid = cq.data.split(":", 1)[1]
    await storage.revoke_access(int(uid))
    await cq.answer("Доступ отозван 🚫")
    await render_revoke_list(cq.message, edit=True)


# ---- список пользователей ----

@router.callback_query(F.data == "user_list")
async def user_list_cb(cq: CallbackQuery):
    if not await storage.is_owner(cq.from_user.id):
        await cq.answer("⛔", show_alert=True)
        return
    await cq.answer()
    data = await storage.load_admin()
    users = data["users"]
    lines = ["👥 <b>Пользователи</b>\n"]
    for uid, u in users.items():
        name = data["known"].get(uid) or ""
        label = f"@{name}" if name else f"ID {uid}"
        icon = status_icon(u)
        until = u.get("until")
        extra = ""
        if until:
            extra = f" до {time.strftime('%d.%m.%Y', time.localtime(int(until)))}"
        lines.append(f"{icon} <b>{esc(label)}</b> — {u.get('status')}{extra}")
    if len(users) == 1:
        lines.append("Пока только владелец.")
    await cq.message.edit_text("\n".join(lines)[:4000], reply_markup=back_kb("admin"))


# ---- цены ----

@router.message(Command("prices"))
async def prices_cmd(message: Message):
    if not await _require_owner(message):
        return
    await render_prices(message, edit=False)


@router.callback_query(F.data == "prices")
async def prices_cb(cq: CallbackQuery):
    if not await storage.is_owner(cq.from_user.id):
        await cq.answer("⛔", show_alert=True)
        return
    await cq.answer()
    await render_prices(cq.message, edit=True)


async def render_prices(message: Message, edit: bool):
    data = await storage.load_admin()
    p = data["prices"]
    text = (
        "💰 <b>Цены и реквизиты</b>\n\n"
        f"⭐ Звёздами: <b>{p['stars']}</b>\n"
        f"💳 Карта: <b>{p['card_rub']} ₽</b>\n"
        f"Номер карты: <code>{esc(p['card_number'] or 'не указан')}</code>\n"
    )
    kbd = kb([
        [btn("⭐ Цена в звёздах", "price_set:stars"), btn("💳 Цена в ₽", "price_set:card_rub")],
        [btn("🏦 Номер карты", "price_set:card_number")],
        [btn("‹ Админ", "admin")],
    ])
    if edit:
        await message.edit_text(text, reply_markup=kbd)
    else:
        await message.answer(text, reply_markup=kbd)


@router.callback_query(F.data.startswith("price_set:"))
async def price_set_cb(cq: CallbackQuery, state: FSMContext):
    if not await storage.is_owner(cq.from_user.id):
        await cq.answer("⛔", show_alert=True)
        return
    key = cq.data.split(":", 1)[1]
    await cq.answer()
    await state.set_state(Form.set_price)
    await state.update_data(price_key=key)
    if key == "card_number":
        await cq.message.answer("🏦 Отправьте номер карты для переводов:")
    else:
        await cq.message.answer("Отправьте новую цену (число):")


@router.message(Form.set_price)
async def price_receive(message: Message, state: FSMContext):
    data = await state.get_data()
    key = data.get("price_key")
    await state.clear()
    raw = (message.text or "").strip()

    if key == "card_number":
        await storage.set_prices(card_number=raw)
        await message.answer("✅ Номер карты обновлён.")
        await render_prices(message, edit=False)
        return

    try:
        val = int(raw)
    except ValueError:
        await message.answer("Введите число.")
        return
    val = max(1, min(val, 10**7))
    if key == "stars":
        await storage.set_prices(stars=val)
    else:
        await storage.set_prices(card_rub=val)
    await message.answer(f"✅ Цена обновлена: {val}")
    await render_prices(message, edit=False)


# ---- платежи ----

@router.callback_query(F.data == "payments")
async def payments_cb(cq: CallbackQuery):
    if not await storage.is_owner(cq.from_user.id):
        await cq.answer("⛔", show_alert=True)
        return
    await cq.answer()
    data = await storage.load_admin()
    pays = data.get("payments", [])
    if not pays:
        await cq.message.edit_text("🧾 Платежей пока нет.", reply_markup=back_kb("admin"))
        return
    lines = ["🧾 <b>Последние платежи</b>\n"]
    for p in pays[-15:]:
        kind = "⭐" if p["kind"] == "stars" else "💳"
        t = time.strftime("%d.%m %H:%M", time.localtime(p["ts"]))
        name = data["known"].get(str(p["user_id"])) or f"ID {p['user_id']}"
        lines.append(f"{t} {kind} <b>{esc(name)}</b> — {p['amount']} · {p['status']}")
    await cq.message.edit_text("\n".join(lines)[:4000], reply_markup=back_kb("admin"))


# ================= Покупка доступа =================

@router.message(Command("buy"))
async def buy_cmd(message: Message, state: FSMContext):
    await state.clear()
    data = await storage.load_admin()
    p = data["prices"]
    card = p["card_number"] or "не указан"
    text = (
        "💳 <b>Покупка доступа</b>\n\n"
        f"⭐ Звёздами Telegram: <b>{p['stars']} ⭐</b>\n"
        f"💳 Перевод на карту: <b>{p['card_rub']} ₽</b>\n\n"
        "Выберите способ оплаты:"
    )
    kbd = kb([
        [btn(f"⭐ Оплатить звёздами ({p['stars']} ⭐)", "pay_stars")],
        [btn(f"💳 Перевод на карту ({p['card_rub']} ₽)", "pay_card")],
    ])
    await message.answer(text, reply_markup=kbd)


@router.callback_query(F.data == "buy")
async def buy_cb(cq: CallbackQuery):
    await cq.answer()
    data = await storage.load_admin()
    p = data["prices"]
    text = (
        "💳 <b>Покупка доступа</b>\n\n"
        f"⭐ Звёздами Telegram: <b>{p['stars']} ⭐</b>\n"
        f"💳 Перевод на карту: <b>{p['card_rub']} ₽</b>"
    )
    kbd = kb([
        [btn(f"⭐ Оплатить звёздами ({p['stars']} ⭐)", "pay_stars")],
        [btn(f"💳 Перевод на карту ({p['card_rub']} ₽)", "pay_card")],
    ])
    await cq.message.edit_text(text, reply_markup=kbd)


# ---- оплата звёздами ----

@router.callback_query(F.data == "pay_stars")
async def pay_stars_cb(cq: CallbackQuery):
    await cq.answer()
    data = await storage.load_admin()
    stars = data["prices"]["stars"]
    price = LabeledPrice(label="Доступ к Playerok Tools", amount=stars)
    await bot.send_invoice(
        chat_id=cq.from_user.id,
        title="Playerok Tools — доступ",
        description="Доступ к боту Playerok Tools (бессрочный).",
        payload="access_sub",
        currency="XTR",
        prices=[price],
    )


@router.pre_checkout_query()
async def pre_checkout(pcq: PreCheckoutQuery):
    await pcq.answer(ok=True)


@router.message(F.successful_payment)
async def successful_payment(message: Message):
    amount = message.successful_payment.total_amount
    user_id = message.from_user.id
    await storage.grant_access(user_id, None, None)
    await storage.log_payment(user_id, "stars", amount, "paid")
    await message.answer(
        "✅ Оплата получена! Доступ активирован.\n\n"
        "Подключите аккаунт Playerok: /login",
        reply_markup=menu_kb(),
    )
    owner_id = (await storage.load_admin())["owner_id"]
    name = message.from_user.username or f"ID {user_id}"
    try:
        await bot.send_message(owner_id, f"💰 Оплата звёздами: {amount} ⭐ от @{name}")
    except Exception:
        pass


# ---- оплата переводом на карту ----

@router.callback_query(F.data == "pay_card")
async def pay_card_cb(cq: CallbackQuery, state: FSMContext):
    await cq.answer()
    data = await storage.load_admin()
    p = data["prices"]
    card = p["card_number"] or "не указан"
    rub = p["card_rub"]
    await state.set_state(Form.card_amount)
    await cq.message.answer(
        f"💳 <b>Оплата переводом на карту</b>\n\n"
        f"Сумма: <b>{rub} ₽</b>\n"
        f"Карта: <code>{esc(card)}</code>\n\n"
        f"После перевода отправьте <b>сумму</b> (или слово <code>ок</code>), "
        f"чтобы уведомить владельца о платеже."
    )


@router.message(Form.card_amount)
async def card_amount_receive(message: Message, state: FSMContext):
    await state.clear()
    raw = (message.text or "").strip()
    data = await storage.load_admin()
    p = data["prices"]
    owner_id = data["owner_id"]
    user_id = message.from_user.id
    name = message.from_user.username or f"ID {user_id}"

    await storage.log_payment(user_id, "card", raw, "claim")
    try:
        await bot.send_message(
            owner_id,
            f"💳 <b>Заявка на оплату картой</b>\n"
            f"От: @{esc(name)} (<code>{user_id}</code>)\n"
            f"Сообщил сумму: <code>{esc(raw)}</code>\n"
            f"Ожидаемая: {p['card_rub']} ₽\n\n"
            f"Проверьте поступление и выдайте доступ командой:\n"
            f"<code>/grant {user_id}</code>",
        )
    except Exception:
        pass
    await message.answer(
        "✅ Заявка отправлена владельцу.\n"
        "Как только перевод подтвердится, владелец выдаст вам доступ.",
    )


# ================= noop / меню =================

@router.callback_query(F.data == "noop")
async def noop_cb(cq: CallbackQuery):
    await cq.answer()


@router.callback_query(F.data == "menu")
async def menu_cb(cq: CallbackQuery):
    await cq.answer()
    if await storage.is_owner(cq.from_user.id):
        await cq.message.edit_text("📋 Меню", reply_markup=owner_menu_kb())
    else:
        await cq.message.edit_text("📋 Меню", reply_markup=menu_kb())


# ================= запуск =================

# Кнопка меню у поля ввода (MenuButtonCommands) + список команд при вводе «/».
MAIN_COMMANDS = [
    BotCommand(command="start", description="Приветствие и меню"),
    BotCommand(command="menu", description="Главное меню"),
    BotCommand(command="login", description="Подключить аккаунт Playerok"),
    BotCommand(command="logout", description="Отключить аккаунт"),
    BotCommand(command="buy", description="Купить доступ"),
    BotCommand(command="help", description="Справка"),
]

OWNER_COMMANDS = MAIN_COMMANDS + [
    BotCommand(command="admin", description="Админ-панель"),
    BotCommand(command="grant", description="Выдать доступ (@user или ID)"),
    BotCommand(command="revoke", description="Забрать доступ (@user или ID)"),
    BotCommand(command="prices", description="Цены и реквизиты"),
]


async def setup_bot_ui():
    """Устанавливает кнопку меню (по умолчанию) и команды для всех чатов."""
    await bot.set_chat_menu_button(menu_button=MenuButtonCommands())
    await bot.set_my_commands(MAIN_COMMANDS)

    # владельцу — расширенный список команд
    try:
        await bot.set_my_commands(
            OWNER_COMMANDS,
            scope=BotCommandScopeChat(chat_id=config.OWNER_ID),
        )
    except Exception:
        pass


async def main():
    global bot
    bot = make_bot()

    dp.message.middleware(AccessMiddleware())
    dp.callback_query.middleware(AccessMiddleware())
    dp.include_router(router)

    await setup_bot_ui()

    # notifier для автоматизации
    async def notifier(user_id: int, text: str):
        try:
            await bot.send_message(user_id, text)
        except Exception:
            pass

    automation.set_notifier(notifier)
    asyncio.create_task(automation.scheduler_loop())

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
