"""Хранилище настроек и состояния каждого пользователя (JSON-файлы).

Модель повторяет chrome.storage расширения: settings + runtime.
"""
from __future__ import annotations

import asyncio
import copy
import inspect
import json
import os
import time
from pathlib import Path
from typing import Any, Optional

DATA_DIR = Path(__file__).parent / "data"

_locks: dict[int, asyncio.Lock] = {}


def _lock(user_id: int) -> asyncio.Lock:
    if user_id not in _locks:
        _locks[user_id] = asyncio.Lock()
    return _locks[user_id]


def _path(user_id: int) -> Path:
    return DATA_DIR / f"{user_id}.json"


DEFAULT_SETTINGS: dict = {
    "templates": [
        {"id": "hello", "title": "Приветствие",
         "text": "Здравствуйте! Спасибо за обращение. Чем могу помочь?"},
        {"id": "thanks", "title": "Спасибо",
         "text": "Спасибо за покупку! Если появятся вопросы — напишите, обязательно помогу."},
    ],
    "automation": {
        "enabled": False,
        "accepted": False,
        "poll_seconds": 15,
        "delay_seconds": 3,
        "hourly_limit": 15,
        "notifications": True,
        "notification_preview": True,
        "auto_read": False,
        "keyword_enabled": False,
        "rules": [],
    },
    "bump": {"enabled": False, "accepted": False},
    "relist": {
        "enabled": False,
        "accepted": False,
        "paid_enabled": False,
        "max_price_per_item": 100,
        "min_balance": 0,
        "delay_minutes": 5,
    },
    "return_message": {
        "enabled": False,
        "accepted": False,
        "text": ("Здравствуйте, {{username}}! Увидели возврат по сделке с «{{item}}». "
                 "Если что-то пошло не так — напишите, обязательно разберёмся и решим вопрос."),
    },
}


def _default_runtime() -> dict:
    return {
        "processed_message_ids": [],
        "sent_timestamps": [],
        "automation_log": [],
        "baseline_done": False,
        "relist_state": {},
        "bump_state": {},
        "last_relist_at": 0,
        "last_bump_at": 0,
        "rollback_baseline_done": False,
        "processed_rollback_ids": [],
        # планировщик (epoch ms)
        "next_automation_at": 0,
        "next_bump_at": 0,
        "next_relist_at": 0,
        "next_rollback_at": 0,
    }


def _new_record(user_id: int, username: str = "") -> dict:
    return {
        "user_id": user_id,
        "username": username,
        "cookies": None,
        "settings": copy.deepcopy(DEFAULT_SETTINGS),
        "runtime": _default_runtime(),
    }


def _deep_merge(base: dict, incoming: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (incoming or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def _load_raw(user_id: int) -> dict:
    p = _path(user_id)
    if p.exists():
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return _new_record(user_id)
    return _new_record(user_id)


def _save_raw(user_id: int, record: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    tmp = _path(user_id).with_suffix(".tmp")
    tmp.write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, _path(user_id))


async def load(user_id: int) -> dict:
    async with _lock(user_id):
        return await asyncio.to_thread(_load_raw, user_id)


async def save(user_id: int, record: dict) -> None:
    async with _lock(user_id):
        await asyncio.to_thread(_save_raw, user_id, record)


async def update(user_id: int, mutate) -> dict:
    """Атомарно: читает запись, применяет mutate(record), сохраняет, возвращает запись.

    mutate может быть как синхронным, так и асинхронным (async def).
    """
    async with _lock(user_id):
        rec = await asyncio.to_thread(_load_raw, user_id)
        result = mutate(rec)
        if inspect.isawaitable(result):
            await result
        await asyncio.to_thread(_save_raw, user_id, rec)
        return rec


async def get_settings(user_id: int) -> dict:
    rec = await load(user_id)
    return rec["settings"]


async def get_runtime(user_id: int) -> dict:
    rec = await load(user_id)
    return rec["runtime"]


async def set_settings(user_id: int, settings: dict) -> None:
    await update(user_id, lambda rec: rec.update(settings=settings))


async def set_cookies(user_id: int, cookie_header: Optional[str]) -> None:
    await update(user_id, lambda rec: rec.update(cookies=cookie_header))


async def get_cookies(user_id: int) -> Optional[str]:
    rec = await load(user_id)
    return rec.get("cookies")


async def log_automation(user_id: int, message: str, kind: str = "info") -> None:
    def mutate(rec):
        rec["runtime"].setdefault("automation_log", []).append(
            {"at": int(__import__("time").time() * 1000), "message": message, "kind": kind}
        )
        # оставляем последние 300 записей
        rec["runtime"]["automation_log"] = rec["runtime"]["automation_log"][-300:]
    await update(user_id, mutate)


async def all_user_ids() -> list[int]:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    ids = []
    for p in DATA_DIR.glob("*.json"):
        try:
            ids.append(int(p.stem))
        except ValueError:
            continue
    return ids


# ================== админка: владелец, доступы, оплата ==================

ADMIN_FILE = DATA_DIR / "admin.json"
_admin_lock = asyncio.Lock()

# Цены по умолчанию.
DEFAULT_PRICES = {
    "stars": 100,          # цена в звёздах
    "card_rub": 100,       # цена в рублях на карту
    "card_number": "",     # номер карты (заполняет владелец)
}


def _default_admin() -> dict:
    import config
    return {
        "owner_id": config.OWNER_ID,
        "known": {},   # user_id -> username (кто когда-либо писал боту)
        "users": {
            str(config.OWNER_ID): {
                "status": "owner",
                "added_at": int(time.time()),
                "until": None,
                "granted_by": None,
            }
        },
        "prices": dict(DEFAULT_PRICES),
        "payments": [],
    }


def _load_admin_raw() -> dict:
    import config
    ADMIN_FILE.parent.mkdir(parents=True, exist_ok=True)
    if ADMIN_FILE.exists():
        try:
            data = json.loads(ADMIN_FILE.read_text(encoding="utf-8"))
        except Exception:
            data = _default_admin()
    else:
        data = _default_admin()
    # гарантируем присутствие владельца и свежих цен
    data.setdefault("owner_id", config.OWNER_ID)
    data.setdefault("known", {})
    data.setdefault("users", {})
    data.setdefault("payments", [])
    data.setdefault("prices", dict(DEFAULT_PRICES))
    data["users"].setdefault(str(config.OWNER_ID), {
        "status": "owner", "added_at": int(time.time()), "until": None, "granted_by": None,
    })
    data["users"][str(config.OWNER_ID)]["status"] = "owner"
    for k, v in DEFAULT_PRICES.items():
        data["prices"].setdefault(k, v)
    return data


def _save_admin_raw(data: dict) -> None:
    ADMIN_FILE.parent.mkdir(parents=True, exist_ok=True)
    tmp = ADMIN_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(tmp, ADMIN_FILE)


async def load_admin() -> dict:
    async with _admin_lock:
        return await asyncio.to_thread(_load_admin_raw)


async def update_admin(mutate) -> dict:
    async with _admin_lock:
        data = await asyncio.to_thread(_load_admin_raw)
        result = mutate(data)
        if inspect.isawaitable(result):
            await result
        await asyncio.to_thread(_save_admin_raw, data)
        return data


async def is_owner(user_id: int) -> bool:
    data = await load_admin()
    return int(data.get("owner_id", 0)) == int(user_id)


async def is_allowed(user_id: int) -> bool:
    data = await load_admin()
    if int(data.get("owner_id", 0)) == int(user_id):
        return True
    u = data["users"].get(str(user_id))
    if not u or u.get("status") != "active":
        return False
    until = u.get("until")
    if until and int(until) < int(time.time()):
        return False
    return True


async def register_user(user_id: int, username: str = "") -> None:
    def mutate(data):
        data["known"][str(user_id)] = username or data["known"].get(str(user_id), "")
        data["users"].setdefault(str(user_id), {"status": "none", "added_at": int(time.time()), "until": None, "granted_by": None})
    await update_admin(mutate)


async def resolve_user(ref: str) -> tuple[int | None, str | None]:
    """Возвращает (user_id, username) по '@username' или числовому ID, либо (None, ошибка)."""
    ref = (ref or "").strip()
    data = await load_admin()
    if ref.startswith("@"):
        uname = ref[1:].lower()
        for uid, name in data["known"].items():
            if (name or "").lower() == uname:
                return int(uid), name
        return None, f"Пользователь @{uname} ещё не писал боту (не найден)."
    if ref.lstrip("-").isdigit():
        uid = int(ref)
        return uid, data["known"].get(str(uid), "")
    return None, "Укажите @username или числовой ID."


async def grant_access(user_id: int, until: int | None, granted_by: int) -> dict:
    def mutate(data):
        data["users"][str(user_id)] = {
            "status": "active",
            "added_at": int(time.time()),
            "until": until,
            "granted_by": granted_by,
        }
        return data["users"][str(user_id)]
    return await update_admin(mutate)


async def revoke_access(user_id: int) -> None:
    def mutate(data):
        if str(user_id) in data["users"]:
            data["users"][str(user_id)]["status"] = "revoked"
    await update_admin(mutate)


async def set_prices(stars: int = None, card_rub: int = None, card_number: str = None) -> dict:
    def mutate(data):
        if stars is not None:
            data["prices"]["stars"] = int(stars)
        if card_rub is not None:
            data["prices"]["card_rub"] = int(card_rub)
        if card_number is not None:
            data["prices"]["card_number"] = card_number
        return data["prices"]
    return await update_admin(mutate)


async def log_payment(user_id: int, kind: str, amount, status: str) -> None:
    def mutate(data):
        data["payments"].append({
            "user_id": int(user_id),
            "kind": kind,
            "amount": amount,
            "status": status,
            "ts": int(time.time()),
        })
        data["payments"] = data["payments"][-200:]
    await update_admin(mutate)
